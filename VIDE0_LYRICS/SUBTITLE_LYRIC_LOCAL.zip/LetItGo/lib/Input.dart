const String APP_ID = "ca-app-pub-6420987903580707~1696659971";

const String BANNER_ID = "ca-app-pub-6420987903580707/1260711555";
const String INTERSTITIAL_ID = "ca-app-pub-6420987903580707/9383578300";

const String TITLE = 'Let It Go - Video Subtitle';
const String VIDEO_URL = 'images/LetItGo.mp4';
const String LYRIC = "\nThe snow blows white on the mountain tonight \n" +
    "Not a footprint to be seen \n" +
    "A kingdom of isolation, and it looks like I'm the queen \n" +
    "The wind is howling like the swirling storm inside \n" +
    "Couldn't keep it in \n" +
    "Heaven knows I tried \n" +
    "\n" +
    "Don't let them in, don't let them see \n" +
    "Be the good girl, you always have to be \n" +
    "Conceal, don't feel, don't let them know \n" +
    "Well, now they know \n" +
    "\n" +
    "Let it go, let it go \n" +
    "Can't hold it back anymore \n" +
    "Let it go, let it go \n" +
    "Turn my back and slam the door \n" +
    "\n" +
    "And here I stand \n" +
    "And here I'll stay \n" +
    "Let it go, let it go \n" +
    "The cold never bothered me anyway \n" +
    "\n" +
    "It's funny how some distance makes everything seem small \n" +
    "And the fears that once controlled me, can't get to me at all \n" +
    "Up here in the cold, thin air I finally can breathe \n" +
    "I know I left a life behind, but I'm too relieved to grieve \n" +
    "\n" +
    "Let it go, let it go \n" +
    "Can't hold it back anymore \n" +
    "Let it go, let it go \n" +
    "Turn my back, and slam the door \n" +
    "\n" +
    "And here I stand \n" +
    "And here I'll stay \n" +
    "Let it go, let it go \n" +
    "The cold never bothered me anyway \n" +
    "\n" +
    "Standing frozen in the life I've chosen \n" +
    "You won't find me, the past is so behind me \n" +
    "Buried in the snow \n" +
    "\n" +
    "Let it go, let it go \n" +
    "Can't hold it back anymore \n" +
    "Let it go, let it go \n" +
    "Turn my back and slam the door \n" +
    "\n" +
    "And here I stand \n" +
    "And here I'll stay \n" +
    "Let it go, let it go \n" +
    "The cold never bothered me anyway \n" +
    "\n";

const String APP_ID = "ca-app-pub-6420987903580707~4671977916";
const String BANNER_ID = "ca-app-pub-6420987903580707/2425567455";
const String INTERSTITIAL_ID = "ca-app-pub-6420987903580707/8657408664";

const String TITLE = 'Delicate - Taylor Swift';
const String VIDEO_URL = '';

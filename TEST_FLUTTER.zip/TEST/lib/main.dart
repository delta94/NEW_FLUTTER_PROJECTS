import 'package:flutter/material.dart';
import 'package:flutter_gifimage/flutter_gifimage.dart';

void main() => runApp(MyApp());

class MyApp extends StatefulWidget {
  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> with TickerProviderStateMixin {
  @override
  Widget build(BuildContext context) {
    GifController controller= GifController(vsync: this);
    WidgetsBinding.instance.addPostFrameCallback((_){
      controller.repeat(min: 0,max: 53,period: Duration(seconds: 4));
    });

    ///or you can use other action as a AnimationController
    return MaterialApp(
      title: 'Welcome to Flutter',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Welcome to Flutter'),
        ),
        body: Center(
          child: Column(
            children: <Widget>[
              GifImage(
                controller: controller,
                image: AssetImage("images/dancing_girl.gif"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

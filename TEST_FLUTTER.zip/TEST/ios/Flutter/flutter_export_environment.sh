#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=C:\WORK\Softwares\flutter_sdk"
export "FLUTTER_APPLICATION_PATH=C:\WORK\STUDY\NEW_FLUTTER_PROJECTS\TEST"
export "FLUTTER_TARGET=lib\main.dart"
export "FLUTTER_BUILD_DIR=build"
export "SYMROOT=${SOURCE_ROOT}/../build\ios"
export "OTHER_LDFLAGS=$(inherited) -framework Flutter"
export "FLUTTER_FRAMEWORK_DIR=C:\WORK\Softwares\flutter_sdk\bin\cache\artifacts\engine\ios"
export "FLUTTER_BUILD_NAME=1.1.4"
export "FLUTTER_BUILD_NUMBER=1.1.4"

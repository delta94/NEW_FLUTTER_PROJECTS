package io.flutter.plugins;

import io.flutter.plugin.common.PluginRegistry;
import theindianappguy.zeeshux7860.image_color_picker.ImageColorPickerPlugin;
import io.flutter.plugins.pathprovider.PathProviderPlugin;
import com.prateektimer.wallpaper.WallpaperPlugin;
import io.flutter.plugins.webviewflutter.WebViewFlutterPlugin;

/**
 * Generated file. Do not edit.
 */
public final class GeneratedPluginRegistrant {
  public static void registerWith(PluginRegistry registry) {
    if (alreadyRegisteredWith(registry)) {
      return;
    }
    ImageColorPickerPlugin.registerWith(registry.registrarFor("theindianappguy.zeeshux7860.image_color_picker.ImageColorPickerPlugin"));
    PathProviderPlugin.registerWith(registry.registrarFor("io.flutter.plugins.pathprovider.PathProviderPlugin"));
    WallpaperPlugin.registerWith(registry.registrarFor("com.prateektimer.wallpaper.WallpaperPlugin"));
    WebViewFlutterPlugin.registerWith(registry.registrarFor("io.flutter.plugins.webviewflutter.WebViewFlutterPlugin"));
  }

  private static boolean alreadyRegisteredWith(PluginRegistry registry) {
    final String key = GeneratedPluginRegistrant.class.getCanonicalName();
    if (registry.hasPlugin(key)) {
      return true;
    }
    registry.registrarFor(key);
    return false;
  }
}

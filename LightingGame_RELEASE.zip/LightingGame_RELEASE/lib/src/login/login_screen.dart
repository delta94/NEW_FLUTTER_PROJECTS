import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:data_connection_checker/data_connection_checker.dart';
import 'package:flutter/material.dart';
import 'package:flutter_appauth/flutter_appauth.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:provider/provider.dart';

class LoginScreen extends StatefulWidget {
  LoginScreen();

  @override
  LoginScreenState createState() => LoginScreenState();
}

class LoginScreenState extends State<LoginScreen> {
  LoginScreenState();
  bool isBusy = false;
  final FlutterAppAuth appAuth = FlutterAppAuth();
  Widget build(context) {
    final theme = Theme.of(context);
    return Stack(children: <Widget>[
      background(),
      SafeArea(
        child: Scaffold(
          backgroundColor: Colors.transparent,
          body: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: <Widget>[
              Container(
                margin: EdgeInsets.only(top: 24),
              ),
              heading(),
              Container(
                  margin: EdgeInsets.only(
                      top: (MediaQuery.of(context).size.height / 4) - 40)),
              Visibility(
                visible: isBusy,
                child: CircularProgressIndicator(
                  value: null,
                  backgroundColor: theme.buttonColor,
                ),
              ),
              Visibility(
                visible: !isBusy,
                child: signInButton(theme, context),
              ),
            ],
          ),
        ),
      )
    ]);
  }

  Widget background() {
    return Image.asset(
      'assets/ft_bg_image.jpg',
      height: MediaQuery.of(context).size.height,
      width: MediaQuery.of(context).size.width,
      fit: BoxFit.cover,
    );
  }

  Widget heading() {
    return Text(
      'Fishtalk Control',
      style: TextStyle(
          fontSize: 30.0, fontWeight: FontWeight.bold, color: Colors.black),
    );
  }

  Widget signInButton(theme, context) {
    final signinHandler = () async {
      final appText = S.of(context);
      final appModel = Provider.of<AppModel>(context, listen: false);
      if (appModel.connectionStatus == DataConnectionStatus.disconnected) {
        UiUtils.showToast(
            message: appText.no_connection_msg, appModel: appModel);
      } else {
        setBusyState(true);
        try {
          await appModel.authenticate();
        } catch (e) {
          print(e.toString());
        }
        setBusyState(false);
      }
    };

    return SizedBox(
      width: double.infinity,
      child: Padding(
        padding: const EdgeInsets.only(left: 32.0, right: 32.0),
        child: RaisedButton(
          elevation: 8.0,
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Text(
              'Sign in',
              style: TextStyle(fontSize: 20.0),
            ),
          ),
          color: theme.buttonColor,
          onPressed: signinHandler,
          shape: new RoundedRectangleBorder(
            borderRadius: new BorderRadius.circular(20.0),
          ),
        ),
      ),
    );
  }

  void setBusyState(bool val) {
    setState(() {
      isBusy = val;
    });
  }
}

import 'package:Commons/icons.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/widgets/offline_status.dart';
import 'package:control_app/src/widgets/synchronize_progress_status.dart';
import 'package:flutter/material.dart';
import 'dart:core';
import 'package:Commons/colors.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:provider/provider.dart';

import '../../shared_data_model.dart';

class SearchLocationScreenHeader extends StatelessWidget {
  static const double FONT_SIZE = 20;
  static const double CLOSE_ICON_SIZE = 32;

  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context, listen: false);
    final appText = S.of(context);
    var safePadding = MediaQuery.of(context).padding.top;

    return Container(
      color: appModel.isDarkTheme ? akvaDarkColorD : akvaDarkColorE,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.only(top: safePadding),
          ),
          SynchronizeProgressStatus(),
          OfflineStatus(),
          Row(
            mainAxisSize: MainAxisSize.max,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.only(left: 20, right: 60, bottom: 14, top: 51),
                child: Text(
                  appText.search_location,
                  style: TextStyle(
                    fontSize: FONT_SIZE,
                    color:
                        appModel.isDarkTheme ? akvaDarkTextA : akvaLightColorB,
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(top: 24, right: 20, bottom: 51),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    child: Icon(
                      AkvaIcons.close,
                      size: CLOSE_ICON_SIZE,
                      color: appModel.isDarkTheme
                          ? akvaDarkTextA
                          : akvaLightColorB,
                    ),
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                ),
              ),
            ],
          ),
          Divider(
            thickness: 1,
            height: 0,
            color: akvaMainNeutral,
          ),
        ],
      ),
    );
  }
}

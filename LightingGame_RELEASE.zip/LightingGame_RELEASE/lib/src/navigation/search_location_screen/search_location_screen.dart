import 'dart:core';
import 'package:Commons/colors.dart';
import 'package:control_app/src/app_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'search_location_company.dart';
import 'search_location_screen_header.dart';

//TODO: these data structure will be changed and move to another location later, now it is used for GUI only
class SiteModel {
  final String siteID;
  final String siteName;

  SiteModel(this.siteID, this.siteName);
}

class CompanyModel {
  final String companyId;
  final String companyName;
  final List<SiteModel> sites;

  CompanyModel(
      {@required this.companyId,
      @required this.companyName,
      @required this.sites});
}

class SearchLocationScreen extends StatelessWidget {
  const SearchLocationScreen({Key key, this.companies}) : super(key: key);

  final List<CompanyModel> companies;

  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context, listen: false);
    return Scaffold(
      backgroundColor: appModel.isDarkTheme ? akvaDarkColorF : akvaLightColorF,
      body: Container(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[            
            SearchLocationScreenHeader(),
            Expanded(
              child: Container(
                child: MediaQuery.removePadding(
                  context: context,
                  removeTop: true,
                  child: ListView.builder(
                    itemCount: companies.length,
                    itemBuilder: (context, index) {
                      return SearchLocationCompany(
                        companyName: companies[index].companyName,
                        sites: companies[index].sites,
                      );
                    },
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }
}

import 'dart:core';
import 'package:Commons/colors.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/src/navigation/search_location_screen/search_location_screen.dart';
import 'package:control_app/src/app_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'search_location_site.dart';

class SearchLocationCompany extends StatefulWidget {
  const SearchLocationCompany({Key key, this.companyName, this.sites})
      : super(key: key);

  final String companyName;
  final List<SiteModel> sites;

  @override
  _SearchLocationCompanyState createState() {
    return _SearchLocationCompanyState();
  }
}

class _SearchLocationCompanyState extends State<SearchLocationCompany> {
  static const double HEIGHT = 48;
  static const double FONT_SIZE = 18;

  bool _isExpanded = true;

  @override
  void initState() {
    super.initState();
    _isExpanded = true;
  }

  void companyTapped() {
    setState(() {
      _isExpanded = !_isExpanded;
    });
  }

  List<Widget> createSites(List<SiteModel> sites) {
    List<Widget> widgets = new List<Widget>();
    sites.forEach((site) {
      widgets.add(
        Padding(
          padding: const EdgeInsets.only(bottom: 0.5),
          child: SearchLocationSite(
            site: site,
          ),
        ),
      );
    });
    return widgets;
  }

  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context, listen: false);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Container(
          color: appModel.isDarkTheme ? akvaDarkColorF : akvaLightColorA,
          height: HEIGHT,
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              child: Row(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  Expanded(
                    child: Padding(
                      padding: EdgeInsets.only(left: 20, top: 7, bottom: 5),
                      child: Text(
                        widget.companyName,
                        style: TextStyle(
                          color: appModel.isDarkTheme
                              ? akvaDarkTextA
                              : akvaDarkColorD,
                          fontSize: FONT_SIZE,
                          fontWeight: FontWeight.w500
                        ),
                      ),
                    ),
                  ),
                  Padding(
                    padding: EdgeInsets.only(right: 26),
                    child: Icon(
                      _isExpanded
                          ? AkvaIcons.keyboard_arrow_up
                          : AkvaIcons.keyboard_arrow_down,
                      size: 12,
                      color: appModel.isDarkTheme
                          ? akvaMainNeutral
                          : akvaDarkColorD,
                    ),
                  ),
                ],
              ),
              onTap: companyTapped,
            ),
          ),
        ),
        Divider(
          thickness: 0,
          height: 0.5,
        ),
        _isExpanded
            ? Container(
                child: Column(
                  children: createSites(widget.sites),
                ),
              )
            : Container()
      ],
    );
  }
}

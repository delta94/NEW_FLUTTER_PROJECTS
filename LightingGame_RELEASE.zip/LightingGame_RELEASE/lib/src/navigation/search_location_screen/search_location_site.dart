import 'dart:core';

import 'package:Commons/colors.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/src/navigation/search_location_screen/search_location_screen.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../routers.dart';

class SearchLocationSite extends StatelessWidget {
  const SearchLocationSite({Key key, this.site}) : super(key: key);

  static const double HEIGHT = 44;
  static const double FONT_SIZE = 16;

  final SiteModel site;

  void onSiteTapped(BuildContext context) {
    final organizationModel = Provider.of<OrganizationModel>(context, listen: false);
    organizationModel.setCurrentOrganizationEntityById(site.siteID);

   organizationModel.visit(site.siteID);
    
    Navigator.pushNamed(context, Routers.main);
  }

  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context, listen: false);
    final theme = Theme.of(context);
    return Container(
      height: HEIGHT,
      child: Material(
        color: appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorB,
        child: InkWell(
          child: Row(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              Expanded(
                child: Padding(
                  padding: EdgeInsets.only(left: 23),
                  child: Text(
                    site.siteName,
                    style: TextStyle(
                      color: theme.primaryTextTheme.title.color,
                      fontSize: FONT_SIZE,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(right: 15),
                child: Icon(
                  AkvaIcons.right_arrow,
                  size: 25,
                  color: appModel.isDarkTheme ? akvaMainNeutral : akvaDarkColorD,
                ),
              ),
            ],
          ),
          onTap: () => onSiteTapped(context),
        ),
      ),
    );
  }
}

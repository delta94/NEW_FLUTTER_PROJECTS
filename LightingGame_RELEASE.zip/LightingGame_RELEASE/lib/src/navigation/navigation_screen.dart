import 'package:Commons/colors.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/navigation/search_location_screen/search_location_screen.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/util/scan_qr.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:control_app/src/widgets/app_drawer.dart';
import 'package:control_app/src/widgets/frequently_visited.dart';
import 'package:control_app/src/widgets/navigation_app_bar.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';

import '../shared_data_model.dart';

class NavigationScreen extends StatefulWidget {
  @override
  _NavigationScreenState createState() => _NavigationScreenState();
}

class _NavigationScreenState extends State<NavigationScreen> {
  DragStartDetails _dragStartDetails;
  double height = 0;

  @override
  void initState() {
    final orgModel = Provider.of<OrganizationModel>(context, listen: false);
    final sharedDataModel =
        Provider.of<SharedDataModel>(context, listen: false);

    sharedDataModel.initData(orgModel);

    super.initState();
  }

  _onSearchTap(BuildContext context, AppModel appModel) {
    final state = Provider.of<OrganizationModel>(context, listen: false);

    List<Site> sites = state.getSitesWithAppMode(appModel.appMode);

    Map<String, CompanyModel> companyDict = Map<String, CompanyModel>();

    List<CompanyModel> model = [];
    if (sites != null) {
      for (Site item in sites) {
        if (!item.isHidden && item.parent != null) {
          if (!companyDict.containsKey(item.parent.id)) {
            var company = CompanyModel(
                companyId: item.parent.id,
                companyName: item.parent.name,
                sites: []);
            companyDict[item.parent.id] = company;
            model.add(company);
          }

          companyDict[item.parent.id].sites.add(SiteModel(item.id, item.name));
        }
      }
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => SearchLocationScreen(
          companies: model,
        ),
      ),
    );
  }

  void onVerticalDragStart(DragStartDetails arg) {
    _dragStartDetails = arg;
  }

  void onVerticalDragUpdate(DragUpdateDetails arg) {
    var deltaY = arg.globalPosition.dy - _dragStartDetails.globalPosition.dy;

    if (deltaY > 0) {
      setState(() {
        if(deltaY > 500) {
          height = 500;
        }
        else
        height = deltaY;
      });
    } else {
      setState(() {
        height = 0;
      });
    }
  }

  // TODO: This refresh should possibly be in the main screen?
  void onVerticalDragEnd(DragEndDetails arg) {
    if (height > 0) {
      final orgModel = Provider.of<OrganizationModel>(context, listen: false);
      final sharedDataModel =
          Provider.of<SharedDataModel>(context, listen: false);
      sharedDataModel.resetData();
      orgModel.resetSiteData();

      sharedDataModel.initData(orgModel);

      setState(() {
        height = 0;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context, listen: false);
    final sharedDataModel =
        Provider.of<SharedDataModel>(context, listen: false);
    final orgModel = Provider.of<OrganizationModel>(context);
    final s = S.of(context);

    return Stack(children: <Widget>[
      Scaffold(
        backgroundColor:
            appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorA,
        body: Container(
          child: Column(
            children: [
              NavigationAppBar(),
              Divider(
                color: appModel.isDarkTheme ? akvaDarkColorD : akvaLightColorD,
                thickness: 1,
                height: 0,
              ),
              GestureDetector(
                onVerticalDragStart: onVerticalDragStart,
                onVerticalDragUpdate: onVerticalDragUpdate,
                onVerticalDragEnd: onVerticalDragEnd,
                behavior: HitTestBehavior.opaque,
                child: Column(
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.fromLTRB(20, 32, 20, 33),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: <Widget>[
                          AnimatedContainer(
                            height: height,
                            duration: Duration(milliseconds: 400),
                          ),
                          Text(_getCurrentDateFormatted()),
                          Padding(
                            padding: EdgeInsets.only(top: 23),
                          ),
                          Visibility(
                            visible: appModel.appMode == AppMode.Landbased,
                            child: Padding(
                              padding: const EdgeInsets.only(bottom: 16),
                              child: BigNavigationButton(
                                onPressed: () {
                                  navigateByQR(context);
                                },
                                label: s.scan_barcode,
                                icon: AkvaIcons.barcode,
                              ),
                            ),
                          ),
                          BigNavigationButton(
                            onPressed: () {
                              _onSearchTap(context, appModel);
                            },
                            label: s.search_location,
                            icon: AkvaIcons.location,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              Divider(
                color: appModel.isDarkTheme ? akvaDarkColorB : akvaDarkTextA,
                height: 0,
                thickness: 1.5,
              ),
              FrequentlyVisited(
                  onVerticalDragStart, onVerticalDragUpdate, onVerticalDragEnd),
            ],
          ),
        ),
        drawer: AppDrawer(),
      ),
      ...buildBusyIndicator(context, orgModel, sharedDataModel),
    ]);
  }

  buildBusyIndicator(BuildContext context, OrganizationModel orgModel,
      SharedDataModel sharedDataModel) {
    final widgets = List<Widget>();
    if (orgModel.siteList.length == 0 ||
        sharedDataModel.causesOfDeath == null ||
        sharedDataModel.species == null) {
      widgets.add(UiUtils.loadingIndicator());
    }

    return widgets;
  }

  String _getCurrentDateFormatted() {
    initializeDateFormatting();
    final today = DateTime.now();
    final dateFormat = new DateFormat('EEEE, MMM d, y');
    return dateFormat.format(today);
  }
}

class BigNavigationButton extends StatelessWidget {
  final GestureTapCallback onPressed;
  final String label;
  final IconData icon;

  BigNavigationButton(
      {@required this.onPressed, @required this.label, @required this.icon});

  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context, listen: false);
    return ButtonTheme(
      height: 80,
      child: FlatButton(
        color: appModel.isDarkTheme ? akvaDarkColorD : akvaDarkColorE,
        onPressed: this.onPressed,
        shape: RoundedRectangleBorder(
          side: BorderSide(color: akvaMainNeutral, width: 2),
          borderRadius: BorderRadius.circular(2),
        ),
        child: Container(
          width: 310,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Container(
                child: Wrap(
                  crossAxisAlignment: WrapCrossAlignment.center,
                  spacing: 16,
                  children: <Widget>[
                    Icon(
                      this.icon,
                      size: 32,
                      color: appModel.isDarkTheme
                          ? akvaMainNeutral
                          : akvaLightColorB,
                    ),
                    Text(
                      this.label,
                      style: TextStyle(
                          fontSize: 20,
                          fontFamily: "Roboto",
                          color: appModel.isDarkTheme
                              ? akvaDarkTextA
                              : akvaLightColorB),
                    )
                  ],
                ),
              ),
              Icon(
                AkvaIcons.right_arrow,
                color: appModel.isDarkTheme ? akvaMainNeutral : akvaLightColorB,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class Routers {
  static const main = '/main';
  static const mortality = '/mortality';
  static const feeding = '/feeding';
  static const culling = '/culling';
  static const lice = '/lice';
  static const environment = '/environment';
}

import 'package:Commons/buttons.dart';
import 'package:Commons/colors.dart';
import 'package:Commons/dropdown.dart';
import 'package:control_app/src/util/utils.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_model.dart';

class YesterdayChoices extends StatelessWidget {
  final List<OptionItem> allOptions;
  final List<OptionItem> selectedOptionItems;
  final Function(OptionItem) selectedItemChangedCallback;

  YesterdayChoices({
    this.allOptions,
    this.selectedItemChangedCallback,
    this.selectedOptionItems,
  });

  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context, listen: false);

    return allOptions.isEmpty
        ? Container(height: 120)
        : Container(
            padding: EdgeInsets.only(top: 105, bottom: 19, right: 19, left: 8),
            color: appModel.isDarkTheme ? akvaDarkColorC : akvaLightColorA,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Container(
                  height: 34,
                  child: new ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: allOptions.length,
                    itemBuilder: (BuildContext ctxt, int index) {
                      return Container(
                        margin: EdgeInsets.only(left: 12),
                        child: AkvaClickableLabel(
                          label: allOptions[index].label,
                          active: isSelectedOption(
                              allOptions[index], selectedOptionItems),
                          onPressed: () => selectedItemChangedCallback(
                            allOptions[index],
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          );
  }
}

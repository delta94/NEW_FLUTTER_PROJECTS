import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class RegistrationCheckBox extends StatelessWidget {
  final Function onCheckBoxChanged;
  final bool checked;
  final bool isDarkTheme;
  final bool visible;
  RegistrationCheckBox(
      {this.onCheckBoxChanged,
      this.checked = false,
      this.isDarkTheme = false,
      this.visible = false});

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: visible,
      child: Padding(
        padding: EdgeInsets.only(top: 2, bottom: 2),
        child: Wrap(
          children: <Widget>[
            Container(
              // checkbox
              height: FontSize.large,
              width: FontSize.large,
              decoration: BoxDecoration(
                color: isDarkTheme ? akvaDarkColorA : akvaLightColorB,
                border: Border.all(
                    color: checked
                        ? akvaMainNeutral
                        : isDarkTheme ? akvaDarkColorE : akvaLightColorE),
              ),

              child: FlatButton(
                padding: EdgeInsets.all(0),
                onPressed: () => onCheckBoxChanged(!checked),
                child: checked
                    ? Icon(
                        AkvaIcons.checked_thick,
                        color: akvaMainAction,
                        size: FontSize.xsmall,
                      )
                    : Container(),
              ),
            ),
            SizedBox(width: 15),
          ],
        ),
      ),
    );
  }
}

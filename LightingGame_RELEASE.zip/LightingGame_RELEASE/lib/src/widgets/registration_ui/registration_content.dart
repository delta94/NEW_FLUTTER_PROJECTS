import 'package:Commons/colors.dart';
import 'package:Commons/dropdown.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/environment/view_models/environment_view_model.dart';
import 'package:control_app/src/feeding/view_models/cleaner_fish_feeding_registration_view_model.dart';
import 'package:control_app/src/feeding/view_models/salmon_feeding_registration_view_model.dart';
import 'package:control_app/src/models/environment/sensor_reading.dart';
import 'package:control_app/src/models/environment/sensor_type.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/widgets/confirmation_dialog/confirmation_modal.dart';
import 'package:control_app/src/widgets/number_input.dart';
import 'package:control_app/src/widgets/registration_amount_count_list.dart';
import 'package:control_app/src/widgets/registration_item.dart';
import 'package:control_app/src/widgets/registration_title.dart';
import 'package:control_app/src/widgets/total_amount_count.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import 'registration_amount_count_item.dart';

class RegistrationContent extends StatefulWidget {
  final Key key;
  final RegistrationViewModel model;
  final bool showBottomTotal;
  final bool isNoTab;
  final RegistrationType registrationType;

  RegistrationContent({
    this.key,
    this.model,
    this.showBottomTotal: true,
    this.isNoTab: false,
    @required this.registrationType,
  }) : super(key: key);

  @override
  _RegistrationContentState createState() => _RegistrationContentState();
}

class _RegistrationContentState extends State<RegistrationContent> {
  bool get isFeeding =>
      widget.model is SalmonFeedingRegistrationViewModel ||
      widget.model is CleanerFishFeedingRegistrationViewModel;

  @override
  Widget build(BuildContext context) {
    final S appText = S.of(context);
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);
    OrganizationModel organizationModel =
        Provider.of<OrganizationModel>(context);

    RegistrationUserRight registrationUserRight =
        organizationModel.registrationUserRightMap[widget.registrationType];

    List<Widget> _buildAmountCountList(DateTime dateTime,
        List<Registration<RegistrationBaseItem>> registrations) {
      List<Widget> widgetList = new List<Widget>();
      registrations.forEach((registration) {
        for (int i = 0; i < registration.item.length; i++) {
          widgetList.add(
            Padding(
              padding: EdgeInsets.only(left: 13),
              child: RegistrationAmountCountItem(
                allowDelete: registrationUserRight.allowDelete,
                numberInputType:
                    isFeeding ? NumberInputType.DECIMAL : NumberInputType.INT,
                key: ObjectKey(registration.item.countObjAt(i)),
                registrationType: widget.model.registrationType,
                enable: !widget.model.busy &&
                    widget.model.isEditingCountMode &&
                    registration.item.enable &&
                    registrationUserRight.allowWrite,
                countNum: registration.item.countAt(i),
                title: registration.item.countTitle(context, i),
                speciesId: registration.speciesId,
                onDelete: () {
                  if (widget.model.registrationType != RegistrationType.Lice)
                    showConfirmationModal(
                      context: context,
                      title: appText.delete_registration,
                      messages: [
                        appText.are_you_sure_you_want_to_delete_registration,
                      ],
                      leftButtonTitle: appText.cancel,
                      rightButtonTitle: appText.delete,
                      onTapRightButton: () => widget.model.removeCount(
                        dateTime,
                        registration.speciesId,
                        registration.item.countObjAt(i),
                      ),
                    );
                },
                onChangeCount: (newCount) {
                  if (widget.model.isEditingCountMode) {
                    widget.model.updateAmountCountNumber(
                      registration.time,
                      registration.speciesId,
                      registration.item.countObjAt(i),
                      newCount,
                    );
                  }
                },
              ),
            ),
          );
        }
      });

      return widgetList;
    }

    String _getViewSensorName(SensorReading sensorReading) {
      String tempUnit = sensorReading.measurementUnit;
      String unit = tempUnit == '' ? '' : '[${tempUnit}]';
      return '${sensorReading.sensorTypeName} $unit';
    }

    List<Widget> _buildSensorList(
      DateTime dateTime,
      List<Registration> registrations,
    ) {
      List<Widget> widgetList = new List<Widget>();
      registrations.forEach((registration) {
        SensorReading sensorReading = registration.item as SensorReading;
        String sensorName = _getViewSensorName(sensorReading);
        OptionItem selectedItem;
        List<OptionItem> allOptions = [];
        if (sensorReading.sensorType.measUnit == 29) {
          allOptions = sensorReading.sensorType.valueMap.entries
              .map((e) => OptionItem(id: e.key, label: e.value))
              .toList();

          if (sensorReading.reading != null) {
            selectedItem = allOptions.firstWhere(
                (item) => item.id == sensorReading.reading.toInt(),
                orElse: () => null);
          }
        }

        widgetList.add(
          Padding(
            padding: EdgeInsets.only(left: 13),
            child: RegistrationAmountCountItem(
              numberInputType: NumberInputType.DECIMAL,
              key: ObjectKey(registration.item),
              registrationType: widget.model.registrationType,
              enable: widget.model.isEditingCountMode &&
                  sensorReading.enable &&
                  registrationUserRight.allowWrite,
              allowDelete: registrationUserRight.allowDelete,
              countNum: sensorReading.reading,
              title: sensorName,
              selectedOption:
                  sensorReading.sensorType.measUnit == MeasurementUnit.ValueMap
                      ? selectedItem
                      : null,
              allOptions: allOptions,
              speciesId: 1,
              onDelete: () {
                showConfirmationModal(
                  context: context,
                  title: appText.delete_registration,
                  messages: [
                    appText.are_you_sure_you_want_to_delete_registration,
                  ],
                  leftButtonTitle: appText.cancel,
                  rightButtonTitle: appText.delete,
                  onTapRightButton: () =>
                      widget.model.removeCount(null, null, registration),
                );
              },
              onChangeCount: (newCount) {
                if (sensorReading.sensorType.measUnit ==
                    MeasurementUnit.ValueMap) {
                  setState(() {
                    (widget.model as EnvironmentViewModel)
                        .updateSensorReading(registration, newCount);
                  });
                } else {
                  (widget.model as EnvironmentViewModel)
                      .updateSensorReading(registration, newCount);
                }
              },
            ),
          ),
        );
      });

      return widgetList;
    }

    List<Widget> _buildRegistrationList() {
      List<Widget> registrationWidgetList = new List<Widget>();
      Map<DateTime, List<Registration>> viewRegistrationMap =
          widget.model.viewRegistrationMap;

      bool isEnvironmentViewModel = widget.model is EnvironmentViewModel;
      viewRegistrationMap.forEach((dateTime, registrations) {
        registrationWidgetList.add(
          RegistrationItem(
            digitsOnly: widget.model is SalmonFeedingRegistrationViewModel ||
                    widget.model is CleanerFishFeedingRegistrationViewModel
                ? false
                : true,
            registrationViewModel: widget.model,
            amountCountList: isEnvironmentViewModel
                ? _buildSensorList(
                    dateTime,
                    registrations,
                  )
                : _buildAmountCountList(
                    dateTime,
                    registrations,
                  ),
            dateTime: dateTime,
            registrations: registrations,
            showTotal: !isEnvironmentViewModel,
            registrationUserRight: registrationUserRight,
          ),
        );
      });

      return registrationWidgetList;
    }

    return Column(
      children: <Widget>[
        SizedBox(
          height: 30,
        ),
        Container(
          color: appModel.isDarkTheme ? akvaDarkColorC : akvaLightColorA,
          child: Column(children: <Widget>[
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 13, vertical: 5),
              child: RegistrationTitle(
                isViewMode: !registrationUserRight.allowWrite &&
                    !registrationUserRight.allowDelete,
                isEditingCountMode: widget.model.isEditingCountMode,
                setEditingModeTrue: () =>
                    widget.model.setEditingCountMode(true),
                discardChanges: () => widget.model.discardChanges(),
              ),
            ),
            SizedBox(height: 10),
            RegistrationAmountCountList(
              isNoFishTypeTab: widget.isNoTab,
              amountCountList: _buildRegistrationList(),
            ),
            widget.showBottomTotal
                ? Container(
                    margin: EdgeInsets.only(top: 10),
                    padding: const EdgeInsets.only(right: 15),
                    child: TotalAmountCount(
                      isRightSide: true,
                      title: appText.total,
                      totalAmountCount: widget.showBottomTotal
                          ? widget.model.getTotalAmountCount()
                          : 0,
                    ),
                  )
                : Container(),
          ]),
        ),
      ],
    );
  }
}

import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:control_app/src/widgets/confirm_message.dart';
import 'package:control_app/src/widgets/no_registration_message.dart';
import 'package:flutter/material.dart';

class NoRegistrationContent extends StatelessWidget {
  final Widget confirmationWidget;
  final bool isOnlySalmon;
  final bool isForSalmon;
  final RegistrationStatus registrationStatus;

  NoRegistrationContent(
      {this.confirmationWidget,
      this.isOnlySalmon: false,
      this.isForSalmon,
      this.registrationStatus});

  @override
  Widget build(BuildContext context) {
    final S appText = S.of(context);

    return Container(
      child: registrationStatus == RegistrationStatus.NO_FISH
          ? Column(
              children: [
                ConfirmMessage(
                  confirmText: appText.no_fish,
                  confirmWidget: Container(),
                ),
              ],
            )
          : isForSalmon && confirmationWidget != null
              ? confirmationWidget
              : NoRegistrationMessage(
                  registrationStatus: registrationStatus,
                  isOnlySalmon: isOnlySalmon,
                ),
    );
  }
}

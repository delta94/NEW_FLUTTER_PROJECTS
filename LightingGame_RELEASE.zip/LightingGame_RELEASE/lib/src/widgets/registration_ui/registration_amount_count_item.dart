import 'package:Commons/colors.dart';
import 'package:Commons/dropdown.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/widgets/delete_button.dart';
import 'package:control_app/src/widgets/faded_text.dart';
import 'package:control_app/src/widgets/highlight_text.dart';
import 'package:control_app/src/widgets/number_input.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class RegistrationAmountCountItem extends StatefulWidget {
  final Key key;
  final bool enable;
  final dynamic countNum;
  final String title;
  final int speciesId;
  final RegistrationType registrationType;
  final VoidCallback onDelete;
  final Function(double) onChangeCount;
  final NumberInputType numberInputType;
  final OptionItem selectedOption;
  final List<OptionItem> allOptions;
  final bool allowDelete;

  const RegistrationAmountCountItem({
    this.key,
    this.numberInputType: NumberInputType.INT,
    this.enable,
    this.countNum,
    this.title,
    this.speciesId,
    this.onDelete,
    this.onChangeCount,
    this.registrationType,
    this.selectedOption,
    this.allOptions,
    this.allowDelete,
  }) : super(key: key);

  @override
  _RegistrationAmountCountItemState createState() =>
      _RegistrationAmountCountItemState();
}

class _RegistrationAmountCountItemState
    extends State<RegistrationAmountCountItem> {
  final TextEditingController controller = new TextEditingController(text: '');

  @override
  void initState() {
    if (widget.countNum != null) {
      String count = widget.countNum.toString();
      if (widget.registrationType == RegistrationType.Environment)
        controller.text = count;
      else
        controller.text = count == '0' || count == '0.0' ? '' : count;
    }

    controller.addListener(() {
      String newCount = controller.text ?? '';
      double val = newCount == '' ? 0 : (double.tryParse(newCount) ?? 0);
      if (val != widget.countNum) {
        Future.delayed(Duration.zero, () {
          widget.onChangeCount(newCount == '' ? 0 : double.parse(newCount));
        });
      }
    });

    super.initState();
  }

  @override
  void dispose() {
    controller.dispose();
    super.dispose();
  }

  @override
  void didUpdateWidget(RegistrationAmountCountItem oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.countNum != 0 &&
        ((widget.enable != null && oldWidget.enable != widget.enable) &&
            widget.countNum != oldWidget.countNum)) {
      if (widget.countNum is double) {
        double countNumValue = widget.countNum;
        if (countNumValue.truncateToDouble() == countNumValue)
          controller.text = countNumValue.toStringAsFixed(0);
        else
          controller.text = widget.countNum.toString();
      } else {
        controller.text = widget.countNum.toString();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    final OrganizationModel organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);

    return Column(
      children: <Widget>[
        SizedBox(height: 15),
        Row(children: <Widget>[
          DeleteButton(
            isVisible: widget.enable && widget.allowDelete,
            callback: () => widget.onDelete(),
          ),
          Expanded(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Expanded(
                  child: Row(
                    mainAxisAlignment: widget.speciesId == 1
                        ? MainAxisAlignment.start
                        : MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Visibility(
                        visible: widget.speciesId != 1 &&
                            widget.registrationType != RegistrationType.Feeding,
                        child: Expanded(
                          flex: 5,
                          child: FadedText(
                              text: organizationModel
                                  .getSpecieName(widget.speciesId)),
                        ),
                      ),
                      Expanded(
                        flex: 4,
                        child: FadedText(text: widget.title),
                      ),
                      SizedBox(
                        width: 10,
                      )
                    ],
                  ),
                ),
                widget.selectedOption == null
                    ? NumberInput(
                        allowNegativeNumber: widget.registrationType ==
                                RegistrationType.Environment &&
                            widget.title.contains('[°C]'),
                        numberInputType: widget.numberInputType,
                        controller: controller,
                        enabled: widget.enable,
                        inputHeight: 32,
                        activeColor: widget.enable ? akvaMainAction : null,
                      )
                    : widget.enable
                        ? Container()
                        : Container(
                            child: HighlightText(
                              isShortText: true,
                              text: widget.selectedOption == null
                                  ? ''
                                  : widget.selectedOption.label,
                            ),
                          ),
                SizedBox(width: 15)
              ],
            ),
          )
        ]),
        Visibility(
          visible: widget.enable && widget.selectedOption != null,
          child: Padding(
            padding: const EdgeInsets.only(right: 20),
            child: AkvaDropDown(
              enable: widget.enable,
              isDarkTheme: appModel.isDarkTheme,
              items: widget.allOptions ?? [],
              selectedItems: [widget.selectedOption],
              onSelectedItem: (selectedItem) =>
                  widget.onChangeCount(selectedItem.id.toDouble()),
            ),
          ),
        ),
        SizedBox(height: 15),
        Divider(
          color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
          height: 1,
          thickness: 1.3,
        ),
      ],
    );
  }
}

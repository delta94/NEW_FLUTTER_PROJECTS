import 'package:Commons/colors.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/base_view_model.dart';
import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/base/registration_view_model_factory.dart';
import 'package:control_app/src/environment/view_models/environment_view_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:control_app/src/widgets/registration_tabbar.dart';
import 'package:control_app/src/widgets/registration_ui/no_registration_content.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class NoTabbarRegistrationBody extends StatefulWidget {
  final Widget registrationContent;
  final RegistrationType registrationType;

  NoTabbarRegistrationBody({this.registrationContent, this.registrationType});

  @override
  _NoTabbarRegistrationBodyState createState() =>
      _NoTabbarRegistrationBodyState();
}

class _NoTabbarRegistrationBodyState extends State<NoTabbarRegistrationBody> {
  SharedDataModel sharedDataModel;
  RegistrationViewModel viewModel;

  @override
  void initState() {
    sharedDataModel = Provider.of<SharedDataModel>(context, listen: false);
    sharedDataModel.isSalmonTabActive = true;
    viewModel = RegistrationViewModelFactory.create(
      context,
      widget.registrationType,
      isForSalmon: true,
      listen: false,
    );

    if (viewModel != null) viewModel.createViewRegistrations();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context);
    sharedDataModel = Provider.of<SharedDataModel>(context);
    final viewModel = widget.registrationType == RegistrationType.Lice
        ? Provider.of<LiceSampleViewModel>(context)
        : RegistrationViewModelFactory.create(
            context,
            widget.registrationType,
            isForSalmon: true,
            listen: true,
          );

    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Container(
          margin: EdgeInsets.only(top: 20, left: 7),
          child: Divider(thickness: 1, height: 0, color: akvaMainNeutral),
        ),
        RegistrationTabBar(
          key: UiUtils.getKeyBaseOnSyncConnectionStatus(appModel),
          isSalmonActive: true,
          isOnlyOneTab: true,
          onChangeTabBar: (isSalmon) =>
              sharedDataModel.setTabActive(isSalmon: isSalmon),
          salmonTabView: getRegistrationContent(
            registrationType: widget.registrationType,
            viewModel: viewModel,
          ),
        ),
      ],
    );
  }

  Widget getRegistrationContent(
      {RegistrationType registrationType, BaseViewModel viewModel}) {
    switch (registrationType) {
      case RegistrationType.Lice:
        LiceSampleViewModel liceSampleViewModel =
            viewModel as LiceSampleViewModel;
        return liceSampleViewModel.liceSamples.isNotEmpty
            ? widget.registrationContent
            : NoRegistrationContent(
                registrationStatus: liceSampleViewModel.status,
                isForSalmon: true,
                isOnlySalmon: true,
              );
      case RegistrationType.Environment:
        EnvironmentViewModel environmentViewModel =
            viewModel as EnvironmentViewModel;
        return environmentViewModel.hasSensorData &&
                environmentViewModel.registrations.isNotEmpty
            ? widget.registrationContent
            : NoRegistrationContent(
                registrationStatus: environmentViewModel.status,
                isForSalmon: true,
                isOnlySalmon: false,
              );
      default:
        return null;
    }
  }
}

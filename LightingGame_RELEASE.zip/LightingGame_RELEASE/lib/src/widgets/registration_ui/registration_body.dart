import 'package:Commons/colors.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/base/registration_view_model_factory.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:control_app/src/widgets/registration_tabbar.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'no_registration_content.dart';
import 'registration_content.dart';

class RegistrationBody extends StatefulWidget {
  final RegistrationType registrationType;
  final Widget confirmationWidget;
  RegistrationBody({
    @required this.registrationType,
    this.confirmationWidget,
  });
  @override
  _RegistrationBodyState createState() => _RegistrationBodyState();
}

class _RegistrationBodyState extends State<RegistrationBody> {
  SharedDataModel sharedDataModel;
  RegistrationViewModel salmonViewModel;
  RegistrationViewModel cleanerFishViewModel;
  @override
  void initState() {
    sharedDataModel = Provider.of<SharedDataModel>(context, listen: false);
    sharedDataModel.isSalmonTabActive = true;
    salmonViewModel = RegistrationViewModelFactory.create(
      context,
      widget.registrationType,
      isForSalmon: true,
      listen: false,
    );
    cleanerFishViewModel = RegistrationViewModelFactory.create(
      context,
      widget.registrationType,
      isForSalmon: false,
      listen: false,
    );

    salmonViewModel.createViewRegistrations();
    if (cleanerFishViewModel != null)
      cleanerFishViewModel.createViewRegistrations();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    sharedDataModel = Provider.of<SharedDataModel>(context);
    AppModel appModel = Provider.of<AppModel>(context);

    salmonViewModel = RegistrationViewModelFactory.create(
        context, widget.registrationType,
        isForSalmon: true);
    cleanerFishViewModel = RegistrationViewModelFactory.create(
      context,
      widget.registrationType,
      isForSalmon: false,
    );

    bool isSalmonActive = sharedDataModel.isSalmonTabActive;

    Widget getRegistrationContent({RegistrationViewModel model}) {
      if (model == null) return null;
      return model.status == RegistrationStatus.HAVE_REGISTRATION
          ? RegistrationContent(
              model: model,
              registrationType: widget.registrationType,
            )
          : NoRegistrationContent(
              isForSalmon: model.isForSalmon,
              isOnlySalmon: false,
              registrationStatus: model.status,
              confirmationWidget: widget.confirmationWidget,
            );
    }

    return Column(
      mainAxisAlignment: isSalmonActive
          ? MainAxisAlignment.spaceBetween
          : MainAxisAlignment.center,
      children: <Widget>[
        Column(
          children: <Widget>[
            SizedBox(height: 20),
            Divider(
              thickness: 1,
              height: 0,
              color: akvaMainNeutral,
            ),
          ],
        ),
        RegistrationTabBar(
          key: UiUtils.getKeyBaseOnSyncConnectionStatus(appModel),
          isSalmonActive: isSalmonActive,
          onChangeTabBar: (isSalmon) =>
              sharedDataModel.setTabActive(isSalmon: isSalmon),
          salmonTabView: getRegistrationContent(model: salmonViewModel),
          cleanerFishTabView:
              getRegistrationContent(model: cleanerFishViewModel),
        ),
      ],
    );
  }
}

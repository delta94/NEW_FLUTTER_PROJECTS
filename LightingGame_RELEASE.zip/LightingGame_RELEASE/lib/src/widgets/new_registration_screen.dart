import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/base_view_model.dart';
import 'package:control_app/src/base/registration_view_model.dart';
import 'Package:flutter/material.dart';
import 'package:Commons/colors.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:control_app/src/widgets/common_heaher.dart';
import 'package:control_app/src/widgets/synchronize_progress_status.dart';
import 'package:provider/provider.dart';

import 'add_new_registration_ui/add_new_registration_button.dart';
import 'confirmation_dialog/confirmation_modal.dart';
import 'offline_status.dart';

class NewRegistrationScreen extends StatefulWidget {
  final String title;
  final DateTime registrationDateTime;
  final Widget amountCountWidget;
  final int amountCountLength;
  final bool isAllowedToSave;
  final VoidCallback onPressSave;
  final RegistrationViewModel registrationViewModel;

  NewRegistrationScreen({
    @required this.title,
    @required this.registrationDateTime,
    @required this.amountCountWidget,
    @required this.amountCountLength,
    @required this.isAllowedToSave,
    @required this.onPressSave,
    @required this.registrationViewModel,
  });

  @override
  _NewRegistrationScreenState createState() => _NewRegistrationScreenState();
}

class _NewRegistrationScreenState extends State<NewRegistrationScreen> {
  SavingStatusEnum savingStatusEnum = SavingStatusEnum.NOT_SAVE;

  @override
  void didUpdateWidget(NewRegistrationScreen oldWidget) {
    if (widget.registrationViewModel.busy)
      savingStatusEnum = SavingStatusEnum.SAVING;
    if (!widget.registrationViewModel.busy &&
        savingStatusEnum == SavingStatusEnum.SAVING) {
      setState(() {
        savingStatusEnum = SavingStatusEnum.SAVED;
      });

      Future.delayed(Duration(seconds: 1), () {
        Navigator.pop(context);
        widget.registrationViewModel.clearRegistrations();
      });
    }

    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context, listen: false);

    closeWithoutSaving() {
      widget.registrationViewModel.cancelRegistration();
      widget.registrationViewModel.editMode = EditModeEnum.ADD;
      Navigator.pop(context);
    }

    onClose() {
      if (widget.amountCountLength > 0) {
        showConfirmationModal(
          context: context,
          title: appText.unsaved_changes,
          messages: [
            appText.you_have_unsaved_changes,
            appText.are_you_sure_you_want_to_continue
          ],
          leftButtonTitle: appText.save,
          rightButtonTitle: appText.dont_save,
          onTapLeftButton: () {
            if (widget.isAllowedToSave) {
              widget.onPressSave();
              Navigator.pop(context);
            } else {
              UiUtils.showToast(
                  message: appText.cant_save_0, appModel: appModel);
            }
          },
          onTapRightButton: () {
            closeWithoutSaving();
          },
        );
      } else {
        closeWithoutSaving();
      }

      return Future<bool>.value(false);
    }

    return WillPopScope(
      onWillPop: () => onClose(),
      child: Stack(
        children: [
          Container(
            child: Column(
              children: <Widget>[
                Expanded(
                  child: Container(
                    color:
                        appModel.isDarkTheme ? akvaDarkColorC : akvaDarkColorE,
                  ),
                ),
                Expanded(
                  child: Container(
                    color:
                        appModel.isDarkTheme ? akvaDarkColorC : akvaLightColorA,
                  ),
                )
              ],
            ),
          ),
          Scaffold(
            backgroundColor: Colors.transparent,
            body: SingleChildScrollView(
              child: SafeArea(
                child: Container(
                  color:
                      appModel.isDarkTheme ? akvaDarkColorC : akvaLightColorA,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      SynchronizeProgressStatus(),
                      OfflineStatus(),
                      CommonHeader(
                        unitName: widget.registrationViewModel.organizationModel
                            .currentOrganizationEntity.name,
                        headerTitle: widget.title,
                        onClose: () => onClose(),
                      ),
                      Divider(
                        color: appModel.isDarkTheme
                            ? akvaDarkColorD
                            : akvaLightColorD,
                        thickness: 1,
                        height: 0,
                      ),
                      widget.amountCountWidget,
                      SizedBox(
                        height: 23,
                      )
                    ],
                  ),
                ),
              ),
            ),
            bottomNavigationBar: Container(
              color: appModel.isDarkTheme ? akvaDarkColorC : akvaLightColorA,
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 20.0, right: 20.0, bottom: 30.0),
                child: AddNewRegistrationButton(
                  buttonTitle: appText.save,
                  isBusy: widget.registrationViewModel.busy,
                  savingStatusEnum: savingStatusEnum,
                  isAllowedToSave: widget.isAllowedToSave,
                  onPressSave: () => widget.onPressSave(),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

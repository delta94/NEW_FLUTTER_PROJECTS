import 'package:Commons/colors.dart';
import 'package:control_app/src/app_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

enum NumberInputType { INT, DECIMAL, TEXT }

class NumberInput extends StatelessWidget {
  final TextEditingController controller;
  final bool enabled;
  final double inputHeight;
  final Color activeColor;
  final NumberInputType numberInputType;
  final double inputWidth;
  final TextAlign textAlign;
  final bool allowNegativeNumber;

  NumberInput({
    this.enabled = true,
    this.inputHeight: 38,
    this.inputWidth: 70,
    this.activeColor,
    this.numberInputType = NumberInputType.INT,
    @required this.controller,
    this.textAlign: TextAlign.center,
    this.allowNegativeNumber: false,
  });

  _getTextFieldColor(bool isDarkTheme) {
    if (controller.value.toString() == '') {
      return isDarkTheme ? akvaDarkTextB : akvaLightTextB;
    } else {
      return isDarkTheme ? akvaDarkTextA : akvaDarkColorD;
    }
  }

  String _getHintText() {
    switch (numberInputType) {
      case NumberInputType.INT:
        return '0';
      case NumberInputType.DECIMAL:
        return '0.0';
      case NumberInputType.TEXT:
        return '0';
      default:
        return '0';
    }
  }

  TextInputFormatter _getInputFormat() {
    switch (numberInputType) {
      case NumberInputType.INT:
        return IntegerTextInputFormatter();
      case NumberInputType.DECIMAL:
        return DecimalTextInputFormatter(
          decimalRange: 2,
          allowNegativeNumber: allowNegativeNumber,
        );
      case NumberInputType.TEXT:
        return null;
      default:
        return IntegerTextInputFormatter();
    }
  }

  TextInputType getTextInputType() {
    switch (numberInputType) {
      case NumberInputType.INT:
        return TextInputType.number;
      case NumberInputType.DECIMAL:
        TextInputType textInputType =
            TextInputType.numberWithOptions(decimal: true);
        if (allowNegativeNumber) textInputType = TextInputType.phone;
        return textInputType;
      case NumberInputType.TEXT:
        return TextInputType.text;
      default:
        return TextInputType.text;
    }
  }

  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context);

    return Container(
      width: inputWidth,
      height: inputHeight,
      child: new TextField(
        style: new TextStyle(color: _getTextFieldColor(appModel.isDarkTheme)),
        controller: controller,
        decoration: new InputDecoration(
          hintText: _getHintText(),
          filled: true,
          fillColor: appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorB,
          contentPadding: textAlign == TextAlign.center
              ? EdgeInsets.all(0.0)
              : EdgeInsets.only(left: 16),
          enabledBorder: new OutlineInputBorder(
            borderSide: new BorderSide(
                color: activeColor != null
                    ? activeColor
                    : appModel.isDarkTheme ? akvaDarkColorE : akvaLightColorE),
            borderRadius: BorderRadius.all(Radius.circular(0)),
          ),
          border: new OutlineInputBorder(
            borderSide: new BorderSide(
                color: appModel.isDarkTheme ? akvaDarkColorE : akvaLightColorE),
            borderRadius: BorderRadius.all(Radius.circular(0)),
          ),
          focusedBorder: new OutlineInputBorder(
            borderSide: new BorderSide(
                color: appModel.isDarkTheme ? akvaDarkColorE : akvaLightColorE),
            borderRadius: BorderRadius.all(Radius.circular(0)),
          ),
        ),
        textAlign: textAlign,
        enabled: enabled,
        keyboardType: getTextInputType(),
        inputFormatters:
            numberInputType != NumberInputType.TEXT ? [_getInputFormat()] : [],
      ),
    );
  }
}

class DecimalTextInputFormatter extends TextInputFormatter {
  DecimalTextInputFormatter(
      {this.decimalRange, this.allowNegativeNumber: false})
      : assert(decimalRange == null || decimalRange > 0);

  final int decimalRange;
  final bool allowNegativeNumber;

  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue, // unused.
    TextEditingValue newValue,
  ) {
    RegExp regExp =
        allowNegativeNumber ? RegExp(r'[-]|[0-9]|[.]?') : RegExp(r'\d|[.]?');
    List<int> dashIndices = [];
    List<int> dotIndices = [];

    String truncated = regExp
        .allMatches(newValue.text)
        .map<String>((Match match) => match.group(0))
        .join();

    if (truncated == '00') truncated = '0';
    List<String> truncatedArray = truncated.split('');
    if (truncated.length > 1 && !truncated.contains('.')) {
      if (truncatedArray[0] == '0') truncatedArray.removeAt(0);
    }

    for (var i = 0; i < truncatedArray.length; i++) {
      if (truncatedArray[i] == '-') {
        dashIndices.add(i);
      }
    }

    for (var i = 0; i < truncatedArray.length; i++) {
      if (truncatedArray[i] == '.') {
        dotIndices.add(i);
      }
    }

    if (dashIndices.length > 0) {
      dashIndices.forEach((index) {
        if (index > 0) truncatedArray.removeAt(index);
      });
    }

    if (dotIndices.length == 2) {
      truncatedArray.removeAt(dotIndices[1]);
    }

    truncated = truncatedArray.join();

    truncatedArray = truncated.split('.');
    String integerPart = truncatedArray[0];
    if (truncatedArray.length == 2) {
      String decimalPart = truncatedArray[1];
      if (truncated.contains('.') && decimalPart.length > decimalRange) {
        decimalPart = decimalPart.substring(0, decimalRange);
        truncated = '$integerPart.$decimalPart';
      }
    }

    int selectionIndex = newValue.selection.end;

    return TextEditingValue(
      text: truncated,
      selection: TextSelection.collapsed(offset: selectionIndex),
      composing: TextRange.empty,
    );
  }
}

class IntegerTextInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(
    TextEditingValue oldValue, // unused.
    TextEditingValue newValue,
  ) {
    int selectionIndex = 0;
    final StringBuffer newText = StringBuffer();
    String validNewValue = RegExp(r'\d+')
        .allMatches(newValue.text)
        .map<String>((Match match) => match.group(0))
        .join();
    validNewValue = validNewValue.length <= 1
        ? validNewValue
        : int.parse(validNewValue).toString();

    selectionIndex = newValue.selection.end;
    newText.write(validNewValue);

    return TextEditingValue(
      text: newText.toString(),
      selection: TextSelection.collapsed(offset: selectionIndex),
      composing: TextRange.empty,
    );
  }
}

import 'package:Commons/colors.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/base/base_view_model.dart';
import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/base/registration_view_model_factory.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/routers.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:control_app/src/widgets/registration_screen_header.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import '../app_model.dart';
import 'confirmation_dialog/confirmation_modal.dart';
import 'offline_status.dart';
import 'synchronize_progress_status.dart';

class RegistrationScreen extends StatefulWidget {
  final RegistrationType registrationType;
  final String title;
  final Color decorationColor;
  final String unitName;
  final Widget body;
  final Widget bottomNavigationBar;

  RegistrationScreen(
      {@required this.title,
      @required this.decorationColor,
      @required this.unitName,
      @required this.body,
      @required this.bottomNavigationBar,
      @required this.registrationType});

  @override
  _RegistrationScreenState createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  @override
  void initState() {
    SharedDataModel sharedDataModel =
        Provider.of<SharedDataModel>(context, listen: false);
    sharedDataModel.isSalmonTabActive = true;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context);
    SharedDataModel sharedDataModel = Provider.of<SharedDataModel>(context);
    RegistrationViewModel salmonViewModel = RegistrationViewModelFactory.create(
        context, widget.registrationType,
        isForSalmon: true, listen: true);
    RegistrationViewModel cleanerFishViewModel =
        RegistrationViewModelFactory.create(context, widget.registrationType,
            isForSalmon: false, listen: true);

    final isSalmonTabActive = sharedDataModel.isSalmonTabActive;
    RegistrationViewModel model =
        isSalmonTabActive ? salmonViewModel : cleanerFishViewModel;

    onTapSavingDialogAction({bool isSave, bool needBack}) {
      if (model.editMode == EditModeEnum.EDIT) {
        if (isSave) {
          if (model.isValidData) {
            model.updateRegistrations();
            Navigator.of(context).pop();
          } else
            UiUtils.showToast(message: appText.cant_save_0, appModel: appModel);
        } else {
          model.discardChanges();
          Navigator.of(context).pop();
        }
      }
    }

    onBack() {
      if (model != null && model.busy) return Future<bool>.value(false);
      if (widget.registrationType == RegistrationType.Lice) {
        Navigator.of(context).popUntil(ModalRoute.withName(Routers.main));
      } else {
        bool isEditing = salmonViewModel.editMode == EditModeEnum.EDIT ||
            (cleanerFishViewModel != null &&
                cleanerFishViewModel.editMode == EditModeEnum.EDIT);
        if (isEditing) {
          showConfirmationModal(
            context: context,
            title: appText.unsaved_changes,
            messages: [
              appText.you_have_unsaved_changes,
              appText.are_you_sure_you_want_to_continue
            ],
            leftButtonTitle: appText.save,
            rightButtonTitle: appText.dont_save,
            onTapLeftButton: () => onTapSavingDialogAction(isSave: true),
            onTapRightButton: () => onTapSavingDialogAction(isSave: false),
          );
        } else {
          Navigator.of(context).pop();
        }
      }

      return Future<bool>.value(false);
    }

    var safePadding = MediaQuery.of(context).padding.top;

    return WillPopScope(
      onWillPop: () => onBack(),
      child: Stack(
        children: [
          Scaffold(
            backgroundColor:
                appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorA,
            body: Stack(
              children: <Widget>[
                // Faked background: is used to fix issue: showing black background when show input keyboard
                Column(
                  children: <Widget>[
                    Padding(
                      padding: EdgeInsets.only(top: safePadding),
                    ),
                    Expanded(
                      child: Container(
                        margin: EdgeInsets.only(top: 300, left: 16, right: 16),
                        decoration: BoxDecoration(
                          color: appModel.isDarkTheme
                              ? akvaDarkColorC
                              : akvaLightColorC,
                          gradient: UiUtils.getRegistraionLinearGradient(
                              widget.decorationColor, appModel.isDarkTheme),
                        ),
                      ),
                    ),
                  ],
                ),
                SingleChildScrollView(
                  child: SafeArea(
                    child: Column(
                      children: <Widget>[
                        SynchronizeProgressStatus(),
                        OfflineStatus(),
                        Container(
                          margin: EdgeInsets.only(top: 32, left: 16, right: 16),
                          decoration: BoxDecoration(
                            gradient: UiUtils.getRegistraionLinearGradient(
                                widget.decorationColor, appModel.isDarkTheme),
                            borderRadius: new BorderRadius.only(
                              topLeft: Radius.circular(8),
                              topRight: Radius.circular(8),
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: appModel.isDarkTheme
                                    ? akvaDarkColorB
                                    : akvaLightColorC,
                                blurRadius: 5,
                                spreadRadius: 5,
                                offset: Offset(0.0, -10),
                              )
                            ],
                          ),
                          child: Column(
                            children: <Widget>[
                              RegistrationScreenHeader(
                                title: widget.title,
                                unitName: widget.unitName,
                                onBack: () => onBack(),
                              ),
                              widget.body,
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            bottomNavigationBar: widget.bottomNavigationBar,
          ),
        ],
      ),
    );
  }
}

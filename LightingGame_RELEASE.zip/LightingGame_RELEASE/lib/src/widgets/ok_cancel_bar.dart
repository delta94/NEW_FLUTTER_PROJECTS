import 'package:flutter/material.dart';
import 'modal_progress.dart';
import 'ok_cancel_modal_dialog.dart';

// TODO: Review this, and consider if it should be deleted or updated
Future<bool> showBackNavigationConfirmDialog(
    context, Future Function() confirmCallback) {
  return showDialog(
    context: context,
    barrierDismissible: true,
    builder: (BuildContext context) {
      return YesNoModalDialog(
        title: "Save Changes",
        description: "Do you want to save the changes",
        okCallback: () async {
          await confirmCallback();
          Navigator.pop(context, true);
        },
        cancelCallback: () {
          Navigator.pop(context, false);
          Navigator.pop(context, false);
        },
      );
    },
  );
}

class OkCancelBar extends StatelessWidget {
  final VoidCallback cancelCallback;
  final VoidCallback okCallback;

  OkCancelBar({this.cancelCallback, this.okCallback});
  factory OkCancelBar.withConfirmDialogAndSnacbar(
      context,
      bool hasAnythingChanged,
      GlobalKey<ScaffoldState> scaffoldKey,
      Future Function() saveCallback) {
    void cancelFunction() async {
      if (hasAnythingChanged) {
        await showBackNavigationConfirmDialog(context, saveCallback);
      } else {
        Navigator.pop(context);
      }
    }

    void saveFunction() async {
      try {
        showDialog(
          context: context,
          barrierDismissible: false,
          builder: (BuildContext context) {
            return ModalProgress();
          },
        );
        await saveCallback();
      } catch (e) {
        final sn = SnackBar(
          content: Text('Uploading failed'),
          duration: Duration(seconds: 2),
        );

        Scaffold.of(context).showSnackBar(sn);
        return;
      } finally {
        Navigator.pop(context);
      }
      Navigator.pop(context);
      final sn = SnackBar(
          content: Text('Registration was uploaded'));
      scaffoldKey.currentState.showSnackBar(sn);
    }

    return OkCancelBar(
      cancelCallback: cancelFunction,
      okCallback: hasAnythingChanged ? saveFunction : null,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      padding: EdgeInsets.only(top: 16, bottom: 24, left: 32, right: 32),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          ButtonTheme(
            minWidth: 144,
            height: 42,
            child: RaisedButton(
              elevation: 4,
              child: Text("CANCEL"),
              onPressed: cancelCallback,
            ),
          ),
          Padding(
            padding: EdgeInsets.only(bottom: 16),
          ),
          ButtonTheme(
            minWidth: 144,
            height: 42,
            child: RaisedButton(
              elevation: 4,
              child: Text( "SAVE"),
              onPressed: okCallback,
            ),
          )
        ],
      ),
    );
  }
}

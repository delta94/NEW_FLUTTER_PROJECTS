import 'package:Commons/buttons.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/base_view_model.dart';
import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/base/registration_view_model_factory.dart';
import 'package:control_app/src/culling/view_models/cleaner_fish_culling_registration_view_model.dart';
import 'package:control_app/src/culling/view_models/salmon_culling_registration_view_model.dart';
import 'package:control_app/src/environment/view_models/environment_view_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class RegistrationBottomActionButton extends StatefulWidget {
  final Color decorationColor;
  final RegistrationType registrationType;
  final Widget addRegistrationPage;
  RegistrationBottomActionButton({
    this.decorationColor,
    this.registrationType,
    this.addRegistrationPage,
  });

  @override
  _RegistrationBottomActionButtonState createState() =>
      _RegistrationBottomActionButtonState();
}

class _RegistrationBottomActionButtonState
    extends State<RegistrationBottomActionButton> {
  SavingStatusEnum savingStatusEnum = SavingStatusEnum.NOT_SAVE;

  getBottomButtonContent(
    BuildContext context,
    RegistrationViewModel registrationViewModel,
    RegistrationType registrationType,
  ) {
    final S appText = S.of(context);
    IconData iconData = AkvaIcons.plus;
    String buttonText = appText.new_registration;
    double iconSize = 18;
    Widget widget;

    _setSavedButton() {
      iconData = AkvaIcons.checked;
      iconSize = FontSize.large;
      buttonText = '';
      Future.delayed(Duration(seconds: 1), () {
        setState(() {
          savingStatusEnum = SavingStatusEnum.NOT_SAVE;
        });
      });
    }

    if (registrationType != RegistrationType.Lice) {
      if (registrationViewModel.busy) {
        savingStatusEnum = SavingStatusEnum.SAVING;
      } else {
        if (!registrationViewModel.busy &&
            savingStatusEnum == SavingStatusEnum.SAVING) {
          savingStatusEnum = SavingStatusEnum.SAVED;
        }
      }

      switch (registrationViewModel.editMode) {
        case EditModeEnum.ADD:
          if (savingStatusEnum == SavingStatusEnum.NOT_SAVE) {
            iconData = AkvaIcons.plus;
            buttonText = appText.new_registration;
          } else if (savingStatusEnum == SavingStatusEnum.SAVED) {
            _setSavedButton();
          } else
            iconData = null;
          break;
        case EditModeEnum.EDIT:
          if (savingStatusEnum == SavingStatusEnum.NOT_SAVE) {
            iconData = AkvaIcons.checked_thick;
            iconSize = FontSize.medium;
            buttonText = appText.save_changes;
          } else if (savingStatusEnum == SavingStatusEnum.SAVED) {
            _setSavedButton();
          } else {
            buttonText = '';
          }

          break;
        default:
          iconData = AkvaIcons.plus;
          buttonText = appText.new_registration;
          break;
      }
    }

    return new BottomButtonContent(iconData, iconSize, buttonText, widget);
  }

  Future<void> onPressBottomButton(
      BuildContext context,
      RegistrationViewModel registrationViewModel,
      RegistrationType registrationType,
      Widget newRegistrationScreen) async {
    if (registrationType != RegistrationType.Lice)
      switch (registrationViewModel.editMode) {
        case EditModeEnum.ADD:
          registrationViewModel.discardChanges(shouldNotify: false);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => newRegistrationScreen,
            ),
          );
          break;
        case EditModeEnum.EDIT:
          savingStatusEnum = SavingStatusEnum.SAVING;
          await registrationViewModel.updateRegistrations();
          setState(() {
            savingStatusEnum = SavingStatusEnum.SAVED;
          });
          break;
        default:
      }
    else
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => newRegistrationScreen,
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    SharedDataModel sharedDataModel = Provider.of<SharedDataModel>(context);
    LiceSampleViewModel liceSampleViewModel;
    OrganizationModel organizationModel =
        Provider.of<OrganizationModel>(context);

    if (widget.registrationType == RegistrationType.Lice) {
      liceSampleViewModel = Provider.of<LiceSampleViewModel>(context);
    }

    RegistrationViewModel model = RegistrationViewModelFactory.create(
      context,
      widget.registrationType,
      isForSalmon: sharedDataModel.isSalmonTabActive,
    );

    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    BottomButtonContent bottomButtonContent =
        getBottomButtonContent(context, model, widget.registrationType);

    RegistrationStatus registrationStatus;
    if (widget.registrationType == RegistrationType.Lice) {
      LiceSampleViewModel liceSampleViewModel =
          Provider.of<LiceSampleViewModel>(context, listen: false);
      registrationStatus = liceSampleViewModel.status;
    } else {
      registrationStatus = model.status;
    }

    /// Special check culled all if it is in culling registration.
    bool _wasCulledAll = false;
    if (model is SalmonCullingRegistrationViewModel) {
      _wasCulledAll = model.wasCulledAll || model.stockNumber <= 0;
    } else if (model is CleanerFishCullingRegistrationViewModel) {
      _wasCulledAll = model.wasCulledAll || model.stockNumber <= 0;
    }

    bool isBusy = model != null ? model.busy : liceSampleViewModel.busy;
    bool allowPressButton() {
      bool isNotSaving = savingStatusEnum == SavingStatusEnum.NOT_SAVE;
      bool hasSensorData =
          widget.registrationType == RegistrationType.Environment &&
              (model as EnvironmentViewModel).hasSensorData;
      bool isValideRegistrationStatus =
          registrationStatus == RegistrationStatus.NO_REGISTRATION ||
              registrationStatus == RegistrationStatus.HAVE_REGISTRATION;
      bool isLiceRegistration =
          widget.registrationType == RegistrationType.Lice;

      bool hasWriteRight = organizationModel
          .registrationUserRightMap[widget.registrationType].allowWrite;

      return (isValideRegistrationStatus || hasSensorData) &&
          !_wasCulledAll &&
          (isLiceRegistration || model.isValidData) &&
          isNotSaving &&
          hasWriteRight;
    }

    return Container(
      decoration: BoxDecoration(
        gradient: UiUtils.getRegistraionLinearGradient(
          widget.decorationColor,
          appModel.isDarkTheme,
        ),
      ),
      margin: EdgeInsets.only(left: 16, right: 16),
      padding: EdgeInsets.only(left: 19, right: 15, bottom: 30),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Stack(
              children: [
                AkvaPrimaryButton(
                  widget: UiUtils.spinArrow,
                  onPressed: null,
                ),
                isBusy
                    ? Container(height: 0)
                    : AkvaPrimaryButton(
                        onPressed: allowPressButton()
                            ? () => onPressBottomButton(
                                  context,
                                  model,
                                  widget.registrationType,
                                  widget.addRegistrationPage,
                                )
                            : null,
                        label: bottomButtonContent.buttonText,
                        icon: bottomButtonContent.iconData,
                        iconSize: bottomButtonContent.iconSize,
                      ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class BottomButtonContent {
  final IconData iconData;
  final double iconSize;
  final String buttonText;
  final Widget widget;

  BottomButtonContent(
      this.iconData, this.iconSize, this.buttonText, this.widget);
}

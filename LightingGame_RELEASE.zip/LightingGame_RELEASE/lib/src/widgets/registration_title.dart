import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class RegistrationTitle extends StatelessWidget {
  final bool isViewMode;
  final bool isEditingCountMode;
  final VoidCallback setEditingModeTrue;
  final VoidCallback discardChanges;

  const RegistrationTitle(
      {Key key,
      this.isViewMode,
      this.isEditingCountMode,
      this.setEditingModeTrue,
      this.discardChanges})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    final S appText = S.of(context);
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Text(
          appText.registration,
          style: TextStyle(
              color: appModel.isDarkTheme ? akvaDarkTextA : akvaDarkColorD,
              fontSize: FontSize.medium,
              fontWeight: FontWeight.normal),
        ),
        Visibility(
          visible: !isViewMode || isEditingCountMode,
          child: isEditingCountMode
              ? Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () => discardChanges(),
                    child: Text(
                      appText.cancel,
                      style: TextStyle(
                        color: akvaMainLiveAction,
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                )
              : Material(
                  color: Colors.transparent,
                  child: InkWell(
                    onTap: () => setEditingModeTrue(),
                    child: Row(
                      children: <Widget>[
                        Icon(
                          AkvaIcons.pen_circle,
                          size: 20,
                          color: akvaMainLiveAction,
                        ),
                        SizedBox(width: 5),
                        Text(
                          appText.edit,
                          style: TextStyle(
                            color: akvaMainLiveAction,
                            fontSize: 16,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
        ),
      ],
    );
  }
}

import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/src/app_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ConfirmationModal extends StatelessWidget {
  const ConfirmationModal({
    Key key,
    this.onCloseDialog,
    this.onTapLeftButton,
    this.onTapRightButton,
    this.title,
    this.messages,
    this.leftButtonTitle,
    this.rightButtonTitle,
  }) : super(key: key);

  final String title;
  final List<String> messages;
  final String leftButtonTitle;
  final String rightButtonTitle;
  final VoidCallback onCloseDialog;
  final VoidCallback onTapLeftButton;
  final VoidCallback onTapRightButton;

  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context, listen: false);

    _buildContentMessages() {
      List<Widget> contentMessages = [];
      messages.forEach((message) {
        contentMessages.add(
          Container(
            alignment: Alignment.centerLeft,
            child: Wrap(
              children: <Widget>[
                ModalText(text: message),
              ],
            ),
          ),
        );
      });

      return contentMessages;
    }

    return Material(
      color: Colors.transparent,
      child: Stack(
        children: [
          Opacity(
            opacity: 0.9,
            child: Container(color: akvaDarkColorA),
          ),
          Container(
            margin: EdgeInsets.symmetric(horizontal: 29),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Container(
                  child: Column(children: <Widget>[
                    Container(
                      color: appModel.isDarkTheme
                          ? akvaDarkColorF
                          : akvaDarkColorE,
                      padding:
                          EdgeInsets.symmetric(vertical: 10, horizontal: 19),
                      child: Row(
                        children: <Widget>[
                          ModalText(text: title),
                        ],
                      ),
                    ),
                    Container(
                      color: akvaDarkColorD,
                      padding: EdgeInsets.only(
                        left: 19,
                        right: 19,
                        top: 16,
                        bottom: 36,
                      ),
                      child: Column(
                        children: _buildContentMessages(),
                      ),
                    ),
                  ]),
                ),
                Container(
                  color: akvaDarkColorD,
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: FlatButton(
                          color: akvaMainNeutral,
                          padding: EdgeInsets.symmetric(vertical: 12),
                          onPressed: () => onTapLeftButton(),
                          child: ButtonTitle(text: leftButtonTitle),
                        ),
                      ),
                      Expanded(
                        child: FlatButton(
                          color: akvaMainAction,
                          padding: EdgeInsets.symmetric(vertical: 12),
                          onPressed: () => onTapRightButton(),
                          child: ButtonTitle(text: rightButtonTitle),
                        ),
                      ),
                    ],
                  ),
                )
              ],
            ),
          )
        ],
      ),
    );
  }
}

class ModalText extends StatelessWidget {
  final String text;
  const ModalText({Key key, @required this.text}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context, listen: false);

    return Text(
      text,
      style: GoogleFonts.roboto(
        color: appModel.isDarkTheme ? akvaDarkTextA : akvaLightColorB,
        fontSize: FontSize.medium,
        decoration: TextDecoration.none,
        fontWeight: FontWeight.normal,
      ),
    );
  }
}

class ButtonTitle extends StatelessWidget {
  final String text;
  const ButtonTitle({Key key, @required this.text}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: GoogleFonts.roboto(
        color: akvaMainDark,
        fontSize: FontSize.small,
        decoration: TextDecoration.none,
        fontWeight: FontWeight.bold,
      ),
    );
  }
}

import 'dart:async';

import 'package:control_app/src/widgets/confirmation_dialog/confirmation_content.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

Future showConfirmationModal({
  @required BuildContext context,
  bool barrierDismissible = false,
  String title,
  List<String> messages,
  String leftButtonTitle,
  String rightButtonTitle,
  VoidCallback onCloseDialog,
  VoidCallback onTapLeftButton,
  VoidCallback onTapRightButton,
}) async {
  return await showDialog(
    context: context,
    builder: (_) => GestureDetector(
      onTap: () {
        if (!barrierDismissible) {
          Navigator.pop(context);
        }
      },
      child: ConfirmationModal(
        title: title,
        messages: messages,
        leftButtonTitle: leftButtonTitle,
        rightButtonTitle: rightButtonTitle,
        onCloseDialog: () => Navigator.pop(context),
        onTapLeftButton: () {
          Navigator.pop(context);
          if (onTapLeftButton != null) onTapLeftButton();
        },
        onTapRightButton: () {
          Navigator.pop(context);
          if (onTapRightButton != null) onTapRightButton();
        },
      ),
    ),
  );
}

Future showDialog({
  @required BuildContext context,
  WidgetBuilder builder,
}) {
  return showGeneralDialog(
    context: context,
    pageBuilder: (BuildContext buildContext, Animation<double> animation,
        Animation<double> secondaryAnimation) {
      return SafeArea(
        child: Builder(builder: builder),
      );
    },
    barrierDismissible: true,
    barrierLabel: MaterialLocalizations.of(context).modalBarrierDismissLabel,
    transitionDuration: const Duration(milliseconds: 150),
  );
}

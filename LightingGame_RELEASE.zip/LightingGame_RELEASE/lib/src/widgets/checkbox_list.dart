import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/src/app_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class CheckboxList extends StatefulWidget {
  const CheckboxList({
    Key key,
    this.title,
    @required this.checkboxTitles,
    this.enable: true,
    this.onChangeCheckedBoxIndices,
    @required this.checkedIndices,
    this.paddingRight: 0,
  }) : super(key: key);

  final String title;
  final List<String> checkboxTitles;
  final bool enable;
  final double paddingRight;
  final Function onChangeCheckedBoxIndices;
  final List<int> checkedIndices;
  @override
  _CheckboxListState createState() => _CheckboxListState();
}

class _CheckboxListState extends State<CheckboxList> {
  @override
  Widget build(BuildContext context) {
    _onUpdateCheckBox(int index) {
      setState(() {
        if (widget.checkedIndices.contains(index)) {
          widget.checkedIndices.remove(index);
        } else {
          widget.checkedIndices.add(index);
        }

        widget.onChangeCheckedBoxIndices();
      });
    }

    _buildCheckboxList() {
      List<Widget> checkboxes = [];
      widget.checkboxTitles.asMap().forEach((index, radioTitle) {
        if (index != 0) checkboxes.add(SizedBox(height: 20));
        checkboxes.add(Checkbox(
          currentCheckboxValue: index,
          enableCheckboxList: widget.enable,
          title: radioTitle,
          isChecked: widget.checkedIndices.contains(index),
          onTap: (newRadioIndex) =>
              widget.enable ? _onUpdateCheckBox(newRadioIndex) : null,
        ));
      });

      return checkboxes;
    }

    return Column(
      children: <Widget>[
        Row(
          children: <Widget>[
            Visibility(
              visible: widget.title != null,
              child: Text(
                widget.title ?? '',
                style: TextStyle(
                  fontSize: FontSize.small,
                  fontWeight: FontWeight.normal,
                ),
                textAlign: TextAlign.left,
              ),
            ),
          ],
        ),
        SizedBox(height: widget.title != null ? 20 : 0),
        Column(children: _buildCheckboxList())
      ],
    );
  }
}

class Checkbox extends StatelessWidget {
  const Checkbox(
      {Key key,
      this.isChecked,
      this.title,
      this.currentCheckboxValue,
      this.onTap,
      this.enableCheckboxList,
      this.paddingRight: 0})
      : super(key: key);

  final bool isChecked;
  final String title;
  final int currentCheckboxValue;
  final bool enableCheckboxList;
  final double paddingRight;
  final Function(int) onTap;

  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context, listen: false);

    return Row(
      children: <Widget>[
        InkWell(
          onTap: () => onTap(currentCheckboxValue),
          child: Row(
            children: <Widget>[
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color:
                      appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorB,
                  shape: BoxShape.rectangle,
                  borderRadius: BorderRadius.circular(4),
                  border: new Border.all(
                    color: appModel.isDarkTheme
                        ? akvaMainNeutral
                        : akvaLightColorE,
                    width: 1.0,
                  ),
                ),
                child: Visibility(
                  visible: isChecked,
                  child: Icon(
                    AkvaIcons.checked_thick,
                    size: FontSize.xsmall,
                    color: enableCheckboxList
                        ? akvaMainAction
                        : akvaMainActionDisabled,
                  ),
                ),
              ),
              SizedBox(width: 8),
              Container(
                padding: EdgeInsets.only(top: 2),
                constraints: new BoxConstraints(
                    maxWidth:
                        MediaQuery.of(context).size.width - paddingRight - 84),
                child: Text(
                  title,
                  style: TextStyle(
                      fontSize: FontSize.small,
                      fontWeight: FontWeight.normal,
                      color: appModel.isDarkTheme
                          ? akvaDarkTextA
                          : akvaDarkColorD),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

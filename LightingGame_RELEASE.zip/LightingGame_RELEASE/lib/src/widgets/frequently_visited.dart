import 'package:Commons/colors.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/models/organization_unit.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/widgets/selection_button.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../routers.dart';

class FrequentlyVisited extends StatefulWidget {
  final Function onVerticalDragStart;
  final Function onVerticalDragUpdate;
  final Function onVerticalDragEnd;

  FrequentlyVisited(this.onVerticalDragStart, this.onVerticalDragUpdate,
      this.onVerticalDragEnd);

  @override
  _FrequentlyVisitedState createState() => _FrequentlyVisitedState();
}

class _FrequentlyVisitedState extends State<FrequentlyVisited> {
  bool _isExpanded = false;
  AccessType accessType = AccessType.Favorite;

  Map<AccessType, String> get accessTypeList => {
        AccessType.FrequentlyVisit: "Frequently visited sites",
        AccessType.Favorite: "Favorites sites",
      };

  void onSelectionListExpandOrCollapsed(bool isExpanded) {
    setState(() {
      _isExpanded = isExpanded;
    });
  }

  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context, listen: false);
    final organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);

    final S appText = S.of(context);
    var accessTypeList = {
      AccessType.FrequentlyVisit: appText.frequently_visited_sites,
      AccessType.Favorite: appText.favorites_sites,
    };
    return Expanded(
      child: GestureDetector(
        onVerticalDragStart: widget.onVerticalDragStart,
        onVerticalDragUpdate: widget.onVerticalDragUpdate,
        onVerticalDragEnd: widget.onVerticalDragEnd,
        behavior: HitTestBehavior.opaque,
        child: Container(
          color: appModel.isDarkTheme ? akvaDarkColorF : akvaLightColorA,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              SelectionButton(
                  selectionList: accessTypeList,
                  selectedItem: accessType,
                  selectedItemChanged: (_, type) {
                    setState(() {
                      accessType = type as AccessType;
                    });
                  },
                  onSelectionListExpandOrCollapsed: (_) {},
                  formatSelectionHintText: null,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  childrenMainAxisAlignment: MainAxisAlignment.start,
                  height: 70,
                  arrowIconColor:
                      appModel.isDarkTheme ? akvaMainNeutral : akvaLightTextA),
              Divider(
                color: appModel.isDarkTheme ? akvaDarkColorB : akvaDarkTextA,
                height: 0,
                thickness: 1,
              ),
              _isExpanded
                  ? Container()
                  : FavoriteVisitList(
                      organizationModel.getAccessList(accessType),
                      (context, id) {
                      organizationModel.visit(id);
                      Navigator.pushNamed(context, Routers.main);
                    }, widget.onVerticalDragStart, widget.onVerticalDragUpdate,
                      widget.onVerticalDragEnd),
            ],
          ),
        ),
      ),
    );
  }
}

class VisitUnit extends StatelessWidget {
  final OrganizationUnit _item;

  VisitUnit(OrganizationUnit item) : _item = item;

  @override
  Widget build(BuildContext context) {
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);
    return Row(
      children: <Widget>[
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.only(top: 10, left: 26),
                child: Text(
                  _item.siteName,
                  style: new TextStyle(fontSize: 18),
                ),
              ),
              _item.departmentName != null
                  ? Padding(
                      padding: EdgeInsets.only(bottom: 10, left: 26),
                      child: Text(
                        _item.departmentName,
                        style: new TextStyle(fontSize: 18),
                      ),
                    )
                  : Container(),
            ],
          ),
        ),
        Padding(
          padding: EdgeInsets.only(right: 25),
          child: Icon(
            AkvaIcons.right_arrow,
            color: appModel.isDarkTheme ? akvaMainNeutral : akvaLightTextA,
          ),
        )
      ],
    );
  }
}

class FavoriteVisitList extends StatelessWidget {
  final List<OrganizationUnit> visitList;
  final Function(BuildContext context, String id) onSiteTap;

  final Function onVerticalDragStart;
  final Function onVerticalDragUpdate;
  final Function onVerticalDragEnd;

  FavoriteVisitList(this.visitList, this.onSiteTap, this.onVerticalDragStart,
      this.onVerticalDragUpdate, this.onVerticalDragEnd);

  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context, listen: false);
    return Expanded(
      child: GestureDetector(
        onVerticalDragStart: onVerticalDragStart,
        onVerticalDragUpdate: onVerticalDragUpdate,
        onVerticalDragEnd: onVerticalDragEnd,
        behavior: HitTestBehavior.translucent,
        child: Container(
          child: MediaQuery.removePadding(
            context: context,
            removeTop: true,
            child: visitList.length > 0
                ? ListView.builder(
                    key: UniqueKey(),
                    itemCount: visitList.length,
                    itemBuilder: (context, index) {
                      return Card(
                        elevation: 0.4,
                        margin: const EdgeInsets.symmetric(
                            horizontal: 1, vertical: 0.2),
                        shape: BeveledRectangleBorder(),
                        color: appModel.isDarkTheme
                            ? akvaDarkColorA
                            : akvaLightColorB,
                        child: InkWell(
                          child: VisitUnit(visitList[index]),
                          onTap: () {
                            // Navigate to Detail Screen
                            if (onSiteTap != null) {
                              onSiteTap(context, visitList[index].id);
                            }
                          },
                        ),
                      );
                    },
                  )
                : Container(color: appModel.isDarkTheme ? akvaDarkColorF : akvaLightColorA,),
          ),
        ),
      ),
    );
  }
}

import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import '../app_model.dart';

class RegistrationScreenHeader extends StatelessWidget {
  final String title;
  final String unitName;
  final VoidCallback onBack;

  RegistrationScreenHeader(
      {@required this.title, @required this.unitName, this.onBack});

  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context);

    return Container(
      padding: EdgeInsets.only(left: 20, right: 20, top: 25),
      child: Column(
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              BackButton(
                onBack: () => onBack(),
              ),
              // Icon(
              //   AkvaIcons.history,
              //   size: 24,
              //   color:
              //       appModel.isDarkTheme ? akvaDarkTextA : akvaMainLiveAction,
              // ),
            ],
          ),
          Padding(
              padding: EdgeInsets.only(top: 30, left: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  HeaderText(title),
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: appModel.isDarkTheme
                            ? akvaDarkTextA
                            : akvaLightTextA,
                      ),
                    ),
                    child: Padding(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 6, vertical: 2),
                      child: Text(
                        unitName,
                        style: TextStyle(fontSize: 12),
                      ),
                    ),
                  )
                ],
              ))
        ],
      ),
    );
  }
}

class BackButton extends StatelessWidget {
  final VoidCallback onBack;

  const BackButton({Key key, this.onBack}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context);
    var appText = S.of(context);

    return FlatButton(
      materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
      padding: EdgeInsets.zero,
      onPressed: () => onBack(),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Icon(
            AkvaIcons.back_circle,
            size: 24,
            color: appModel.isDarkTheme ? akvaDarkTextA : akvaMainLiveAction,
          ),
          SizedBox(
            width: 10,
          ),
          Container(
            padding: EdgeInsets.only(top: 2, bottom: 2),
            child: Text(
              appText.back,
              style: TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.normal,
                color:
                    appModel.isDarkTheme ? akvaDarkTextA : akvaMainLiveAction,
              ),
            ),
          )
        ],
      ),
    );
  }
}

class HeaderText extends StatelessWidget {
  final String text;
  HeaderText(this.text);
  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: TextStyle(
        fontSize: FontSize.medium,
        fontWeight: FontWeight.normal,
        color: Provider.of<AppModel>(context).isDarkTheme
            ? akvaDarkTextA
            : akvaLightTextA,
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

class WarningWidget extends StatelessWidget {
  final String message;
  WarningWidget({this.message});

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Center(
        child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
          Text(
            message,
            style: TextStyle(fontSize: 24),
          ),
          Opacity(
            opacity: 0.1,
            child:
                SvgPicture.asset('assets/warning.svg', width: 256, height: 256),
          ),
        ]),
      ),
    );
  }
}

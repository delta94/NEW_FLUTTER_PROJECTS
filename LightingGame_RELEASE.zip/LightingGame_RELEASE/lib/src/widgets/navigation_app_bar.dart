import 'package:Commons/buttons.dart';
import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/util/utils.dart';
import 'package:control_app/src/widgets/selection_button.dart';
import 'package:control_app/src/widgets/synchronize_progress_status.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';
import 'package:control_app/src/util/scan_qr.dart';

import 'offline_status.dart';

class NavigationAppBar extends StatelessWidget {
  Map<dynamic, String> _appModes(BuildContext context) {
    return {
      AppMode.Landbased: S.of(context).landbased,
      AppMode.Seabased: S.of(context).seabased,
    };
  }

  onselectedItemChanged(BuildContext context, dynamic accessType) {
    var appMode = accessType as AppMode;
    if (appMode != null) {
      var appModel = Provider.of<AppModel>(context, listen: false);
      appModel.setAppMode(appMode);
    }
  }

  void onSelectionListExpandOrCollapsed(bool isExpaned) {}

  @override
  Widget build(BuildContext context) {
    var appModel = Provider.of<AppModel>(context);
    var shortname = getShortName(appModel);

    var safePadding = MediaQuery.of(context).padding.top;
    return Material(
      color: appModel.isDarkTheme ? akvaDarkColorF : akvaDarkColorE,
      child: Column(
        children: <Widget>[
          Padding(
            padding: EdgeInsets.only(top: safePadding),
          ),
          SynchronizeProgressStatus(),
          OfflineStatus(),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Padding(
                padding: EdgeInsets.only(left: 23, top: 15),
                child: SizedBox.fromSize(
                  size: Size(32, 32), // button width and height
                  child: ClipOval(
                    child: Material(
                      color: akvaMainNeutral, // button color
                      child: InkWell(
                        splashColor: Colors.green, // splash color
                        onTap: () {
                          Scaffold.of(context).openDrawer();
                        }, // button pressed
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            Text(
                              shortname,
                              style: TextStyle(
                                  color: appModel.isDarkTheme
                                      ? akvaDarkColorB
                                      : akvaLightColorB,
                                  fontSize: FontSize.xsmall,
                                  fontWeight: FontWeight.bold),
                            ), // text
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'Fishtalk Control',
                      style: new TextStyle(
                        fontSize: FontSize.medium,
                        color: appModel.isDarkTheme
                            ? akvaDarkTextA
                            : akvaLightColorB,
                      ),
                    ),
                    SelectionButton(
                      selectionList: _appModes(context),
                      selectedItem: appModel.appMode,
                      selectedItemChanged: onselectedItemChanged,
                      onSelectionListExpandOrCollapsed:
                          onSelectionListExpandOrCollapsed,
                      formatSelectionHintText: null,
                      mainAxisAlignment: MainAxisAlignment.center,
                      childrenMainAxisAlignment: MainAxisAlignment.center,
                      height: 35,
                      hintTextColor: appModel.isDarkTheme
                          ? akvaMainNeutral
                          : akvaMainLiveAction,
                      selectionItemTextColor: appModel.isDarkTheme
                          ? akvaDarkTextA
                          : akvaLightColorB,
                      arrowIconColor: appModel.isDarkTheme
                          ? akvaMainNeutral
                          : akvaMainLiveAction,
                    ),
                    SizedBox(
                      height: 6,
                    ),
                  ],
                ),
              ),
              Padding(
                padding: EdgeInsets.only(right: 40, top: 15),
                child: SizedBox.fromSize(
                  size: Size(32, 32), // button width and height
                  child: Visibility(
                      visible: appModel.appMode == AppMode.Seabased,
                      child: AkvaSecondaryButton.iconOnly(
                        icon: AkvaIcons.barcode,
                        onPressed: () {
                          navigateByQR(context);
                        },
                      )),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

import 'package:Commons/colors.dart';
import 'package:control_app/src/app_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class TabButton extends StatelessWidget {
  final String title;
  final bool isActive;
  final VoidCallback onPress;

  TabButton({this.title, this.isActive, this.onPress});

  @override
  Widget build(BuildContext context) {
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);

    return Expanded(
      child: Container(
        alignment: Alignment.center,
        decoration: BoxDecoration(
          border: isActive
              ? Border(
                  bottom: BorderSide(color: akvaMainAction, width: 4),
                )
              : null,
        ),
        child: FlatButton(
          color: _getTabColor(appModel, isActive),
          shape: new RoundedRectangleBorder(
            side: BorderSide(color: Colors.transparent),
            borderRadius: BorderRadius.all(Radius.zero),
          ),
          onPressed: onPress,
          child: Column(
            children: <Widget>[
              Expanded(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.only(top: isActive ? 4 : 0),
                      child: Text(
                        title,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.normal,
                          color: _getTitleColor(appModel, isActive),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getTitleColor(AppModel appModel, bool isActive) {
    if (isActive) {
      return appModel.isDarkTheme ? akvaDarkTextA : akvaLightTextA;
    } else {
      return appModel.isDarkTheme ? akvaDarkTextB : akvaLightTextB;
    }
  }

  Color _getTabColor(AppModel appModel, bool isActive) {
    if (isActive) {
      return appModel.isDarkTheme ? akvaDarkColorE : akvaLightColorE;
    } else {
      return appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorC;
    }
  }
}

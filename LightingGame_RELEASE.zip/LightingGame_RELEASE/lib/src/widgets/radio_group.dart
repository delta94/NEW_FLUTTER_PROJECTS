import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/src/app_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class RadioGroup extends StatelessWidget {
  final Axis direction;
  final int currentRadioIndex;
  final bool enable;
  final List<String> radioTitles;
  final Function(int) onChangeRadioIndex;

  RadioGroup({
    Key key,
    @required this.direction,
    this.enable: true,
    @required this.currentRadioIndex,
    @required this.radioTitles,
    @required this.onChangeRadioIndex,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    _buildRadioList() {
      List<Widget> radios = [];
      radioTitles.asMap().forEach((index, radioTitle) {
        if (index != 0)
          radios.add(SizedBox(
            width: direction == Axis.horizontal ? 20 : 0,
            height: direction == Axis.vertical ? 20 : 0,
          ));
        radios.add(RadioButton(
          enableRadioGroup: enable,
          currentRadioValue: currentRadioIndex,
          radioTitle: radioTitle,
          radioValue: index,
          onTap: (newRadioIndex) =>
              enable ? onChangeRadioIndex(newRadioIndex) : null,
        ));
      });

      return radios;
    }

    return direction == Axis.horizontal
        ? Row(
            children: _buildRadioList(),
          )
        : Column(
            children: _buildRadioList(),
          );
  }
}

class RadioButton extends StatelessWidget {
  const RadioButton(
      {Key key,
      this.radioValue,
      this.enableRadioGroup,
      this.radioTitle,
      this.currentRadioValue,
      this.onTap,
      this.paddingRight: 0})
      : super(key: key);

  final int radioValue;
  final bool enableRadioGroup;
  final String radioTitle;
  final int currentRadioValue;
  final double paddingRight;
  final Function(int) onTap;

  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context, listen: false);

    Color _getCircleColor() {
      if (radioValue == currentRadioValue) {
        return enableRadioGroup ? akvaMainAction : akvaMainActionDisabled;
      } else {
        return appModel.isDarkTheme ? akvaDarkColorC : akvaLightColorC;
      }
    }

    return InkWell(
      onTap: () => onTap(radioValue),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Container(
            width: 24,
            height: 24,
            decoration: BoxDecoration(
              color: appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorB,
              shape: BoxShape.circle,
              border: new Border.all(
                color: appModel.isDarkTheme ? akvaDarkColorE : akvaLightColorE,
                width: 1.0,
              ),
            ),
            child: Padding(
              padding: const EdgeInsets.all(5),
              child: Container(
                width: 6,
                height: 6,
                decoration: BoxDecoration(
                  color: _getCircleColor(),
                  borderRadius: new BorderRadius.all(new Radius.circular(30)),
                ),
              ),
            ),
          ),
          SizedBox(width: 8),
          Container(
            padding: EdgeInsets.only(top: 2),
            constraints: new BoxConstraints(
                maxWidth: MediaQuery.of(context).size.width - 91),
            child: Text(
              radioTitle,
              textAlign: TextAlign.start,
              style: TextStyle(
                  fontSize: FontSize.small,
                  fontWeight: FontWeight.normal,
                  color: appModel.isDarkTheme ? akvaDarkTextA : akvaDarkColorD),
            ),
          ),
        ],
      ),
    );
  }
}

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

import 'widgets/date_picker_dialog.dart';

typedef SelectableDayPredicate = bool Function(DateTime day);

Future<DateTime> showControlAppDatePicker(
    {@required BuildContext context,
    DateTime initialDate,
    DateTime firstDate,
    DateTime lastDate,
    bool barrierDismissible = false}) async {
  initialDate ??= DateTime.now();
  firstDate ??= DateTime(initialDate.year - 50);
  lastDate ??= DateTime(initialDate.year + 50);

  return await showDatePickerDialog(
    context: context,
    builder: (_) => GestureDetector(
      onTap: () {
        if (!barrierDismissible) {
          Navigator.pop(context);
        }
      },
      child: DatePickerDialog(
        initialDate: initialDate,
        firstDate: firstDate,
        lastDate: lastDate,
      ),
    ),
  );
}

Future showDatePickerDialog({
  @required BuildContext context,
  WidgetBuilder builder,
}) {
  return showGeneralDialog(
    context: context,
    pageBuilder: (BuildContext buildContext, Animation<double> animation,
        Animation<double> secondaryAnimation) {
      return SafeArea(
        child: Builder(builder: builder),
      );
    },
    barrierDismissible: true,
    barrierLabel: MaterialLocalizations.of(context).modalBarrierDismissLabel,
    transitionDuration: const Duration(milliseconds: 150),
  );
}

import 'package:control_app/generated/l10n.dart';

class DatePickerUtils {
  static String getMonthYear(DateTime dateTime, S appText) {
    List<String> languageMonths = [
      appText.january,
      appText.february,
      appText.march,
      appText.april,
      appText.may,
      appText.june,
      appText.july,
      appText.august,
      appText.september,
      appText.october,
      appText.november,
      appText.december
    ];

    String _year = dateTime.year.toString();
    String _month = languageMonths[dateTime.month - DateTime.january];
    return '$_month $_year';
  }
}

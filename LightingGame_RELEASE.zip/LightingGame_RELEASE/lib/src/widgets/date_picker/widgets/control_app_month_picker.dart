import 'dart:async';

import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/widgets/date_picker/date_picker_utils.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';
import 'package:provider/provider.dart';

import 'control_app_day_picker.dart';

const Duration _kMonthScrollDuration = Duration(milliseconds: 200);

class ControlAppMonthPicker extends StatefulWidget {
  ControlAppMonthPicker({
    Key key,
    @required this.selectedDate,
    @required this.onChanged,
    @required this.firstDate,
    @required this.lastDate,
    this.dragStartBehavior = DragStartBehavior.start,
  })  : assert(selectedDate != null),
        assert(onChanged != null),
        assert(!firstDate.isAfter(lastDate)),
        super(key: key);

  final DateTime selectedDate;
  final ValueChanged<DateTime> onChanged;
  final DateTime firstDate;
  final DateTime lastDate;
  final DragStartBehavior dragStartBehavior;

  @override
  _ControlAppMonthPickerState createState() => _ControlAppMonthPickerState();
}

class _ControlAppMonthPickerState extends State<ControlAppMonthPicker> {
  @override
  void initState() {
    super.initState();
    // Initially display the pre-selected date.
    final int monthPage = _monthDelta(widget.firstDate, widget.selectedDate);
    _dayPickerController = PageController(initialPage: monthPage);
    _handleMonthPageChanged(monthPage);
    _updateCurrentDate();
  }

  @override
  void didUpdateWidget(ControlAppMonthPicker oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.selectedDate != oldWidget.selectedDate) {
      final int monthPage = _monthDelta(widget.firstDate, widget.selectedDate);
      _dayPickerController = PageController(initialPage: monthPage);
      _handleMonthPageChanged(monthPage);
    }
  }

  TextDirection textDirection;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    textDirection = Directionality.of(context);
  }

  DateTime _todayDate;
  Timer _timer;
  PageController _dayPickerController;
  int currentPage = 0;
  double datePickerHeight = 355;

  void _updateCurrentDate() {
    _todayDate = DateTime.now();
    final DateTime tomorrow =
        DateTime(_todayDate.year, _todayDate.month, _todayDate.day + 1);
    Duration timeUntilTomorrow = tomorrow.difference(_todayDate);
    // so we don't miss it by rounding
    timeUntilTomorrow += const Duration(seconds: 1);
    _timer?.cancel();
    _timer = Timer(timeUntilTomorrow, () {
      setState(() => _updateCurrentDate());
    });
  }

  static int _monthDelta(DateTime startDate, DateTime endDate) {
    return (endDate.year - startDate.year) * 12 +
        endDate.month -
        startDate.month;
  }

  /// Add months to a month truncated date.
  DateTime _addMonthsToMonthDate(DateTime monthDate, int monthsToAdd) {
    return DateTime(
      monthDate.year + monthsToAdd ~/ 12,
      monthDate.month + monthsToAdd % 12,
    );
  }

  Widget _buildItems(BuildContext context, int index) {
    final DateTime month = _addMonthsToMonthDate(widget.firstDate, index);
    return ControlAppDayPicker(
      key: ValueKey<DateTime>(month),
      selectedDate: widget.selectedDate,
      currentDate: _todayDate,
      onChanged: widget.onChanged,
      firstDate: widget.firstDate,
      lastDate: widget.lastDate,
      displayedMonth: month,
      dragStartBehavior: widget.dragStartBehavior,
    );
  }

  DateTime _nextMonthDate;
  DateTime _previousMonthDate;
  DateTime _nextYearDate;
  DateTime _previousYearDate;

  void _handleMonthPageChanged(int monthPage) {
    setState(() {
      currentPage = monthPage;
      _previousMonthDate =
          _addMonthsToMonthDate(widget.firstDate, monthPage - 1);
      _nextMonthDate = _addMonthsToMonthDate(widget.firstDate, monthPage + 1);

      _previousYearDate =
          _addMonthsToMonthDate(widget.firstDate, monthPage - 12);
      _nextYearDate = _addMonthsToMonthDate(widget.firstDate, monthPage + 12);
    });
  }

  @override
  Widget build(BuildContext context) {
    S appText = S.of(context);
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);

    void _handleNextMonth() {
      SemanticsService.announce(
        DatePickerUtils.getMonthYear(_nextMonthDate, appText),
        textDirection,
      );

      currentPage += 1;

      _dayPickerController.nextPage(
        duration: _kMonthScrollDuration,
        curve: Curves.ease,
      );
    }

    void _handlePreviousMonth() {
      SemanticsService.announce(
        DatePickerUtils.getMonthYear(_previousMonthDate, appText),
        textDirection,
      );

      currentPage -= 1;

      _dayPickerController.previousPage(
        duration: _kMonthScrollDuration,
        curve: Curves.ease,
      );
    }

    void _handleNextYear() {
      SemanticsService.announce(
        DatePickerUtils.getMonthYear(_nextYearDate, appText),
        textDirection,
      );

      currentPage += 12;
      _dayPickerController.animateToPage(currentPage,
          duration: _kMonthScrollDuration, curve: Curves.ease);
    }

    void _handlePreviousYear() {
      SemanticsService.announce(
        DatePickerUtils.getMonthYear(_previousYearDate, appText),
        textDirection,
      );

      currentPage -= 12;
      _dayPickerController.animateToPage(currentPage,
          duration: _kMonthScrollDuration, curve: Curves.ease);
    }

    return Container(
      color: Colors.transparent,
      padding: EdgeInsets.all(10),
      child: Stack(
        children: <Widget>[
          InkWell(
            onTap: () {},
            child: Container(
              color: appModel.isDarkTheme ? akvaDarkColorF : akvaLightColorC,
              height: datePickerHeight,
              padding: EdgeInsets.only(top: 9),
              child: PageView.builder(
                dragStartBehavior: widget.dragStartBehavior,
                key: ValueKey<DateTime>(widget.selectedDate),
                controller: _dayPickerController,
                scrollDirection: Axis.horizontal,
                itemCount: _monthDelta(widget.firstDate, widget.lastDate) + 1,
                itemBuilder: _buildItems,
                onPageChanged: _handleMonthPageChanged,
              ),
            ),
          ),

          /// Year Arrow Left
          PositionedDirectional(
            top: 20.0,
            start: 16.0,
            child: Semantics(
              sortKey: _MonthYearPickerSortKey.previousYear,
              child: ChangingMonthYearButton(
                icon: AkvaIcons.double_left_arrow,
                onTap: _handlePreviousYear,
              ),
            ),
          ),

          ///Month Arrow Left
          PositionedDirectional(
            top: 20.0,
            start: 65.0,
            child: Semantics(
              sortKey: _MonthYearPickerSortKey.previousMonth,
              child: ChangingMonthYearButton(
                icon: AkvaIcons.single_left_arrow,
                onTap: _handlePreviousMonth,
              ),
            ),
          ),

          /// Month Arrow Right
          PositionedDirectional(
            top: 20.0,
            end: 65.0,
            child: Semantics(
              sortKey: _MonthYearPickerSortKey.nextMonth,
              child: ChangingMonthYearButton(
                icon: AkvaIcons.single_right_arrow,
                onTap: _handleNextMonth,
              ),
            ),
          ),

          /// Year Arrow Right
          PositionedDirectional(
            top: 20.0,
            end: 16.0,
            child: Semantics(
              sortKey: _MonthYearPickerSortKey.nextYear,
              child: ChangingMonthYearButton(
                icon: AkvaIcons.double_right_arrow,
                onTap: _handleNextYear,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timer?.cancel();
    _dayPickerController?.dispose();
    super.dispose();
  }
}

class ChangingMonthYearButton extends StatefulWidget {
  const ChangingMonthYearButton({
    Key key,
    @required this.icon,
    @required this.onTap,
  }) : super(key: key);

  final IconData icon;
  final VoidCallback onTap;

  @override
  _ChangingMonthYearButtonState createState() =>
      _ChangingMonthYearButtonState();
}

class _ChangingMonthYearButtonState extends State<ChangingMonthYearButton>
    with SingleTickerProviderStateMixin {
  AnimationController _chevronOpacityController;
  Animation<double> _chevronOpacityAnimation;
  static final Animatable<double> _chevronOpacityTween =
      Tween<double>(begin: 1.0, end: 0.0)
          .chain(CurveTween(curve: Curves.easeInOut));

  @override
  void initState() {
    _chevronOpacityController = AnimationController(
      duration: const Duration(milliseconds: 250),
      vsync: this,
    );

    _chevronOpacityAnimation = _chevronOpacityController.drive(
      _chevronOpacityTween,
    );
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);
    return FadeTransition(
      opacity: _chevronOpacityAnimation,
      child: Material(
        color: appModel.isDarkTheme ? akvaDarkColorB : akvaMainLiveAction,
        borderRadius: BorderRadius.circular(4),
        child: InkWell(
          child: Padding(
            padding: EdgeInsets.all(10),
            child: Icon(
              widget.icon,
              size: FontSize.small,
              color: appModel.isDarkTheme ? akvaMainNeutral : akvaLightTextA,
            ),
          ),
          onTap: widget.onTap,
        ),
      ),
    );
  }

  @override
  void dispose() {
    _chevronOpacityController?.dispose();
    super.dispose();
  }
}

// Defines semantic traversal order of the top-level widgets inside the month
// picker.
class _MonthYearPickerSortKey extends OrdinalSortKey {
  const _MonthYearPickerSortKey(double order) : super(order);

  static const _MonthYearPickerSortKey previousMonth =
      _MonthYearPickerSortKey(1.0);
  static const _MonthYearPickerSortKey nextMonth = _MonthYearPickerSortKey(2.0);

  static const _MonthYearPickerSortKey previousYear =
      _MonthYearPickerSortKey(3.0);
  static const _MonthYearPickerSortKey nextYear = _MonthYearPickerSortKey(4.0);
}

import 'package:Commons/buttons.dart';
import 'package:Commons/colors.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/widgets/date_picker/widgets/control_app_month_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/semantics.dart';

class DatePickerDialog extends StatefulWidget {
  const DatePickerDialog({
    Key key,
    this.initialDate,
    this.firstDate,
    this.lastDate,
  }) : super(key: key);

  final DateTime initialDate;
  final DateTime firstDate;
  final DateTime lastDate;

  @override
  _DatePickerDialogState createState() => _DatePickerDialogState();
}

class _DatePickerDialogState extends State<DatePickerDialog> {
  @override
  void initState() {
    super.initState();
    _selectedDate = widget.initialDate;
  }

  bool _announcedInitialDate = false;

  TextDirection textDirection;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    textDirection = Directionality.of(context);
    if (!_announcedInitialDate) {
      _announcedInitialDate = true;
      SemanticsService.announce(
        _selectedDate.toString(),
        textDirection,
      );
    }
  }

  DateTime _selectedDate;
  final GlobalKey _pickerKey = GlobalKey();

  void _handleDayChanged(DateTime value) {
    setState(() {
      _selectedDate = value;
    });
  }

  void _handleSave() {
    Navigator.of(context).pop(_selectedDate);
  }

  @override
  Widget build(BuildContext context) {
    final S appText = S.of(context);
    return Material(
      color: Colors.transparent,
      child: Stack(
        children: [
          Opacity(opacity: 0.9, child: Container(color: akvaDarkColorA)),
          Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Container(),
              ControlAppMonthPicker(
                key: _pickerKey,
                selectedDate: _selectedDate,
                onChanged: _handleDayChanged,
                firstDate: widget.firstDate,
                lastDate: widget.lastDate,
              ),
              Container(
                padding: EdgeInsets.only(left: 19, right: 15, bottom: 30),
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: AkvaPrimaryButton(
                        onPressed: _handleSave,
                        label: appText.save,
                      ),
                    ),
                  ],
                ),
              )
            ],
          ),
        ],
      ),
    );
  }
}

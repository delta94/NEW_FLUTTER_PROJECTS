import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/widgets/date_picker/date_picker_utils.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/semantics.dart';
import 'dart:math' as math;

import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

const _DayPickerGridDelegate _kDayPickerGridDelegate = _DayPickerGridDelegate();
const double _kDayPickerRowHeight = 40.0;

typedef BuilderDayOfDatePicker = Widget Function(DateTime dateTime,
    bool isCurrentDay, bool selected, TextStyle defaultTextStyle);
typedef OnTapDay = bool Function(DateTime dateTime, bool available);

class _DayPickerGridDelegate extends SliverGridDelegate {
  const _DayPickerGridDelegate();

  @override
  SliverGridLayout getLayout(SliverConstraints constraints) {
    const int columnCount = DateTime.daysPerWeek;
    final double tileWidth = constraints.crossAxisExtent / columnCount;
    final double viewTileHeight = 34;
    final double tileHeight = math.max(_kDayPickerRowHeight, viewTileHeight);

    return SliverGridRegularTileLayout(
      crossAxisCount: columnCount,
      mainAxisStride: tileHeight,
      crossAxisStride: tileWidth,
      childMainAxisExtent: tileHeight,
      childCrossAxisExtent: tileWidth,
      reverseCrossAxis: axisDirectionIsReversed(constraints.crossAxisDirection),
    );
  }

  @override
  bool shouldRelayout(_DayPickerGridDelegate oldDelegate) => false;
}

class ControlAppDayPicker extends StatelessWidget {
  ControlAppDayPicker({
    Key key,
    @required this.selectedDate,
    @required this.currentDate,
    @required this.onChanged,
    @required this.firstDate,
    @required this.lastDate,
    @required this.displayedMonth,
    this.dragStartBehavior = DragStartBehavior.start,
  })  : assert(selectedDate != null),
        assert(currentDate != null),
        assert(onChanged != null),
        assert(displayedMonth != null),
        assert(dragStartBehavior != null),
        assert(!firstDate.isAfter(lastDate)),
        super(key: key);

  final DateTime selectedDate;
  final DateTime currentDate;
  final ValueChanged<DateTime> onChanged;
  final DateTime firstDate;
  final DateTime lastDate;
  final DateTime displayedMonth;
  final DragStartBehavior dragStartBehavior;

  List<Widget> _getDayHeaders(S appText) {
    List<String> customWeekDays = <String>[
      appText.mon,
      appText.tue,
      appText.wed,
      appText.thu,
      appText.fri,
      appText.sat,
      appText.sun
    ];

    final List<Widget> result = <Widget>[];
    for (int i = 0; i < 7; i++) {
      result.add(
        ExcludeSemantics(
          child: Center(
            child: Text(
              i < customWeekDays.length ? customWeekDays[i] : "",
              style: GoogleFonts.dmSans(
                color: akvaMainNeutral,
                fontWeight: FontWeight.bold,
                fontSize: FontSize.small,
              ),
            ),
          ),
        ),
      );
    }

    return result;
  }

  // Do not use this directly - call getDaysInMonth instead.
  static const List<int> _daysInMonth = <int>[
    31,
    -1,
    31,
    30,
    31,
    30,
    31,
    31,
    30,
    31,
    30,
    31
  ];

  static int getDaysInMonth(int year, int month) {
    if (month == DateTime.february) {
      final bool isLeapYear =
          (year % 4 == 0) && (year % 100 != 0) || (year % 400 == 0);
      if (isLeapYear) return 29;
      return 28;
    }
    return _daysInMonth[month - 1];
  }

  int _computeFirstDayOffset(int year, int month) {
    // 0-based day of week, with 0 representing Monday.
    final int weekdayFromMonday = DateTime(year, month).weekday - 1;
    // 1-based day of week, with 1 representing Monday.
    final int firstDayOfWeekFromSunday = 1;
    // firstDayOfWeekFromSunday recomputed to be Monday-based
    final int firstDayOfWeekFromMonday = (firstDayOfWeekFromSunday - 1) % 7;
    // Number of days between the first day of week appearing on the calendar,
    // and the day corresponding to the 1-st of the month.
    return (weekdayFromMonday - firstDayOfWeekFromMonday) % 7;
  }

  TextStyle getItemStyle(
      {bool isSelectedDay,
      bool disabled,
      bool isCurrentDay,
      AppModel appModel}) {
    Color color = appModel.isDarkTheme ? akvaDarkTextA : akvaLightTextA;
    FontWeight fontWeight = FontWeight.w500;

    if (isSelectedDay) {
      color = akvaDarkColorB;
      fontWeight = FontWeight.bold;
    } else if (disabled) {
      color = akvaMainNeutral;
    } else if (isCurrentDay) {
      color = akvaMainLiveAction;
    }

    return GoogleFonts.dmSans(
        color: color, fontWeight: fontWeight, fontSize: FontSize.small);
  }

  Widget getDayWidget(
      {Decoration decoration,
      TextStyle itemStyle,
      DateTime dayToBuild,
      int day,
      bool isSelectedDay,
      BuildContext context}) {
    Widget dayWidget = Container(
      decoration: decoration,
      padding: EdgeInsets.all(5),
      child: Center(
        child: Semantics(
          label: '$day',
          selected: isSelectedDay,
          sortKey: OrdinalSortKey(day.toDouble()),
          child: ExcludeSemantics(
            child: Text(
              day.toString(),
              style: itemStyle,
            ),
          ),
        ),
      ),
    );

    _onTapDay({bool isDoubleTap: false}) {
      bool allow = true;

      if ((dayToBuild.isAtSameMomentAs(firstDate) ||
              dayToBuild.isAfter(firstDate)) &&
          (dayToBuild.isAtSameMomentAs(lastDate) ||
              dayToBuild.isBefore(lastDate))) {
        allow = true;
      } else {
        allow = false;
      }

      if (allow) {
        onChanged(dayToBuild);
        if (isDoubleTap) Navigator.of(context).pop(dayToBuild);
      }
    }

    dayWidget = GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: _onTapDay,
      onDoubleTap: () => _onTapDay(isDoubleTap: true),
      child: dayWidget,
      dragStartBehavior: dragStartBehavior,
    );

    return dayWidget;
  }

  @override
  Widget build(BuildContext context) {
    S appText = S.of(context);
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);

    final int year = displayedMonth.year;
    final int month = displayedMonth.month;
    final int daysInMonth = getDaysInMonth(year, month);
    final int firstDayOffset = _computeFirstDayOffset(
      year,
      month,
    );

    final List<Widget> labels = [];
    for (int i = 0; true; i += 1) {
      // 1-based day of month, e.g. 1-31 for January, and 1-29 for February on
      // a leap year.
      final int day = i - firstDayOffset + 1;
      final DateTime dayToBuild = DateTime(year, month, day);
      if (day > daysInMonth) break;
      if (day < 1) {
        labels.add(
          Container(),
        );
      } else {
        BoxDecoration decoration;
        bool disabled = false;
        if (dayToBuild.weekday < 1 || dayToBuild.weekday > 5) {
          disabled = true;
        }

        final bool isSelectedDay = selectedDate.year == year &&
            selectedDate.month == month &&
            selectedDate.day == day;
        final bool isCurrentDay = currentDate.year == year &&
            currentDate.month == month &&
            currentDate.day == day;

        if (isSelectedDay) {
          decoration = BoxDecoration(
            color: akvaMainAction,
            shape: BoxShape.circle,
          );
        }

        TextStyle itemStyle = getItemStyle(
            disabled: disabled,
            isCurrentDay: isCurrentDay,
            isSelectedDay: isSelectedDay,
            appModel: appModel);

        labels.add(
          getDayWidget(
            decoration: decoration,
            itemStyle: itemStyle,
            dayToBuild: dayToBuild,
            day: day,
            isSelectedDay: isSelectedDay,
            context: context,
          ),
        );
      }
    }

    String monthYearHeader =
        DatePickerUtils.getMonthYear(displayedMonth, appText);

    return Container(
      child: Padding(
        padding: EdgeInsets.symmetric(horizontal: 4, vertical: 5),
        child: Column(
          children: <Widget>[
            SizedBox(height: 10),
            Center(
              child: ExcludeSemantics(
                child: Text(
                  monthYearHeader,
                  style: GoogleFonts.dmSans(
                    color:
                        appModel.isDarkTheme ? akvaDarkTextA : akvaLightTextA,
                    fontSize: FontSize.medium,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
            ),
            SizedBox(height: 25),
            Divider(
              thickness: 1,
              height: 1,
              color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: _getDayHeaders(appText),
              ),
            ),
            Divider(
              thickness: 1,
              height: 1,
              color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
            ),
            SizedBox(height: 12),
            Flexible(
              child: GridView.custom(
                gridDelegate: _kDayPickerGridDelegate,
                childrenDelegate: SliverChildListDelegate(
                  labels,
                  addRepaintBoundaries: false,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

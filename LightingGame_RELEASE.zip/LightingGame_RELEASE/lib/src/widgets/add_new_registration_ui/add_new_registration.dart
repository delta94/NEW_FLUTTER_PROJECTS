import 'package:Commons/dropdown.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/base/registration_view_model_factory.dart';
import 'package:control_app/src/culling/view_models/culling_registration_view_model.dart';
import 'package:control_app/src/culling/view_models/salmon_culling_registration_view_model.dart';
import 'package:control_app/src/database/yesterday_db_repository.dart';
import 'package:control_app/src/models/base/base_cause.dart';
import 'package:control_app/src/models/culling/culling.dart';
import 'package:control_app/src/models/culling/culling_registration.dart';
import 'package:control_app/src/models/feeding/feed_type_available.dart';
import 'package:control_app/src/models/feeding/feeding.dart';
import 'package:control_app/src/models/mortality/mortality.dart';
import 'package:control_app/src/models/yesterday_cause.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/models/species.dart';
import 'Package:flutter/material.dart';
import 'package:Commons/colors.dart';
import 'package:control_app/src/models/yesterday_feedtype.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/services/timezone_service.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:control_app/src/util/utils.dart';
import 'package:control_app/src/widgets/cleaner_fishes.dart';
import 'package:control_app/src/widgets/new_registration_screen.dart';
import 'package:control_app/src/widgets/number_input.dart';
import 'package:control_app/src/widgets/radio_group.dart';
import 'package:control_app/src/widgets/registration_amount_count_list.dart';
import 'package:control_app/src/widgets/registration_ui/registration_amount_count_item.dart';
import 'package:control_app/src/widgets/total_amount_count.dart';
import 'package:control_app/src/widgets/yesterday_choices.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';

class AddNewRegistration extends StatefulWidget {
  final RegistrationType registrationType;
  final Widget child;
  AddNewRegistration({@required this.registrationType, this.child});
  @override
  _AddNewRegistrationState createState() => _AddNewRegistrationState();
}

class _AddNewRegistrationState extends State<AddNewRegistration> {
  Map<int, List<OptionItem>> selectedOptionItemMap = {};
  bool isAllowedToSave = false;
  int numberOfDeath = 0;
  int selectedFishId;
  bool isSalmonTabActive = false;
  DateTime registrationDateTime;
  Registration currentRegistration;
  List<dynamic> yesterdayTypes = List<dynamic>();
  YesterdayDBRepository yesterdayRepos;

  /// Below properties are for culling only
  int currentRadioIndex = 1;
  bool enableRadioGroup = false;

  @override
  void initState() {
    isSalmonTabActive =
        Provider.of<SharedDataModel>(context, listen: false).isSalmonTabActive;
    RegistrationViewModel model = RegistrationViewModelFactory.create(
        context, widget.registrationType,
        isForSalmon: isSalmonTabActive, listen: false);

    Site site = model.organizationModel.currentSite;
    this.registrationDateTime =
        TimeZoneService.convertToTimezone(DateTime.now(), site.timeZoneId);
    yesterdayRepos =
        YesterdayDBRepositoryFactory.create(widget.registrationType);
    setDefaultCleanerFishId();
    getOrCreateRegistration(model);
    getYesterdaysTypes().then((result) {
      setState(() {
        yesterdayTypes = result;
      });
    });

    super.initState();
  }

  setDefaultCleanerFishId() {
    var organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);
    if (isSalmonTabActive) {
      selectedFishId = 1;
    } else {
      List<Species> species = organizationModel.speciesOfCurrentUnit
          .where((specie) => specie.speciesId != 1)
          .toList();
      if (species.isNotEmpty) {
        selectedFishId = species[0].speciesId;
      }
    }
  }

  _getTypesList() {
    List<dynamic> _types;
    var sharedDataModel =
        Provider.of<SharedDataModel>(this.context, listen: false);
    switch (widget.registrationType) {
      case RegistrationType.Mortality:
        _types = sharedDataModel.causesOfDeath;
        break;
      case RegistrationType.Culling:
        _types = sharedDataModel.cullingCauses;
        break;
      default:
        var organizationModel =
            Provider.of<OrganizationModel>(this.context, listen: false);
        _types = organizationModel.feedTypesOfCurrentUnit;
        break;
    }
    return _types;
  }

  List<dynamic> convertYesterdayTypes(List<dynamic> types) {
    List<dynamic> result = List<dynamic>();
    var sharedDataModel =
        Provider.of<SharedDataModel>(this.context, listen: false);
    RegistrationViewModel model = RegistrationViewModelFactory.create(
        context, widget.registrationType,
        isForSalmon: sharedDataModel.isSalmonTabActive, listen: false);
    List<dynamic> _types = _getTypesList();

    _types = model.filterByFishType(_types, model.isForSalmon);
    if (_types != null) {
      types.forEach((type) {
        dynamic existed = _types.firstWhere((item) {
          if (item is BaseCause) {
            return item.causeId == type.causeId;
          } else if (item is FeedTypeAvailable) {
            return item.feedTypeId == type.feedTypeId &&
                item.feedStoreId == type.feedStoreId;
          }

          return false;
        }, orElse: () => null);

        if (existed != null) result.add(existed);
      });
    }
    return result;
  }

  Future<List<dynamic>> getYesterdaysTypes() async {
    final username = Provider.of<AppModel>(this.context, listen: false)
        .currentUserInfo
        .email;

    final organizationModel =
        Provider.of<OrganizationModel>(this.context, listen: false);

    final unitId = organizationModel.currentUnit.id;

    var yesterdayCauses =
        await yesterdayRepos.getByUsernameAndUnitId(username, unitId);

    return convertYesterdayTypes(yesterdayCauses);
  }

  getOrCreateRegistration(RegistrationViewModel model) async {
    if (model.isForSalmon) {
      this.currentRegistration = await model.addNewRegistration(1);
      this.currentRegistration.time = registrationDateTime;
      selectedOptionItemMap[selectedFishId] = [];
    } else {
      if (selectedFishId != null) {
        var registration = model.newRegistrations.firstWhere(
            (registration) => (registration.speciesId == selectedFishId &&
                registration.time == registrationDateTime),
            orElse: () => null);

        if (registration == null) {
          this.currentRegistration =
              await model.addNewRegistration(selectedFishId);
          this.currentRegistration.time = registrationDateTime;
          selectedOptionItemMap[selectedFishId] = [];
        } else {
          this.currentRegistration = registration;
        }
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context);
    SharedDataModel sharedDataModel =
        Provider.of<SharedDataModel>(this.context, listen: false);
    List<dynamic> causesList = _getTypesList();
    final isSalmonTabActive = sharedDataModel.isSalmonTabActive;
    RegistrationViewModel model = RegistrationViewModelFactory.create(
        context, widget.registrationType,
        isForSalmon: isSalmonTabActive);

    // Filter causes by fish type
    causesList = model.filterByFishType(causesList, model.isForSalmon);

    final organizationModel =
        Provider.of<OrganizationModel>(this.context, listen: false);

    List<Registration> _getCurrentRegistrations() {
      return model.newRegistrations
          .where((registration) => (registration.time == registrationDateTime))
          .toList();
    }

    void _validateData() {
      bool isValidated = false;
      List<Registration> registrations = _getCurrentRegistrations();

      var hasAnyCount =
          registrations.any((registration) => !registration.item.isEmpty);
      var isAnyInvalidCount = false;
      for (final registration in registrations) {
        isAnyInvalidCount = !registration.item.isValidData;
        if (isAnyInvalidCount) break;
      }

      isValidated = hasAnyCount & !isAnyInvalidCount;
      Future.delayed(Duration.zero, () {
        setState(() {
          isAllowedToSave = isValidated;
        });
      });
    }

    _updateSelector() {
      if (currentRegistration.item.isEmpty) {
        selectedOptionItemMap[selectedFishId] = [];
      }
    }

    validate() {
      _updateSelector();
      _validateData();
    }

    _getSelectedCause(OptionItem newOptionItem) {
      if (widget.registrationType == RegistrationType.Feeding) {
        return causesList.firstWhere(
            (cause) =>
                cause.feedStoreId == newOptionItem.id.feedStoreId &&
                cause.feedTypeId == newOptionItem.id.feedTypeId,
            orElse: () => null);
      } else {
        return causesList.firstWhere(
            (cause) => cause.causeId == newOptionItem.id,
            orElse: () => null);
      }
    }

    setCullingCount({OptionItem newOptionItem, dynamic selectedItem}) {
      if (currentRegistration.item.isEmpty) {
        CullingRegistrationViewModel cullingRegistrationViewModel =
            (model as CullingRegistrationViewModel);
        int count = currentRadioIndex == 0
            ? cullingRegistrationViewModel.getStockNumber()
            : 0;
        currentRegistration.item.addItem(selectedItem, count.toDouble());
      } else {
        var obj = currentRegistration.item.countObjAt(0);
        (obj as Culling).cullingCauseId = newOptionItem.id;
      }
    }

    Future<void> onCauseChanged(OptionItem newOptionItem) async {
      var selectedItem = _getSelectedCause(newOptionItem);
      bool isNewCauseAvailable = false;
      if (currentRegistration != null) {
        isNewCauseAvailable = selectedOptionItemMap[selectedFishId].any(
            (selectedOptionItem) => selectedOptionItem.id == newOptionItem.id);
      } else {
        this.currentRegistration =
            await model.addNewRegistration(selectedFishId);
      }

      if (currentRegistration != null && !isNewCauseAvailable) {
        if (widget.registrationType == RegistrationType.Culling &&
            currentRadioIndex == 0) {
          setCullingCount(
              newOptionItem: newOptionItem, selectedItem: selectedItem);
        } else {
          currentRegistration.item.addItem(selectedItem, 0.0);
        }

        selectedOptionItemMap[selectedFishId].add(newOptionItem);
        validate();
      }
    }

    Future<void> onTapCleanerFish(int cleanerFishId) async {
      if (cleanerFishId != selectedFishId) {
        selectedFishId = cleanerFishId;
        await getOrCreateRegistration(model);
        validate();
      }
    }

    onChangeCount(Registration registration, int index, dynamic newCount) {
      final obj = registration.item.countObjAt(index);
      registration.item.updateItem(obj, newCount);
      validate();
    }

    onRemoveCount(Registration registration, int index) {
      final obj = registration.item.countObjAt(index);
      registration.item.removeItem(obj);
      if (selectedOptionItemMap.isNotEmpty)
        selectedOptionItemMap[registration.speciesId].removeAt(index);
      validate();
    }

    RegistrationUserRight registrationUserRight =
        organizationModel.registrationUserRightMap[widget.registrationType];
    _buildCountItems() {
      List<Widget> countItems = new List<Widget>();
      var registrations = _getCurrentRegistrations();
      registrations.forEach((registration) {
        for (int i = 0; i < registration.item.length; i++) {
          countItems.add(
            Padding(
              padding: const EdgeInsets.only(left: 15),
              child: RegistrationAmountCountItem(
                allowDelete: registrationUserRight.allowWrite,
                numberInputType:
                    widget.registrationType == RegistrationType.Feeding
                        ? NumberInputType.DECIMAL
                        : NumberInputType.INT,
                key: ObjectKey(registration.item.countObjAt(i)),
                enable:
                    currentRadioIndex != 0 && registrationUserRight.allowWrite,
                registrationType: widget.registrationType,
                countNum: registration.item.countAt(i),
                title: registration.item.countTitle(context, i),
                speciesId: registration.speciesId,
                onChangeCount: (newCount) => onChangeCount(
                    registration,
                    i,
                    widget.registrationType != RegistrationType.Feeding
                        ? newCount.round()
                        : newCount),
                onDelete: () => onRemoveCount(registration, i),
              ),
            ),
          );
        }
      });
      return countItems;
    }

    _addFavoriteCauses() async {
      var registrations = _getCurrentRegistrations();

      var causes = yesterdayRepos.items;

      registrations.forEach((registration) {
        if (!registration.item.isEmpty) {
          for (int i = 0; i < registration.item.length; i++) {
            var obj = registration.item.countObjAt(i);
            if (widget.registrationType == RegistrationType.Mortality ||
                widget.registrationType == RegistrationType.Culling) {
              int causeId;

              if (obj is Mortality) {
                causeId = obj.mortalityCauseId;
              } else if (obj is Culling) {
                causeId = obj.cullingCauseId;
              }
              if (causeId != null) {
                YesterdayCause cause = YesterdayCause(
                    appModel.currentUserInfo.email,
                    causeId,
                    organizationModel.currentOrganizationEntity.id);

                if (!causes.contains(cause)) {
                  causes.add(cause);
                }
              }
            } else {
              YesterdayFeedType cause = YesterdayFeedType(
                appModel.currentUserInfo.email,
                organizationModel.currentUnit.id,
                (obj as Feeding).feedStoreId,
                (obj as Feeding).feedTypeId,
              );

              if (!causes.contains(cause)) {
                causes.add(cause);
              }
            }
          }
        }
      });

      await yesterdayRepos.insert(causes);
    }

    _getTotalCount() {
      List<Registration> currentRegistrations = _getCurrentRegistrations();
      return model.getRegistrationsTotalCount(currentRegistrations);
    }

    _getSelectorOptionList(List<dynamic> causes) {
      List<OptionItem> selectorOptions = [];
      causes.forEach((cause) {
        var id = (cause is FeedTypeAvailable) ? cause : cause.causeId;
        selectorOptions.add(new OptionItem(id: id, label: cause.name));
      });

      return selectorOptions;
    }

    /// Functions specific for culling only
    _cullingBasedOnRadioOption() {
      List<Registration> currentRegistrations = _getCurrentRegistrations();
      currentRegistrations.forEach((registration) {
        if (!registration.item.isEmpty) {
          if (currentRadioIndex == 0) {
            (model as SalmonCullingRegistrationViewModel)
                .culledEntireUnit(registrationDateTime, registration.speciesId);
          } else {
            (model as SalmonCullingRegistrationViewModel)
                .uncheckCulledEntireUnit(
                    registrationDateTime, registration.speciesId);
          }
        }
      });

      validate();
    }

    _onChangeRadio(int newRadioValue) {
      currentRadioIndex = newRadioValue;
      _cullingBasedOnRadioOption();
    }

    _enableCullledEntireUnit() {
      if (widget.registrationType == RegistrationType.Culling) {
        List<Registration> currentRegistrations = _getCurrentRegistrations();
        enableRadioGroup = true;
        for (var currentRegistration in currentRegistrations) {
          if (currentRegistration != null) {
            CullingRegistration cullingRegistration =
                currentRegistration.item as CullingRegistration;
            if (cullingRegistration.cullings.length >= 2 &&
                currentRadioIndex == 1) {
              enableRadioGroup = false;
              break;
            }
          }
        }
      }
    }

    _getTitle() {
      switch (widget.registrationType) {
        case RegistrationType.Mortality:
          return appText.new_mortality_count;
        case RegistrationType.Culling:
          return appText.new_culling;
        default:
          return appText.new_feeding;
      }
    }

    /// end culling functions
    _enableCullledEntireUnit();
    List<Widget> countItems = _buildCountItems();
    ObjectKey objectKey = UiUtils.getKeyBaseOnSyncConnectionStatus(appModel);
    double offsetHeight = yesterdayTypes.isEmpty ? 0 : YESTERDAY_CAUSE_HEIGHT;

    return NewRegistrationScreen(
      title: _getTitle(),
      amountCountLength: countItems.length,
      registrationDateTime: registrationDateTime,
      isAllowedToSave: isAllowedToSave,
      registrationViewModel: model,
      onPressSave: () {
        _addFavoriteCauses();
        model.storeRegistration();
      },
      amountCountWidget: Column(
        children: <Widget>[
          widget.registrationType == RegistrationType.Culling
              ? Visibility(
                  visible: model.isForSalmon,
                  child: Padding(
                    padding:
                        const EdgeInsets.only(left: 20.0, top: 16.0, right: 20),
                    child: Column(
                      children: <Widget>[
                        Row(
                          children: <Widget>[
                            Expanded(
                              flex: 5,
                              child: Text(
                                appText.culled_the_entire_unit,
                                style: TextStyle(
                                    fontSize: FontSize.small,
                                    fontWeight: FontWeight.normal,
                                    color: appModel.isDarkTheme
                                        ? akvaDarkTextA
                                        : akvaDarkColorD),
                              ),
                            ),
                            SizedBox(width: 20),
                            Expanded(
                              flex: 5,
                              child: RadioGroup(
                                direction: Axis.horizontal,
                                enable: enableRadioGroup,
                                currentRadioIndex: currentRadioIndex,
                                radioTitles: [appText.yes, appText.no],
                                onChangeRadioIndex: (newRadioValue) =>
                                    _onChangeRadio(newRadioValue),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(
                          height: 18,
                        ),
                        Divider(
                          color: appModel.isDarkTheme
                              ? akvaDarkColorB
                              : akvaLightColorC,
                          thickness: 1,
                          height: 0,
                        ),
                      ],
                    ),
                  ),
                )
              : Container(),
          widget.registrationType != RegistrationType.Feeding
              ? Visibility(
                  visible: !model.isForSalmon,
                  child: CleanerFishes(
                    selectedCleanerFishId: selectedFishId,
                    onTapCleanerFish: onTapCleanerFish,
                  ),
                )
              : Container(),
          Container(
            child: Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  mainAxisSize: MainAxisSize.max,
                  children: <Widget>[
                    YesterdayChoices(
                      allOptions: _getSelectorOptionList(yesterdayTypes),
                      selectedOptionItems:
                          selectedOptionItemMap[selectedFishId],
                      selectedItemChangedCallback: onCauseChanged,
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left: 19.0),
                      child: Divider(
                        color: appModel.isDarkTheme
                            ? akvaDarkColorB
                            : akvaLightColorC,
                        thickness: 1,
                        height: 0,
                      ),
                    ),
                    GestureDetector(
                      onTap: () => SystemChannels.textInput
                          .invokeMethod('TextInput.hide'),
                      child: RegistrationAmountCountList(
                          key: objectKey,
                          isNoFishTypeTab: true,
                          isAddingNewRegistration: true,
                          offsetHeight: offsetHeight,
                          amountCountList: countItems),
                    ),
                    SizedBox(height: 10),
                    Padding(
                      padding: const EdgeInsets.only(right: 20),
                      child: TotalAmountCount(
                        isRightSide: true,
                        title: appText.total,
                        totalAmountCount: _getTotalCount(),
                      ),
                    )
                  ],
                ),
                Padding(
                  padding:
                      const EdgeInsets.only(left: 20.0, top: 16.0, right: 20),
                  child: AkvaDropDown(
                    items: _getSelectorOptionList(causesList),
                    onSelectedItem: onCauseChanged,
                    label: widget.registrationType == RegistrationType.Feeding
                        ? appText.feeding_series
                        : appText.cause,
                    leftIcon: AkvaIcons.search,
                    hint: widget.registrationType == RegistrationType.Feeding
                        ? appText.select_series
                        : appText.search,
                    selectedItems: selectedOptionItemMap.isEmpty
                        ? []
                        : selectedOptionItemMap[selectedFishId],
                    isDarkTheme: appModel.isDarkTheme,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:Commons/buttons.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/src/base/base_view_model.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:flutter/widgets.dart';

class AddNewRegistrationButton extends StatelessWidget {
  const AddNewRegistrationButton({
    Key key,
    @required this.savingStatusEnum,
    @required this.onPressSave,
    @required this.isBusy,
    @required this.isAllowedToSave,
    @required this.buttonTitle,
  }) : super(key: key);

  final SavingStatusEnum savingStatusEnum;
  final VoidCallback onPressSave;
  final bool isBusy;
  final bool isAllowedToSave;
  final String buttonTitle;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        AkvaPrimaryButton(
          widget: UiUtils.spinArrow,
          onPressed: null,
        ),
        isBusy
            ? Container(height: 0)
            : AkvaPrimaryButton(
                label: savingStatusEnum == SavingStatusEnum.NOT_SAVE
                    ? buttonTitle
                    : '',
                fontWeight: FontWeight.bold,
                icon: savingStatusEnum == SavingStatusEnum.SAVED
                    ? AkvaIcons.checked
                    : null,
                iconSize: FontSize.large,
                onPressed: isAllowedToSave &&
                        savingStatusEnum == SavingStatusEnum.NOT_SAVE
                    ? () async {
                        onPressSave();
                      }
                    : null,
              ),
      ],
    );
  }
}

import 'package:flutter/material.dart';

class RegistrationCard extends StatefulWidget {
  final String title;
  final double initialValue;
  final bool showDeleteButton;

  final ValueChanged<double> onValueChanged;
  final Function onDelete;
  RegistrationCard({
    this.title,
    this.initialValue,
    this.showDeleteButton,
    this.onValueChanged,
    this.onDelete,
  });

  @override
  _RegistrationCardState createState() => _RegistrationCardState();
}

class _RegistrationCardState extends State<RegistrationCard> {
  TextEditingController _controller;
  bool isShowingDeleteButton = false;
  @override
  initState() {
    super.initState();
    isShowingDeleteButton = widget.showDeleteButton;
    _controller = TextEditingController();
    if (widget.initialValue != null) {
      _controller.text = widget.initialValue.toString();
    }
  }

  @override
  dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: isShowingDeleteButton
            ? Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                    IconButton(
                      padding: EdgeInsets.only(top: 8, bottom: 8, right: 8),
                      icon: Icon(Icons.delete),
                      onPressed: _onDelete,
                    ),
                    VerticalDivider(),
                  ])
            : null,
        title: Text(widget.title),
        trailing: Container(
          width: 55,
          child: TextField(
            textAlign: TextAlign.right,
            controller: _controller,
            keyboardType:
                TextInputType.numberWithOptions(signed: false, decimal: true),
            onChanged: _onValueTextChanged,
          ),
        ),
      ),
    );
  }

  void _onValueTextChanged(String value) {
    if (value.isNotEmpty) {
      String valueOnlyDots = value.replaceAll(',', '.');
      double newValue = double.parse(valueOnlyDots);
      widget.onValueChanged(newValue);
      if (!isShowingDeleteButton) {
        setState(() {
          isShowingDeleteButton = true;
        });
      }
    }
  }

  void _onDelete() {
    widget.onDelete();
    _controller.clear();
    FocusScope.of(context).requestFocus(new FocusNode());
    setState(() {
      isShowingDeleteButton = false;
    });
  }
}

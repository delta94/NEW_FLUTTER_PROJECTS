import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/util/utils.dart';
import 'package:control_app/src/widgets/delete_button.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import 'confirmation_dialog/confirmation_modal.dart';

class RegistrationItem extends StatefulWidget {
  final Key key;
  final bool digitsOnly;
  final RegistrationViewModel registrationViewModel;
  final List<Registration> registrations;
  final DateTime dateTime;
  final List<Widget> amountCountList;
  final bool showTotal;
  final RegistrationUserRight registrationUserRight;

  RegistrationItem({
    this.key,
    this.digitsOnly: true,
    this.showTotal: true,
    @required this.registrationViewModel,
    @required this.registrations,
    @required this.dateTime,
    @required this.amountCountList,
    @required this.registrationUserRight,
  }) : super(key: key);

  @override
  _RegistrationItemState createState() => _RegistrationItemState();
}

class _RegistrationItemState extends State<RegistrationItem> {
  bool isExpanded = true;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        RegistrationItemInfoTitle(
          showTotal: widget.showTotal,
          digitsOnly: widget.digitsOnly,
          registrationViewModel: widget.registrationViewModel,
          dateTime: widget.dateTime,
          registrations: widget.registrations,
          onToggle: () => setState(() => isExpanded = !isExpanded),
          isExpanded: isExpanded,
          registrationUserRight: widget.registrationUserRight,
        ),
        isExpanded
            ? Column(
                children: <Widget>[...widget.amountCountList],
              )
            : Container()
      ],
    );
  }
}

class RegistrationItemInfoTitle extends StatelessWidget {
  final bool digitsOnly;
  final RegistrationViewModel registrationViewModel;
  final DateTime dateTime;
  final List<Registration> registrations;
  final VoidCallback onToggle;
  final bool isExpanded;
  final bool showTotal;
  final RegistrationUserRight registrationUserRight;

  RegistrationItemInfoTitle({
    this.digitsOnly,
    @required this.dateTime,
    @required this.onToggle,
    @required this.registrations,
    @required this.registrationViewModel,
    this.showTotal: true,
    this.isExpanded,
    @required this.registrationUserRight,
  });

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);

    return Column(
      children: <Widget>[
        Divider(
          color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
          height: 1,
          thickness: 1.3,
        ),
        Container(
          color: appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorB,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Expanded(
                child: Row(
                  children: <Widget>[
                    Wrap(
                      children: <Widget>[
                        SizedBox(width: 12),
                        DeleteButton(
                            isVisible: !registrationViewModel.busy &&
                                registrationViewModel.isEditingCountMode &&
                                registrationUserRight.allowDelete,
                            callback: () {
                              showConfirmationModal(
                                context: context,
                                title: appText.delete_registration,
                                messages: [
                                  appText
                                      .are_you_sure_you_want_to_delete_registration,
                                ],
                                leftButtonTitle: appText.cancel,
                                rightButtonTitle: appText.delete,
                                onTapRightButton: () => registrationViewModel
                                    .removeRegistration(dateTime),
                              );
                            }),
                      ],
                    ),
                    Expanded(
                      child: InkWell(
                        onTap: () => onToggle(),
                        child: Padding(
                          padding:
                              EdgeInsets.only(right: 11, top: 7, bottom: 7),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: <Widget>[
                              Row(
                                children: <Widget>[
                                  RegistrationDateTime(dateTime: dateTime),
                                  SizedBox(width: 13),
                                  showTotal
                                      ? TotalRegistrationAmountCount(
                                          digitsOnly: digitsOnly,
                                          registrationViewModel:
                                              registrationViewModel,
                                          registrations: registrations,
                                        )
                                      : Container(height: 25),
                                ],
                              ),
                              CollapsedArrows(isExpanded: isExpanded),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
        Divider(
          color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
          height: 1,
          thickness: 1.3,
        ),
      ],
    );
  }
}

class CollapsedArrows extends StatelessWidget {
  const CollapsedArrows({
    Key key,
    @required this.isExpanded,
  }) : super(key: key);

  final bool isExpanded;

  @override
  Widget build(BuildContext context) {
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);
    return Container(
      margin: EdgeInsets.only(right: 3),
      width: 20,
      child: Material(
        color: Colors.transparent,
        child: Icon(
          isExpanded
              ? AkvaIcons.keyboard_arrow_up
              : AkvaIcons.keyboard_arrow_down,
          size: 12,
          color: appModel.isDarkTheme ? akvaMainNeutral : akvaDarkColorD,
        ),
      ),
    );
  }
}

class RegistrationDateTime extends StatelessWidget {
  const RegistrationDateTime({
    Key key,
    @required this.dateTime,
  }) : super(key: key);

  final DateTime dateTime;

  @override
  Widget build(BuildContext context) {
    S appText = S.of(context);
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);
    return Text(
      getRegistrationTime(
        appText.at,
        dateTime,
      ),
      style: TextStyle(
        fontSize: FontSize.small,
        color: appModel.isDarkTheme ? akvaDarkTextA : akvaDarkColorD,
      ),
    );
  }
}

class TotalRegistrationAmountCount extends StatelessWidget {
  final bool digitsOnly;
  final RegistrationViewModel registrationViewModel;
  final List<Registration> registrations;

  TotalRegistrationAmountCount({
    this.digitsOnly: true,
    @required this.registrationViewModel,
    @required this.registrations,
  });

  @override
  Widget build(BuildContext context) {
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);
    double tempAmountCount =
        registrationViewModel.getRegistrationsTotalCount(registrations);

    String amountCount = tempAmountCount.toInt() == tempAmountCount
        ? tempAmountCount.toStringAsFixed(0)
        : tempAmountCount.toStringAsFixed(2);

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 14, vertical: 3),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
      ),
      child: Text(
        amountCount,
        style: TextStyle(
          color: akvaMainNeutral,
          fontSize: FontSize.small,
          fontWeight: FontWeight.w500,
        ),
      ),
    );
  }
}

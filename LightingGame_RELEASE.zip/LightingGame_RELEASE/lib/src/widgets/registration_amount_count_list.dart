import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class RegistrationAmountCountList extends StatefulWidget {
  const RegistrationAmountCountList({
    this.key,
    this.offsetHeight: 0,
    @required this.amountCountList,
    this.isNoFishTypeTab: false,
    this.isAddingNewRegistration: false,
  }) : super(key: key);

  final Key key;
  final bool isNoFishTypeTab;
  final double offsetHeight;
  final bool isAddingNewRegistration;
  final List<Widget> amountCountList;

  @override
  _RegistrationAmountCountListState createState() =>
      _RegistrationAmountCountListState();
}

class _RegistrationAmountCountListState
    extends State<RegistrationAmountCountList> {
  double amountCountListHeight = 0;
  GlobalKey amountCountListKey = GlobalKey();
  ScrollController scrollController = ScrollController();

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback(getAmountCountListHeight);
    super.initState();
  }

  void getAmountCountListHeight(_) {
    final RenderBox registrationListKeyBox =
        amountCountListKey.currentContext.findRenderObject();
    Offset position = registrationListKeyBox.localToGlobal(Offset.zero);
    double registrationListPositionY = position.dy;
    setState(() {
      amountCountListHeight = MediaQuery.of(context).size.height -
          registrationListPositionY -
          kBottomNavigationBarHeight -
          85;
    });
  }

  @override
  Widget build(BuildContext context) {
    double height = amountCountListHeight;
    if (height > 0) height -= widget.offsetHeight;

    return Container(
      key: amountCountListKey,
      padding: EdgeInsets.only(top: 0),
      height: height,
      child: Visibility(
        visible: widget.amountCountList.isNotEmpty,
        child: Scrollbar(
          key: PageStorageKey('scroll'),
          isAlwaysShown: true,
          controller: scrollController,
          child: MediaQuery.removePadding(
            removeTop: true,
            context: context,
            child: SingleChildScrollView(
              key: PageStorageKey('scroll'),
              controller: scrollController,
              child: Column(
                children: widget.amountCountList,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

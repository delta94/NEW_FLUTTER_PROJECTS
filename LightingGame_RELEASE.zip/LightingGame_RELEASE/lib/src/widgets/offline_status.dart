import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:data_connection_checker/data_connection_checker.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_model.dart';

class OfflineStatus extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context, listen: true);
    final appText = S.of(context);
    return Container(
      color: appModel.isDarkTheme ? akvaMainNeutral : akvaDarkColorD,
      height: appModel.connectionStatus == DataConnectionStatus.disconnected ? 32 : 0,
      child: appModel.connectionStatus == DataConnectionStatus.disconnected
          ? Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Icon(
                  AkvaIcons.internetconnection_lost,
                  size: FontSize.medium,
                  color: appModel.isDarkTheme
                            ? akvaDarkTextA
                            : akvaLightColorB,
                ),
                Padding(
                  padding: EdgeInsets.only(right: 10),
                ),
                Text(
                  appText.you_are_currently_in_offline_mode,
                  textAlign: TextAlign.center,
                  style: TextStyle(
                    color: appModel.isDarkTheme
                            ? akvaDarkTextA
                            : akvaLightColorB,
                    fontSize: FontSize.small,
                    fontWeight: FontWeight.w500,
                  ),
                )
              ],
            )
          : SizedBox.shrink(),
    );
  }
}

import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

const double TABVIEW_BOTTOM_PADDING = 100;

class RegistrationTabBar extends StatefulWidget {
  const RegistrationTabBar({
    this.key,
    @required this.isSalmonActive,
    @required this.onChangeTabBar,
    @required this.salmonTabView,
    this.cleanerFishTabView,
    this.isOnlyOneTab: false,
  }) : super(key: key);

  final Key key;
  final bool isSalmonActive;
  final Function(bool) onChangeTabBar;
  final Widget salmonTabView;
  final Widget cleanerFishTabView;
  final bool isOnlyOneTab;

  @override
  _RegistrationTabBarState createState() => _RegistrationTabBarState();
}

class _RegistrationTabBarState extends State<RegistrationTabBar>
    with SingleTickerProviderStateMixin {
  TabController tabController;
  double tabViewHeight = 0;
  int currentTabIndex = 0;
  GlobalKey tabViewKey = GlobalKey();

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback(_getTabViewHeight);
    SharedDataModel sharedDataModel =
        Provider.of<SharedDataModel>(context, listen: false);
    int tabLength = widget.cleanerFishTabView == null ? 1 : 2;
    currentTabIndex = sharedDataModel.isSalmonTabActive ? 0 : 1;
    tabController = new TabController(
        length: tabLength, vsync: this, initialIndex: currentTabIndex)
      ..addListener(() {
        changeTabbar(tabController);
      });

    super.initState();
  }

  void changeTabbar(TabController _tabController) {
    if (_tabController.index != currentTabIndex) {
      currentTabIndex = _tabController.index;
      widget.onChangeTabBar(_tabController.index == 0);
    }
  }

  void _getTabViewHeight(_) {
    final RenderBox registrationListKeyBox =
        tabViewKey.currentContext.findRenderObject();
    Offset position = registrationListKeyBox.localToGlobal(Offset.zero);
    double tabViewPositionY = position.dy;
    setState(() {
      tabViewHeight = MediaQuery.of(context).size.height -
          tabViewPositionY -
          (TABVIEW_BOTTOM_PADDING -
              (widget.cleanerFishTabView == null ? 20 : 0));
    });
  }

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    List<Widget> tabBarBackgrounds = [
      TabbarBackground(isActive: widget.isSalmonActive)
    ];
    List<Widget> tabBars = [Tab(text: appText.salmon)];
    List<Widget> tabBarViews = [widget.salmonTabView];
    if (widget.cleanerFishTabView != null) {
      tabBarBackgrounds.add(TabbarBackground(isActive: !widget.isSalmonActive));
      tabBars.add(Tab(text: appText.cleaner_fish));
      tabBarViews.add(widget.cleanerFishTabView);
    }

    return Container(
      alignment: Alignment.topRight,
      child: FractionallySizedBox(
        widthFactor: 0.983,
        child: Column(
          children: <Widget>[
            SizedBox(height: widget.cleanerFishTabView == null ? 15 : 29),
            appModel.appMode == AppMode.Seabased &&
                    widget.cleanerFishTabView != null
                ? Stack(children: <Widget>[
                    Row(children: tabBarBackgrounds),
                    TabBar(
                      labelColor:
                          appModel.isDarkTheme ? akvaDarkTextA : akvaLightTextA,
                      unselectedLabelColor:
                          appModel.isDarkTheme ? akvaDarkTextB : akvaLightTextB,
                      labelStyle: TextStyle(fontSize: FontSize.small),
                      indicatorColor: akvaMainAction,
                      indicatorWeight: 4,
                      tabs: tabBars,
                      controller: tabController,
                      indicatorSize: TabBarIndicatorSize.tab,
                    ),
                  ])
                : Container(),
            Container(
              key: tabViewKey,
              height: tabViewHeight,
              child: TabBarView(
                children: tabBarViews,
                controller: tabController,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class TabbarBackground extends StatelessWidget {
  const TabbarBackground({Key key, @required this.isActive}) : super(key: key);

  final bool isActive;

  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    Color _getTabColor(bool isActive) {
      if (isActive) {
        return appModel.isDarkTheme ? akvaDarkColorE : akvaLightColorE;
      } else {
        return appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorC;
      }
    }

    return Expanded(
      child: Container(
        height: isActive ? 46 : 48,
        margin: EdgeInsets.only(top: isActive ? 0 : 2),
        color: _getTabColor(isActive),
      ),
    );
  }
}

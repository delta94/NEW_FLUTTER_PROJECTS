import 'package:Commons/colors.dart';
import 'package:Commons/icons.dart';
import 'package:flutter/material.dart';

class SelectionButton extends StatefulWidget {
  final Map<dynamic, String> selectionList;
  final dynamic selectedItem;
  final void Function(BuildContext, dynamic) selectedItemChanged;
  final void Function(bool) onSelectionListExpandOrCollapsed;
  final String Function(dynamic) formatSelectionHintText;
  final mainAxisSize = MainAxisSize.max;
  final double height;
  final Color hintTextColor;
  final Color selectionItemTextColor;
  final Color arrowIconColor;

  var mainAxisAlignment = MainAxisAlignment.center;
  var childrenMainAxisAlignment = MainAxisAlignment.center;

  SelectionButton(
      {@required this.selectionList,
      @required this.selectedItem,
      @required this.selectedItemChanged,
      @required this.onSelectionListExpandOrCollapsed,
      this.formatSelectionHintText,
      this.height,
      this.mainAxisAlignment,
      this.childrenMainAxisAlignment,
      this.hintTextColor,
      this.selectionItemTextColor,
      this.arrowIconColor});

  @override
  _SelectionButtonState createState() => _SelectionButtonState();
}

class _SelectionButtonState extends State<SelectionButton> {
  bool isExpanded = false;

  @override
  Widget build(BuildContext context) {
    return typeSelection(context);
  }

  void toggleSelectionTypeList() {
    setState(() {
      isExpanded = !isExpanded;
      if (widget.onSelectionListExpandOrCollapsed != null)
        widget.onSelectionListExpandOrCollapsed(isExpanded);
    });
  }

  String _getHintText() {
    if (widget.formatSelectionHintText != null) {
      return widget.formatSelectionHintText(widget.selectedItem);
    } else {
      if (widget.selectedItem != null &&
          widget.selectionList.containsKey((widget.selectedItem))) {
        return widget.selectionList[widget.selectedItem];
      } else {
        return "";
      }
    }
  }

  Widget buildSelectionHint() {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () => toggleSelectionTypeList(),
        child: Row(
          mainAxisAlignment: widget.mainAxisAlignment,
          children: <Widget>[
            Padding(
              padding: EdgeInsets.only(
                left: 26.0,
              ),
              child: Text(
                _getHintText(),
                style: new TextStyle(fontSize: 18, color: widget.hintTextColor),
              ),
            ),
            Container(
              height: widget.height,
              padding: EdgeInsets.only(right: 15.0),
              child: IconButton(
                icon: Icon(
                  isExpanded
                      ? AkvaIcons.keyboard_arrow_up
                      : AkvaIcons.keyboard_arrow_down,
                  color: widget.arrowIconColor,
                  size: 12,
                ),
                onPressed: () => toggleSelectionTypeList(),
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> buildSelectionList(BuildContext context) {
    List<Widget> widgets = new List<Widget>();
    if (isExpanded) {
      widget.selectionList.forEach((key, value) {
        widgets.add(Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: () => {
              setState(() {
                isExpanded = !isExpanded;
                widget.onSelectionListExpandOrCollapsed(isExpanded);
                widget.selectedItemChanged(context, key);
              })
            },
            child: Row(
              mainAxisSize: widget.mainAxisSize,
              mainAxisAlignment: widget.childrenMainAxisAlignment,
              children: [
                Padding(
                  padding:
                      EdgeInsets.only(left: 26, right: 15, top: 10, bottom: 10),
                  child: Text(
                    value,
                    style: new TextStyle(
                      fontSize: 18,
                      fontWeight: key == widget.selectedItem
                          ? FontWeight.w500
                          : FontWeight.normal,
                      color: widget.selectionItemTextColor,
                    ),
                  ),
                ),
                Container(
                  padding: EdgeInsets.only(right: 26.0),
                  child: Visibility(
                    visible: key == widget.selectedItem,
                    maintainSize: true,
                    maintainAnimation: true,
                    maintainState: true,
                    child: Icon(
                      AkvaIcons.checked,
                      color: akvaMainAction,
                      size: 20,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ));
      });
    }

    return widgets;
  }

  Widget typeSelection(BuildContext context) {
    return Container(
      child: Column(
        children: <Widget>[
          buildSelectionHint(),
          ...buildSelectionList(context),
        ],
      ),
    );
  }
}

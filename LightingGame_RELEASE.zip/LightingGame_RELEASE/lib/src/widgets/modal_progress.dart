import 'package:flutter/material.dart';

class ModalProgress extends StatelessWidget {
  Widget build(BuildContext context) {
    return Dialog(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          SizedBox(height: 16),
          CircularProgressIndicator(),
          SizedBox(height: 16),
          Text( "Saving..."),
          SizedBox(height: 16),
        ],
      ),
    );
  }
}

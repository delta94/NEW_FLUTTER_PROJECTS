import 'package:flutter/material.dart';

class YesNoModalDialog extends StatelessWidget {
  final VoidCallback okCallback;
  final VoidCallback cancelCallback;
  final String title;
  final String description;
  YesNoModalDialog(
      {this.cancelCallback, this.okCallback, this.title, this.description});

  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return AlertDialog(
      title: Text(title),
      content: Text(description),
      actions: <Widget>[
        RaisedButton(
          color: theme.cardColor,
          elevation: 4,
          child: Text("NO"),
          onPressed: cancelCallback,
        ),
        RaisedButton(
          color: theme.cardColor,
          elevation: 4,
          child: Text("YES"),
          onPressed: okCallback,
        ),
      ],
    );
  }
}

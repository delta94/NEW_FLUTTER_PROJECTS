import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/src/app_model.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class TotalAmountCount extends StatelessWidget {
  const TotalAmountCount(
      {Key key,
      this.isRightSide: false,
      @required this.title,
      @required this.totalAmountCount,
      this.unitSymbol: ''})
      : super(key: key);

  final String title;
  final double totalAmountCount;
  final bool isRightSide;
  final String unitSymbol;

  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context);

    _totalAmountCountTitlte() {
      return Text(
        title,
        softWrap: false,
        textAlign: TextAlign.left,
        overflow: TextOverflow.fade,
        style: TextStyle(
            color: akvaMainNeutral,
            fontSize: FontSize.small,
            fontWeight: FontWeight.w500),
      );
    }

    _totalAmountCountValue() {
      String amountCountValue;
      if (totalAmountCount == null) {
        amountCountValue = '_';
      } else {
        amountCountValue = totalAmountCount.toStringAsFixed(
            totalAmountCount.truncateToDouble() == totalAmountCount ? 0 : 2);
      }

      return Text(
        '$amountCountValue $unitSymbol',
        textAlign: TextAlign.right,
        style: TextStyle(
            color: akvaMainNeutral,
            fontSize: FontSize.small,
            fontWeight: FontWeight.w500),
      );
    }

    _getRightSideAmountCountWidget() {
      return Container(
        alignment: Alignment.topRight,
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 5, horizontal: 12),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorE),
          child: Wrap(
            children: <Widget>[
              _totalAmountCountTitlte(),
              SizedBox(
                width: 30,
              ),
              _totalAmountCountValue()
            ],
          ),
        ),
      );
    }

    _getFullWidthAmountCountWidget() {
      return Row(
        children: <Widget>[
          Expanded(
            child: Container(
              padding: EdgeInsets.symmetric(vertical: 5, horizontal: 12),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorE,
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Flexible(
                    fit: FlexFit.loose,
                    child: _totalAmountCountTitlte(),
                  ),
                  _totalAmountCountValue()
                ],
              ),
            ),
          ),
        ],
      );
    }

    return isRightSide
        ? _getRightSideAmountCountWidget()
        : _getFullWidthAmountCountWidget();
  }
}

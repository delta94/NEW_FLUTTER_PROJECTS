import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_model.dart';

class SynchronizeProgressStatus extends StatefulWidget {
  @override
  _SynchronizeProgressStatusState createState() =>
      _SynchronizeProgressStatusState();
}

class _SynchronizeProgressStatusState extends State<SynchronizeProgressStatus> {
  DragStartDetails _dragStartDetails;
  double height = 32;
  double originHeight = 32;
  bool isExpand = false;
  final items = List<ListItem>();

  void onVerticalDragStart(DragStartDetails arg) {
    _dragStartDetails = arg;
  }

  void onVerticalDragUpdate(DragUpdateDetails arg) {
    var deltaY = arg.globalPosition.dy - _dragStartDetails.globalPosition.dy;

    if (deltaY > 0) {
      isExpand = true;
      setState(() {
        if (originHeight + deltaY < 198)
          height = originHeight + deltaY;
        else
          height = 198;
      });
    } else {
      isExpand = false;
      setState(() {
        if (originHeight + deltaY > 32)
          height = originHeight + deltaY;
        else {
          height = 42;
        }
      });
    }
  }

  void onVerticalDragEnd(DragEndDetails arg) {
    if (isExpand) {
      setState(() {
        height = 198;
      });
    } else {
      setState(() {
        height = 32;
      });
    }

    originHeight = height;
  }

  @override
  Widget build(BuildContext context) {
    items.clear();

    final appModel = Provider.of<AppModel>(context, listen: true);
    final appText = S.of(context);

    items.add(SyncProgressHeadingItem(appModel, appText));
    items.add(SyncProgressResultItem(appModel, appText));

    return GestureDetector(
      onVerticalDragStart: onVerticalDragStart,
      onVerticalDragUpdate: onVerticalDragUpdate,
      onVerticalDragEnd: onVerticalDragEnd,
      child: appModel.synResult.length > 0
          ? Dismissible(
              key: Key('dismissSyncResult'),
              onDismissed: (direction) {
                appModel.dismissSyncResult();
              },
              child: AnimatedContainer(
                height: height,
                duration: Duration(milliseconds: 400),
                child: MediaQuery.removePadding(
                    context: context,
                    removeTop: true,
                    child: ListView.builder(
                      physics: const NeverScrollableScrollPhysics(),
                      // Let the ListView know how many items it needs to build.
                      itemCount: items.length,
                      // Provide a builder function. This is where the magic happens.
                      // Convert each item into a widget based on the type of item it is.
                      itemBuilder: (context, index) {
                        final item = items[index];

                        return item.buildTitle(context);
                      },
                    )),
              ),
            )
          : Container(),
    );
  }
}

/// The base class for the different types of items the list can contain.
abstract class ListItem {
  /// The title line to show in a list item.
  Widget buildTitle(BuildContext context);
}

/// A ListItem that contains data to display a heading.
class SyncProgressHeadingItem implements ListItem {
  final AppModel appModel;
  final S appText;

  SyncProgressHeadingItem(this.appModel, this.appText);

  Widget buildTitle(BuildContext context) {
    var n = appModel.synResult.values
        .fold(0, (previousValue, element) => previousValue + element);
    return Container(
      height: 32,
      color: akvaMainAction,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Icon(
            AkvaIcons.refresh,
            size: FontSize.medium,
            color: appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorA,
          ),
          Padding(
            padding: EdgeInsets.only(right: 10),
          ),
          Text(
            n > 1 ? appText.n_registrations_were_successfully_uploaded(n) : appText.one_registration_was_successfully_uploaded,
            textAlign: TextAlign.center,
            style: TextStyle(
              color: appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorA,
              fontSize: FontSize.small,
              fontWeight: FontWeight.w500,
            ),
          )
        ],
      ),
    );
  }
}

/// A ListItem that contains data to display a message.
class SyncProgressResultItem implements ListItem {
  final S appText;
  final AppModel appModel;

  SyncProgressResultItem(this.appModel, this.appText);

  Widget buildTitle(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(top: 16, bottom: 16),
      color: akvaDarkColorA,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          Column(children: <Widget>[
            SyncResultItem(
              appModel,
              appText,
              RegistrationType.Mortality,
              appModel.synResult.containsKey(RegistrationType.Mortality),
              appText.mortality_registration + (appModel.synResult.containsKey(RegistrationType.Mortality) ? ' ' +  appText.sent : ''),
              position: true,
            ),
            SyncResultItem(
              appModel,
              appText,
              RegistrationType.Feeding,
              appModel.synResult.containsKey(RegistrationType.Feeding),
              appText.feeding_registration + (appModel.synResult.containsKey(RegistrationType.Feeding) ? ' ' +  appText.sent : '')
            ),
            SyncResultItem(
              appModel,
              appText,
              RegistrationType.Culling,
              appModel.synResult.containsKey(RegistrationType.Culling),
              appText.culling_registration + (appModel.synResult.containsKey(RegistrationType.Culling) ? ' ' +  appText.sent : '')
            ),
            SyncResultItem(
              appModel,
              appText,
              RegistrationType.Lice,
              appModel.synResult.containsKey(RegistrationType.Lice),
             appText.lice_registration + (appModel.synResult.containsKey(RegistrationType.Lice) ? ' ' +  appText.sent : '')
            ),
            SyncResultItem(
              appModel,
              appText,
              RegistrationType.Environment,
              appModel.synResult.containsKey(RegistrationType.Environment),
              appText.environment + (appModel.synResult.containsKey(RegistrationType.Environment) ? ' ' +  appText.sent : ''),
              position: false,
            ),
          ]),
        ],
      ),
    );
  }
}

class SyncResultItem extends StatelessWidget {
  final S appText;
  final AppModel appModel;
  final RegistrationType type;
  final bool hasSent;
  final String text;
  // If position is null => this is in the middle of the list
  // If position is true => this is at the begining of the list
  // Else this is at the end of the list
  final bool position;

  SyncResultItem(
      this.appModel, this.appText, this.type, this.hasSent, this.text,
      {this.position});

  Widget sentIndicator() {
    return hasSent
        ? Container(
            width: 16,
            height: 16,
            decoration: BoxDecoration(
                color: akvaMainAction,
                borderRadius: BorderRadiusDirectional.circular(15)),
            child: Icon(AkvaIcons.checked,
                size: FontSize.xsmall, color: akvaMainDark),
          )
        : Container(
            width: 8,
            height: 8,
            decoration: new BoxDecoration(
              borderRadius: BorderRadius.all(Radius.circular(8)),
              border: Border.all(color: akvaMainAction, width: 1),
            ),
          );
  }

  Widget build(BuildContext context) {
    return Container(
      height: 26,
      child: Row(
        children: <Widget>[
          Padding(
            padding: EdgeInsets.only(left: 46),
          ),
          Container(
            width: 16,
            child: Column(
              //mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              //mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Expanded(
                  child: Container(
                    color: (position == null || position == false)
                        ? akvaMainAction
                        : Colors.transparent,
                    width: 1,
                  ),
                ),
                sentIndicator(),
                Expanded(
                  child: Container(
                    color: (position == null || position == true)
                        ? akvaMainAction
                        : Colors.transparent,
                    width: 1,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 15),
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: akvaMainAction,
                fontSize: FontSize.small,
                fontWeight: FontWeight.w500,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

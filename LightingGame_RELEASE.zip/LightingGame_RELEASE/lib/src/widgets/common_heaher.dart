import 'package:Commons/colors.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../app_model.dart';

class CommonHeader extends StatelessWidget {
  final String unitName;
  final String headerTitle;
  final bool showBackButton;
  final VoidCallback onBack;
  final VoidCallback onClose;
  static const double HEIGHT = 143;
  static const double FONT_SIZE = 20;
  static const double CLOSE_ICON_SIZE = 32;
  CommonHeader({
    @required this.unitName,
    @required this.headerTitle,
    this.onClose,
    this.showBackButton: false,
    this.onBack,
  });
  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    final appModel = Provider.of<AppModel>(context, listen: false);
    var safePadding = MediaQuery.of(context).padding.top;

    return Container(
      color: appModel.isDarkTheme ? akvaDarkColorA : akvaDarkColorE,
      height: HEIGHT + safePadding,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: EdgeInsets.only(top: safePadding),
          ),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Visibility(
                visible: showBackButton,
                child: Padding(
                  padding: EdgeInsets.only(top: 20, left: 20),
                  child: Material(
                    color: Colors.transparent,
                    child: InkWell(
                      child: Row(
                        children: <Widget>[
                          Icon(
                            AkvaIcons.back_circle,
                            size: 24,
                            color: appModel.isDarkTheme
                                ? akvaDarkTextA
                                : akvaMainLiveAction,
                          ),
                          SizedBox(
                            width: 10,
                          ),
                          Container(
                            padding: EdgeInsets.only(top: 2, bottom: 2),
                            child: Text(
                              appText.back,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.normal,
                                color: appModel.isDarkTheme
                                    ? akvaDarkTextA
                                    : akvaMainLiveAction,
                              ),
                            ),
                          )
                        ],
                      ),
                      onTap: () => onBack != null ? onBack() : null,
                    ),
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(top: 15, right: 20),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    child: Icon(
                      AkvaIcons.close,
                      size: CLOSE_ICON_SIZE,
                      color: appModel.isDarkTheme
                          ? akvaDarkTextA
                          : akvaLightColorB,
                    ),
                    onTap: () => onClose(),
                  ),
                ),
              ),
            ],
          ),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              children: <Widget>[
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Container(
                      padding: const EdgeInsets.fromLTRB(7, 2, 7, 2),
                      margin: const EdgeInsets.only(left: 20, bottom: 11),
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: appModel.isDarkTheme
                              ? akvaDarkTextA
                              : akvaLightColorB,
                          width: 1.0,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(2.0)),
                      ),
                      child: Text(
                        unitName,
                        style: TextStyle(
                          fontSize: 16.0,
                          color: appModel.isDarkTheme
                              ? akvaDarkTextA
                              : akvaLightColorB,
                        ),
                      ),
                    ),
                  ],
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: <Widget>[
                    Padding(
                      padding: EdgeInsets.only(left: 18, bottom: 19),
                      child: Text(
                        headerTitle,
                        style: TextStyle(
                          fontWeight: FontWeight.normal,
                          fontSize: 20.0,
                          color: appModel.isDarkTheme
                              ? akvaDarkTextA
                              : akvaLightColorB,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          Divider(
            thickness: 1.5,
            height: 1,
            color: akvaMainNeutral,
          ),
        ],
      ),
    );
  }
}

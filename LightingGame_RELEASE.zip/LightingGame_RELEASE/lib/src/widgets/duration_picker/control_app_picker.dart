import 'package:Commons/buttons.dart';
import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart' as Dialog;
import 'dart:async';

import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

import 'custom_picker.dart';

/// Picker selected callback.
typedef PickerSelectedCallback = void Function(
    ConrolAppPicker picker, int index, List<int> selecteds);

/// Picker confirm callback.
typedef PickerConfirmCallback = void Function(ConrolAppPicker picker);

/// Picker value format callback.
typedef PickerValueFormat<T> = String Function(T value);

/// Picker
class ConrolAppPicker {
  static const double DefaultTextSize = FontSize.medium;

  /// Index of currently selected items
  List<int> selecteds;

  final PickerAdapter adapter;
  final PickerConfirmCallback onConfirm;

  Widget _widget;
  PickerWidgetState _state;

  ConrolAppPicker({this.adapter, this.selecteds, this.onConfirm})
      : assert(adapter != null);

  Widget get widget => _widget;
  PickerWidgetState get state => _state;
  int _maxLevel = 1;

  /// Build picker control
  Widget makePicker([ThemeData themeData, bool isModal = false]) {
    _maxLevel = adapter.maxLevel;
    adapter.picker = this;
    adapter.initSelects();
    _widget =
        _PickerWidget(picker: this, themeData: themeData, isModal: isModal);
    return _widget;
  }

  /// show picker
  void show(ScaffoldState state, [ThemeData themeData]) {
    state.showBottomSheet((BuildContext context) {
      return makePicker(themeData);
    });
  }

  /// Display modal picker
  Future<T> showModal<T>(BuildContext context, [ThemeData themeData]) async {
    return await showModalBottomSheet<T>(
        context: context, //state.context,
        builder: (BuildContext context) {
          return makePicker(themeData, true);
        });
  }

  /// show dialog picker
  Future<List<int>> showDurationDialog(BuildContext context,
      {bool barrierDismissible = false, Key key}) {
    final S appText = S.of(context);
    final appModel = Provider.of<AppModel>(context, listen: false);
    return Dialog.showDialog<List<int>>(
        context: context,
        barrierDismissible: barrierDismissible,
        builder: (BuildContext context) {
          return GestureDetector(
            onTap: () {
              if (!barrierDismissible) {
                Navigator.pop(context);
              }
            },
            child: Material(
              color: Colors.transparent,
              child: Stack(
                children: [
                  Opacity(
                    opacity: 0.9,
                    child: Container(color: akvaDarkColorA),
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: <Widget>[
                      Container(),
                      GestureDetector(
                        onTap: () {},
                        child: Container(
                          margin: EdgeInsets.symmetric(horizontal: 9),
                          color: appModel.isDarkTheme
                              ? akvaDarkColorF
                              : akvaLightColorC,
                          child: makePicker(),
                        ),
                      ),
                      Container(
                        padding:
                            EdgeInsets.only(left: 19, right: 15, bottom: 30),
                        child: Row(
                          children: <Widget>[
                            Expanded(
                              child: AkvaPrimaryButton(
                                onPressed: () {
                                  Navigator.pop<List<int>>(context, selecteds);

                                  if (onConfirm != null) onConfirm(this);
                                },
                                label: appText.save,
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ],
              ),
            ),
          );
        });
  }

  List getSelectedValues() {
    return adapter.getSelectedValues();
  }

  void doConfirm(BuildContext context) {
    if (onConfirm != null) onConfirm(this);
    Navigator.of(context).pop();
    _widget = null;
  }
}

class PickerItem<T> {
  final Widget text;
  final T value;
  final List<PickerItem<T>> children;

  PickerItem({this.text, this.value, this.children});
}

class _PickerWidget<T> extends StatefulWidget {
  final ConrolAppPicker picker;
  final ThemeData themeData;
  final bool isModal;
  _PickerWidget(
      {Key key, @required this.picker, @required this.themeData, this.isModal})
      : super(key: key);

  @override
  PickerWidgetState createState() =>
      PickerWidgetState<T>(picker: this.picker, themeData: this.themeData);
}

class PickerWidgetState<T> extends State<_PickerWidget> {
  final ConrolAppPicker picker;
  final ThemeData themeData;
  PickerWidgetState({Key key, @required this.picker, @required this.themeData});

  ThemeData theme;
  final List<FixedExtentScrollController> scrollController = [];
  final List<GlobalKey<_StateViewState>> _keys = [];

  @override
  void initState() {
    super.initState();
    theme = themeData;
    picker._state = this;
    picker.adapter.doShow();

    if (scrollController.length == 0) {
      for (int i = 0; i < picker._maxLevel; i++) {
        scrollController
            .add(FixedExtentScrollController(initialItem: picker.selecteds[i]));
        _keys.add(GlobalKey(debugLabel: i.toString()));
      }
    }
  }

  void update() {
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    _wait = false;

    var _body = <Widget>[];
    _body.add(_wait
        ? Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: _buildViews(),
          )
        : AnimatedSwitcher(
            duration: Duration(milliseconds: 300),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: _buildViews(),
            ),
          ));

    Widget v = Column(
      mainAxisSize: MainAxisSize.min,
      children: _body,
    );
    if (widget.isModal != null && widget.isModal) {
      return GestureDetector(
        onTap: () {},
        child: v,
      );
    }
    return v;
  }

  bool _wait = true;
  final Map<int, int> lastData = {};

  List<Widget> _buildViews() {
    if (theme == null) theme = Theme.of(context);

    List<Widget> items = [];

    PickerAdapter adapter = picker.adapter;
    if (adapter != null) adapter.setColumn(-1);

    if (adapter != null && adapter.length > 0) {
      for (int i = 0; i < picker._maxLevel; i++) {
        Widget view = Expanded(
          child: Container(
            height: 250,
            child: _wait
                ? null
                : _StateView(
                    key: _keys[i],
                    builder: (context) {
                      adapter.setColumn(i - 1);
                      var _length = adapter.length;
                      var _view = CustomPicker.builder(
                        scrollController: scrollController[i],
                        itemExtent: 55,
                        onSelectedItemChanged: (int _index) {
                          if (_length <= 0) return;
                          var index = _index % _length;
                          picker.selecteds[i] = index;
                          updateScrollController(i);
                          adapter.doSelect(i, index);

                          if (adapter.needUpdatePrev(i))
                            setState(() {});
                          else {
                            _keys[i].currentState.update();
                          }
                        },
                        itemBuilder: (context, index) {
                          adapter.setColumn(i - 1);
                          return adapter.buildItem(context, index % _length);
                        },
                        childCount: _length,
                      );

                      if (picker.selecteds[i] >= _length) {
                        Timer(Duration(milliseconds: 100), () {
                          adapter.setColumn(i - 1);
                          var _len = adapter.length;
                          var _index = (_len < _length ? _len : _length) - 1;
                          scrollController[i]?.jumpToItem(_index);
                        });
                      }

                      return _view;
                    },
                  ),
          ),
        );
        items.add(view);
      }
    }

    return items;
  }

  void updateScrollController(int i) {
    for (int j = 0; j < picker.selecteds.length; j++) {
      if (j != i) {
        if (scrollController[j].position.maxScrollExtent == null) continue;
        scrollController[j].position.notifyListeners();
      }
    }
  }
}

abstract class PickerAdapter<T> {
  ConrolAppPicker picker;

  int getLength();
  int getMaxLevel();
  void setColumn(int index);
  void initSelects();
  Widget buildItem(BuildContext context, int index);

  bool needUpdatePrev(int curIndex) {
    return false;
  }

  Widget makeText(Widget child, String text, bool isSel) {
    return new Center(
      child: DefaultTextStyle(
        textAlign: TextAlign.start,
        style: GoogleFonts.dmSans(
            color: akvaMainNeutral,
            fontSize: FontSize.medium,
            fontWeight: FontWeight.bold),
        child: child != null
            ? child
            : Text(
                text,
                style: (isSel
                    ? TextStyle(
                        color: akvaMainAction,
                        fontSize: FontSize.medium,
                        fontWeight: FontWeight.bold,
                      )
                    : null),
              ),
      ),
    );
  }

  String getText() {
    return getSelectedValues().toString();
  }

  List<T> getSelectedValues() {
    return [];
  }

  void doShow() {}
  void doSelect(int column, int index) {}

  int get maxLevel => getMaxLevel();
  int get length => getLength();
  String get text => getText();

  @override
  String toString() {
    return getText();
  }

  void notifyDataChanged() {
    if (picker != null && picker.state != null) {
      picker.adapter.doShow();
      picker.adapter.initSelects();
      for (int j = 0; j < picker.selecteds.length; j++) {
        picker.state.scrollController[j].jumpToItem(picker.selecteds[j]);
      }
    }
  }
}

class PickerDataAdapter<T> extends PickerAdapter<T> {
  List<PickerItem<T>> data;
  List<PickerItem<dynamic>> _datas;
  int _maxLevel = -1;
  int _col = 0;

  PickerDataAdapter({List pickerdata, this.data}) {
    _parseData(pickerdata);
  }

  void _parseData(final List pickerData) {
    if (pickerData != null &&
        pickerData.length > 0 &&
        (data == null || data.length == 0)) {
      if (data == null) data = List<PickerItem<T>>();
      _parseArrayPickerDataItem(pickerData, data);
    }
  }

  _parseArrayPickerDataItem(List pickerData, List<PickerItem> data) {
    if (pickerData == null) return;
    var len = pickerData.length;
    for (int i = 0; i < len; i++) {
      var v = pickerData[i];
      if (!(v is List)) continue;
      List lv = v;
      if (lv.length == 0) continue;

      PickerItem item = PickerItem<T>(children: List<PickerItem<T>>());
      data.add(item);

      for (int j = 0; j < lv.length; j++) {
        var o = lv[j];
        if (o is T) {
          item.children.add(PickerItem<T>(value: o));
        } else if (T == String) {
          String _v = o.toString();
          item.children.add(PickerItem<T>(value: _v as T));
        }
      }
    }
  }

  void setColumn(int index) {
    if (_datas != null && _col == index + 1) return;
    _col = index + 1;
    if (_col < data.length)
      _datas = data[_col].children;
    else
      _datas = null;
    return;
  }

  @override
  int getLength() {
    return _datas == null ? 0 : _datas.length;
  }

  @override
  getMaxLevel() {
    if (_maxLevel == -1) _checkPickerDataLevel(data, 1);
    return _maxLevel;
  }

  @override
  Widget buildItem(BuildContext context, int index) {
    final PickerItem item = _datas[index];
    if (item.text != null) {
      return item.text;
    }
    return makeText(item.text, item.text != null ? null : item.value.toString(),
        index == picker.selecteds[_col]);
  }

  @override
  void initSelects() {
    if (picker.selecteds == null || picker.selecteds.length == 0) {
      if (picker.selecteds == null) picker.selecteds = new List<int>();
      for (int i = 0; i < _maxLevel; i++) picker.selecteds.add(0);
    }
  }

  @override
  List<T> getSelectedValues() {
    List<T> _items = [];
    if (picker.selecteds != null) {
      var _sLen = picker.selecteds.length;
      for (int i = 0; i < _sLen; i++) {
        int j = picker.selecteds[i];
        if (j < 0 || data[i].children == null || j >= data[i].children.length)
          break;
        _items.add(data[i].children[j].value);
      }
    }
    return _items;
  }

  _checkPickerDataLevel(List<PickerItem> data, int level) {
    if (data == null) return;
    _maxLevel = data.length;
    return;
  }
}

class _StateView extends StatefulWidget {
  final WidgetBuilder builder;
  const _StateView({Key key, this.builder}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _StateViewState();
}

class _StateViewState extends State<_StateView> {
  @override
  Widget build(BuildContext context) {
    return widget.builder(context);
  }

  update() {
    setState(() {});
  }
}

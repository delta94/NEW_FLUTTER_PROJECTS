import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/src/app_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class ConfirmMessage extends StatelessWidget {
  final VoidCallback onTap;
  final String confirmText;
  final bool isConfirmed;
  final Widget confirmWidget;

  ConfirmMessage(
      {this.onTap,
      this.isConfirmed = false,
      this.confirmText,
      this.confirmWidget});
  @override
  Widget build(BuildContext context) {
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);

    return Container(
      margin: EdgeInsets.only(top: 30, left: 20, right: 16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(4),
        border: Border.all(color: akvaMainLiveAction, width: 1.5),
        color: appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorB,
      ),
      child: Column(
        children: <Widget>[
          InkWell(
            onTap: onTap,
            child: Container(
              padding: EdgeInsets.all(16),
              child: Row(
                children: <Widget>[
                  isConfirmed
                      ? Row(
                          children: <Widget>[
                            Container(
                              padding: EdgeInsets.only(
                                  left: 5, right: 7, top: 7, bottom: 5),
                              decoration: BoxDecoration(
                                  color: akvaMainLiveAction,
                                  borderRadius:
                                      BorderRadiusDirectional.circular(32)),
                              child: Icon(AkvaIcons.checked,
                                  size: FontSize.xsmall, color: akvaDarkColorA),
                            ),
                            SizedBox(
                              width: 8,
                            ),
                          ],
                        )
                      : Container(),
                  Expanded(
                    child: Text(
                      confirmText,
                      style: TextStyle(fontSize: FontSize.small),
                    ),
                  )
                ],
              ),
            ),
          ),
          confirmWidget
        ],
      ),
    );
  }
}

import 'package:Commons/fonts.dart';
import 'package:flutter/widgets.dart';

class FadedText extends StatelessWidget {
  const FadedText({
    Key key,
    @required this.text,
  }) : super(key: key);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      overflow: TextOverflow.fade,
      textAlign: TextAlign.left,
      style: TextStyle(fontSize: FontSize.small, fontWeight: FontWeight.w500),
    );
  }
}
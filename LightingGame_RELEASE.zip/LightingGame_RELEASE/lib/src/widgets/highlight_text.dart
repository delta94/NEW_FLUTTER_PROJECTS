import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/src/app_model.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class HighlightText extends StatelessWidget {
  const HighlightText({
    Key key,
    @required this.text,
    this.isShortText: false,
    this.mainAxisAlignment: MainAxisAlignment.start,
  }) : super(key: key);

  final String text;
  final bool isShortText;
  final MainAxisAlignment mainAxisAlignment;

  @override
  Widget build(BuildContext context) {
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);

    _getTextWidget() {
      return Text(
        text,
        style: TextStyle(
          color: akvaMainNeutral,
          fontSize: FontSize.small,
          fontWeight: FontWeight.w500,
        ),
      );
    }

    return Container(
      padding: EdgeInsets.symmetric(vertical: 5, horizontal: 12),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(20),
        color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorE,
      ),
      child: Row(
        mainAxisAlignment: mainAxisAlignment,
        children: <Widget>[
          isShortText
              ? _getTextWidget()
              : Flexible(
                  fit: FlexFit.loose,
                  child: _getTextWidget(),
                ),
        ],
      ),
    );
  }
}

import 'package:flutter/material.dart';

class NumberInput extends StatefulWidget {
  final String title;
  final double initialCount;
  final bool showDeleteButton;
  final bool isInteger;
  final ValueChanged<double> onCountChanged;
  final Function onDelete;

  NumberInput(
      {this.title,
      this.initialCount = 0,
      this.showDeleteButton,
      this.isInteger = true,
      this.onCountChanged,
      this.onDelete});

  @override
  State<StatefulWidget> createState() {
    return _NumberInputState();
  }
}

class _NumberInputState extends State<NumberInput> {
  TextEditingController _controller;
  final FocusNode _focusNode = FocusNode();

  @override
  initState() {
    super.initState();

    _controller = TextEditingController();

    String text = widget.initialCount.toString();
    _controller.value = _controller.value.copyWith(
      text: text,
      selection: TextSelection(baseOffset: 0, extentOffset: text.length),
      composing: TextRange(start: 0, end: text.length),
    );
    _controller.text = widget.isInteger
        ? widget.initialCount.round().toString()
        : widget.initialCount.toString();
    _controller.addListener(_onCountTextChanged);

    _focusNode.addListener(() {
      _controller.value = _controller.value.copyWith(
        selection:
            TextSelection(baseOffset: 0, extentOffset: _controller.text.length),
      );
    });
  }

  @override
  dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: ListTile(
        leading: IconButton(
          icon: Icon(Icons.delete),
          onPressed: widget.onDelete,
        ),
        title: Text(widget.title),
        trailing: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Container(
              width: 55,
              child: TextField(
                  focusNode: _focusNode,
                  textAlign: TextAlign.right,
                  controller: _controller,
                  keyboardType: widget.isInteger
                      ? TextInputType.number
                      : TextInputType.numberWithOptions(decimal: true)),
            ),
            ...stepperButtons(theme),
          ],
        ),
      ),
    );
  }

  List<Widget> stepperButtons(theme) {
    if (widget.isInteger) {
      return [
        Padding(padding: EdgeInsets.only(left: 16)),
        StepperButton(
          iconData: Icons.remove,
          color: theme.secondaryHeaderColor,
          onPressed: () {
            _onStepperButtonPressed(doIncrement: false);
          },
        ),
        Padding(padding: EdgeInsets.only(left: 8)),
        StepperButton(
          color: theme.secondaryHeaderColor,
          iconData: Icons.add,
          onPressed: () {
            _onStepperButtonPressed(doIncrement: true);
          },
        ),
      ];
    }
    return [];
  }

  void _onStepperButtonPressed({doIncrement: bool}) {
    if (!widget.isInteger) {
      return;
    }
    int count = int.parse(_controller.text);
    if (doIncrement) {
      count++;
    } else if (count > 0) {
      count--;
    }
    _controller.text = count.toString();
  }

  void _onCountTextChanged() {
    var number = double.tryParse(_controller.text);
    if (number != null) {
      widget.onCountChanged(number);
    }
  }
}

class StepperButton extends StatelessWidget {
  StepperButton({this.iconData, this.onPressed, this.color});
  final VoidCallback onPressed;
  final IconData iconData;
  final Color color;
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 40,
      height: 40,
      child: Ink(
        decoration: ShapeDecoration(shape: CircleBorder(), color: color),
        child: IconButton(
            color: Colors.white,
            onPressed: onPressed,
            icon: Icon(iconData, size: 24)),
      ),
    );
  }
}

import 'package:Commons/colors.dart';
import 'package:Commons/custom_switch.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/util/utils.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AppDrawer extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context);
    final appText = S.of(context);

    return SafeArea(
      child: Drawer(
        child: Scaffold(
          backgroundColor:
              appModel.isDarkTheme ? akvaDarkColorF : akvaDarkColorE,
          body: Container(
            child: Column(
              children: <Widget>[
                DrawerHeader(),
                Container(
                  color:
                      appModel.isDarkTheme ? akvaDarkColorF : akvaLightColorB,
                  child: Column(
                    children: <Widget>[
                      Divider(
                          height: 1,
                          thickness: 1,
                          color: appModel.isDarkTheme
                              ? akvaDarkColorD
                              : akvaDarkTextA),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(appModel.isDarkTheme
                                ? appText.dark_mode
                                : appText.light_mode),
                            CustomSwitch(
                              haveOnOffColor: false,
                              isDarkTheme: appModel.isDarkTheme,
                              initValue: appModel.isDarkTheme,
                              onChanged: () => appModel.toggleTheme(),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 20, top: 0),
                        child: Divider(
                            height: 1,
                            thickness: 1,
                            color: appModel.isDarkTheme
                                ? akvaDarkColorB
                                : akvaDarkTextA),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 20, vertical: 20),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Text(appText.hide_empty_units),
                            CustomSwitch(
                              isDarkTheme: appModel.isDarkTheme,
                              initValue: appModel.hideEmptyUnit,
                              onChanged: () => appModel.toggleHideEmptyUnits(),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 20),
                        child: Divider(
                            height: 1,
                            thickness: 1,
                            color: appModel.isDarkTheme
                                ? akvaDarkColorB
                                : akvaDarkTextA),
                      ),
                      Container(
                        margin: const EdgeInsets.only(
                            left: 20, right: 20, bottom: 20, top: 20),
                        decoration: BoxDecoration(
                            border: Border.all(
                                color: appModel.isDarkTheme
                                    ? akvaDarkColorE
                                    : akvaLightColorE),
                            color: appModel.isDarkTheme
                                ? akvaDarkColorA
                                : akvaLightColorA),
                        child: LanguageSelector(),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 20),
                        child: Divider(
                            thickness: 1,
                            color: appModel.isDarkTheme
                                ? akvaDarkColorB
                                : akvaDarkTextA),
                      ),
                      Container(
                          margin: EdgeInsets.only(bottom: 30, top: 20),
                          child: LogoutButton()),
                    ],
                  ),
                ),
                Divider(
                    height: 1,
                    thickness: 1,
                    color:
                        appModel.isDarkTheme ? akvaDarkColorB : akvaDarkTextA),
                Expanded(
                  child: Container(
                    color:
                        appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorA,
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class LanguageSelector extends StatelessWidget {
  const LanguageSelector({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context);
    return Row(children: <Widget>[
      SizedBox(width: 20),
      Icon(AkvaIcons.language, color: akvaMainNeutral),
      SizedBox(width: 10),
      Expanded(
        child: DropdownButtonHideUnderline(
          child: DropdownButton<String>(
              isDense: true,
              value: appModel.currentLocale.languageCode,
              icon: Container(
                padding: EdgeInsets.all(8),
                decoration: BoxDecoration(
                    border: Border(
                      left: BorderSide(
                          color: appModel.isDarkTheme
                              ? akvaDarkColorE
                              : akvaLightColorE),
                    ),
                    color: appModel.isDarkTheme
                        ? akvaDarkColorA
                        : akvaLightColorA),
                child: Icon(Icons.keyboard_arrow_down,
                    size: 26, color: akvaMainNeutral),
              ),
              onChanged: (String val) {
                appModel.setCurrentLocale(Locale(val));
              },
              iconSize: 40,
              items: <DropdownMenuItem<String>>[
                new DropdownMenuItem(
                  child: Text("English"),
                  value: 'en',
                ),
                new DropdownMenuItem(
                  child: Text("Norsk"),
                  value: 'nb',
                ),
              ]),
        ),
      ),
    ]);
  }
}

class DrawerHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context);
    return Container(
        margin: EdgeInsets.only(top: 24),
        padding: EdgeInsets.all(10),
        child: Column(
          children: <Widget>[
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: <Widget>[
                Container(
                  margin: EdgeInsets.only(left: 10),
                  child: CircleAvatar(
                    backgroundColor: akvaMainAction,
                    child: Text(
                      getShortName(appModel),
                      style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.bold,
                          color: akvaDarkColorB),
                    ),
                  ),
                ),
                SizedBox(width: 10),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    Wrap(children: <Widget>[
                      Text(
                        this._getUserName(appModel),
                        style: TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 15,
                            color: appModel.isDarkTheme
                                ? akvaDarkTextA
                                : akvaLightColorB),
                      )
                    ]),
                    Text(
                        'Job Description', //Placeholder; don´t need translatable text
                        style: TextStyle(
                            fontSize: 12,
                            color: appModel.isDarkTheme
                                ? akvaDarkTextB
                                : akvaLightColorB)),
                  ],
                ),
              ],
            ),
          ],
        ));
  }

  _getUserName(AppModel appModel) {
    String userName = '';
    if (appModel.currentUserInfo != null) {
      userName = (appModel.currentUserInfo.givenName ?? '') +
          ' ' +
          (appModel.currentUserInfo.familyName ?? '');
    }

    if (userName.trim() == '') {
      String name = appModel.currentUserInfo.name;
      if (name != null && name != '') userName = name;
    }

    return userName;
  }
}

class LogoutButton extends StatelessWidget {
  const LogoutButton({
    Key key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context);
    final appText = S.of(context);

    return Container(
      margin: EdgeInsets.only(left: 20, right: 20),
      child: Row(
        children: <Widget>[
          Expanded(
            child: FlatButton(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(4),
              ),
              padding: EdgeInsets.only(top: 8, bottom: 8),
              color: akvaMainAction,
              onPressed: () async {
                Navigator.pop(context);
                await appModel.logOut();
              },
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Icon(
                    AkvaIcons.logout,
                    size: 24,
                    color:
                        appModel.isDarkTheme ? akvaDarkColorD : akvaLightTextA,
                  ),
                  SizedBox(width: 10),
                  Text(
                    appText.logout,
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: appModel.isDarkTheme
                          ? akvaDarkColorD
                          : akvaLightTextA,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

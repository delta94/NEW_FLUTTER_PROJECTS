import 'package:Commons/colors.dart';
import 'package:Commons/icons.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';

class DeleteButton extends StatelessWidget {
  final bool isVisible;
  final VoidCallback callback;

  DeleteButton({@required this.isVisible, @required this.callback});

  @override
  Widget build(BuildContext context) {
    return Visibility(
      visible: isVisible,
      child: Wrap(
        children: [
          Material(
            color: Colors.transparent,
            child: InkWell(
              onTap: () => callback(),
              child: Icon(
                AkvaIcons.trash,
                size: 25,
                color: akvaMainActionDisabled,
              ),
            ),
          ),
          SizedBox(width: 8),
        ],
      ),
    );
  }
}

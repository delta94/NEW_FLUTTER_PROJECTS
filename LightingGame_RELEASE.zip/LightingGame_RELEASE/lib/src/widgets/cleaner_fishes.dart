import 'package:Commons/buttons.dart';
import 'package:Commons/colors.dart';
import 'package:Commons/dropdown.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/util/utils.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class CleanerFishes extends StatefulWidget {
  final int selectedCleanerFishId;
  final Function(int) onTapCleanerFish;

  CleanerFishes(
      {@required this.selectedCleanerFishId, @required this.onTapCleanerFish});

  @override
  _CleanerFishesState createState() => _CleanerFishesState();
}

class _CleanerFishesState extends State<CleanerFishes> {
  isSelectedCleanerFish(int cleanerFishId) {
    return widget.selectedCleanerFishId == cleanerFishId;
  }

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    var appModel = Provider.of<AppModel>(context, listen: false);
    var organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);

    List<OptionItem> allCleanerFishOptions = [];
    organizationModel.speciesOfCurrentUnit.forEach((specie) {
      if (specie.speciesId != 1) {
        allCleanerFishOptions
            .add(new OptionItem(id: specie.speciesId, label: specie.name));
      }
    });

    return Row(
      children: [
        Expanded(
          child: Padding(
            padding: const EdgeInsets.only(left: 20.0, top: 16.0, right: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Visibility(
                  visible: organizationModel.speciesOfCurrentUnit.length > 1,
                  child: Column(
                    children: <Widget>[
                      Text(
                        appText.cleaner_fish_type,
                        style: TextStyle(
                            fontSize: FontSize.small,
                            fontWeight: FontWeight.normal,
                            color: appModel.isDarkTheme
                                ? akvaDarkTextA
                                : akvaDarkColorD),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                    ],
                  ),
                ),
                Container(
                  height: 34,
                  margin: EdgeInsets.only(top: 12),
                  child: new ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: allCleanerFishOptions.length,
                    itemBuilder: (BuildContext ctxt, int index) {
                      return Container(
                        margin: EdgeInsets.only(right: 12),
                        child: AkvaClickableLabel(
                          label: allCleanerFishOptions[index].label,
                          active:
                              isSelectedOption(allCleanerFishOptions[index], [
                            new OptionItem(
                              id: widget.selectedCleanerFishId,
                              label: null,
                            )
                          ]),
                          onPressed: () => widget.onTapCleanerFish(
                            allCleanerFishOptions[index].id,
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

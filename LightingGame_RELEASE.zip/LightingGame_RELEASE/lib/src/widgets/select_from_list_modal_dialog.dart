import 'package:flutter/material.dart';

class SelectFromListModalDialog extends StatelessWidget {
  final String dialogTitle;
  final List<String> itemTitles;
  final Function(int) clickedItemCallback;

  SelectFromListModalDialog(
      {this.dialogTitle, this.itemTitles, this.clickedItemCallback});

  Widget build(BuildContext context) {
    return SimpleDialog(
      title: Text(dialogTitle),
      children: List.generate(itemTitles.length, (i) {
        return SimpleDialogOption(
          onPressed: () => clickedItemCallback(i),
          child: Card(
            elevation: 0,
            child: InkWell(child: Text(itemTitles[i])),
          ),
        );
      }),
    );
  }
}

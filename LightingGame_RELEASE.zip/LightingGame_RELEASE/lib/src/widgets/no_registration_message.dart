import 'package:Commons/colors.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import 'confirm_message.dart';

class NoRegistrationMessage extends StatefulWidget {
  const NoRegistrationMessage({
    Key key,
    this.isOnlySalmon: false,
    this.registrationStatus,
  }) : super(key: key);

  final bool isOnlySalmon;
  final RegistrationStatus registrationStatus;

  @override
  _NoRegistrationMessageState createState() => _NoRegistrationMessageState();
}

class _NoRegistrationMessageState extends State<NoRegistrationMessage> {
  GlobalKey noRegistrationKey = GlobalKey();
  double noRegistrationKeyWidth = 0;

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback(_getNoRegistrationKeyWidth);
    super.initState();
  }

  void _getNoRegistrationKeyWidth(_) {
    final RenderBox noRegistrationKeyBox =
        noRegistrationKey.currentContext.findRenderObject();
    setState(() {
      noRegistrationKeyWidth = noRegistrationKeyBox.size.width;
    });
  }

  Widget getClickAddNewCountMessage(message) {
    if (noRegistrationKey.currentContext != null) {
      return Container(
        width: noRegistrationKeyWidth,
        child: Text(
          message,
          style: TextStyle(fontSize: 18, color: akvaMainNeutral),
          textAlign: TextAlign.center,
        ),
      );
    } else {
      return Container();
    }
  }

  @override
  Widget build(BuildContext context) {
    final S appText = S.of(context);
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: <Widget>[
        Visibility(
          visible: widget.registrationStatus == RegistrationStatus.NO_FISH,
          child: ConfirmMessage(
            confirmText: appText.no_fish,
            confirmWidget: Container(),
          ),
        ),
        Visibility(
          visible:
              widget.registrationStatus == RegistrationStatus.NO_REGISTRATION,
          maintainState: true,
          maintainSize: true,
          maintainAnimation: true,
          child: Container(
            child: Column(
              children: <Widget>[
                Container(
                  child: CircleAvatar(
                    radius: 30,
                    backgroundColor:
                        appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
                    child: Icon(
                      AkvaIcons.pen_thin,
                      size: 35,
                      color: appModel.isDarkTheme
                          ? akvaDarkColorA
                          : akvaMainNeutral,
                    ),
                  ),
                ),
                SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 72, right: 72),
                  child: Row(
                    children: <Widget>[
                      Expanded(
                        child: Column(
                          children: <Widget>[
                            Text(
                              appText.no_registrations_yet,
                              key: noRegistrationKey,
                              style: TextStyle(
                                fontSize: 22,
                                color: akvaMainNeutral,
                              ),
                              textAlign: TextAlign.center,
                            ),
                            SizedBox(height: 5),
                            getClickAddNewCountMessage(appText
                                .click_new_registration_to_start_registering),
                            SizedBox(height: 15),
                            widget.isOnlySalmon
                                ? Text(
                                    appText.only_applicable_to_salmon,
                                    style: TextStyle(
                                      fontSize: 18,
                                      color: akvaMainNeutral,
                                    ),
                                    textAlign: TextAlign.center,
                                  )
                                : Container(),
                          ],
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
        SizedBox(
          height: 10,
        ),
        SizedBox(
          height: 10,
        ),
      ],
    );
  }
}

import 'dart:convert';
import 'package:control_app/src/database/app_config_db_repository.dart';
import 'package:control_app/src/models/user_right.dart';
import 'package:intl/intl.dart';
import 'package:control_app/src/models/feeding/feed_type_available.dart';
import 'package:control_app/src/models/unit_status.dart';
import 'package:control_app/src/services/timezone_service.dart';

import '../models/site_model.dart';
import '../repositories/organization_repository.dart';
import '../services/api_service.dart';

class OrganizationCloudRepository extends OrganizationRepository {
  final _apiService = ApiService();

  @override
  Future<OrganizationRoot> fetchOrganization() async {
    try {
      return await _apiService.httpGet('${ApiService.urlRoot}/organization/structure', (data) {
        orgTreeJson = data;

        return parseOrgTreeJsonData(data);
      });
    } on AuthenticationException catch (e) {
      print('got exception');
      print(e);
      return null;
    }
  }

  Future<UserRight> fetchUserRight() async {
    try {
      return await _apiService.httpGet('${ApiService.urlRoot}/users/rights',
          (data) async {
        await AppConfigDBRepository.saveAppConfig(
            AppConfigKeys.userRight, data);
        return userRightFromMap(data);
      });
    } catch (e) {
      print('got exception');
      print(e);
      return null;
    }
  }

  @override
  Future<OrganizationRoot> fetchSites() async {
    try {
      return await _apiService.httpGet('${ApiService.urlRoot}/sites', (data) {
        sitesJson = data;
        return parseSitesJsonData(data);
      });
    } on AuthenticationException catch (e) {
      print('got exception');
      print(e);
      return null;
    }
  }

  Future<Map<String, UnitStatus>> fetchUnitStatusBySite(List<Site> sites) async {
    var futures = <Future>[];

    Map<String, UnitStatus> unitStatusMap = new Map<String, UnitStatus>();
    for (int i = 0; i < sites.length; i++) {
      var future = fetchSiteStatus(sites[i]).then((map) {
        unitStatusMap.addAll(map);
      });

      futures.add(future);
    }

    await Future.wait(futures);

    return unitStatusMap;
  }

  Future<Map<String, UnitStatus>> fetchSiteStatus(Site site) async {
    
    var nowInSite = TimeZoneService.convertToTimezone(DateTime.now(), site.timeZoneId);

    DateTime from = new DateTime(nowInSite.year, nowInSite.month, nowInSite.day);
    DateTime to = new DateTime(nowInSite.year, nowInSite.month, nowInSite.day, 23, 59, 0);

    DateFormat dateFormat = DateFormat('yyyy-MM-ddTHH:mm:ss');
    
    return await _apiService.httpGet(
        '${ApiService.urlRoot}/control/status/site/${site.id}?openingtime=${dateFormat.format(from)}&closingtime=${dateFormat.format(to)}', (body) {
      Map<String, UnitStatus> unitStatusMap = new Map<String, UnitStatus>();

      var jsonBody = jsonDecode(body);
      var statusArray = jsonBody['data'];

      if (statusArray.length > 0) {
        statusArray.forEach((item) {
          try{
            var status = UnitStatus.fromMap(item);
            unitStatusMap[status.unitId] = status;
          }
          catch (e) {
            print(e);
          } 
        });
      } 
      
      return unitStatusMap;
    });
  }

  @override
  Future<Map<String, List<int>>> fetchUnitSpecies(List<String> siteIds) async {
    var futures = <Future>[];

    Map<String, List<int>> unitSpeciesMap = new Map<String, List<int>>();
    for (int i = 0; i < siteIds.length; i++) {
      var future = fetchSiteSpecies(siteIds[i]).then((map) {
        unitSpeciesMap.addAll(map);
      });

      futures.add(future);
    }

    await Future.wait(futures);

    return unitSpeciesMap;
  }

  Future<Map<String, List<int>>> fetchSiteSpecies(String siteId) async {
    return await _apiService.httpGet(
        '${ApiService.urlRoot}/control/site/$siteId/species/controlapp', (body) {
      Map<String, List<int>> unitSpeciesMap = new Map<String, List<int>>();

      List<dynamic> siteSpecies = jsonDecode(body);
      if (siteSpecies.length > 0) {
        siteSpecies.forEach((reg) {
          String unitId = reg['unitId'];
          int speciesId = reg['speciesId'];
          
          if (!unitSpeciesMap.containsKey(unitId)) {
            unitSpeciesMap[unitId] = new List<int>();
          }

          if (!unitSpeciesMap[unitId].contains(speciesId)) {
            unitSpeciesMap[unitId].add(speciesId);
          }
        });
      }

      return unitSpeciesMap;
    });
  }

  Future<List<FeedTypeAvailable>> fetchSiteFeedTypes(String siteId) async {
    return await _apiService.httpGet(
        '${ApiService.urlRoot}/control/feeding/site/$siteId/feedtypes', (body) {
      List<FeedTypeAvailable> result = feedTypeAvailableFromMap(body);

      return result;
    });
  }

  Future<Map<String, List<FeedTypeAvailable>>> fetchSitesFeedTypes(List<String> siteIds) async {
    var futures = <Future>[];

    Map<String, List<FeedTypeAvailable>> siteFeedTypesMap = new Map<String, List<FeedTypeAvailable>>();
    
    for (int i = 0; i < siteIds.length; i++) {
      var future = fetchSiteFeedTypes(siteIds[i]).then((map) {
        siteFeedTypesMap[siteIds[i]] = map;
      });

      futures.add(future);
    }

    await Future.wait(futures);

    return siteFeedTypesMap;
  }

}

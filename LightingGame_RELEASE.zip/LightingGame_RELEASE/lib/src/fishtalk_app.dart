import 'package:Commons/colors.dart';
import 'package:Commons/themes.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/environment/view_models/environment_view_model.dart';
import 'package:control_app/src/feeding/view_models/salmon_feeding_registration_view_model.dart';
import 'package:control_app/src/lice/widgets/lice_registration_content.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/mortality/no_mortality_confirmation.dart';
import 'package:control_app/src/mortality/view_models/salmon_mortality_registration_view_model.dart';
import 'package:control_app/src/provider_setup.dart';
import 'package:control_app/src/routers.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/main/main_screen.dart';
import 'package:control_app/src/navigation/navigation_screen.dart';
import 'package:control_app/src/widgets/add_new_registration_ui/add_new_registration.dart';
import 'package:control_app/src/widgets/registration_screen.dart';
import 'package:control_app/src/widgets/registration_ui/registration_body.dart';
import 'package:control_app/src/widgets/registration_ui/registration_content.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'environment/widgets/add_new_environment_registration.dart';
import 'feeding/missed_feeding_confirmation.dart';
import 'lice/widgets/add_new_lice_registration.dart';
import 'login/login_screen.dart';
import 'widgets/registration_bottom_action_button.dart';
import 'widgets/registration_ui/no_tabbar_registration_body.dart';

class FishtalkApp extends StatelessWidget {
  // This widget is the root of your application.

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: providers,
      child: InitialScreen(),
    );
  }
}

class InitialScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final appModel = Provider.of<AppModel>(context);
    final orgModel = Provider.of<OrganizationModel>(context, listen: false);

    return MaterialApp(
      title: 'Fishtalk App',
      theme: appModel.isDarkTheme ? akvaDarkTheme : akvaLightTheme,
      home: appModel.isAuthenticated && appModel.currentUserInfo != null
          ? NavigationScreen()
          : LoginScreen(),
      routes: {
        Routers.main: (context) => MainScreen(),
        Routers.mortality: (context) => RegistrationScreen(
              registrationType: RegistrationType.Mortality,
              title: S.of(context).mortality_registration,
              unitName: orgModel.currentOrganizationEntity.name,
              decorationColor: akvaMainSecondary,
              body: RegistrationBody(
                registrationType: RegistrationType.Mortality,
                confirmationWidget: NoMortalityConfirmation(
                  model: Provider.of<SalmonMortalityRegistrationViewModel>(
                    context,
                  ),
                ),
              ),
              bottomNavigationBar: RegistrationBottomActionButton(
                decorationColor: akvaMainSecondary,
                addRegistrationPage: AddNewRegistration(
                    registrationType: RegistrationType.Mortality),
                registrationType: RegistrationType.Mortality,
              ),
            ),
        Routers.feeding: (context) => RegistrationScreen(
              registrationType: RegistrationType.Feeding,
              title: S.of(context).feeding_registration,
              unitName: orgModel.currentOrganizationEntity.name,
              decorationColor: akvaAccentMain,
              body: RegistrationBody(
                registrationType: RegistrationType.Feeding,
                confirmationWidget: MissedFeedConfirmation(
                    model: Provider.of<SalmonFeedingRegistrationViewModel>(
                        context)),
              ),
              bottomNavigationBar: RegistrationBottomActionButton(
                decorationColor: akvaAccentMain,
                addRegistrationPage: AddNewRegistration(
                    registrationType: RegistrationType.Feeding),
                registrationType: RegistrationType.Feeding,
              ),
            ),
        Routers.culling: (context) => RegistrationScreen(
              registrationType: RegistrationType.Culling,
              title: S.of(context).culling_registration,
              unitName: orgModel.currentOrganizationEntity.name,
              decorationColor: akvaMainTertiary,
              body:
                  RegistrationBody(registrationType: RegistrationType.Culling),
              bottomNavigationBar: RegistrationBottomActionButton(
                decorationColor: akvaMainTertiary,
                addRegistrationPage: AddNewRegistration(
                  registrationType: RegistrationType.Culling,
                ),
                registrationType: RegistrationType.Culling,
              ),
            ),
        Routers.lice: (context) => RegistrationScreen(
              registrationType: RegistrationType.Lice,
              title: S.of(context).lice_registration,
              unitName: orgModel.currentUnit.name,
              decorationColor: akvaLiceColor,
              body: NoTabbarRegistrationBody(
                  registrationType: RegistrationType.Lice,
                  registrationContent: new LiceRegistrationContent()),
              bottomNavigationBar: RegistrationBottomActionButton(
                decorationColor: akvaLiceColor,
                addRegistrationPage: AddNewLiceRegistration(
                    addNewLiceScreenType: AddNewLiceScreenType.SEDATION),
                registrationType: RegistrationType.Lice,
              ),
            ),
        Routers.environment: (context) => RegistrationScreen(
              registrationType: RegistrationType.Environment,
              title: S.of(context).environment_registration,
              unitName: orgModel.currentUnit.name,
              decorationColor: akvaMainActionDisabled,
              body: NoTabbarRegistrationBody(
                registrationType: RegistrationType.Environment,
                registrationContent: RegistrationContent(
                  isNoTab: true,
                  registrationType: RegistrationType.Environment,
                  model: Provider.of<EnvironmentViewModel>(context),
                  showBottomTotal: false,
                ),
              ),
              bottomNavigationBar: RegistrationBottomActionButton(
                decorationColor: akvaMainActionDisabled,
                addRegistrationPage: AddNewEnvironmentRegistration(),
                registrationType: RegistrationType.Environment,
              ),
            ),
      },
      localizationsDelegates: [
        S.delegate,
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
      ],
      supportedLocales: S.delegate.supportedLocales,
      locale: appModel.currentLocale,
    );
  }
}

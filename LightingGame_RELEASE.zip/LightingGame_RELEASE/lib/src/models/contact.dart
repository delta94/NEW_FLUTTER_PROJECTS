// To parse this JSON data, do
//
//     final contact = contactFromMap(jsonString);

import 'dart:convert';

List<Contact> contactFromMap(String str) => List<Contact>.from(json.decode(str).map((x) => Contact.fromMap(x)));

String contactToMap(List<Contact> data) => json.encode(List<dynamic>.from(data.map((x) => x.toMap())));

class Contact {
    Contact({
        this.name,
        this.id,
        this.userId
    });

    String name;
    String id;
    String userId;

    factory Contact.fromMap(Map<String, dynamic> json) => Contact(
        name: json["name"],
        id: json["id"],
        userId: json["userId"],
    );

    Map<String, dynamic> toMap() => {
        "name": name,
        "id": id,
        "userId": userId
    };
}

class RegistrationWrasse{
  bool wrasse = false;
  RegistrationWrasse({this.wrasse});
}
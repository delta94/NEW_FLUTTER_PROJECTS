// To parse this JSON data, do
//
//     final sedationMethod = sedationMethodFromMap(jsonString);

import 'dart:convert';

import 'lice_sample.dart';

List<SedationMethod> sedationMethodFromMap(String str) => List<SedationMethod>.from(json.decode(str).map((x) => SedationMethod.fromMap(x)));

String sedationMethodToMap(List<SedationMethod> data) => json.encode(List<dynamic>.from(data.map((x) => x.toMap())));

class SedationMethod {
    SedationMethod({
        this.withdrawal,
        this.medicamentCategoryId,
        this.name,
        this.itemId,
    });

    Withdrawal withdrawal;
    String name;
    int itemId;
    int medicamentCategoryId;

    factory SedationMethod.fromMap(Map<String, dynamic> json) => SedationMethod(
        withdrawal: json["withdrawal"] == null ? null : Withdrawal.fromMap(json["withdrawal"]),
        medicamentCategoryId: json["medicamentCategoryId"] == null ? null : json["medicamentCategoryId"],
        name: json["name"],
        itemId: json["itemId"],
    );

    Map<String, dynamic> toMap() => {
        "withdrawal": withdrawal == null ? null : withdrawal.toMap(),
        "medicamentCategoryId": medicamentCategoryId == null ? null : medicamentCategoryId,
        "name": name,
        "itemId": itemId,
    };
}


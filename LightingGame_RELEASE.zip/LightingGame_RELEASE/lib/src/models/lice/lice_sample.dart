// To parse this JSON data, do
//
//     final liceRegistration = liceRegistrationFromMap(jsonString);

import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:flutter/material.dart';
import 'package:undo/undo.dart';

LiceSample liceRegistrationFromMap(String str) =>
    LiceSample.fromMap(json.decode(str));

String liceRegistrationToMap(LiceSample data) => json.encode(data.toMap());

class LiceSample extends RegistrationBaseItem {
  LiceSample({
    medicamentId,
    volumeLitre = 0.0,
    amountMilliLitre = 0.0,
    bathDuration,
    batchNo,
    expiryDate,
    this.overrideWithdrawal = false,
    this.withdrawal,
    quarantineDetails,
    this.samples,
    this.sampleTakerContactId,
    this.reportGenerated = false,
  })  : _medicamentId = medicamentId,
        _volumeLitre = volumeLitre,
        _amountMilliLitre = amountMilliLitre,
        _bathDuration = bathDuration,
        _batchNo = batchNo,
        _expiryDate = expiryDate,
        _quarantineDetails = quarantineDetails;

  /// The property is for tracking if the model has any changed
  /// and be able to rollback to orginal data in case user discard update.
  /// It does not affect to data model.
  final ChangeStack _changeStack = new ChangeStack();

  /// Sedation method id
  int _medicamentId;
  int get medicamentId => _medicamentId;
  set medicamentId(int val) {
    if (_medicamentId != val) {
      _changeStack.add(Change.property(_medicamentId, () => _medicamentId = val,
          (oldValue) => _medicamentId = oldValue));
    }
  }

  /// Water in sedation unit
  double _volumeLitre;
  double get volumeLitre => _volumeLitre;
  set volumeLitre(double val) {
    if (_volumeLitre != val) {
      _changeStack.add(Change.property(_volumeLitre, () => _volumeLitre = val,
          (oldValue) => _volumeLitre = oldValue));
    }
  }

  /// Sedation used
  double _amountMilliLitre;
  double get amountMilliLitre => _amountMilliLitre;
  set amountMilliLitre(double val) {
    if (_amountMilliLitre != val) {
      _changeStack.add(Change.property(
          _amountMilliLitre,
          () => _amountMilliLitre = val,
          (oldValue) => _amountMilliLitre = oldValue));
    }
  }

  /// Duration
  String _bathDuration;
  String get bathDuration => _bathDuration;
  set bathDuration(String val) {
    if (_bathDuration != val) {
      _changeStack.add(Change.property(_bathDuration, () => _bathDuration = val,
          (oldValue) => _bathDuration = oldValue));
    }
  }

  /// Batch Number
  String _batchNo;
  String get batchNo => _batchNo;
  set batchNo(String val) {
    if (_batchNo != val) {
      _changeStack.add(Change.property(
          _batchNo, () => _batchNo = val, (oldValue) => _batchNo = oldValue));
    }
  }

  /// Expriration date
  DateTime _expiryDate;
  DateTime get expiryDate => _expiryDate;
  set expiryDate(DateTime val) {
    if (_expiryDate != val) {
      _changeStack.add(Change.property(_expiryDate, () => _expiryDate = val,
          (oldValue) => _expiryDate = oldValue));
    }
  }

  /// Helper property to mark quarantine the fish or not
  /// This property will not be persisted to local storage or cloud api
  bool _quarantineTheFish = true;
  bool get quarantineTheFish => _quarantineTheFish;
  set quarantineTheFish(bool val) {
    if (_quarantineTheFish != val) {
      _changeStack.add(Change.property(
          _quarantineTheFish,
          () => _quarantineTheFish = val,
          (oldValue) => _quarantineTheFish = oldValue));
    }
  }

  /// By default, widthdrawal info will be retreived
  /// from medication data. In case user overrides
  /// this info then [overrideWithdrawal] will set to [true]
  bool overrideWithdrawal;

  /// When [overrideWithdrawal] was set to true then
  /// this property must be filled.
  Withdrawal withdrawal;

  /// Quarantine object
  QuarantineDetails _quarantineDetails;
  QuarantineDetails get quarantineDetails => _quarantineDetails;
  set quarantineDetails(QuarantineDetails val) {
    _changeStack.add(Change.property(
        _quarantineDetails,
        () => _quarantineDetails = val,
        (oldValue) => _quarantineDetails = oldValue));
  }

  /// List of lice samples
  List<Sample> samples;

  /// sample taker id
  String sampleTakerContactId;

  /// This property will be set to [true] automatically
  /// on API when user sign & submit the registration.
  bool reportGenerated;

  double get concentration => _calConcentration();
  double _calConcentration() {
    if (volumeLitre != 0) {
      double val = amountMilliLitre / volumeLitre;
      return num.parse(val.toStringAsFixed(1));
    }
    return 0.0;
  }

  factory LiceSample.fromMap(Map<String, dynamic> json) => LiceSample(
        medicamentId: json["medicamentId"],
        volumeLitre: json["volumeLitre"].toDouble(),
        amountMilliLitre: json["amountMilliLitre"].toDouble(),
        bathDuration: json["bathDuration"],
        batchNo: json["batchNo"],
        expiryDate: json["expiryDate"] == null
            ? null
            : DateTime.tryParse(json["expiryDate"]),
        overrideWithdrawal: json["overrideWithdrawal"],
        withdrawal: json["withdrawal"] == null
            ? null
            : Withdrawal.fromMap(json["withdrawal"]),
        quarantineDetails: json["quarantineDetails"] != null
            ? QuarantineDetails.fromMap(json["quarantineDetails"])
            : null,
        samples:
            List<Sample>.from(json["samples"].map((x) => Sample.fromMap(x))),
        sampleTakerContactId: json["sampleTakerContactId"],
        reportGenerated: json["reportGenerated"],
      );

  Map<String, dynamic> toMap() => {
        "medicamentId": medicamentId,
        "volumeLitre": volumeLitre,
        "amountMilliLitre": amountMilliLitre,
        "bathDuration": bathDuration,
        "batchNo": batchNo,
        "expiryDate": expiryDate != null
            ? DateFormat('yyyy-MM-ddTHH:mm:ss').format(expiryDate)
            : null,
        "overrideWithdrawal": overrideWithdrawal,
        "withdrawal": withdrawal == null ? null : withdrawal.toMap(),
        "quarantineDetails":
            quarantineDetails != null ? quarantineDetails.toMap() : null,
        "samples": List<dynamic>.from(samples.map((x) => x.toMap())),
        "sampleTakerContactId": sampleTakerContactId,
        "reportGenerated": reportGenerated,
      };

  @override
  void addItem(itemId, double val) {
    throw UnimplementedError();
  }

  @override
  countAt(int index) {
    throw UnimplementedError();
  }

  @override
  countObjAt(int index) {
    throw UnimplementedError();
  }

  @override
  String countTitle(BuildContext context, int index) {
    throw UnimplementedError();
  }

  @override
  bool get enable => true;

  @override
  bool hasChanged() {
    throw UnimplementedError();
  }

  @override
  bool get isEmpty => false;

  @override
  bool get isValidData => throw UnimplementedError();

  @override
  bool isSameCount(obj, item) {
    throw UnimplementedError();
  }

  @override
  bool isSameCountAt(int index, itemId) {
    throw UnimplementedError();
  }

  @override
  int get length => throw UnimplementedError();

  @override
  void removeItem(item) {
    throw UnimplementedError();
  }

  @override
  void rollback() {
    while (_changeStack.canUndo) {
      _changeStack.undo();
    }
    withdrawal.rollback();

    /// In case user select no quarantine then
    /// [quarantineDetails] will be null. We need
    /// to check null for this case.
    if (quarantineDetails != null) {
      quarantineDetails.rollback();
    }
    samples.forEach((sample) {
      sample.rollback();
    });
  }

  void commit() {
    if (_changeStack.canUndo) {
      _changeStack.clear();
    }
    withdrawal.commit();
    if (quarantineDetails != null) quarantineDetails.commit();
    samples.forEach((sample) {
      sample.commit();
    });
  }

  @override
  totalCount() {
    throw UnimplementedError();
  }

  @override
  void updateItem(itemId, val) {
    throw UnimplementedError();
  }

  @override
  void clearTracking() {
    _changeStack.clear();
  }
}

enum Consequence { CanNotHarvest, CanNotSell, CannotMix, CanNotMove }

class QuarantineDetails {
  QuarantineDetails({
    consequences = 15,
    affectedUnitIds,
    manualClearance = false,
    affectedOtherUnits = false,
  })  : _consequences = consequences,
        _affectedUnitIds = affectedUnitIds,
        _manualClearance = manualClearance,
        _affectedOtherUnits = affectedOtherUnits;

  /// The property is for tracking if the model has any changed
  /// and be able to rollback to orginal data in case user discard update.
  /// It does not affect to data model.
  final ChangeStack _changeStack = new ChangeStack();

  /// enum flags. 1: CanNotHarvest, 2: CanNotSell,
  /// 4: CannotMix, 8: CanNotMove. We can combine these values by bitwise.
  int _consequences;
  int get consequences => _consequences;
  set consequences(int val) {
    if (_consequences != val) {
      _changeStack.add(Change.property(_consequences, () => _consequences = val,
          (oldValue) => _consequences = oldValue));
    }
  }

  /// List of affected units
  List<String> _affectedUnitIds;
  List<String> get affectedUnitIds => _affectedUnitIds;
  set affectedUnitIds(List<String> val) {
    _changeStack.add(Change.property(
        [..._affectedUnitIds],
        () => _affectedUnitIds = [...val],
        (oldValue) => _affectedUnitIds = oldValue));
  }

  /// A helper property to indicate whether the check box
  /// "Affected other units" is checked or not.
  bool _affectedOtherUnits;
  bool get affectedOtherUnits => _affectedOtherUnits;
  set affectedOtherUnits(bool val) {
    _changeStack.add(Change.property(
        _affectedOtherUnits,
        () => _affectedOtherUnits = val,
        (oldValue) => _affectedOtherUnits = oldValue));
  }

  /// false: Automatic clearance at the end of biological period,
  /// true: Require formal clearance
  bool _manualClearance;
  bool get manualClearance => _manualClearance;
  set manualClearance(bool val) {
    if (_manualClearance != val) {
      _changeStack.add(Change.property(
          _manualClearance,
          () => _manualClearance = val,
          (oldValue) => _manualClearance = oldValue));
    }
  }

  void rollback() {
    while (_changeStack.canUndo) {
      _changeStack.undo();
    }
  }

  void commit() {
    if (_changeStack.canUndo) {
      _changeStack.clear();
    }
  }

  factory QuarantineDetails.fromMap(Map<String, dynamic> json) =>
      QuarantineDetails(
        consequences: json["consequences"],
        affectedUnitIds:
            List<String>.from(json["affectedUnitIds"].map((x) => x)),
        manualClearance: json["manualClearance"],
      );

  Map<String, dynamic> toMap() => {
        "consequences": consequences,
        "affectedUnitIds": affectedUnitIds == null
            ? null
            : List<dynamic>.from(affectedUnitIds.map((x) => x)),
        "manualClearance": manualClearance,
      };
}

class Sample {
  Sample({
    killedCount = 0,
    measureId = -1,
    parameters,
  })  : _killedCount = killedCount,
        _measureId = measureId,
        _parameters = parameters;

  /// The property is for tracking if the model has any changed
  /// and be able to rollback to orginal data in case user discard update.
  /// It does not affect to data model.
  final ChangeStack _changeStack = new ChangeStack();

  /// 0 if returned to unit
  /// 1 if the fish was died
  int _killedCount;
  int get killedCount => _killedCount;
  set killedCount(int val) {
    if (_killedCount != val) {
      _changeStack.add(Change.property(_killedCount, () => _killedCount = val,
          (oldValue) => _killedCount = oldValue));
    }
  }

  void updateParameter(String key, int val) {
    var _oldParams = Map<String, int>.from(_parameters);
    var _newParams = Map<String, int>.from(_oldParams);
    _newParams[key] = val;
    parameters = _newParams;
  }

  /// Usually 1. Can be 0 if we count on sedation tank
  int get individCount => measureId == -1 ? 0 : 1;
  bool get returnedToUnit => killedCount == null || killedCount == 0;
  set returnedToUnit(bool val) {
    killedCount = val ? 0 : 1;
  }

  /// -1 for common data, sedation tank. 0: not allow,
  ///  1,2,3..: the ordinal number of the fish we sample.
  int _measureId;
  int get measureId => _measureId;
  set measureId(int val) {
    if (_measureId != val) {
      _changeStack.add(Change.property(_measureId, () => _measureId = val,
          (oldValue) => _measureId = oldValue));
    }
  }

  /// the value for each sample parameter.
  /// The key refers to sample parameter id, the value is the result of that parameter.
  Map<String, int> _parameters;
  Map<String, int> get parameters => _parameters;
  bool get hasChanged => _changeStack.canUndo;
  set parameters(Map<String, int> val) {
    if (_parameters != val) {
      _changeStack.add(Change.property(
          Map<String, int>.from(_parameters),
          () => _parameters = Map<String, int>.from(val),
          (oldValue) => _parameters = oldValue));
    }
  }

  void rollback() {
    while (_changeStack.canUndo) {
      _changeStack.undo();
    }
  }

  void commit() {
    if (_changeStack.canUndo) {
      _changeStack.clear();
    }
  }

  factory Sample.fromMap(Map<String, dynamic> json) => Sample(
        killedCount: json["killedCount"],
        measureId: json["measureId"],
        parameters: Map.from(json["parameters"])
            .map((k, v) => MapEntry<String, int>(k, v)),
      );

  Map<String, dynamic> toMap() => {
        "killedCount": killedCount,
        "IndividCount": individCount,
        "measureId": measureId,
        "parameters":
            Map.from(parameters).map((k, v) => MapEntry<String, dynamic>(k, v)),
      };
}

class Withdrawal {
  Withdrawal({
    atus,
    and = false,
    days,
  })  : _atus = atus,
        _and = and,
        _days = days;

  /// The property is for tracking if the model has any changed
  /// and be able to rollback to orginal data in case user discard update.
  /// It does not affect to data model.
  final ChangeStack _changeStack = new ChangeStack();

  /// degree days
  int _atus;
  int get atus => _atus;
  set atus(int val) {
    if (_atus != val) {
      _changeStack.add(Change.property(
          _atus, () => _atus = val, (oldValue) => _atus = oldValue));
    }
  }

  /// true: and operator
  /// false: or opertor
  bool _and;
  bool get and => _and;
  set and(bool val) {
    if (_and != val) {
      _changeStack.add(Change.property(
          _and, () => _and = val, (oldValue) => _and = oldValue));
    }
  }

  /// calendar days
  int _days;
  int get days => _days;
  set days(int val) {
    if (_days != val) {
      _changeStack.add(Change.property(
          _days, () => _days = val, (oldValue) => _days = oldValue));
    }
  }

  void rollback() {
    while (_changeStack.canUndo) {
      _changeStack.undo();
    }
  }

  void commit() {
    if (_changeStack.canUndo) {
      _changeStack.clear();
    }
  }

  factory Withdrawal.fromMap(Map<String, dynamic> json) => Withdrawal(
        atus: json["atus"],
        and: json["and"],
        days: json["days"],
      );

  Map<String, dynamic> toMap() => {
        "atus": atus,
        "and": and,
        "days": days,
      };

  Withdrawal.clone(Withdrawal obj)
      : this(atus: obj.atus, and: obj.and, days: obj.days);

  @override
  bool operator ==(dynamic other) {
    Withdrawal that = other as Withdrawal;
    return (that.atus == this.atus &&
        that.and == this.and &&
        that.days == this.days);
  }

  @override
  int get hashCode => atus.hashCode ^ and.hashCode ^ days.hashCode;
}

class LiceType {
  int itemId;
  String name;
  int sampleParameterCategoryId;

  LiceType({this.itemId, this.name, this.sampleParameterCategoryId});

  LiceType.fromMap(Map<String, dynamic> parsedJson) {
    itemId = parsedJson['itemId'];
    name = parsedJson['name'];
    sampleParameterCategoryId = parsedJson['sampleParameterCategoryId'];
  }
}

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:undo/undo.dart';

enum RegistrationType { Mortality, Feeding, Culling, Environment, Lice }

abstract class RegistrationBaseItem {
  RegistrationBaseItem();
  Map toMap();

  /// Rollback to original data in case user discards updated data
  void rollback();

  /// Function to check whether the item has changed or not.
  bool hasChanged();

  /// Clear the tracking change
  void clearTracking();

  /// commit changes
  void commit();

  /// Remove an item based on its id
  void removeItem(dynamic item);

  /// Update value for item base on its id
  void updateItem(dynamic itemId, dynamic val);

  /// Calculate total count
  dynamic totalCount();

  /// Check empty list (if any)
  dynamic countAt(int index);
  dynamic countObjAt(int index);
  String countTitle(BuildContext context, int index);
  bool isSameCountAt(int index, dynamic itemId);
  bool isSameCount(dynamic obj, dynamic item);
  void addItem(dynamic itemId, double val);
  bool get isValidData;
  bool get isEmpty;
  int get length;
  bool get enable;
}

class Registration<Item extends RegistrationBaseItem> {
  String id;
  int rowId;
  String unitId;
  String siteId;
  final int speciesId;
  DateTime time;
  Item item;
  ChangeStatus _changeStatus;

  /// The property is for tracking changeStatus if it is changed
  /// and be able to rollback to orginal data in case user discard update.
  /// It does not affect to data model.
  final ChangeStack _changeStack = new ChangeStack();

  /// Flag to determine that current registration was changed.
  /// It does not affect to data model.
  bool _changed = false;

  bool get changed => _isChanged();
  bool _isChanged() {
    return _changed || item.hasChanged();
  }

  void clearTracking() {
    if (_changed) {
      _changeStack.clear();
      _changed = false;
    }
    item.clearTracking();
  }

  ChangeStatus get changeStatus => _changeStatus;
  set changeStatus(ChangeStatus status) {
    if (_changeStack.canUndo) {
      _changeStack.undo();
    }
    if (_changeStatus != status) {
      _changeStack.add(Change.property(_changeStatus,
          () => _changeStatus = status, (oldVal) => _changeStatus = oldVal));
      _changed = true;
    } else {
      _changed = false;
    }
  }

  Registration({
    this.id,
    this.rowId,
    this.unitId,
    this.siteId,
    this.speciesId,
    this.time,
    this.item,
    ChangeStatus changeStatus,
  }) : _changeStatus = changeStatus;

  factory Registration.fromMap(Map<String, dynamic> map, Item create(Map obj)) {
    var item = create(map);
    return Registration(
      rowId: map['rowid'],
      id: map['id'],
      unitId: map['unitId'],
      siteId: map['siteId'],
      speciesId: map['speciesId'],
      time: DateTime.tryParse(map['time']),
      item: item,
      changeStatus: map['status'] != null
          ? ChangeStatus.values[map['status']]
          : ChangeStatus.Unchanged,
    );
  }

  Map<String, dynamic> toMap(
      {bool useRawJson = true,
      bool includeStatus = true,
      bool includeId = false}) {
    Map<String, dynamic> commonObj = {
      'unitId': unitId,
      'siteId': siteId,
      'speciesId': speciesId,
      'time': DateFormat('yyyy-MM-ddTHH:mm:ss').format(time),
    };
    if (id != null) {
      commonObj['id'] = id;
    } else if (includeId) // When post new registration unable to complete it action, need to set back id to null
    {
      commonObj['id'] = id;
    }
    if (changeStatus != null && includeStatus) {
      commonObj['status'] = changeStatus.index;
    }

    /// useRawJson flag is used for database storage
    if (useRawJson) {
      return {...commonObj, 'rawJson': json.encode(item.toMap())};
    }
    return {...commonObj, ...item.toMap()};
  }

  void rollback() {
    while (_changeStack.canUndo) {
      _changeStack.undo();
    }
    item.rollback();
  }

  void undo() {
    if (_changeStack.canUndo) {
      _changeStack.undo();
    }
    _changed = false;
  }
}

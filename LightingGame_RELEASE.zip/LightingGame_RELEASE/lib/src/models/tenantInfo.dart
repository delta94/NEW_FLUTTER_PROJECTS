// To parse this JSON data, do
//
//     final tenantInfo = tenantInfoFromJson(jsonString);

import 'dart:convert';

TenantInfo tenantInfoFromJson(String str) => TenantInfo.fromJson(json.decode(str));

String tenantInfoToJson(TenantInfo data) => json.encode(data.toJson());

class TenantInfo {
    String id;
    String timeZoneId;

    TenantInfo({
        this.id,
        this.timeZoneId,
    });

    factory TenantInfo.fromJson(Map<String, dynamic> json) => TenantInfo(
        id: json["id"],
        timeZoneId: json["timeZoneId"],
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "timeZoneId": timeZoneId,
    };
}

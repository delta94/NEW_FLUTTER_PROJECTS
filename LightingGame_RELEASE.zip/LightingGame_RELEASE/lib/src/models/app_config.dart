/// AppConfig data model
class AppConfig {
  static const String colKey = 'key';
  static const String colJsonData = 'jsonData';

  String key;
  String jsonData;

  AppConfig({this.key, this.jsonData});

  /// convenience constructor to create a AppConfig object
  AppConfig.fromMap(Map<String, dynamic> map) {
    
    key = map[colKey];
    jsonData = map[colJsonData];
  }

  /// convenience method to create a Map from this AppConfig object
  Map<String, dynamic> toMap() {

    var map = <String, dynamic>{
      colKey: key,
      colJsonData: jsonData,
    };

    return map;
  }
}

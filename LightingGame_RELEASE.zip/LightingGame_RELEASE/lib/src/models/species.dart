class Species  {
  int speciesId;
  String name;
  bool wrasse;

  @override
  Species({this.speciesId, this.name, this.wrasse});

  Species.fromJson(Map<String, dynamic> parsedJson) {
    speciesId = parsedJson['speciesId'];
    name = parsedJson['name'];
    wrasse = parsedJson['wrasse'];
  }
}
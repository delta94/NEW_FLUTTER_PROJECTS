import 'dart:convert';

FeedType feedTypeFromMap(String str) => FeedType.fromMap(json.decode(str));

String feedTypeToMap(FeedType data) => json.encode(data.toMap());

class FeedType {
    FeedType({
        this.itemId,
        this.name,
        this.wrasse,
    });

    int itemId;
    String name;
    bool wrasse;

    factory FeedType.fromMap(Map<String, dynamic> json) => FeedType(
        itemId: json["itemId"],
        name: json["name"],
        wrasse: json["wrasse"],
    );

    Map<String, dynamic> toMap() => {
        "itemId": itemId,
        "name": name,
        "wrasse": wrasse,
    };
}
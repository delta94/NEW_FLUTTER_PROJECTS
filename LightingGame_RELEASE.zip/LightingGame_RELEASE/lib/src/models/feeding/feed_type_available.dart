// To parse this JSON data, do
//
//     final feedTypeAvailable = feedTypeAvailableFromMap(jsonString);

import 'dart:convert';

import 'package:control_app/src/models/registration_wrasse.dart';

List<FeedTypeAvailable> feedTypeAvailableFromMap(String str) => List<FeedTypeAvailable>.from(json.decode(str).map((x) => FeedTypeAvailable.fromMap(x)));

String feedTypeAvailableToMap(List<FeedTypeAvailable> data) => json.encode(List<dynamic>.from(data.map((x) => x.toMap())));

class FeedTypeAvailable extends RegistrationWrasse{
    FeedTypeAvailable({
        this.feedStoreId,
        this.feedGroupId,
        this.feedTypeId,
        this.startTime,
        this.endTime,
        wrasse,
    }): super(wrasse: wrasse);

    String feedStoreId;
    String feedGroupId;
    int feedTypeId;
    DateTime startTime;
    DateTime endTime;
    String name;

    factory FeedTypeAvailable.fromMap(Map<String, dynamic> json) => FeedTypeAvailable(
        feedStoreId: json["feedStoreId"],
        feedGroupId: json["feedGroupId"],
        feedTypeId: json["feedTypeId"],
        startTime: DateTime.parse(json["startTime"]),
        endTime: json["endTime"],
    );

    Map<String, dynamic> toMap() => {
        "feedStoreId": feedStoreId,
        "feedGroupId": feedGroupId,
        "feedTypeId": feedTypeId,
        "startTime": startTime.toIso8601String(),
        "endTime": endTime,
    };
}

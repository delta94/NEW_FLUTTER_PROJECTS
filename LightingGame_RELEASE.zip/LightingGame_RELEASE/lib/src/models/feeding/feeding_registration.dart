import 'package:control_app/src/models/feeding/feed_type_available.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:undo/undo.dart';

import 'feeding.dart';

class FeedingRegistration extends RegistrationBaseItem {
  int missedFeedingReasonId;
  List<Feeding> feedings;

  /// The property is for tracking feedings list if the list is changed
  /// and be able to rollback to orginal data in case user discard update.
  /// It does not affect to data model.
  final ChangeStack _changeStack = new ChangeStack();
  bool _changed = false;

  FeedingRegistration({this.feedings, this.missedFeedingReasonId = -1}) {
    if (feedings == null) {
      feedings = new List<Feeding>();
    }
  }

  @override
  Map toMap() {
    List<Map> items = feedings != null
        ? feedings.map((feeding) => feeding.toMap()).toList()
        : null;
    return {'feedings': items, 'missedFeedingReasonId': missedFeedingReasonId};
  }

  factory FeedingRegistration.fromMap(Map jsonObj) {
    return FeedingRegistration(
      feedings: List<Feeding>.from(
          jsonObj["feedings"].map((x) => Feeding.fromMap(x))),
      missedFeedingReasonId: jsonObj['missedFeedingReasonId'],
    );
  }

  @override
  bool hasChanged() {
    return _changed || feedings.any((feeding) => feeding.changed);
  }

  @override
  void rollback() {
    while (_changeStack.canUndo) {
      _changeStack.undo();
    }
    feedings.forEach((feeding) => feeding.rollback());
    _changed = false;
  }

  @override
  void removeItem(feeding) {
    if (feeding is Feeding) {
      _changeStack.add(Change.property(
          [...feedings],
          () => feedings.removeWhere((_feeding) =>
              _feeding.feedTypeId == feeding.feedTypeId &&
              _feeding.feedStoreId == feeding.feedStoreId),
          (oldValue) => feedings = oldValue));
      _changed = true;
    }
  }

  @override
  void updateItem(feeding, val) {
    if (feeding is Feeding) {
      var feedItem = feedings.firstWhere((item) =>
          item.feedTypeId == feeding.feedTypeId &&
          item.feedStoreId == feeding.feedStoreId);
      feedItem.feedAmountKg = val;
    }
  }

  @override
  bool get isEmpty => feedings.isEmpty;

  @override
  totalCount() {
    return feedings.fold(
      0,
      (previousValue, feeding) => previousValue + feeding.feedAmountKg,
    );
  }

  @override
  countAt(int index) {
    if (feedings != null && index < feedings.length && index >= 0) {
      return feedings[index].feedAmountKg;
    }
    return 0;
  }

  @override
  int get length => feedings.length;

  @override
  countObjAt(int index) {
    if (feedings != null && index < feedings.length && index >= 0) {
      return feedings[index];
    }
    return null;
  }

  String _getFeedTypeStoreName(int feedTypeId, String feedStoreId,
      List<FeedTypeAvailable> feedTypesAvailable) {
    FeedTypeAvailable foundFeedTypeAvailable;
    for (var feedTypeAvailable in feedTypesAvailable) {
      if (feedTypeAvailable.feedTypeId == feedTypeId &&
          feedTypeAvailable.feedStoreId == feedStoreId) {
        foundFeedTypeAvailable = feedTypeAvailable;
        break;
      }
    }

    if (foundFeedTypeAvailable != null) {
      return foundFeedTypeAvailable.name;
    } else {
      return 'Unknown';
    }
  }

  @override
  String countTitle(BuildContext context, int index) {
    final organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);
    return _getFeedTypeStoreName(feedings[index].feedTypeId,
        feedings[index].feedStoreId, organizationModel.feedTypesOfCurrentUnit);
  }

  @override
  bool get isValidData {
    return (feedings.isEmpty && missedFeedingReasonId != -1) ||
        !feedings.any((feeding) =>
            feeding.feedAmountKg == null || feeding.feedAmountKg <= 0);
  }

  @override
  bool isSameCountAt(int index, feeding) {
    var countObj = countObjAt(index);
    if (countObj != null) {
      return countObj.feedTypeId == feeding.feedTypeId &&
          countObj.feedStoreId == feeding.feedStoreId;
    }
    return false;
  }

  @override
  void addItem(feedType, double val) {
    if (feedType is FeedTypeAvailable) {
      feedings.add(Feeding(
          feedTypeId: feedType.feedTypeId,
          feedStoreId: feedType.feedStoreId,
          feedAmountKg: val));
    }
  }

  @override
  bool get enable => true;

  @override
  bool isSameCount(obj, item) {
    if (obj != null &&
        obj is Feeding &&
        item != null &&
        item is FeedTypeAvailable) {
      return obj.feedTypeId == item.feedTypeId &&
          obj.feedStoreId == item.feedStoreId;
    }
    return false;
  }

  @override
  void clearTracking() {
    if (_changed) {
      _changeStack.clear();
      _changed = false;
    }
  }

  @override
  void commit() {
    _changeStack.clear();
    _changed = false;
    feedings.forEach((feeding) {
      feeding.clearTracking();
    });
  }
}

import 'package:undo/undo.dart';

class Feeding {
  double _feedAmountKg;
  int feedTypeId;
  String feedStoreId;

  /// The property is for tracking if the model has any changed
  /// and be able to rollback to orginal data in case user discard update.
  /// It does not affect to data model.
  final ChangeStack _changeStack = new ChangeStack();

  /// Flag to determine that current registration was changed.
  /// It does not affect to data model.
  bool _changed = false;

  /// getters and setter =================================================
  double get feedAmountKg => _feedAmountKg;

  set feedAmountKg(double val) {
    if (_changeStack.canUndo) {
      _changeStack.undo();
    }
    if (_feedAmountKg != val) {
      _changeStack.add(Change.property(_feedAmountKg, () => _feedAmountKg = val,
          (oldVal) => _feedAmountKg = oldVal));
      _changed = true;
    } else {
      _changed = false;
    }
  }

  bool get changed => _changed;

  Feeding({
    double feedAmountKg,
    this.feedTypeId,
    this.feedStoreId,
  }) : _feedAmountKg = feedAmountKg;

  Map<String, dynamic> toMap() {
    /// For the count that is not committed (changed = true)
    /// then we must keep the old value.
    /// This is for the case that user modified some counts
    /// and delete another count, the modified values will be
    /// stored back to local storage and cloud api if we do not handle
    /// keeping the old values.
    double newCount = _feedAmountKg;
    double oldCount = _feedAmountKg;
    if (_changed) {
      if (_changeStack.canUndo) {
        _changeStack.undo();
        oldCount = _feedAmountKg;
        feedAmountKg = newCount;
      }
    }
    return {
      'feedAmountKg': oldCount,
      'feedTypeId': feedTypeId,
      'feedStoreId': feedStoreId
    };
  }

  factory Feeding.fromMap(Map json) => Feeding(
        feedAmountKg: json['feedAmountKg'],
        feedTypeId: json['feedTypeId'],
        feedStoreId: json['feedStoreId'],
      );

  void rollback() {
    while (_changeStack.canUndo) {
      _changeStack.undo();
    }
    _changed = false;
  }

  void clearTracking() {
    _changeStack.clear();
    _changed = false;
  }

  @override
  bool operator ==(dynamic other) {
    Feeding that = other as Feeding;
    if (that == null) return false;

    if (that.feedAmountKg == this.feedAmountKg &&
        that.feedTypeId == this.feedTypeId &&
        that.feedStoreId == this.feedStoreId) {
      return true;
    }

    return false;
  }

  @override
  int get hashCode =>
      feedAmountKg.hashCode ^ feedTypeId.hashCode ^ feedStoreId.hashCode;
}

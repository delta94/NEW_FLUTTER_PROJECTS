import 'dart:convert';

import 'package:control_app/src/models/feeding/feed_type_available.dart';

List<SiteFeedTypes> siteFeedTypesFromJson(String str) =>
    List<SiteFeedTypes>.from(
        jsonDecode(str).map((x) => SiteFeedTypes.fromJson(x)));

String siteFeedTypesToJson(List<SiteFeedTypes> data) =>
    jsonEncode(List<dynamic>.from(data.map((x) => x.toJson())));

class SiteFeedTypes {
  String siteId;

  List<FeedTypeAvailable> feedTypes;

  SiteFeedTypes({this.siteId, this.feedTypes});

  factory SiteFeedTypes.fromJson(Map<String, dynamic> json) => SiteFeedTypes(
        siteId: json["siteId"],
        feedTypes: List<FeedTypeAvailable>.from(
            json["feedTypes"].map((x) => FeedTypeAvailable.fromMap(x))),
      );

  Map<String, dynamic> toJson() => {
        "siteId": siteId,
        "feedTypes": List<dynamic>.from(feedTypes.map((x) => x.toMap())),
      };
}

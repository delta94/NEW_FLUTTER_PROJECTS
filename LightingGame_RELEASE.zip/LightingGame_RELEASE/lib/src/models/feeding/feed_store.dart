import 'dart:convert';

FeedStore feedStoreFromMap(String str) => FeedStore.fromMap(json.decode(str));

String feedStoreToMap(FeedStore data) => json.encode(data.toMap());

class FeedStore {
    FeedStore({
        this.id,
        this.name,
        this.active,
    });

    String id;
    String name;
    bool active;

    factory FeedStore.fromMap(Map<String, dynamic> json) => FeedStore(
        id: json["id"],
        name: json["name"],
        active: json["active"],
    );

    Map<String, dynamic> toMap() => {
        "id": id,
        "name": name,
        "active": active,
    };
}
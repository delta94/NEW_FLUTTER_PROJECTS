// To parse this JSON data, do
//
//     final userRight = userRightFromMap(jsonString);

import 'dart:convert';

UserRight userRightFromMap(String str) => UserRight.fromMap(json.decode(str));

String userRightToMap(UserRight data) => json.encode(data.toMap());

class UserRight {
  UserRight({
    this.type,
    this.userId,
    this.tenantRights,
    this.siteRights,
    this.id,
    this.key,
  });

  String type;
  String userId;
  List<dynamic> tenantRights;
  List<SiteRight> siteRights;
  String id;
  String key;

  Map<String, Map<String, String>> _siteRightDict;

  factory UserRight.fromMap(Map<String, dynamic> json) {
    var userRight = UserRight(
      type: json["type"],
      userId: json["userId"],
      tenantRights: List<dynamic>.from(json["tenantRights"].map((x) => x)),
      siteRights: List<SiteRight>.from(
          json["siteRights"].map((x) => SiteRight.fromMap(x))),
      id: json["id"],
      key: json["key"],
    );

    var siteRightDict = new Map<String, Map<String, String>>();

    if (userRight.siteRights != null) {
      userRight.siteRights.forEach((element) {
        if (element.siteIds != null && element.rights != null) {
          element.siteIds.forEach((id) {
            if (!siteRightDict.containsKey(id)) {
              siteRightDict[id] = Map<String, String>();
            }

            element.rights.forEach((right) {
              siteRightDict[id][right] = right;
            });
          });
        }
      });
    }

    userRight._siteRightDict = siteRightDict;

    return userRight;
  }

  Map<String, dynamic> toMap() => {
        "type": type,
        "userId": userId,
        "tenantRights": List<dynamic>.from(tenantRights.map((x) => x)),
        "siteRights": List<dynamic>.from(siteRights.map((x) => x.toMap())),
        "id": id,
        "key": key,
      };

  /// Check has Mortality read permission on site base on [siteId]
  /// [siteId] site Id
  bool hasMortalityReadOnSite(String siteId) {
    return _hasRightOnSite('mortality', siteId);
  }

  /// Check has Mortality write permission on site base on [siteId]
  /// [siteId] site Id
  bool hasMortalityWriteOnSite(String siteId) {
    return _hasRightOnSite('mortality_write', siteId);
  }

  /// Check has Mortality delete permission on site base on [siteId]
  /// [siteId] site Id
  bool hasMortalityDeleteOnSite(String siteId) {
    return _hasRightOnSite('mortality_delete', siteId);
  }

  /// Check has Culling read permission on site base on [siteId]
  /// [siteId] site Id
  bool hasCullingReadOnSite(String siteId) {
    return _hasRightOnSite('culling', siteId);
  }

  /// Check has Culling write permission on site base on [siteId]
  /// [siteId] site Id
  bool hasCullingWriteOnSite(String siteId) {
    return _hasRightOnSite('culling_write', siteId);
  }

  /// Check has Culling delete permission on site base on [siteId]
  /// [siteId] site Id
  bool hasCullingDeleteOnSite(String siteId) {
    return _hasRightOnSite('culling_delete', siteId);
  }

  /// Check has Lice sample read permission on site base on [siteId]
  /// [siteId] site Id
  bool hasLiceSampleReadOnSite(String siteId) {
    return _hasRightOnSite('sample', siteId);
  }

  /// Check has Lice sample write permission on site base on [siteId]
  /// [siteId] site Id
  bool hasLiceSampleWriteOnSite(String siteId) {
    return _hasRightOnSite('sample_write', siteId);
  }

  /// Check has Lice sample delete permission on site base on [siteId]
  /// [siteId] site Id
  bool hasLiceSampleDeleteOnSite(String siteId) {
    return _hasRightOnSite('sample_delete', siteId);
  }

  /// Check has Feeding read permission on site base on [siteId]
  /// [siteId] site Id
  bool hasFeedingReadOnSite(String siteId) {
    return _hasRightOnSite('feeding', siteId);
  }

  /// Check has Feeding write permission on site base on [siteId]
  /// [siteId] site Id
  bool hasFeedingWriteOnSite(String siteId) {
    return _hasRightOnSite('feeding_write', siteId);
  }

  /// Check has Feeding delete permission on site base on [siteId]
  /// [siteId] site Id
  bool hasFeedingDeleteOnSite(String siteId) {
    return _hasRightOnSite('feeding_delete', siteId);
  }

  /// Check has Sensors read permission on site base on [siteId]
  /// [siteId] site Id
  bool hasSensorsReadOnSite(String siteId) {
    return _hasRightOnSite('sensors', siteId);
  }

  /// Check has Sensors write permission on site base on [siteId]
  /// [siteId] site Id
  bool hasSensorsWriteOnSite(String siteId) {
    return _hasRightOnSite('sensors_write', siteId);
  }

  /// Check has Sensors delete permission on site base on [siteId]
  /// [siteId] site Id
  bool hasSensorsDeleteOnSite(String siteId) {
    return _hasRightOnSite('sensors_delete', siteId);
  }

  bool _hasRightOnSite(String right, String siteId) {
    if (siteId != null &&
        right != null &&
        _siteRightDict.containsKey(siteId) &&
        _siteRightDict[siteId].containsKey(right)) {
      return true;
    }
    return false;
  }
}

class SiteRight {
  SiteRight({
    this.siteIds,
    this.rights,
  });

  List<String> siteIds;
  List<String> rights;

  factory SiteRight.fromMap(Map<String, dynamic> json) => SiteRight(
        siteIds: List<String>.from(json["siteIds"].map((x) => x)),
        rights: List<String>.from(json["rights"].map((x) => x)),
      );

  Map<String, dynamic> toMap() => {
        "siteIds": List<dynamic>.from(siteIds.map((x) => x)),
        "rights": List<dynamic>.from(rights.map((x) => x)),
      };
}

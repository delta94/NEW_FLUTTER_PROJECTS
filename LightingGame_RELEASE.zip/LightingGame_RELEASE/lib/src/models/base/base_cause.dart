import 'package:control_app/src/models/registration_wrasse.dart';

enum CauseType {Mortality, Culling}

/// This is base class for both cause of dealth (used in mortality)
/// and culling cause (used in culling) since both are the same
class BaseCause extends RegistrationWrasse{
  int causeId;
  String name;

  BaseCause({this.causeId, this.name, wrasse}):super(wrasse: wrasse);

  BaseCause.fromJson(Map<String, dynamic> parsedJson) {
    causeId = parsedJson['itemId'];
    name = parsedJson['name'];
    wrasse = parsedJson['wrasse'];
  }
}
import 'package:undo/undo.dart';

class Mortality {
  int _mortalityCount;
  int _mortalityCauseId;

  /// The property is for tracking if the model has any changed
  /// and be able to rollback to orginal data in case user discard update.
  /// It does not affect to data model.
  final ChangeStack _changeStack = new ChangeStack();

  /// Flag to determine that current registration was changed.
  /// It does not affect to data model.
  bool _changed = false;

  /// getters and setter =================================================
  int get mortalityCount => _mortalityCount;
  int get mortalityCauseId => _mortalityCauseId;

  set mortalityCount(int val) {
    if (_changeStack.canUndo) {
      _changeStack.undo();
    }
    if (_mortalityCount != val) {
      _changeStack.add(Change.property(_mortalityCount,
          () => _mortalityCount = val, (oldVal) => _mortalityCount = oldVal));
      _changed = true;
    } else {
      _changed = false;
    }
  }

  bool get changed => _changed;

  Mortality({
    int mortalityCount,
    int mortalityCauseId,
  })  : _mortalityCount = mortalityCount,
        _mortalityCauseId = mortalityCauseId;

  Map toMap() {
    /// For the count that is not committed (changed = true)
    /// then we must keep the old value.
    /// This is for the case that user modified some counts
    /// and delete another count, the modified values will be
    /// stored back to local storage and cloud api if we do not handle
    /// keeping the old values.
    int newCount = _mortalityCount;
    int oldCount = _mortalityCount;
    if (_changed) {
      if (_changeStack.canUndo) {
        _changeStack.undo();
        oldCount = _mortalityCount;
        mortalityCount = newCount;
      }
    }

    return {'mortalityCount': oldCount, 'mortalityCauseId': _mortalityCauseId};
  }

  factory Mortality.fromMap(Map json) => Mortality(
      mortalityCount: json['mortalityCount'],
      mortalityCauseId: json['mortalityCauseId']);

  void rollback() {
    while (_changeStack.canUndo) {
      _changeStack.undo();
    }
    _changed = false;
  }

  void clearTracking() {
    _changeStack.clear();
    _changed = false;
  }

  @override
  bool operator ==(dynamic other) {
    Mortality that = other as Mortality;
    if (that == null) return false;

    if (that.mortalityCount == this.mortalityCount &&
        that.mortalityCauseId == this.mortalityCauseId) {
      return true;
    }

    return false;
  }

  @override
  int get hashCode => mortalityCount.hashCode ^ mortalityCauseId.hashCode;
}

import 'package:control_app/src/models/base/base_cause.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:undo/undo.dart';
import '../registration.dart';
import 'mortality.dart';

class MortalityRegistration extends RegistrationBaseItem {
  bool hasCheckedForMortality;
  int missedMortalityReasonId;
  List<Mortality> mortalities;

  /// The property is for tracking mortalities list if the list is changed
  /// and be able to rollback to orginal data in case user discard update.
  /// It does not affect to data model.
  final ChangeStack _changeStack = new ChangeStack();
  bool _changed = false;

  MortalityRegistration(
      {this.mortalities,
      this.hasCheckedForMortality = true,
      this.missedMortalityReasonId = -1}) {
    if (mortalities == null) {
      mortalities = new List<Mortality>();
    }
  }

  @override
  Map toMap() {
    List<Map> items = mortalities != null
        ? mortalities.map((mortality) => mortality.toMap()).toList()
        : null;
    return {
      'mortalities': items,
      'missedMortalityReasonId': missedMortalityReasonId,
      'hasCheckedForMortality': hasCheckedForMortality
    };
  }

  factory MortalityRegistration.fromMap(Map jsonObj) {
    return MortalityRegistration(
        mortalities: List<Mortality>.from(
            jsonObj["mortalities"].map((x) => Mortality.fromMap(x))),
        hasCheckedForMortality: jsonObj['hasCheckedForMortality'],
        missedMortalityReasonId: jsonObj['missedMortalityReasonId']);
  }

  @override
  void rollback() {
    while (_changeStack.canUndo) {
      _changeStack.undo();
    }
    mortalities.forEach((mortality) => mortality.rollback());
    _changed = false;
  }

  @override
  bool hasChanged() {
    return _changed || mortalities.any((mortality) => mortality.changed);
  }

  /// Remove a mortality by cause Id permanently
  @override
  void removeItem(mortalityCount) {
    mortalities.removeWhere((mortality) =>
        mortality.mortalityCauseId == mortalityCount.mortalityCauseId);
  }

  @override
  void updateItem(mortalityCount, val) {
    var mortality = mortalities.firstWhere(
        (item) => item.mortalityCauseId == mortalityCount.mortalityCauseId);
    mortality.mortalityCount = val.round();
  }

  @override
  bool get isEmpty => mortalities.isEmpty;

  @override
  totalCount() {
    return mortalities.fold(
      0,
      (previousValue, mortality) => previousValue + mortality.mortalityCount,
    );
  }

  @override
  countAt(int index) {
    if (mortalities != null && index < mortalities.length && index >= 0) {
      return mortalities[index].mortalityCount;
    }
    return 0;
  }

  @override
  int get length => mortalities.length;

  @override
  countObjAt(int index) {
    if (mortalities != null && index < mortalities.length && index >= 0) {
      return mortalities[index];
    }
    return null;
  }

  @override
  String countTitle(BuildContext context, int index) {
    final sharedDataModel =
        Provider.of<SharedDataModel>(context, listen: false);
    String title = sharedDataModel
            .getDeathCauseName(mortalities[index].mortalityCauseId) ??
        'Unknown';
    return title;
  }

  @override
  bool get isValidData =>
      (mortalities.isEmpty &&
          (hasCheckedForMortality || missedMortalityReasonId != -1)) ||
      !mortalities.any((mortality) =>
          mortality.mortalityCount == null || mortality.mortalityCount <= 0);

  @override
  bool isSameCountAt(int index, cause) {
    var countObj = countObjAt(index);
    if (countObj != null) {
      return countObj.mortalityCauseId == cause.causeId;
    }
    return false;
  }

  @override
  void addItem(cause, double val) {
    if (cause is BaseCause) {
      mortalities.add(Mortality(
          mortalityCauseId: cause.causeId, mortalityCount: val.round()));
    }
  }

  @override
  bool get enable => true;

  @override
  bool isSameCount(obj, item) {
    if (obj != null && obj is Mortality && item != null && item is BaseCause) {
      return obj.mortalityCauseId == item.causeId;
    }
    return false;
  }

  @override
  void clearTracking() {
    if (_changed) {
      _changeStack.clear();
      _changed = false;
    }
  }

  @override
  void commit() {
    _changeStack.clear();
    _changed = false;
    mortalities.forEach((mortality) {
      mortality.clearTracking();
    });
  }
}

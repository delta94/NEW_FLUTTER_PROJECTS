/// Quick Access data model
class QuickAccess {
  static const String columnUserName = 'username';
  static const String columnUnitId = 'unitId';
  static const String columnFrequency = 'frequency';
  static const String columnFavorite = 'favorite';

  String username;
  String unitId;
  int frequency;
  bool favorite;

  QuickAccess({this.username, this.unitId, this.frequency, this.favorite});

  /// convenience constructor to create a QuickAccess object
  QuickAccess.fromMap(Map<String, dynamic> map) {
    username = map[columnUserName];
    unitId = map[columnUnitId];
    frequency = map[columnFrequency];

    favorite = (map[columnFavorite] == 1);
  }

  /// convenience method to create a Map from this QuickAccess object
  Map<String, dynamic> toMap() {
    var map = <String, dynamic>{
      columnUserName: username,
      columnUnitId: unitId,
      columnFrequency: frequency
    };

    map[columnFavorite] = favorite ? 1 : 0;

    return map;
  }
}

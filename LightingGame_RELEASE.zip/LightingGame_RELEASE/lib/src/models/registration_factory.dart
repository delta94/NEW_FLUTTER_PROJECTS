import 'package:control_app/src/models/culling/culling_registration.dart';
import 'package:control_app/src/models/environment/sensor_reading.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';

import 'feeding/feeding_registration.dart';
import 'mortality/mortality_registration.dart';
import 'registration.dart';

class RegistrationFactory {
  static RegistrationBaseItem create(RegistrationType type,
      {Map<String, dynamic> jsonObj}) {
    RegistrationBaseItem item;
    switch (type) {
      case RegistrationType.Mortality:
        if (jsonObj != null) {
          item = MortalityRegistration.fromMap(jsonObj);
        } else {
          item = new MortalityRegistration();
        }
        break;
      case RegistrationType.Feeding:
        if (jsonObj != null) {
          item = FeedingRegistration.fromMap(jsonObj);
        } else {
          item = new FeedingRegistration();
        }
        break;
      case RegistrationType.Culling:
        if (jsonObj != null) {
          item = CullingRegistration.fromMap(jsonObj);
        } else {
          item = new CullingRegistration(
              cullings: [], resultingStock: ResultingStock());
        }
        break;
      case RegistrationType.Lice:
        if (jsonObj != null) {
          item = LiceSample.fromMap(jsonObj);
        } else {
          item = new LiceSample(
              quarantineDetails: QuarantineDetails(affectedUnitIds: <String>[]),
              samples: List<Sample>(),
              withdrawal: Withdrawal());
        }
        break;
      case RegistrationType.Environment:
        if (jsonObj != null) {
          item = SensorReading.fromMap(jsonObj);
        } else {
          item = new SensorReading();
        }
        break;
      default:
        return null;
    }

    return item;
  }
}

class Coordinates {
  double lat;
  double lon;
  Coordinates.fromJson(Map<String, dynamic> parsedJson) {
    lat = parsedJson['lat'];
    lon = parsedJson['lon'];
  }
}

class Unit implements OrganizationEntity {
  @override
  String id;
  @override
  List<String> extIds = [];
  @override
  String name;
  @override
  OrganizationEntity parent;
  @override
  List<OrganizationEntity> children = [];

  bool isHidden;
  Unit.fromJson(Map<String, dynamic> parsedJson) {
    id = parsedJson['id'];
    name = parsedJson['unitName'];
    isHidden = parsedJson['isHidden'];
    final mappingList = parsedJson['mapping'] ?? [];
    for (final mapping in mappingList) {
      extIds.add(mapping['extUnitId']);
    }
  }
}

class Site implements OrganizationEntity {
  @override
  String id;
  @override
  List<String> extIds = [];
  @override
  String name;
  @override
  OrganizationEntity parent;
  @override
  List<OrganizationEntity> children;

  String sitePlacement;

  bool isHidden;
  Coordinates coordinates;
  String timeZoneId;

  Site.fromJson(Map<String, dynamic> parsedJson) {
    id = parsedJson['id'];
    name = parsedJson['siteName'];
    timeZoneId = parsedJson['timeZoneId'];
    isHidden = parsedJson['isHidden'];
    sitePlacement = parsedJson['sitePlacement'];
    final jsonCoordinates = parsedJson['coordinates'];
    if (jsonCoordinates != null) {
      coordinates = Coordinates.fromJson(jsonCoordinates);
    } else {
      coordinates = null;
    }
    final unitList = parsedJson['units'] as List;
    children = unitList.map((unit) {
      var child = Unit.fromJson(unit);
      child.parent = this;
      return child;
    }).toList();

    final mappingList = parsedJson['mapping'] ?? [];
    for (final mapping in mappingList) {
      extIds.add(mapping['extSiteId']);
    }
  }
}

final rootGuid = "00000000-0000-0000-0000-000000000000";

class OrganizationRoot extends OrganizationEntity {
  @override
  String id = rootGuid;
  @override
  List<String> extIds;
  @override
  String name = "Root";
  @override
  OrganizationEntity parent;
  @override
  List<OrganizationEntity> children;

  OrganizationRoot(){
    id = rootGuid;
    name = 'Root';
    children = List<OrganizationEntity>();
  }

  OrganizationRoot.fromJson(List<dynamic> parsedJson) {
    children = parsedJson.map((site) {
      var child = Site.fromJson(site);
      child.parent = this;
      return child;
    }).toList();
  }

  OrganizationRoot.fromOrgTreeJson(Map<String, dynamic> parsedJson) {
    id = parsedJson['id'];
    name = parsedJson['name'];
    children = ((parsedJson['subDivisions'] as List)
        .map((child) => OrganizationRoot.fromOrgTreeJson(child))).toList();
  }
}

abstract class OrganizationEntity {
  String id;
  List<String> extIds; // the mapping ids, one of which is from fishtalk
  String name;
  OrganizationEntity parent;
  List<OrganizationEntity> children;
}

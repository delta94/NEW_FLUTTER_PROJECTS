// To parse this JSON data, do
//
//     final sensorReading = sensorReadingFromMap(jsonString);

import 'dart:convert';

import 'package:control_app/src/models/registration.dart';
import 'package:flutter/material.dart';
import 'package:undo/undo.dart';

import 'sensor.dart';
import 'sensor_type.dart';

SensorReading sensorReadingFromMap(String str) =>
    SensorReading.fromMap(json.decode(str));

String sensorReadingToMap(SensorReading data) => json.encode(data.toMap());

class SensorReading extends RegistrationBaseItem {
  SensorReading({
    this.sensorId,
    reading,
    this.sensorGroupId,
    this.departmentId,
    this.depth,
    this.sensorTypeId,
    this.name,
    this.sensorTypeName,
    this.measurementUnit,
    this.sensorType,
  }) : _reading = reading;

  String sensorId;
  double _reading;
  double get reading => _reading;
  set reading(double val) {
    if (_changeStack.canUndo) {
      _changeStack.undo();
    }
    if (_reading != val) {
      _changeStack.add(Change.property(
          _reading, () => _reading = val, (oldVal) => _reading = oldVal));
      _changed = true;
    } else {
      _changed = false;
    }
  }

  String sensorGroupId;
  String departmentId;
  double depth;
  int sensorTypeId;

  ///Helper properties. These properties
  /// will not be persited to local storage or api
  ///
  /// Name of sensor
  String name;

  /// Type name of sensor
  String sensorTypeName;

  /// measurement name
  String measurementUnit;

  /// Sensor type object
  SensorType sensorType;

  /// Sensor object
  Sensor sensor;

  /// The property is for tracking changing properties value
  final ChangeStack _changeStack = new ChangeStack();
  bool _changed = false;

  factory SensorReading.fromMap(Map<String, dynamic> json) => SensorReading(
        sensorId: json["sensorId"],
        reading: json["reading"] != null ? json["reading"].toDouble() : null,
        sensorGroupId: json["sensorGroupId"],
        departmentId: json["departmentId"],
        depth: json["depth"],
        sensorTypeId: json["sensorTypeId"],
      );

  Map<String, dynamic> toMap() => {
        "sensorId": sensorId,
        "reading": reading,
        "sensorGroupId": sensorGroupId,
        "departmentId": departmentId,
        "depth": depth,
        "sensorTypeId": sensorTypeId,
      };

  @override
  void addItem(itemId, double val) {
    throw UnimplementedError();
  }

  @override
  countAt(int index) {
    throw UnimplementedError();
  }

  @override
  countObjAt(int index) {
    throw UnimplementedError();
  }

  @override
  String countTitle(BuildContext context, int index) {
    throw UnimplementedError();
  }

  @override
  bool get enable => sensor != null ? !sensor.isAuto : true;

  @override
  bool hasChanged() {
    return _changed;
  }

  @override
  bool get isEmpty => false;

  @override
  bool get isValidData => true;

  @override
  bool isSameCount(obj, item) {
    throw UnimplementedError();
  }

  @override
  bool isSameCountAt(int index, itemId) {
    throw UnimplementedError();
  }

  @override
  int get length => 0;

  @override
  void removeItem(item) {
    throw UnimplementedError();
  }

  @override
  void rollback() {
    while (_changeStack.canUndo) {
      _changeStack.undo();
    }
    _changed = false;
  }

  void commit() {
    _changeStack.clear();
    _changed = false;
  }

  @override
  totalCount() {
    throw UnimplementedError();
  }

  @override
  void updateItem(itemId, val) {
    throw UnimplementedError();
  }

  @override
  void clearTracking() {
    _changeStack.clear();
    _changed = false;
  }
}

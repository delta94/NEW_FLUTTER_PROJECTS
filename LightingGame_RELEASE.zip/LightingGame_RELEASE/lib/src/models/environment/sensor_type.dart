// To parse this JSON data, do
//
//     final sensorType = sensorTypeFromMap(jsonString);

import 'dart:convert';

SensorType sensorTypeFromMap(String str) =>
    SensorType.fromMap(json.decode(str));

class MeasurementUnit {
  static const int DegreesCelsius = 1; // °C
  static const int PartsPerMillion = 2; // ppm
  static const int Percent = 3; // %
  static const int Degrees = 4; // °
  static const int MetresPerSecond = 5; // m/s
  static const int Metres = 6; // m
  static const int Permille = 7; // ‰
  static const int MilligramsPerLitre = 8; // mg/l
  static const int CentimetresPerSecond = 9; // cm/s
  static const int CellsPerLitre = 10; // cells/l
  static const int Centimetres = 11; // cm
  static const int MilliSiemensPerCentimetre = 12; // mS/s
  static const int LitresPerMinute = 13; // l/min
  static const int MicrogramsPerLitre = 14; // µg/l
  static const int MillimetresOfMercury = 15; // mm/Hg
  static const int PH = 19; // pH
  static const int Hours = 20; // h
  static const int Lux = 21;
  static const int Count = 22;
  static const int CellsPerMilliLitre = 23; // cells/ml
  static const int MilliVolts = 24; // mV
  static const int M3PerHour = 26; // m3/h
  static const int MilligramsPerGram = 27; // mg/g
  static const int Bar = 28; // bar
  static const int ValueMap = 29;

  static String getMeasurementUnitName(int measUnit) {
    switch (measUnit) {
      case DegreesCelsius:
        return "°C";
      case PartsPerMillion:
        return "ppm";
      case Percent:
        return "%";
      case Degrees:
        return "°";
      case MetresPerSecond:
        return "m/s";
      case Metres:
        return "m";
      case Permille:
        return "‰";
      case MilligramsPerLitre:
        return "mg/l";
      case CentimetresPerSecond:
        return "cm/s";
      case CellsPerLitre:
        return "cells/l";
      case Centimetres:
        return "cm";
      case MilliSiemensPerCentimetre:
        return "mS/s";
      case LitresPerMinute:
        return "l/min";
      case MicrogramsPerLitre:
        return "µg/l";
      case MillimetresOfMercury:
        return "mm/Hg";
      case PH:
        return "pH";
      case Hours:
        return "h";
      case CellsPerMilliLitre:
        return "cells/ml";
      case MilliVolts:
        return "mV";
      case M3PerHour:
        return "m3/h";
      case M3PerHour:
        return "m3/h";
      case MilligramsPerGram:
        return "mg/g";
      case Bar:
        return "bar";
      default:
        return "";
    }
  }
}

class SensorType {
  SensorType({
    this.itemId,
    this.name,
    this.valueMapTypeName,
    this.valueMap,
    this.measUnit,
  });

  /// The sensorType id
  int itemId;

  String name;

  /// If measUnit == 29 (ValueMap), then this field is the name of measure unit.
  /// Example: Wind Direction, Water Color
  String valueMapTypeName;

  /// the mapping between the number and name. Example
  /// {
  /// “1”: White,
  /// “2”: Blue,
  /// “3”: Grey
  /// }
  Map<int, String> valueMap;

  /// The measurement unit of this senssorType. They are defined in [MeasurementUnit]
  int measUnit;

  factory SensorType.fromMap(Map<String, dynamic> json) => SensorType(
        itemId: json["itemId"],
        valueMapTypeName: json["valueMapTypeName"],
        valueMap: json["valueMap"],
        measUnit: json["measUnit"],
      );
}

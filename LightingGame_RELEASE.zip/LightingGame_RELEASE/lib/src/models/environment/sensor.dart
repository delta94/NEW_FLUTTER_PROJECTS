// To parse this JSON data, do
//
//     final sensor = sensorFromMap(jsonString);

import 'dart:convert';
import 'package:intl/intl.dart';

List<Sensor> sensorsFromMap(String str) => List<Sensor>.from(json.decode(str).map((x) => Sensor.fromMap(x)));

String sensorToMap(Sensor data) => json.encode(data.toMap());

class Sensor {
  Sensor({
    this.id,
    this.name,
    this.sensorTypeId,
    this.disabled,
    this.depth,
    this.isAuto,
    this.history,
  });

  /// id of the sensor
  String id;

  /// name of the sensor
  String name;

  /// sensor type id of the sensor
  int sensorTypeId;

  /// if this sensor is disabled or not
  bool disabled;

  /// the depth of the sensor, default is –1
  double depth;

  /// is this sensor the auto sensor (auto push the value) or manual senso
  bool isAuto;

  /// List of SensorAssignment (the history of assignment of a sensor to a site/unit/department...)
  List<SensorAssignment> history;

  factory Sensor.fromMap(Map<String, dynamic> json) => Sensor(
        id: json["id"],
        name: json["name"],
        sensorTypeId: json["sensorTypeId"],
        disabled: json["disabled"],
        depth: json["depth"].toDouble(),
        isAuto: json["isAuto"],
        history: List<SensorAssignment>.from(
            json["history"].map((x) => SensorAssignment.fromMap(x))),
      );

  Map<String, dynamic> toMap() => {
        "id": id,
        "name": name,
        "sensorTypeId": sensorTypeId,
        "disabled": disabled,
        "depth": depth,
        "isAuto": isAuto,
        "history": List<dynamic>.from(history.map((x) => x.toMap())),
      };
}

/// NOTE:
/// If sensorGroupId, departmentId, unitId are all null, then this sensor is applied to the whole site.
/// Example: if unit A sees this value, then unit B sees this value also.
/// If unit B edits these values, then unit A may see these changes as well.
/// Organization Tree is on the way of developing, so in ControlApp, in the meantime,
/// I think we just need siteId and unitId only.
class SensorAssignment {
  SensorAssignment({
    this.startTime,
    this.endTime,
    this.siteId,
    this.sensorGroupId,
    this.departmentId,
    this.unitId,
  });

  /// the start time of the assignment
  DateTime startTime;

  /// the endtime of the assigment. If it is null, it means the current assignment
  DateTime endTime;

  /// the siteId that this sensor is assigned
  String siteId;

  /// the sensorGroupId that this sensor is assigned, maybe null
  String sensorGroupId;

  /// the departmentId that this sensor is assigned, maybe null
  String departmentId;

  /// the unitId that this sensor is assigned, maybe null.
  String unitId;

  factory SensorAssignment.fromMap(Map<String, dynamic> json) =>
      SensorAssignment(
        startTime: DateTime.tryParse(json["startTime"]),
        endTime: json["endTime"] != null ? DateTime.tryParse(json["endTime"]) : null,
        siteId: json["siteId"],
        sensorGroupId: json["sensorGroupId"],
        departmentId: json["departmentId"],
        unitId: json["unitId"],
      );

  Map<String, dynamic> toMap() => {
        "startTime": DateFormat('yyyy-MM-ddTHH:mm:ss').format(startTime),
        "endTime": endTime != null ? DateFormat('yyyy-MM-ddTHH:mm:ss').format(endTime) : null,
        "siteId": siteId,
        "sensorGroupId": sensorGroupId,
        "departmentId": departmentId,
        "unitId": unitId,
      };
}

import 'package:flutter/material.dart';

class OrganizationUnit {
  String id;
  String siteName;
  String departmentName;
  int visit;
  bool favorite;

  OrganizationUnit({@required this.id, @required this.siteName, this.departmentName});

}

import 'package:intl/intl.dart';

class YesterdayFeedType {
  static const String columnUserName = 'username';
  static const String columnUnitId = 'unitId';
  static const String columnFeedStoreId = 'feedStoreId';
  static const String columnFeedTypeId = 'feedTypeId';
  static const String columnDate = 'date';
  
  String username;
  String unitId;
  String feedStoreId;
  int feedTypeId;
  String date;

  YesterdayFeedType(this.username, this.unitId, this.feedStoreId, this.feedTypeId) {
    var formatter = DateFormat('yyyy-MM-dd');
    this.date = formatter.format(DateTime.now());
  }

  YesterdayFeedType.fromMap(Map<String, dynamic> map) {
    username = map[columnUserName];
    unitId = map[columnUnitId];
    feedStoreId = map[columnFeedStoreId];
    feedTypeId = map[columnFeedTypeId];
    date = map[columnDate];
  }

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      columnUserName: username,
      columnUnitId: unitId,
      columnFeedStoreId: feedStoreId,
      columnFeedTypeId: feedTypeId,
      columnDate: date
    };
  }

  @override
  bool operator ==(dynamic other) {
    YesterdayFeedType that = other as YesterdayFeedType;
    if(that == null) return false;

    if(that.username == this.username && that.feedTypeId == this.feedTypeId && that.feedStoreId == this.feedStoreId && that.unitId == this.unitId && that.date == this.date) {
      return true;
    }

    return false;
  }

  @override
  int get hashCode => username.hashCode ^ unitId.hashCode ^ feedStoreId.hashCode ^ feedTypeId.hashCode ^ date.hashCode;
}

// To parse this JSON data, do
//
//     final unitStatus = unitStatusFromMap(jsonString);

import 'dart:convert';

List<UnitStatus> unitStatusFromMap(String str) =>
    List<UnitStatus>.from(json.decode(str).map((x) => UnitStatus.fromMap(x)));

String unitStatusToMap(List<UnitStatus> data) =>
    json.encode(List<dynamic>.from(data.map((x) => x.toMap())));

class UnitStatus {
  UnitStatus({
    this.statusTime,
    this.stockNo,
    this.stockBm,
    this.id,
    this.popId,
    this.statusId,
    this.siteId,
    this.unitId,
  });

  DateTime statusTime;
  int stockNo;
  double stockBm;
  String id;
  String popId;
  String statusId;
  String siteId;
  String unitId;

  factory UnitStatus.fromMap(Map<String, dynamic> json) => UnitStatus(
        statusTime: DateTime.tryParse(json["statusTime"]),
        stockNo: json["stockNo"] != null ? json["stockNo"].toInt() : 0.0,
        stockBm: json["stockBm"] != null ? json["stockBm"].toDouble() : 0.0,
        id: json["id"],
        popId: json["popId"],
        statusId: json["statusId"],
        siteId: json["siteId"],
        unitId: json["unitId"],
      );

  Map<String, dynamic> toMap() => {
        "statusTime": statusTime != null ? statusTime.toIso8601String() : null,
        "stockNo": stockNo,
        "stockBm": stockBm,
        "id": id,
        "popId": popId,
        "statusId": statusId,
        "siteId": siteId,
        "unitId": unitId,
      };
}

import 'package:undo/undo.dart';

class Culling {
  int _cullingCount;
  int _cullingCauseId;

  /// The property is for tracking if the model has any changed
  /// and be able to rollback to orginal data in case user discard update.
  /// It does not affect to data model.
  final ChangeStack _changeStack = new ChangeStack();

  /// Flag to determine that current registration was changed.
  /// It does not affect to data model.
  bool _changed = false;

  /// getters and setter =================================================
  int get cullingCount => _cullingCount;
  int get cullingCauseId => _cullingCauseId;

  set cullingCount(int val) {
    if (_changeStack.canUndo) {
      _changeStack.undo();
    }
    if (_cullingCount != val) {
      _changeStack.add(Change.property(_cullingCount, () => _cullingCount = val,
          (oldVal) => _cullingCount = oldVal));
      _changed = true;
    } else {
      _changed = false;
    }
  }

  set cullingCauseId(int val) {
    if (_cullingCount != val) _cullingCauseId = val;
  }

  bool get changed => _changed;

  Culling({
    int cullingCount,
    int cullingCauseId,
  })  : _cullingCount = cullingCount,
        _cullingCauseId = cullingCauseId;

  Map toMap() {
    /// For the count that is not committed (changed = true)
    /// then we must keep the old value.
    /// This is for the case that user modified some counts
    /// and delete another count, the modified values will be
    /// stored back to local storage and cloud api if we do not handle
    /// keeping the old values.
    int newCount = _cullingCount;
    int oldCount = _cullingCount;
    if (_changed) {
      if (_changeStack.canUndo) {
        _changeStack.undo();
        oldCount = _cullingCount;
        cullingCount = newCount;
      }
    }
    return {'cullingCount': oldCount, 'cullingCauseId': _cullingCauseId};
  }

  factory Culling.fromMap(Map json) => Culling(
      cullingCount: json['cullingCount'],
      cullingCauseId: json['cullingCauseId']);

  void rollback() {
    while (_changeStack.canUndo) {
      _changeStack.undo();
    }
    _changed = false;
  }

  void clearTracking() {
    _changeStack.clear();
    _changed = false;
  }

  @override
  bool operator ==(dynamic other) {
    Culling that = other as Culling;
    if (that == null) return false;

    if (that.cullingCount == this.cullingCount &&
        that.cullingCauseId == this.cullingCauseId) {
      return true;
    }

    return false;
  }

  @override
  int get hashCode => cullingCount.hashCode ^ cullingCauseId.hashCode;
}

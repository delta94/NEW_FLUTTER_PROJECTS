import 'package:control_app/src/models/base/base_cause.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:undo/undo.dart';

import '../registration.dart';
import 'culling.dart';

class ResultingStock {
  int individCount;
  ResultingStock({this.individCount});

  Map<String, dynamic> toMap() {
    return {
      "individCount": individCount,
    };
  }

  factory ResultingStock.fromMap(Map jsonObj) {
    return ResultingStock(individCount: jsonObj['individCount']);
  }
}

class CullingRegistration extends RegistrationBaseItem {
  List<Culling> cullings;
  ResultingStock resultingStock;

  /// The property is for tracking mortalities list if the list is changed
  /// and be able to rollback to orginal data in case user discard update.
  /// It does not affect to data model.
  final ChangeStack _changeStack = new ChangeStack();
  bool _changed = false;

  CullingRegistration({@required this.cullings, @required this.resultingStock});

  @override
  Map toMap() {
    List<Map> items = cullings != null
        ? cullings.map((culling) => culling.toMap()).toList()
        : null;
    return {
      'cullings': items,
      'resultingStock': resultingStock.toMap(),
    };
  }

  factory CullingRegistration.fromMap(Map jsonObj) {
    return CullingRegistration(
      cullings: List<Culling>.from(
          jsonObj["cullings"].map((x) => Culling.fromMap(x))),
      resultingStock: ResultingStock.fromMap(jsonObj['resultingStock']),
    );
  }

  @override
  void rollback() {
    while (_changeStack.canUndo) {
      _changeStack.undo();
    }
    cullings.forEach((culling) => culling.rollback());
    _changed = false;
  }

  @override
  bool hasChanged() {
    return _changed || cullings.any((culling) => culling.changed);
  }

  /// Remove a mortality by cause Id combine with tracking change
  @override
  void removeItem(cullingCount) {
    _changeStack.add(Change.property(
        [...cullings],
        () => cullings.removeWhere(
            (culling) => culling.cullingCauseId == cullingCount.cullingCauseId),
        (oldValue) => cullings = oldValue));
    _changed = true;
  }

  @override
  void updateItem(cullingCount, val) {
    var culling = cullings.firstWhere(
        (item) => item.cullingCauseId == cullingCount.cullingCauseId);
    if (culling.cullingCount != val) {
      culling.cullingCount = val.round();
    }
  }

  @override
  bool get isEmpty => cullings.isEmpty;

  @override
  totalCount() {
    return cullings.fold(
      0,
      (previousValue, culling) => previousValue + culling.cullingCount,
    );
  }

  @override
  countAt(int index) {
    if (cullings != null && index < cullings.length && index >= 0) {
      return cullings[index].cullingCount;
    }
    return 0;
  }

  @override
  int get length => cullings.length;

  @override
  countObjAt(int index) {
    if (cullings != null && index < cullings.length && index >= 0) {
      return cullings[index];
    }
    return null;
  }

  @override
  String countTitle(BuildContext context, int index) {
    final sharedDataModel =
        Provider.of<SharedDataModel>(context, listen: false);
    String title =
        sharedDataModel.getCullingCauseName(cullings[index].cullingCauseId) ??
            'Unknown';
    return title;
  }

  @override
  bool get isValidData => !cullings.any(
      (culling) => culling.cullingCount == null || culling.cullingCount <= 0);

  @override
  bool isSameCountAt(int index, cause) {
    var countObj = countObjAt(index);
    if (countObj != null) {
      return countObj.cullingCauseId == cause.causeId;
    }
    return false;
  }

  @override
  bool get enable => resultingStock.individCount == null;

  @override
  void addItem(cause, double val) {
    if (cause is BaseCause) {
      cullings.add(
          Culling(cullingCauseId: cause.causeId, cullingCount: val.round()));
    }
  }

  @override
  bool isSameCount(obj, item) {
    if (obj != null && obj is Culling && item != null && item is BaseCause) {
      return obj.cullingCauseId == item.causeId;
    }
    return false;
  }

  @override
  void clearTracking() {
    if (_changed) {
      _changeStack.clear();
      _changed = false;
    }
  }

  @override
  void commit() {
    _changeStack.clear();
    _changed = false;
    cullings.forEach((culling) {
      culling.clearTracking();
    });
  }
}

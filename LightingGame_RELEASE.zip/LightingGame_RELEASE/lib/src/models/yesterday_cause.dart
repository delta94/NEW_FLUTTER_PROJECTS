import 'package:intl/intl.dart';

/// Yesterday cause data model
class YesterdayCause {
  static const String columnUserName = 'username';
  static const String columnCauseId = 'causeId';
  static const String columnUnitId = 'unitId';
  static const String columnDate = 'date';

  String username;
  int causeId;
  String unitId;
  String date;

  // YesterdayCauses are initiated with datetime now as default
  YesterdayCause(this.username, this.causeId, this.unitId) {
    var formatter = DateFormat('yyyy-MM-dd');
    this.date = formatter.format(DateTime.now());
  }

  /// convenience constructor to create a YesterdayCause object
  YesterdayCause.fromMap(Map<String, dynamic> map) {
    username = map[columnUserName];
    causeId = map[columnCauseId];
    unitId = map[columnUnitId];
    date = map[columnDate];
  }

  /// convenience method to create a Map from this YesterdayCause object
  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      columnUserName: username,
      columnCauseId: causeId,
      columnUnitId: unitId,
      columnDate: date
    };
  }

  @override
  bool operator ==(dynamic other) {
    YesterdayCause that = other as YesterdayCause;
    if(that == null) return false;

    if(that.username == this.username && that.causeId == this.causeId && that.unitId == this.unitId && that.date == this.date) {
      return true;
    }

    return false;
  }

  @override
  int get hashCode => username.hashCode ^ causeId.hashCode ^ unitId.hashCode ^ date.hashCode;
}

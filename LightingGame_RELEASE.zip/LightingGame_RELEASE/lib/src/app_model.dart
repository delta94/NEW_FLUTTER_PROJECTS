import 'dart:convert';
import 'dart:ui';

import 'package:Commons/themes.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/base/base_view_model.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/services/api_service.dart';
import 'package:control_app/src/services/auth_service.dart';
import 'package:control_app/src/services/timezone_service.dart';
import 'package:control_app/src/sync/synchronize_manager.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mutex/mutex.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:data_connection_checker/data_connection_checker.dart';

enum AppMode { Landbased, Seabased }

class AppModel extends BaseViewModel {
  static final AppModel _instance = AppModel._internal();

  AppMode appMode = AppMode.Seabased;

  bool isAuthenticated = false;
  bool isDarkTheme = false;
  bool hideEmptyUnit = true;
  String languageCode = 'en';
  Locale currentLocale = Locale('en');
  UserInfo currentUserInfo;
  ThemeData currentTheme = akvaDarkTheme;

  final _authService = AuthService();
  SharedPreferences _sharedPreferences;
  static const _themePreferenceKey = 'isDarkThemeEnabled';
  static const _userInfoKey = 'userInfo';
  static const _hideEmptyUnits = 'hideEmptyUnits';
  static const _languageKey = 'language';
  var listener;
  DataConnectionStatus connectionStatus;
  SynchronizeManager synchronizeManager;

  Map<RegistrationType, int> _syncResultDict = new Map<RegistrationType, int>();
  Map<RegistrationType, int> get synResult => _syncResultDict;

  final m = Mutex();

  factory AppModel() {
    return _instance;
  }

  AppModel._internal();

  _sync() async {
    if (isAuthenticated &&
        currentUserInfo != null &&
        connectionStatus == DataConnectionStatus.connected) {
      print(
          "SYNC: ========== Start to sync when Network connection is available.");
      await synchronizeManager.performSync();
      notifyListeners();
    }
  }

  Future initialize() async {
    setBusy(true);
    await _authService.initialize();
    this.isAuthenticated = _authService.isLoggedIn();
    this._sharedPreferences = await SharedPreferences.getInstance();
    this._loadLanguage();
    this._loadThemePrefeence();
    this._loadUserInfo();
    this._loadHideEmptyUnitsPreference();
    TimeZoneService();
    synchronizeManager = new SynchronizeManager();

    synchronizeManager.syncResultStream.listen((syncResult) async {
      if (syncResult.numberOfItems > 0) {
        await m.acquire();

        if (_syncResultDict.containsKey(syncResult.type)) {
          _syncResultDict[syncResult.type] =
              _syncResultDict[syncResult.type] + syncResult.numberOfItems;
        } else {
          _syncResultDict[syncResult.type] = syncResult.numberOfItems;
        }

        m.release();

        notifyListeners();
      }
    });
    connectionStatus = await DataConnectionChecker().connectionStatus;
    synchronizeManager.connectionStatus = connectionStatus;
    _sync();
    setBusy(false);
    listener = DataConnectionChecker().onStatusChange.listen((status) {
      switch (status) {
        case DataConnectionStatus.connected:
          print('Data connection is available.');
          break;
        case DataConnectionStatus.disconnected:
          print('You are disconnected from the internet.');
          break;
      }

      if (connectionStatus != status) {
        connectionStatus = status;
        synchronizeManager.connectionStatus = connectionStatus;
        _sync();
        notifyListeners();
      }
    });
  }

  void dismissSyncResult() {
    _syncResultDict.clear();
    notifyListeners();
  }

  Future<void> authenticate() async {
    try {
      await _authService.authenticate();
      currentUserInfo = await _authService.getUserInfo();
      await ApiService().httpGet('${ApiService.urlRoot}/users/current',
          (userJson) {
        Map<String, dynamic> user = jsonDecode(userJson);
        currentUserInfo.id = user['id'];
      });
      this.isAuthenticated = true;
      this._saveUserInfo();

      /// Call sync data to cloud everytimes user authenticated
      _sync();
      notifyListeners();
    } on PlatformException catch (e) {
      throw e;
    }
  }

  Future logOut() async {
    await _authService.deleteEverything();
    this.isAuthenticated = false;
    notifyListeners();
  }

  void setCurrentLocale(Locale locale) {
    this.currentLocale = locale;
    this.languageCode = locale.languageCode;
    S.load(locale);
    _saveLanguage();
    notifyListeners();
  }

  void toggleTheme() async {
    this.isDarkTheme = !this.isDarkTheme;
    this.currentTheme = this.isDarkTheme ? akvaDarkTheme : akvaLightTheme;
    _saveThemePreference(this.isDarkTheme);
    notifyListeners();
  }

  void _loadThemePrefeence() async {
    try {
      this.isDarkTheme =
          _sharedPreferences.getBool(_themePreferenceKey) ?? true;
      this.currentTheme = this.isDarkTheme ? akvaDarkTheme : akvaLightTheme;
    } catch (e) {
      this.isDarkTheme = true;
      this.currentTheme = akvaDarkTheme;
    }
  }

  Future _saveThemePreference(bool isDarkTheme) async {
    await _sharedPreferences.setBool(_themePreferenceKey, isDarkTheme);
  }

  void _loadUserInfo() async {
    try {
      String encodedUSerInfo = _sharedPreferences.getString(_userInfoKey);
      if (encodedUSerInfo != null) {
        currentUserInfo = UserInfo.fromJson(json.decode(encodedUSerInfo));
      }
    } catch (e) {
      currentUserInfo = null;
    }
  }

  void _saveUserInfo() async {
    String encodedUserInfo = json.encode(currentUserInfo.toJson());
    await _sharedPreferences.setString(_userInfoKey, encodedUserInfo);
  }

  void _loadHideEmptyUnitsPreference() async {
    try {
      this.hideEmptyUnit = _sharedPreferences.getBool(_hideEmptyUnits) ?? true;
    } catch (e) {
      this.hideEmptyUnit = true;
    }
  }

  Future _saveHideEmptyUnitsPreference(bool hideEmptyUnits) async {
    await _sharedPreferences.setBool(_hideEmptyUnits, isDarkTheme);
  }

  void _loadLanguage() {
    try {
      languageCode = _sharedPreferences.getString(_languageKey);
      if (languageCode == null || languageCode.isEmpty) {
        languageCode = 'en';
      }
      this.currentLocale = Locale(languageCode);
      S.load(currentLocale);
      //notifyListeners();
    } catch (e) {
      print(e.toString());
    }
  }

  Future _saveLanguage() async {
    await _sharedPreferences.setString(_languageKey, languageCode);
  }

  void toggleHideEmptyUnits() async {
    this.hideEmptyUnit = !this.hideEmptyUnit;
    _saveHideEmptyUnitsPreference(this.hideEmptyUnit);
    notifyListeners();
  }

  void setAppMode(AppMode mode) {
    if (appMode != mode) {
      appMode = mode;
      notifyListeners();
    }
  }
}

import 'package:flutter/material.dart';

import 'sensor_bloc.dart';
import 'sensor_registration_screen.dart';

class SensorScreen extends StatefulWidget {
  @override
  State<StatefulWidget> createState() {
    return SensorState();
  }
}

class SensorState extends State<SensorScreen> {
  SensorBloc _sensorBloc;
  @override
  initState() {
    super.initState();
    _sensorBloc = SensorBloc();
    _sensorBloc.fetchSensorReadings();
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      child: Stack(children: [
        Align(
          alignment: Alignment.bottomRight,
          child: Padding(
            padding: const EdgeInsets.only(bottom: 16.0, right: 16.0),
            child: FloatingActionButton.extended(
              label: Text("New Registration"),
              icon: Icon(Icons.add),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) {
                      return SensorRegistrationScreen(_sensorBloc);
                    },
                    settings: RouteSettings(arguments: null),
                  ),
                );
              },
            ),
          ),
        )
      ]),
    );
  }
}

import 'dart:convert';
import 'package:uuid/uuid.dart';
import '../main/base_model.dart';
import '../services/api_service.dart';
import 'package:control_app/src/util/constants.dart';
class SensorModel {
  String id;
  String name;
  String sensorCategoryId;
  String unitOfMeasurement;
  double depth;
  SensorModel.fromJson(Map<String, dynamic> parsedJson) {
    id = parsedJson['sensorId'];
    name = parsedJson['displayName'];
    sensorCategoryId = parsedJson['sensorCategoryId'];
    unitOfMeasurement = parsedJson['unitOfMeasurement'];
    depth = parsedJson['depth'];
  }
}

class Sensors {
  List<SensorModel> sensors;
  Sensors.fromJson(List<dynamic> parsedJson) {
    sensors = parsedJson.map((sensor) => SensorModel.fromJson(sensor)).toList();
  }
}

class SensorReadingModel extends BaseModel {
  String id;
  String sensorId;
  DateTime time;
  double utcOffset;

  double reading;

  SensorReadingModel({
    this.sensorId,
    this.time,
    this.utcOffset = 0.0,
    this.reading,
  }) {
    id = Uuid().v4();
    changeStatus = ChangeStatus.New;
  }

  SensorReadingModel.fromJson(Map<String, dynamic> parsedJson) {
    id = parsedJson['id'];
    sensorId = parsedJson['sensorId'];
    time = DateTime.parse(parsedJson['time']);
    utcOffset = parsedJson['utcOffset'];
    reading = parsedJson['reading'];
    changeStatus = ChangeStatus.Unchanged;
  }

  SensorReadingModel.fromSensorReadingModel(SensorReadingModel model) {
    id = model.id;
    sensorId = model.sensorId;
    time = model.time;
    utcOffset = model.utcOffset;
    reading = model.reading;
    changeStatus = model.changeStatus;
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'sensorId': sensorId,
        'time': time.toIso8601String(),
        'utcOffset': utcOffset,
        'reading': reading,
      };
}

class SensorReadings {
  List<SensorReadingModel> sensorReadings;
  SensorReadings.fromJson(Map<String, dynamic> parsedJson) {
    // TODO: For now, just extract the data here. Later implement paging support in api service
    sensorReadings = parsedJson['data']
        .map((reading) => SensorReadingModel.fromJson(reading))
        .toList();
  }
}

class UnitOfMeasurement {
  String id;
  String name;
  String abbreviation;
  UnitOfMeasurement.fromJson(Map<String, dynamic> parsedJson) {
    id = parsedJson['id'];
    name = parsedJson['name'];
    abbreviation = parsedJson['abbreviation'];
  }
}

class UnitsOfMeasurement {
  List<UnitOfMeasurement> measurements;
  UnitsOfMeasurement.fromJson(List<dynamic> parsedJson) {
    measurements =
        parsedJson.map((m) => UnitOfMeasurement.fromJson(m)).toList();
  }
}

class SensorCategory {
  String id;
  String name;
  List<UnitOfMeasurement> allowedUnitOfMeasurements;

  SensorCategory.fromJson(Map<String, dynamic> parsedJson) {
    id = parsedJson['id'];
    name = parsedJson['name'];
    final unitsOfMeasurement =
        UnitsOfMeasurement.fromJson(parsedJson['allowedUnitOfMeasurements']);
    allowedUnitOfMeasurements = unitsOfMeasurement.measurements;
    /*allowedUnitOfMeasurements = parsedJson['allowedUnitOfMeasurements']
        .map((m) => UnitOfMeasurement.fromJson(m))
        .toList();*/
  }
}

class SensorCategories {
  List<SensorCategory> sensorCategories;

  SensorCategories.fromJson(List<dynamic> parsedJson) {
    sensorCategories = parsedJson.map((category) {
      return SensorCategory.fromJson(category);
    }).toList();
  }
}

// As for all values in the control app, readings are for today
class SensorRepository {
  final _apiService = ApiService();

  Future<List<SensorModel>> getSensorsForUnit(String siteId, String unitId) {
    return _apiService.httpGet(
        '${ApiService.urlRoot}/sensors?siteId=$siteId&unitId=$unitId', (data) {
      final parsedJson = json.decode(data);
      final extractedSensors = parsedJson.map((c) => c['current']);
      return Sensors.fromJson(extractedSensors.toList()).sensors;
    });
  }

  Future<List<SensorModel>> getSensorsForSite(String siteId) {
    return _apiService.httpGet('${ApiService.urlRoot}/sensors?siteId=$siteId',
        (data) {
      final parsedJson = json.decode(data);
      return Sensors.fromJson(parsedJson).sensors;
    });
  }

  Future<List<SensorReadingModel>> getReadingsForUnit(String unitId) {
    DateTime now = DateTime.now();
    DateTime today = DateTime(now.year, now.month, now.day);
    return _apiService.httpGet(
        '${ApiService.urlRoot}/sensor-readings?unitId=$unitId&from=${today.toIso8601String()}',
        (data) {
      final parsedJson = json.decode(data);
      return SensorReadings.fromJson(parsedJson);
    });
  }

  Future<List<SensorReadingModel>> getReadingsForSite(String siteId) {
    DateTime now = DateTime.now();
    DateTime today = DateTime(now.year, now.month, now.day);
    return _apiService.httpGet(
        '${ApiService.urlRoot}/sensor-readings?siteId=$siteId&from=${today.toIso8601String()}',
        (data) {
      final parsedJson = json.decode(data);
      return SensorReadings.fromJson(parsedJson);
    });
  }

  Future<List<SensorCategory>> getSensorCategories() {
    return _apiService.httpGet('${ApiService.urlRoot}/sensor-categories',
        (data) {
      final parsedJson = json.decode(data);
      final SensorCategories sensors = SensorCategories.fromJson(parsedJson);
      return sensors.sensorCategories;
    });
  }

  Future postReading(SensorReadingModel reading) {}
}

import 'package:control_app/src/sensors/sensor_registration_bloc.dart';
import 'package:control_app/src/widgets/ok_cancel_bar.dart';
import 'package:flutter/material.dart';
import '../widgets/ok_cancel_modal_dialog.dart';
import 'sensor_bloc.dart';
import '../widgets/registration_card.dart';

class SensorRegistrationScreen extends StatefulWidget {
  final SensorRegistrationBloc sensorRegistrationBloc;
  SensorRegistrationScreen(SensorBloc sensorBloc)
      : sensorRegistrationBloc = SensorRegistrationBloc(
            sensorBloc: sensorBloc, registrationTime: DateTime.now());

  @override
  _SensorRegistrationState createState() => _SensorRegistrationState();
}

class _SensorRegistrationState extends State<SensorRegistrationScreen> {
  bool hasAnythingChanged = false;

  @override
  initState() {
    super.initState();
    widget.sensorRegistrationBloc.fetchSensors();
    widget.sensorRegistrationBloc.fetchSensorCategories();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Environment Registration'),
      ),
      body: createBody(),
    );
  }

  Widget createBody() {
    return StreamBuilder<SensorsAndUnitsOfMeasurements>(
        stream: widget.sensorRegistrationBloc.sensorsAndUnitsOfMeasurement,
        builder:
            (context, AsyncSnapshot<SensorsAndUnitsOfMeasurements> snapshot) {
          if (!snapshot.hasData) {
            return LinearProgressIndicator();
          }
          if (snapshot.hasError) {
            return Text("Failed");
          }
          return Column(children: <Widget>[
            createSensorList(context, snapshot.data),
            createOkCancelBar(context),
          ]);
        });
  }

  Widget createSensorList(
      context, SensorsAndUnitsOfMeasurements sensorsAndMeasurements) {
    return Expanded(
        child: ListView.builder(
            itemCount: sensorsAndMeasurements.sensors.length,
            itemBuilder: (context, index) {
              final sensor = sensorsAndMeasurements.sensors[index];
              final denomination = sensorsAndMeasurements
                  .unitsOfMeasurement[sensor.unitOfMeasurement].abbreviation;
              final cardTitle = '${sensor.name} ($denomination)';
              return RegistrationCard(
                title: cardTitle,
                initialValue: null,
                showDeleteButton: false,
                onDelete: () {
                  widget.sensorRegistrationBloc.deleteReading(sensor.id);
                },
                onValueChanged: (double val) {
                  widget.sensorRegistrationBloc
                      .addOrUpdateReading(sensor.id, val);
                },
              );
            }));
  }

  Future<bool> confirmDialog() {
    return showDialog(
      context: context,
      barrierDismissible: true,
      builder: (BuildContext context) {
        return YesNoModalDialog(
          title: "Save Changes",
          description: "Do you want to save the changes",
          okCallback: () async {
            Navigator.pop(context, true);
          },
          cancelCallback: () {
            Navigator.pop(context, false);
            Navigator.pop(context, false);
          },
        );
      },
    );
  }

  Widget createOkCancelBar(context) {
    void cancelFunction() async {
      if (hasAnythingChanged) {
        await confirmDialog();
      } else {
        Navigator.pop(context);
      }
    }

    void saveFunction() async {}
    return OkCancelBar(
        cancelCallback: cancelFunction, okCallback: saveFunction);
  }
}

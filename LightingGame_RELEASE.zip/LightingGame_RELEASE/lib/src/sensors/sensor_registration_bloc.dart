import 'package:control_app/src/util/constants.dart';

import '../organization/organization_bloc.dart';
import 'package:rxdart/rxdart.dart';

import 'sensor_bloc.dart';
import 'sensor_repository.dart';

class SensorsAndUnitsOfMeasurements {
  List<SensorModel> sensors;
  Map<String, UnitOfMeasurement> unitsOfMeasurement;
  SensorsAndUnitsOfMeasurements({this.sensors, this.unitsOfMeasurement});
}

// Since the temporary state is held by textfields, no need to make a copy of state
// When saving, check differences
class SensorRegistrationBloc {
  final _sensors = BehaviorSubject<List<SensorModel>>();
  final _unitsOfMeasurement = BehaviorSubject<Map<String, UnitOfMeasurement>>();
  final _sensorIdToReading = BehaviorSubject<Map<String, SensorReadingModel>>();

  final _sensorRepository = SensorRepository();
  final _orgBloc = OrganizationBloc();
  final SensorBloc sensorBloc;
  final DateTime registrationTime;

  SensorRegistrationBloc({this.registrationTime, this.sensorBloc}) {
    if (sensorBloc.currentSensorReadings != null) {
      final deepCopyOfoldReadingsAtRegistrationTime = sensorBloc
          .currentSensorReadings
          .where((reading) => reading.time.isAtSameMomentAs((registrationTime)))
          .map((reading) => SensorReadingModel.fromSensorReadingModel(reading));

      final sensorIdToReading = Map.fromIterable(
          deepCopyOfoldReadingsAtRegistrationTime,
          key: (s) => s.sensorId,
          value: (s) => s);
      _sensorIdToReading.add(sensorIdToReading);
    } else {
      _sensorIdToReading.add({});
    }
  }

  Map<String, SensorCategory> sensorCategories;
  Map<String, UnitOfMeasurement> unitsOfMeasurement;

  Observable<List<SensorModel>> get sensorsStream => _sensors.stream;
  Observable<SensorsAndUnitsOfMeasurements> get sensorsAndUnitsOfMeasurement =>
      Observable.combineLatest2(_sensors, _unitsOfMeasurement,
          (List<SensorModel> sensors, Map<String, UnitOfMeasurement> units) {
        return SensorsAndUnitsOfMeasurements(
            sensors: sensors, unitsOfMeasurement: units);
      });

  Future fetchSensorCategories() async {
    final sensorCategoriesAsList =
        await _sensorRepository.getSensorCategories();
    sensorCategories = Map.fromIterable(sensorCategoriesAsList,
        key: (c) => c.id, value: (c) => c);
    final unitsOfMeasurementAsSet =
        sensorCategoriesAsList.fold([], (curr, next) {
      return [...curr, ...next.allowedUnitOfMeasurements];
    }).toSet();
    unitsOfMeasurement = Map.fromIterable(unitsOfMeasurementAsSet,
        key: (u) => u.id, value: (u) => u);
    _unitsOfMeasurement.add(unitsOfMeasurement);
  }

  Future fetchSensors() async {
    final currentOrganizationEntity = _orgBloc.currentOrganizationEntity;
    final bool isSite = _orgBloc.isCurrentOrganizationSite();
    if (isSite == null) {
      assert(
          false, 'Organization unit is not site or unit, cannot fetch sensors');
    } else if (isSite) {
      final fetchedSensors = await _sensorRepository
          .getSensorsForSite(currentOrganizationEntity.id);
      _sensors.sink.add(fetchedSensors);
    } else {
      final fetchedSensors = await _sensorRepository.getSensorsForUnit(
          currentOrganizationEntity.parent.id, currentOrganizationEntity.id);
      _sensors.sink.add(fetchedSensors);
    }
  }

  void addOrUpdateReading(String sensorId, double reading) {
    final newReadingModel = SensorReadingModel(
        sensorId: sensorId, reading: reading, time: registrationTime);
    final Map<String, SensorReadingModel> copyOfOldSensorIdToReading =
        Map.from(_sensorIdToReading.value);
    if (copyOfOldSensorIdToReading.containsKey(sensorId)) {
      newReadingModel.changeStatus = ChangeStatus.Changed;
    } else {
      newReadingModel.changeStatus = ChangeStatus.New;
    }
    copyOfOldSensorIdToReading[sensorId] = newReadingModel;
    _sensorIdToReading.add(copyOfOldSensorIdToReading);
  }

  void deleteReading(String sensorId) {
    final Map<String, SensorReadingModel> copyOfOldSensorIdToReading =
        Map.from(_sensorIdToReading.value);
    copyOfOldSensorIdToReading.remove(sensorId);
    _sensorIdToReading.add(copyOfOldSensorIdToReading);
  }

  Future saveChanges() async {
    //await _sensorRepository.saveSensorReadings(_sensorIdToReading.value);
    // If save fails somehow, maybe not update model?
    // for now just update model if no exceptions propagate past here.
    sensorBloc.updateReadings(_sensorIdToReading.value);
  }

  /* Future saveChanges(Map<String, double> newSensorIdToReading) {
    final oldSensorReadingsAtRegistrationTime = sensorBloc
        .currentSensorReadings
        .where((reading) => reading.time.isAtSameMomentAs((registrationTime)));

    final sensorIdToOldReadingAtRegistrationTime = Map.fromIterable(
        oldSensorReadingsAtRegistrationTime,
        key: (r) => r.sensorId,
        value: (r) => r);

    for(int i = 0; i < _sensors.value.length; i++) {
      final sensor = _sensors.value[i];
      final SensorReadingModel oldReadingForSensor = sensorIdToOldReadingAtRegistrationTime[sensor.id];
      final newReadingForSensor = newSensorIdToReading[sensor.id];
      if (oldReadingForSensor == null && newReadingForSensor != null) {
        // New reading
        final newReadingModel = SensorReadingModel(sensorId: sensor.id, reading: newReadingForSensor, time: registrationTime);

      } else if (oldReadingForSensor != null && newReadingForSensor != null) {
        // changed or not changed existing reading
        
        
      } else if (oldReadingForSensor != null && newReadingForSensor == null) {
        //deleted
      }
    }
    
  }
*/
  void dispose() {
    _sensors.close();
    _unitsOfMeasurement.close();
  }
}

import 'package:control_app/src/organization/organization_bloc.dart';
import 'package:rxdart/rxdart.dart';

import 'sensor_repository.dart';

// will fetch data based on current organization at the time fetch methods are called
class SensorBloc {
  final _sensorReadings = BehaviorSubject<List<SensorReadingModel>>();
  final _orgBloc = OrganizationBloc();

  final _sensorRepository = SensorRepository();

  Observable<List<SensorReadingModel>> get sensorReadingStream =>
      _sensorReadings.stream;
  List<SensorReadingModel> get currentSensorReadings => _sensorReadings.value;

  Future fetchSensorReadings() async {
    final currentOrganizationEntity = _orgBloc.currentOrganizationEntity;
    final bool isSite = _orgBloc.isCurrentOrganizationSite();
    if (isSite == null) {
      assert(false,
          'Organization unit is not site or unit, cannot fetch sensorreadings');
    } else if (isSite) {
      final fetchedReadings = await _sensorRepository
          .getReadingsForSite(currentOrganizationEntity.id);
      _sensorReadings.sink.add(fetchedReadings);
    } else {
      final fetchedReadings = await _sensorRepository
          .getReadingsForUnit(currentOrganizationEntity.id);
      _sensorReadings.sink.add(fetchedReadings);
    }
  }

  void updateReadings(Map<String, SensorReadingModel> sensorIdToReading) {}
  void dispose() {
    _sensorReadings.close();
  }
}

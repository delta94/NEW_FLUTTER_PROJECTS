import 'dart:convert';
import 'dart:io';
import 'package:control_app/src/app_model.dart';
import 'package:http/http.dart' as http;
import 'package:http/http.dart';
import 'auth_service.dart';
import 'package:mutex/mutex.dart';

final _tenantId =
    '28bc2ef6-e88d-459b-8753-ecabed76bfd0'; //'5ddc4a87-4406-442f-a0a3-d47a041e846e';

class AuthenticationException implements Exception {
  String cause;
  AuthenticationException({this.cause});
}

class ApiService {
  static final ApiService _instance = ApiService._internal();
  //static const urlRoot = 'https://akvaplatform.azurewebsites.net/api/v1';
  static const urlRoot = 'https://fishtalk-api-dev.azurewebsites.net/api/v1';
  final tokenType = "Bearer";
  final _authService = AuthService();
  final appModel = AppModel();
  final m = Mutex();

  factory ApiService() {
    return _instance;
  }

  ApiService._internal() {
    // Read stored queue from db here
  }

  Map<String, String> getHeaders({String cursor}) {
    var header = {
      HttpHeaders.authorizationHeader: tokenType + ' ' + _authService.authorizationToken,
      HttpHeaders.contentTypeHeader: 'application/json',
      'x-language-code': appModel.currentLocale.languageCode,
      'x-tenant-id': _tenantId,
    };

    if(cursor != null && cursor != "") {
      header['x-cursor'] = cursor;
    }

    return header;
  }

  Map<String, dynamic> parseJwt(String token) {
    final parts = token.split('.');
    if (parts.length != 3) {
      throw Exception('invalid token');
    }

    final payload = _decodeBase64(parts[1]);
    final payloadMap = json.decode(payload);
    if (payloadMap is! Map<String, dynamic>) {
      throw Exception('invalid payload');
    }

    return payloadMap;
  }

  String _decodeBase64(String str) {
    String output = str.replaceAll('-', '+').replaceAll('_', '/');

    switch (output.length % 4) {
      case 0:
        break;
      case 2:
        output += '==';
        break;
      case 3:
        output += '=';
        break;
      default:
        throw Exception('Illegal base64url string!"');
    }

    return utf8.decode(base64Url.decode(output));
  }

  Future<void> validateAccessToken() async {
    await m.acquire();

    try {
      var accessToken = parseJwt(_authService.authorizationToken);

      int exp = accessToken['exp'];

      DateTime expireTime = new DateTime.fromMillisecondsSinceEpoch(0)
          .add(Duration(seconds: exp));
      DateTime currentTime = DateTime.now().add(Duration(minutes: 5));

      if (currentTime.isAfter(expireTime)) {
        await _authService.refreshAccessToken();
      }
    } finally {
      m.release();
    }
  }

  Future<T> httpGet<T>(String uri, Function d, {String cursor}) async {
    print('REQUEST: $uri');
    await validateAccessToken();

    final response = await http.get(uri, headers: getHeaders(cursor : cursor));

    print('RESPONSE: ${response.statusCode}');

    if (response.statusCode == HttpStatus.ok) {
      return d(response.body);
    } else {
      print('REQUEST: $uri FAILED with error: ${response.body}');
      throw Exception("Failed http get: " + response.body.toString());
    }
  }

  Future httpPost(uri, String jsonEncodedModel) async {
    await validateAccessToken();

    final response =
        await http.post(uri, headers: getHeaders(), body: jsonEncodedModel);

    if (response.statusCode != HttpStatus.created) {
      throw ApiException("Failed http post", response);
    } else {
      return response.body;
    }
  }

  Future<Response> httpPut(uri, String jsonEncodedModel) async {
    await validateAccessToken();

    return http.put(uri, headers: getHeaders(), body: jsonEncodedModel);
  }

  Future<Response> httpDelete(uri) async {
    await validateAccessToken();

    return http.delete(uri, headers: getHeaders());
  }
}

typedef HttpFunction = Future<Response> Function(
    String a, Map<String, String> b, String c);

/**
 * Exception thrown when an expected
 * communicate problem with api happend.
 */
class ApiException implements Exception {
  
  /**
   * A message describing the format error.
   */
  final String message;

  /**
   * The actual source input which caused the error.
   *
   * This is usually a [String], but can be other types too.
   * If it is a string, parts of it may be included in the [toString] message.
   *
   * The source is `null` if omitted or unknown.
   */
  
  final Response source;

  /**
   * Creates a new ApiException with an optional error [message].
   *
   * Optionally also supply the actual [source] with the incorrect format,
   * and the [offset] in the format where a problem was detected.
   */
  const ApiException([this.message = "", this.source]);

  /**
   * Returns a description of the api exception.
   *
   * The description always contains the [message].
   *
   * If [source] is present and is a Reponse, the description will contain
   * body that carry message from http response
   *
   * If the source is a string and it contains a line break before offset,
   * only the line containing offset will be included, and its line number
   * will also be part of the description. Line and character offsets are
   * 1-based.
   */
  String toString() {
    String report = "ApiException";

    if(message != null) {
      report += ": $message";
    }

    if(source != null) {
      report += ". Reponse message: ${source.body}. Http status code: ${source.statusCode}";
    }

    return report;
  }
}
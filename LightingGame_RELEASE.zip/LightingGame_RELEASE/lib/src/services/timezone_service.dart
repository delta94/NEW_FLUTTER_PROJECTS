import 'package:timezone/timezone.dart';
import 'package:flutter/services.dart';

class TimeZoneService {
  static final TimeZoneService _singleton = TimeZoneService._internal();

  factory TimeZoneService() {
    return _singleton;
  }

  TimeZoneService._internal() {
    setup();
  }

  Future setup() async {
    var byteData = await rootBundle.load('packages/timezone/data/2020a.tzf');

    initializeDatabase(byteData.buffer.asUint8List());
  }

  /// Convert datetime [source] to datetime of a timezone by [timeZoneId].
  ///
  /// [timeZoneId] is from IANA time zone database.
  static DateTime convertToTimezone(DateTime source, String timeZoneId) {
    if(timeZoneId == null) return source;

    final location = getLocation(timeZoneId);
    if (location != null) {
      return new TZDateTime.from(source, location);
    }

    return source;
  }

  /// Convert datetime of a timezone to local datetime.
  ///
  /// [timeZoneTime] is datetime of a timezone.
  static DateTime convertFromTimezone(TZDateTime timeZoneTime) {
    if(timeZoneTime == null) return null;
    
    final localTime = DateTime.fromMillisecondsSinceEpoch(
        timeZoneTime.toUtc().millisecondsSinceEpoch);

    return localTime;
  }
}

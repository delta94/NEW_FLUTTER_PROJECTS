import 'dart:convert';

import 'package:control_app/src/services/api_service.dart';
import 'package:flutter/services.dart';
import 'package:flutter_appauth/flutter_appauth.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

final String clientId = 'f0aa3249-9d8e-4e1f-8fa2-778075e872fe';
//final String disco = 'https://akvaauth.azurewebsites.net/.well-known/openid-configuration';
final String disco =
    'https://fishtalk-auth-dev.azurewebsites.net/.well-known/openid-configuration';
final String redirectUri = 'akvagroup://login.oauth2';
final List<String> theScopes = [
  'openid',
  'profile',
  'email',
  'offline_access',
  'akvaplatform'
];

class UserInfo {
  String id;
  String name;
  String givenName;
  String familyName;
  String email;

  UserInfo.fromJson(Map<String, dynamic> decodedJson) {
    List<dynamic> nameList = decodedJson['name'];
    name = nameList[0];
    if (nameList.length == 2) {
      email = nameList[1];
    } else {
      email = decodedJson['email'];
    }
    id = decodedJson['id'];
    givenName = decodedJson['given_name'];
    familyName = decodedJson['family_name'];
  }

  Map<String, dynamic> toJson() => {
        'id': this.id,
        'name': [this.name],
        'email': this.email,
        'given_name': this.givenName,
        'family_name': this.familyName,
      };
}

class AuthService {
  static final AuthService _instance = AuthService._internal();

  final FlutterAppAuth _appAuth = FlutterAppAuth();
  FlutterSecureStorage _secureStorage;
  static const String _accessTokenKey = "authToken";
  static const String _refreshTokenKey = "refreshToken";
  static const String _idTokenKey = "idToken";

  String _accessToken;
  String _refreshToken;
  String _idToken;

  String get authorizationToken => _accessToken;

  factory AuthService() {
    return _instance;
  }

  AuthService._internal() {
    _secureStorage = new FlutterSecureStorage();
  }

  Future initialize() async {
    _accessToken = await _secureStorage.read(key: _accessTokenKey);
    if (_accessToken != null) {
      _refreshToken = await _secureStorage.read(key: _refreshTokenKey);
      _idToken = await _secureStorage.read(key: _idTokenKey);
    }
  }

  bool isLoggedIn() {
    return _accessToken != null;
  }

  Future<String> authenticate() async {
    try {
      var result = await _appAuth.authorizeAndExchangeCode(
        AuthorizationTokenRequest(clientId, redirectUri,
            discoveryUrl: disco, scopes: theScopes, loginHint: 'bob'),
      );
      _handleTokenResponse(result);

      return _accessToken;
    } on PlatformException catch (e) {
      throw e;
    }
  }

  Future<UserInfo> getUserInfo() {
    final apiService = ApiService();
    return apiService.httpGet(
        'https://fishtalk-auth-dev.azurewebsites.net/connect/userinfo', (data) {
      final parsedJson = json.decode(data);
      print(parsedJson);
      return UserInfo.fromJson(parsedJson);
    });
  }

  Future<String> refreshAccessToken() async {
    var result = await _appAuth.token(TokenRequest(clientId, redirectUri,
        discoveryUrl: disco, refreshToken: _refreshToken, scopes: theScopes));
    _handleTokenResponse(result);
    return _accessToken;
  }

  Future _handleTokenResponse(response) async {
    _accessToken = response.accessToken;
    _refreshToken = response.refreshToken;
    _idToken = response.idToken;
    await _secureStorage.write(key: _accessTokenKey, value: _accessToken);
    await _secureStorage.write(key: _refreshTokenKey, value: _refreshToken);
    await _secureStorage.write(key: _idTokenKey, value: _idToken);
  }

  Future<void> deleteEverything() async {
    await _secureStorage.deleteAll();
    _accessToken = '';
    _refreshToken = '';
    _idToken = '';
  }

  bool hasToken() {
    return _accessToken != null;
  }
}

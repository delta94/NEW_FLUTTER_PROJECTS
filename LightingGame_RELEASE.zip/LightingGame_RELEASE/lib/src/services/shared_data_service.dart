import 'dart:convert';
import 'dart:ui';

import 'package:Commons/dropdown.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/database/app_config_db_repository.dart';
import 'package:control_app/src/models/base/base_cause.dart';
import 'package:control_app/src/models/contact.dart';
import 'package:control_app/src/models/environment/sensor.dart';
import 'package:control_app/src/models/environment/sensor_type.dart';
import 'package:control_app/src/models/feeding/feed_store.dart';
import 'package:control_app/src/models/feeding/feed_type.dart';
import 'package:control_app/src/models/lice/lice_type.dart';
import 'package:control_app/src/models/lice/sedation_method.dart';
import 'package:control_app/src/models/species.dart';
import 'package:control_app/src/models/tenantInfo.dart';

import 'api_service.dart';

class SharedDataService {
  final ApiService _apiService = ApiService();
  Future<TenantInfo> fetchTenantInfo() async {
    try {
      return await _apiService.httpGet('${ApiService.urlRoot}/tenants/info/',
          (data) async {
        await AppConfigDBRepository.saveAppConfig(
            AppConfigKeys.tenantInfo, data);
        return tenantInfoFromJson(data);
      });
    } catch (e) {
      print('got exception');
      print(e);
      return null;
    }
  }

  Future<TenantInfo> loadTenantInfoFromDB() async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.tenantInfo);
    if (data != null) {
      return tenantInfoFromJson(data.jsonData);
    } else {
      return null;
    }
  }

  Future<Map<String, List<BaseCause>>> fetchAllCauses(CauseType type) async {
    var endpointName =
        type == CauseType.Mortality ? "mortalityCause" : "cullingCause";
    var key = type == CauseType.Mortality
        ? AppConfigKeys.mortalityCauses
        : AppConfigKeys.cullingCauses;
    return await _apiService
        .httpGet('${ApiService.urlRoot}/lists/$endpointName', (data) async {
      await AppConfigDBRepository.saveAppConfig(key, data);
      return _parseCauseJsonData(data);
    });
  }

  Future<Map<String, List<BaseCause>>> loadCausesFromDB(CauseType type) async {
    final data = await AppConfigDBRepository.getAppConfig(
        type == CauseType.Mortality
            ? AppConfigKeys.mortalityCauses
            : AppConfigKeys.cullingCauses);

    if (data == null) {
      return Map<String, List<BaseCause>>();
    }

    return _parseCauseJsonData(data.jsonData);
  }

  Map<String, List<BaseCause>> _parseCauseJsonData(jsonData) {
    if (jsonData == null) {
      return Map<String, List<BaseCause>>();
    }

    final parsedJson = json.decode(jsonData);

    List<Locale> supportedLocales = S.delegate.supportedLocales;

    Map<String, List<BaseCause>> map = new Map.fromIterable(supportedLocales,
        key: (item) => item.languageCode,
        value: (item) => new List<BaseCause>());

    map["?"] = new List<BaseCause>();

    parsedJson.forEach((item) {
      int causeId = item["itemId"];
      var texts = item["texts"];
      bool wrasse = item["wrasse"];

      texts.forEach((text) {
        var code = _getLanguageCode(text["lang"]); 

        if (map.containsKey(code)) {
          var cause = new BaseCause(
              causeId: causeId, name: text["text"], wrasse: wrasse);
          map[code].add(cause);
        }
      });
    });

    return map;
  }

  Future<Map<String, List<Species>>> fetchAllSpecies() async {
    return await _apiService.httpGet('${ApiService.urlRoot}/lists/species',
        (data) async {
      if (data != null) {
        await AppConfigDBRepository.saveAppConfig(AppConfigKeys.species, data);
      }
      var map = _parseSpeciesJsonData(data);
      return map;
    });
  }
  
  Future<List<Sensor>> fetchAllSensors() async {
    return await _apiService.httpGet('${ApiService.urlRoot}/control/sensors',
        (data) async {
      if (data != null) {
        await AppConfigDBRepository.saveAppConfig(AppConfigKeys.sensors, data);
      }
      var map = _parseSensorsJsonData(data);
      return map;
    });
  }

  Future<Map<String, List<SensorType>>> fetchAllSensorTypes() async {
    return await _apiService.httpGet('${ApiService.urlRoot}/lists/SensorType',
        (data) async {
      if (data != null) {
        await AppConfigDBRepository.saveAppConfig(AppConfigKeys.sensorTypes, data);
      }
      var map = _parseSensorTypesJsonData(data);
      return map;
    });
  }

  
  Future<List<Contact>> fetchSampleTakers() async {
    return await _apiService.httpGet('${ApiService.urlRoot}/contacts/?contactType=18',
        (data) async {
      if (data != null) {
        await AppConfigDBRepository.saveAppConfig(AppConfigKeys.sampleTaker, data);
        return contactFromMap(data);
      }
      
      return List<Contact>();
    });
  }

  Future<Map<String, List<LiceType>>> fetchLiceTypes() async {
    return await _apiService.httpGet('${ApiService.urlRoot}/lists/SampleParameter',
        (data) async {
      if (data != null) {
        await AppConfigDBRepository.saveAppConfig(AppConfigKeys.liceType, data);
      }
      var map = _parseLiceTypeJsonData(data);
      return map;
    });
  }
  
  Future<List<SedationMethod>> fetchSedationMethods() async {
    return await _apiService.httpGet('${ApiService.urlRoot}/lists/medicament',
        (data) async {
      if (data != null) {
        
        var sedationMethods = sedationMethodFromMap(data).where((element) => element.medicamentCategoryId == 1).toList();
        
        var sedationMethodsJson = sedationMethodToMap(sedationMethods);
        
        await AppConfigDBRepository.saveAppConfig(AppConfigKeys.medicament, sedationMethodsJson);
        
        return sedationMethods;
      } else {
        return List<SedationMethod>();
      }
    });
  }

  Future<Map<String, List<Species>>> loadAllSpeciesFromDB() async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.species);
    if (data != null) {
      return _parseSpeciesJsonData(data.jsonData);
    } else {
      return Map<String, List<Species>>();
    }
  }

  Future<List<Sensor>> loadAllSensorsFromDB() async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.sensors);
    if (data != null) {
      return _parseSensorsJsonData(data.jsonData);
    } else {
      return List<Sensor>();
    }
  }

  Future<Map<String, List<SensorType>>> loadAllSensorTypesFromDB() async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.sensorTypes);
    if (data != null) {
      return _parseSensorTypesJsonData(data.jsonData);
    } else {
      return Map<String, List<SensorType>>();
    }
  }

  Future<List<Contact>> loadSampleTakers() async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.sampleTaker);
    if (data != null) {
      return contactFromMap(data.jsonData);
    } else {
      return [];
    }
  }

  Future<Map<String, List<LiceType>>> loadLiceTypes() async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.liceType);
    if (data != null) {
      return _parseLiceTypeJsonData(data.jsonData);
    } else {
      return Map<String, List<LiceType>>();
    }
  }

  Future<List<SedationMethod>> loadSedationMethods() async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.medicament);
    if (data != null) {
      return sedationMethodFromMap(data.jsonData);
    } else {
      return List<SedationMethod>();
    }
  }

  Map<String, List<Species>> _parseSpeciesJsonData(String jsonData) {
    if (jsonData == null) {
      return Map<String, List<Species>>();
    }

    final parsedJson = json.decode(jsonData);

    List<Locale> supportedLocales = S.delegate.supportedLocales;

    Map<String, List<Species>> map = new Map.fromIterable(supportedLocales,
        key: (item) => item.languageCode, value: (item) => new List<Species>());

    map["?"] = new List<Species>();

    parsedJson.forEach((item) {
      int causeId = item["itemId"];
      var texts = item["texts"];
      bool wrasse = item["wrasse"];

      texts.forEach((text) {
        var code = _getLanguageCode(text["lang"]); 

        if (map.containsKey(code)) {
          Species cause =
              Species(speciesId: causeId, name: text["text"], wrasse: wrasse);
          map[code].add(cause);
        }
      });
    });

    return map;
  }

  List<Sensor> _parseSensorsJsonData(String jsonData) {
    if (jsonData == null) {
      return List<Sensor>();
    }

    var sensors = sensorsFromMap(jsonData);
   
    return sensors;
  }

  Map<String, List<SensorType>> _parseSensorTypesJsonData(String jsonData) {
    if (jsonData == null) {
      return Map<String, List<SensorType>>();
    }

    final parsedJson = json.decode(jsonData);

    List<Locale> supportedLocales = S.delegate.supportedLocales;

    Map<String, List<SensorType>> map = new Map.fromIterable(supportedLocales,
        key: (item) => item.languageCode, value: (item) => new List<SensorType>());

    map["?"] = new List<SensorType>();

    parsedJson.forEach((item) {
      int itemId = item["itemId"];
      var texts = item["texts"];

      Map<String, dynamic> temp = item["valueMap"];
      int measUnit = item["measUnit"];
      
      texts.forEach((text) {
        var code = _getLanguageCode(text["lang"]);

        if (map.containsKey(code)) {
          
          Map<int, dynamic> valueMap;

          if(measUnit == MeasurementUnit.ValueMap) {
            valueMap = new Map<int, String>();  

            temp.forEach((key, value) { 
              value.forEach((x) {
                if(_getLanguageCode(x['lang']) == code) {
                  int intKey = int.tryParse(key);
                  valueMap[intKey] = x['text'];
                }
              });
            });      
          }   

          SensorType cause =
              SensorType(itemId: itemId, name: text["text"], measUnit: measUnit, valueMapTypeName: item["valueMapTypeName"], valueMap: valueMap);
          map[code].add(cause);
        }
      });

    });

    return map;
  }

  // get language code from full code, ex: en-GB => en, nb-NO => nb
  String _getLanguageCode(String fullCode) {
    var code;
    
    if (fullCode == "?") {
      code = "?";
    } else if (fullCode.length > 2) {
      code = fullCode.substring(0, 2);
    }

    return code;
  }

  Map<String, List<LiceType>> _parseLiceTypeJsonData(String jsonData) {
    if (jsonData == null) {
      return Map<String, List<LiceType>>();
    }

    final parsedJson = json.decode(jsonData);

    List<Locale> supportedLocales = S.delegate.supportedLocales;

    Map<String, List<LiceType>> map = new Map.fromIterable(supportedLocales,
        key: (item) => item.languageCode, value: (item) => new List<LiceType>());

    map["?"] = new List<LiceType>();

    parsedJson.forEach((item) {
      int sampleParameterCategoryId = item["sampleParameterCategoryId"];
      int itemId = item["itemId"];

      if(sampleParameterCategoryId == 2 && itemId >= 202 && itemId <= 232) {
        var texts = item["texts"];
        texts.forEach((text) {
          var code = _getLanguageCode(text["lang"]); 

          if (map.containsKey(code)) {
            map[code].add(LiceType(itemId: itemId, name: text["text"], sampleParameterCategoryId: sampleParameterCategoryId));
          }
        });
      }
    });

    return map;
  }

  Future<Map<String, List<OptionItem>>> fetchMissedReasons(
      String reasonType) async {
    return await _apiService.httpGet('${ApiService.urlRoot}/lists/$reasonType',
        (data) async {
      await AppConfigDBRepository.saveAppConfig(reasonType, data);
      return _parseMissedReasonsJsonData(data);
    });
  }

  Future<Map<String, List<OptionItem>>> loadMissedReasonsFromDB(
      String reasonType) async {
    final data = await AppConfigDBRepository.getAppConfig(reasonType);
    if (data != null) {
      return _parseMissedReasonsJsonData(data.jsonData);
    } else {
      return Map<String, List<OptionItem>>();
    }
  }

  Map<String, List<OptionItem>> _parseMissedReasonsJsonData(String jsonData) {
    if (jsonData == null) {
      return Map<String, List<OptionItem>>();
    }

    final parsedJson = json.decode(jsonData);

    List<Locale> supportedLocales = S.delegate.supportedLocales;

    Map<String, List<OptionItem>> map = new Map.fromIterable(supportedLocales,
        key: (item) => item.languageCode,
        value: (item) => new List<OptionItem>());

    map["?"] = new List<OptionItem>();

    parsedJson.forEach((item) {
      int causeId = item["itemId"];
      var texts = item["texts"];

      texts.forEach((text) {
        var code = _getLanguageCode(text["lang"]);

        if (map.containsKey(code)) {
          OptionItem cause = OptionItem(id: causeId, label: text["text"]);
          map[code].add(cause);
        }
      });
    });

    return map;
  }

  Future<Map<int, FeedType>> fetchFeedTypes() async {
    return await _apiService.httpGet('${ApiService.urlRoot}/lists/feedType',
        (data) async {
      await AppConfigDBRepository.saveAppConfig(AppConfigKeys.feedTypes, data);

      final Map<int, FeedType> feedTypeMap = {};

      if (data != null) {
        List<FeedType>.from(jsonDecode(data).map((x) => FeedType.fromMap(x)))
            .forEach((x) {
          feedTypeMap[x.itemId] = x;
        });
      }

      return feedTypeMap;
    });
  }

  Future<Map<int, FeedType>> loadFeedTypesFromDB() async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.feedTypes);

    final Map<int, FeedType> feedTypeMap = {};

    if (data != null) {
      List<FeedType>.from(
              jsonDecode(data.jsonData).map((x) => FeedType.fromMap(x)))
          .forEach((x) => feedTypeMap[x.itemId] = x);
    }

    return feedTypeMap;
  }

  Future<Map<String, FeedStore>> fetchFeedStores() async {
    return await _apiService.httpGet('${ApiService.urlRoot}/control/feedStore',
        (data) async {
      await AppConfigDBRepository.saveAppConfig(AppConfigKeys.feedStores, data);

      final Map<String, FeedStore> feedStores = {};

      if (data != null) {
        List<FeedStore>.from(jsonDecode(data).map((x) => FeedStore.fromMap(x)))
            .forEach((x) {
          feedStores[x.id] = x;
        });
      }

      return feedStores;
    });
  }

  Future<Map<String, FeedStore>> loadFeedStoresFromDB() async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.feedStores);

    final Map<String, FeedStore> feedStores = {};

    if (data != null) {
      List<FeedStore>.from(
              jsonDecode(data.jsonData).map((x) => FeedStore.fromMap(x)))
          .forEach((x) {
        feedStores[x.id] = x;
      });
    }

    return feedStores;
  }
}

import 'package:flutter/material.dart';

enum EditModeEnum { ADD, EDIT, DELETE }

enum SavingStatusEnum { NOT_SAVE, SAVING, SAVED }

class BaseViewModel extends ChangeNotifier {
  bool _busy = false;
  bool get busy => _busy;
  void setBusy(bool value, {bool notify = true}) {
    _busy = value;
    if (notify) notifyListeners();
  }
}

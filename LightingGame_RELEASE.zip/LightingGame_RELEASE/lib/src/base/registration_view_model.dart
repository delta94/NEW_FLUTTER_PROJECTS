import 'dart:async';

import 'package:control_app/src/base/base_view_model.dart';
import 'package:control_app/src/models/feeding/feeding_registration.dart';
import 'package:control_app/src/models/mortality/mortality_registration.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/registration_factory.dart';
import 'package:control_app/src/models/registration_wrasse.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/organization/organizationListener.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/services/timezone_service.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:control_app/src/util/utils.dart';
import 'package:flutter/material.dart';
import '../app_model.dart';
import '../organization/organization_model.dart';

class RegistrationViewModel extends BaseViewModel implements OrganizationEventListener{
  /// Flag to determine whether current fish model is Salmon or Cleaner Fish
  final bool isForSalmon;
  final RegistrationType registrationType;
  OrganizationModel _organizationModel;

  RegistrationViewModel(this.isForSalmon, this.registrationType) {
    _dbRepos = new DBRegistrationRepository(registrationType);
    this._organizationModel = OrganizationModel();
    this._organizationModel.addEventListener(this);
    if(this._organizationModel.currentUnit != null){
      this.initRegistrationInfo();
    }
  }

  AppModel _appModel;
  StreamSubscription<RegistrationType> _syncSubscription;
  DBRegistrationRepository _dbRepos;

  List<Registration> _registrations = List<Registration>();
  AppModel get appModel => _appModel;
  OrganizationModel get organizationModel => _organizationModel;

  bool isEditingCountMode = false;
  RegistrationStatus status = RegistrationStatus.HAVE_REGISTRATION;
  EditModeEnum editMode = EditModeEnum.ADD;
  List<Registration> get registrations => _registrations;

  /// When user adds new regisration, this property will be
  /// initialized. For Salmon, it will be only one Registration
  /// while for Cleaner Fish, it can be multiple new registrations
  /// depend on which cleaner fish user chooses.
  /// After adding new counts and save, this property will be
  /// added into [registrations] property
  List<Registration> _newRegistrations = List<Registration>();
  List<Registration> get newRegistrations => _newRegistrations;
  Map<DateTime, List<Registration>> viewRegistrationMap =
      new Map<DateTime, List<Registration>>();

  /// Properties for de letion
  DateTime deletedTime;
  dynamic deletedCountObj;
  int deletedSpeciesId;

  /// Get flag to identify whether input data for registration is valid or not
  /// Usually used for Edit mode on registration screen and add new registration
  bool get isValidData => _validateData();

  _validateData() {
    bool validData = true;
    if (_registrations.isNotEmpty) {
      validData =
          !_registrations.any((registration) => !registration.item.isValidData);
    }
    return validData;
  }

  /// ========================================================================
  /// public functions
  /// ========================================================================

  initRegistrationInfo() async {
    UiUtils.initFlareSpinWidget();
    if (isEditingCountMode) {
      discardChanges();
    }

    _clearRegistrationChanges();
    await fetchRegistrations();
  }

  @protected
  Future fetchRegistrations() async {
    var tmpRegistrations =
        await _dbRepos.fetchByUnit(_organizationModel.currentUnit);
    _registrations = tmpRegistrations
        .where((registration) => isForSalmon
            ? (registration.speciesId == 1 || registration.speciesId == null)
            : registration.speciesId != 1)
        .toList();

    _registrations.sort((a, b) => a.time.compareTo(b.time));
    checkRegistration();
    createViewRegistrations();
    notifyListeners();
  }

  setEditingCountMode(bool editing, {bool shouldNotify = true}) {
    isEditingCountMode = editing;

    if (!isEditingCountMode) {
      _clearRegistrationChanges();
      editMode = EditModeEnum.ADD;
    }

    if (shouldNotify) notifyListeners();
  }

  setEditMode(EditModeEnum editMode) {
    this.editMode = editMode;

    if (this.editMode == EditModeEnum.EDIT) {
      this.isEditingCountMode = true;
    }

    notifyListeners();
  }

  reloadData(type) async {
    if (!isEditingCountMode && type == registrationType) {
      await fetchRegistrations();
      createViewRegistrations();
      print("Reloaded registration from DB successfully");
      notifyListeners();
    }
  }

  updateModel(AppModel appModel, OrganizationModel organizationModel) async {
    if (_appModel != appModel) {
      _appModel = appModel;
      if (_syncSubscription != null) {
        await _syncSubscription.cancel();
      }
      if (_appModel.synchronizeManager != null) {
        _syncSubscription =
            _appModel.synchronizeManager.syncStream.listen(reloadData);
      }
    }

    if (_organizationModel != organizationModel) {
      _organizationModel = organizationModel;
    }
  }

  /// Confirm reason with a [reasonId] of not checking mortlity or missed feeding for today check/feed
  ///
  /// * The function will create an empty registration with flag [missedFeedingReasonId] is assigned to [reasonId]
  /// * Note: the function only apply for Salmon
  confirmMissedReason(int reasonId) async {
    if (busy) return;
    setBusy(true);

    try {
      /// Missed reason is only support for mortality & feeding module
      int missedReasonId = checkConfirmedMissedReason();
      if (missedReasonId == -1) {
        if (isForSalmon) {
          /// For mortality only, need to check whether registration for checked and not found mortality was
          /// available. If it was then just update it to be missed reason check. Otherwise then create new
          /// registration and set it to be misssed reason check.
          if (registrationType == RegistrationType.Mortality) {
            var registration = registrations.firstWhere(
                (registration) =>
                    registration.item.isEmpty &&
                    (registration.item as MortalityRegistration)
                            .missedMortalityReasonId ==
                        -1 &&
                    registration.changeStatus != ChangeStatus.Deleted,
                orElse: () => null);
            if (registration != null) {
              (registration.item as MortalityRegistration)
                  .missedMortalityReasonId = reasonId;
              if (registration.changeStatus != ChangeStatus.New) {
                registration.changeStatus = ChangeStatus.Changed;
              }
            } else {
              var registration = await addNewRegistration(1);
              (registration.item as MortalityRegistration)
                  .missedMortalityReasonId = reasonId;
              _registrations.add(registration);
            }
            await saveChanges(keepEmpty: true, notify: false);
            await fetchRegistrations();
          } else {
            var registration = await addNewRegistration(1);
            if (registration.item is FeedingRegistration) {
              (registration.item as FeedingRegistration).missedFeedingReasonId =
                  reasonId;
            }
            _registrations.add(registration);
            await saveChanges(keepEmpty: true, notify: false);
            await fetchRegistrations();
          }
        }
      } else {
        await updateMissedReason(reasonId);
      }

      status = RegistrationStatus.MISSED_REGISTRATION;
    } catch (e) {} finally {
      setBusy(false);
    }
  }

  /// Revert the confirm missed reason (in [confirmMissedReason])
  revertMissedReason() async {
    int missedReasonId = checkConfirmedMissedReason();
    bool confirmed = missedReasonId != -1;
    if (confirmed) {
      _registrations.forEach((registration) {
        if (registration.item is FeedingRegistration) {
          var item = (registration.item as FeedingRegistration);
          if (item.missedFeedingReasonId != -1) {
            registration.changeStatus = ChangeStatus.Deleted;
          }
        } else if (registration.item is MortalityRegistration) {
          var item = (registration.item as MortalityRegistration);
          if (item.missedMortalityReasonId != -1) {
            registration.changeStatus = ChangeStatus.Deleted;
          }
        }
      });

      status = RegistrationStatus.NO_REGISTRATION;
      await saveChanges(keepEmpty: true);
      await fetchRegistrations();
    }
  }

  /// Update missed reason feeding/mortality when user change the reason on UI
  ///
  /// * The function will update missedFeedingReasonId/missedMortalityReasonId to [reasonId]
  /// value for the existing empty registration
  updateMissedReason(int reasonId) async {
    int missedReasonId = checkConfirmedMissedReason();
    if (missedReasonId != -1 && missedReasonId != reasonId) {
      _registrations.forEach((registration) {
        if (registration.item is FeedingRegistration) {
          var item = (registration.item as FeedingRegistration);
          item.missedFeedingReasonId = reasonId;
          if (registration.changeStatus != ChangeStatus.New) {
            registration.changeStatus = ChangeStatus.Changed;
          }
        } else if (registration.item is MortalityRegistration) {
          var item = (registration.item as MortalityRegistration);
          item.missedMortalityReasonId = reasonId;
          if (registration.changeStatus != ChangeStatus.New) {
            registration.changeStatus = ChangeStatus.Changed;
          }
        }
      });
      await saveChanges(keepEmpty: true, notify: false);
      await fetchRegistrations();
    }
  }

  /// Check whether today's registration was already confirmed missed reason of checking mortality/feeding
  int checkConfirmedMissedReason() {
    Registration feedingRegistration = _registrations.firstWhere(
        (registration) =>
            ((registration.item is FeedingRegistration &&
                    (registration.item as FeedingRegistration)
                            .missedFeedingReasonId !=
                        -1) ||
                (registration.item is MortalityRegistration &&
                    (registration.item as MortalityRegistration)
                            .missedMortalityReasonId !=
                        -1)) &&
            registration.changeStatus != ChangeStatus.Deleted,
        orElse: () => null);

    if (feedingRegistration != null) {
      if (feedingRegistration.item is FeedingRegistration) {
        return (feedingRegistration.item as FeedingRegistration)
            .missedFeedingReasonId;
      } else if (feedingRegistration.item is MortalityRegistration) {
        return (feedingRegistration.item as MortalityRegistration)
            .missedMortalityReasonId;
      }
    }

    return -1;
  }

  Future<Registration> addNewRegistration(int speciesId) async {
    var registration = Registration(
      speciesId: speciesId,
      siteId: _organizationModel.currentSite.id,
      unitId: _organizationModel.currentUnit.id,
      time: TimeZoneService.convertToTimezone(
          DateTime.now(), _organizationModel.currentSite.timeZoneId),
      item: RegistrationFactory.create(registrationType),
      changeStatus: ChangeStatus.New,
    );
    _newRegistrations.add(registration);
    return registration;
  }

  Future removeRegistration(DateTime time) async {
    setBusy(true);
    var registrations = _registrations
        .where((registration) => registration.time == time)
        .toList();

    if (registrations.isNotEmpty) {
      registrations.forEach((registration) {
        registration.changeStatus = ChangeStatus.Deleted;
      });

      // Save to local database
      await _dbRepos.saveChanges(registrations);
      _registrations.removeWhere(
          (registration) => registration.changeStatus == ChangeStatus.Deleted);
      await _appModel.synchronizeManager.syncByType(registrationType);
    }

    createViewRegistrations();
    checkRegistration();
    setBusy(false, notify: false);
    updateEditMode();
  }

  Future removeCount([DateTime time, int speciesId, dynamic countObj]) async {
    setBusy(true);
    var registration = _registrations.firstWhere(
        (reg) => reg.speciesId == speciesId && reg.time == time,
        orElse: () => null);
    if (registration != null) {
      // If the registration has only 1 count then it should be deleted
      if (registration.item.length == 1) {
        registration.changeStatus = ChangeStatus.Deleted;
        await _dbRepos.saveChanges([registration]);
        _registrations.remove(registration);
      } else {
        registration.item.removeItem(countObj);

        if (registration.changeStatus != ChangeStatus.New) {
          registration.changeStatus = ChangeStatus.Changed;
        }
        registration.clearTracking();
        await _dbRepos.update(registration);
      }

      await _appModel.synchronizeManager.syncByType(registrationType);
      createViewRegistrations();
      checkRegistration();
      setBusy(false, notify: false);
      updateEditMode();
    }
  }

  void updateAmountCountNumber(
      DateTime time, int speciesId, dynamic countObj, dynamic newValue) {
    try {
      var registration = _registrations
          .firstWhere((reg) => reg.speciesId == speciesId && reg.time == time);
      if (registration != null) {
        registration.item.updateItem(countObj, newValue);
        if (registration.item.hasChanged()) {
          if (registration.changeStatus != ChangeStatus.New) {
            registration.changeStatus = ChangeStatus.Changed;
          }
        } else {
          registration.undo();
        }
        updateEditMode();
      }
    } catch (e) {
      print(e.toString());
    }
  }

  void discardChanges({bool shouldNotify = true}) {
    _registrations.forEach((registration) => registration.rollback());
    checkRegistration();
    createViewRegistrations();
    setEditingCountMode(false, shouldNotify: shouldNotify);
  }

  void cancelRegistration() {
    _newRegistrations.clear();
    notifyListeners();
  }

  Future updateRegistrations() async {
    _clearRegistrationChanges();
    setBusy(true);
    try {
      await saveChanges(notify: false);
      await fetchRegistrations();
      _clearRegistrationChanges(); // this line is mandatory for environment.
      createViewRegistrations();
    } catch (e) {} finally {
      setBusy(false);
    }
  }

  Future storeRegistration() async {
    setBusy(true);
    try {
      _registrations.addAll(newRegistrations);
      await saveChanges();
      await fetchRegistrations();
    } catch (e) {} finally {
      setBusy(false);
    }
  }

  clearRegistrations() {
    newRegistrations.clear();
    createViewRegistrations();
  }

  Future saveChanges({notify = true, keepEmpty = false}) async {
    if (!keepEmpty) {
      //For registration that is empty count, we need to delete it
      _registrations.forEach((registration) {
        if (registration.item.isEmpty) {
          registration.changeStatus = ChangeStatus.Deleted;
        }
      });
    }

    if (_registrations.isNotEmpty) {
      await _dbRepos.saveChanges(_registrations);
      await _appModel.synchronizeManager.syncByType(registrationType);
    }

    checkRegistration();
    if (notify) {
      notifyListeners();
    }
  }

  getTotalAmountCount() {
    double totalCount = 0;
    var registrations = _registrations
        .where(
            (registration) => registration.changeStatus != ChangeStatus.Deleted)
        .toList();
    if (registrations != null && registrations.isNotEmpty) {
      totalCount = getRegistrationsTotalCount(registrations);
    }

    return totalCount;
  }

  getRegistrationsTotalCount(List<Registration> registrations) {
    double totalCount = 0;
    registrations.forEach((registration) {
      totalCount += registration.item.totalCount();
    });

    return totalCount;
  }

  createViewRegistrations() {
    viewRegistrationMap.clear();
    List<Registration> registrations = new List<Registration>();
    _registrations.forEach((registration) {
      if (registration.changeStatus != ChangeStatus.Deleted) {
        bool isNotEmpty = !registration.item.isEmpty;
        if (isNotEmpty) {
          registrations.add(registration);
        }
      }
    });
    if (registrations.isNotEmpty) {
      viewRegistrationMap = groupBy(registrations, (obj) => obj.time);
    }
  }

  List<RegistrationWrasse> filterByFishType(
      List<RegistrationWrasse> registrationWrasse, bool isSalmon) {
    return isSalmon
        ? registrationWrasse
            .where((x) => x.wrasse == null || x.wrasse == false)
            .toList()
        : registrationWrasse
            .where((x) => x.wrasse == null || x.wrasse == true)
            .toList();
  }

  /// ========================================================================
  /// private functions
  /// ========================================================================

  _clearRegistrationChanges() {
    this.checkRegistration();
    //status = RegistrationStatus.NO_REGISTRATION;
    isEditingCountMode = false;
    editMode = EditModeEnum.ADD;
  }

  updateEditMode() {
    bool changed = _registrations.any((registration) => registration.changed);
    if (changed) {
      if (editMode != EditModeEnum.EDIT) {
        setEditMode(EditModeEnum.EDIT);
      } else {
        notifyListeners();
      }
    } else {
      if (editMode != EditModeEnum.ADD) {
        setEditMode(EditModeEnum.ADD);
      } else {
        notifyListeners();
      }
    }
  }

  @protected
  checkRegistration() {
    bool haveFish = isForSalmon
        ? _organizationModel.speciesOfCurrentUnit
            .any((specie) => specie.speciesId == 1)
        : _organizationModel.speciesOfCurrentUnit
            .any((specie) => specie.speciesId != 1);
    status = haveFish
        ? RegistrationStatus.NO_REGISTRATION
        : RegistrationStatus.NO_FISH;
    bool haveRegistration = _registrations.any((registration) {
      if (registration.item is FeedingRegistration) {
        var item = (registration.item as FeedingRegistration);
        if (registration.item.isEmpty &&
            registration.changeStatus != ChangeStatus.Deleted &&
            item.missedFeedingReasonId != -1) {
          status = RegistrationStatus.MISSED_REGISTRATION;
        }
      } else if (registration.item is MortalityRegistration) {
        var item = (registration.item as MortalityRegistration);
        if (registration.item.isEmpty &&
            registration.changeStatus != ChangeStatus.Deleted) {
          if (item.missedMortalityReasonId != -1) {
            status = RegistrationStatus.MISSED_REGISTRATION;
          } else {
            status = RegistrationStatus.CONFIRMED_NO_REGISTRATION;
          }
        }
      }
      return !registration.item.isEmpty;
    });

    status = _getRegistrationStatus(status, haveFish, haveRegistration);
  }

  _getRegistrationStatus(
      RegistrationStatus status, bool haveFish, bool haveRegistration) {
    if (status == RegistrationStatus.CONFIRMED_NO_REGISTRATION ||
        status == RegistrationStatus.MISSED_REGISTRATION) return status;
    if (haveFish) {
      if (haveRegistration) {
        return RegistrationStatus.HAVE_REGISTRATION;
      } else {
        return RegistrationStatus.NO_REGISTRATION;
      }
    } else {
      return RegistrationStatus.NO_FISH;
    }
  }

  @override
  void organizationEntityChanged(OrganizationEntity newEntity) {
    if(newEntity is Unit){
      this.initRegistrationInfo();
    }
  }
}

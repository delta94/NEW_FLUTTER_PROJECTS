import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/culling/view_models/cleaner_fish_culling_registration_view_model.dart';
import 'package:control_app/src/culling/view_models/salmon_culling_registration_view_model.dart';
import 'package:control_app/src/environment/view_models/environment_view_model.dart';
import 'package:control_app/src/feeding/view_models/cleaner_fish_feeding_registration_view_model.dart';
import 'package:control_app/src/feeding/view_models/salmon_feeding_registration_view_model.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/mortality/view_models/cleaner_fish_mortality_registration_view_model.dart';
import 'package:control_app/src/mortality/view_models/salmon_mortality_registration_view_model.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class RegistrationViewModelFactory {
  static RegistrationViewModel create(
      BuildContext context, RegistrationType type,
      {bool isForSalmon, listen = true}) {
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    bool isLandbased = appModel.appMode == AppMode.Landbased;
    RegistrationViewModel model;
    switch (type) {
      case RegistrationType.Mortality:
        model = isForSalmon
            ? Provider.of<SalmonMortalityRegistrationViewModel>(context,
                listen: listen)
            : isLandbased
                ? null
                : Provider.of<CleanerFishMortalityRegistrationViewModel>(
                    context,
                    listen: listen);
        break;
      case RegistrationType.Feeding:
        model = isForSalmon
            ? Provider.of<SalmonFeedingRegistrationViewModel>(context,
                listen: listen)
            : isLandbased
                ? null
                : Provider.of<CleanerFishFeedingRegistrationViewModel>(context,
                    listen: listen);
        break;
      case RegistrationType.Culling:
        model = isForSalmon
            ? Provider.of<SalmonCullingRegistrationViewModel>(context,
                listen: listen)
            : isLandbased
                ? null
                : Provider.of<CleanerFishCullingRegistrationViewModel>(context,
                    listen: listen);
        break;
      case RegistrationType.Environment:
        model = Provider.of<EnvironmentViewModel>(context, listen: listen);
        break;
      default:
        model = null;
        break;
    }

    return model;
  }
}

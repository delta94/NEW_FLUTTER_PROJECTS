import 'package:Commons/dropdown.dart';
import 'package:control_app/src/database/app_config_db_repository.dart';
import 'package:control_app/src/models/base/base_cause.dart';
import 'package:control_app/src/models/environment/sensor_type.dart';
import 'package:control_app/src/models/feeding/feed_type.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/services/shared_data_service.dart';
import 'package:data_connection_checker/data_connection_checker.dart';

import 'app_model.dart';
import 'base/base_view_model.dart';
import 'models/contact.dart';
import 'models/environment/sensor.dart';
import 'models/feeding/feed_store.dart';
import 'models/lice/lice_type.dart';
import 'models/lice/sedation_method.dart';
import 'models/species.dart';
import 'models/tenantInfo.dart';

class SharedDataModel extends BaseViewModel {
  AppModel _appModel;
  TenantInfo _tenantInfo;
  static Map<String, List<BaseCause>> _causesOfDealth;
  static Map<String, List<Species>> _species;
  static List<Sensor> _sensors;
  static Map<String, List<SensorType>> _sensorTypes;
  static Map<String, List<LiceType>> _liceTypes;
  static List<Contact> _sampleTakers;
  static List<SedationMethod> _sedationMethods;
  static Map<String, List<OptionItem>> _missedFeedingReason;
  static Map<String, List<OptionItem>> _missedMortalityReason;
  static Map<int, FeedType> _feedTypes;
  static Map<String, FeedStore> _feedStores;
  static Map<String, List<BaseCause>> _cullingCauses;
  final SharedDataService _sharedDataService = SharedDataService();
  TenantInfo get tenantInfo => _tenantInfo;
  Map<String, List<Species>> get species => _species;
  List<BaseCause> get causesOfDeath => _getCauses(CauseType.Mortality);
  List<OptionItem> get missedFeedingReason =>
      _getMissedReason(AppConfigKeys.missedFeedingReason);
  List<OptionItem> get missedMortalityReason =>
      _getMissedReason(AppConfigKeys.missedMortalityReason);
  Map<int, FeedType> get feedTypes => _feedTypes;
  Map<String, FeedStore> get feedStores => _feedStores;
  List<BaseCause> get cullingCauses => _getCauses(CauseType.Culling);
  List<SedationMethod> get sedationMethods => _sedationMethods;
  List<LiceType> get liceTypes => _getLiceTypes();
  List<Contact> get sampleTakers => _sampleTakers;
  List<Sensor> get sensors => _sensors;
  List<Sensor> get manualActiveSensors => _getManualActiveSensors();
  List<SensorType> get sensorTypes => _getSensorTypes();

  /// Flag to determine current tab active is Salmon (true) or Cleaner Fish (false) in registration screen
  bool isSalmonTabActive = true;
  setTabActive({bool isSalmon}) {
    isSalmonTabActive = isSalmon;
    notifyListeners();
  }

  Future initData(OrganizationModel orgModel) async {
    try {
      var futures = <Future>[];

      /// Init tenant info

      futures.add(_initTenant());
      // Init mortality causes
      futures.add(_initCauses(CauseType.Mortality));
      // Init species
      futures.add(_initSpecies());
      // Init sample takers
      futures.add(_initSampleTakers());
      // Init Lice types
      futures.add(_initLiceType());
      // Init sedation methods
      futures.add(_initSedationMethods());
      // Init missed feeding reasons
      futures.add(_initMissedReasons(AppConfigKeys.missedFeedingReason));
      // Init missed mortality reasons
      futures.add(_initMissedReasons(AppConfigKeys.missedMortalityReason));
      // Init feed types
      futures.add(_initFeedTypes());
      // Init feed stores
      futures.add(_initFeedStores());
      // Init culling cause
      futures.add(_initCauses(CauseType.Culling));
      // Init Sensors
      futures.add(_initSensors());
      // Init Sensor Types
      futures.add(_initSensorTypes());
      //Init organization model
      futures.add(orgModel.initializeData());
      await Future.wait(futures);
    } catch (e) {
      print('Error=========================: $e');
    } finally {
      notifyListeners();
    }
  }

  void resetData() {
    _species = null;
    _causesOfDealth = null;
  }

  updateAppModel(AppModel model) {
    if (model != null && _appModel != model) {
      _appModel = model;
    }
  }

  fetchIfConnected(Function function) {
    if (_appModel.connectionStatus == DataConnectionStatus.connected) {
      function();
    }
  }

  Future _initTenant() async {
    _tenantInfo = await _sharedDataService.loadTenantInfoFromDB();
    if (_tenantInfo == null) {
      await _fetchTenantInfo();
    } else {
      fetchIfConnected(_fetchTenantInfo);
    }
  }

  Future _initCauses(CauseType type) async {
    var causes = await _sharedDataService.loadCausesFromDB(type);
    if (type == CauseType.Mortality) {
      _causesOfDealth = causes;
    } else {
      _cullingCauses = causes;
    }
    if (causes == null) {
      await _fetchAllCauses(type);
    } else {
      fetchIfConnected(() => _fetchAllCauses(type));
    }
  }

  Future _initSpecies() async {
    _species = await _sharedDataService.loadAllSpeciesFromDB();
    if (_species == null) {
      await _fetchAllSpecies();
    } else {
      fetchIfConnected(_fetchAllSpecies);
    }
  }

  Future _initSensors() async {
    _sensors = await _sharedDataService.loadAllSensorsFromDB();
    if (_sensors == null) {
      await _fetchAllSensors();
    } else {
      fetchIfConnected(_fetchAllSensors);
    }
  }

  Future _initSensorTypes() async {
    _sensorTypes = await _sharedDataService.loadAllSensorTypesFromDB();
    if (_sensorTypes == null) {
      await _fetchAllSensorTypes();
    } else {
      fetchIfConnected(_fetchAllSensorTypes);
    }
  }

  Future _initSampleTakers() async {
    _sampleTakers = await _sharedDataService.loadSampleTakers();
    if (_sampleTakers == null) {
      await _fetchSampleTakers();
    } else {
      fetchIfConnected(_fetchSampleTakers);
    }
  }

  Future _initLiceType() async {
    _liceTypes = await _sharedDataService.loadLiceTypes();
    if (_liceTypes == null) {
      await _fetchLiceTypes();
    } else {
      fetchIfConnected(_fetchLiceTypes);
    }
  }

  Future _initSedationMethods() async {
    _sedationMethods = await _sharedDataService.loadSedationMethods();
    if (_sedationMethods == null) {
      await _fetchSedationMethods();
    } else {
      fetchIfConnected(_fetchSedationMethods);
    }
  }

  Future _initMissedReasons(String reasonType) async {
    var missedReason =
        await _sharedDataService.loadMissedReasonsFromDB(reasonType);
    if (reasonType == AppConfigKeys.missedFeedingReason) {
      _missedFeedingReason = missedReason;
    } else {
      _missedMortalityReason = missedReason;
    }
    if (missedReason == null) {
      await _fetchMissedReasons(reasonType);
    } else {
      fetchIfConnected(() => _fetchMissedReasons(reasonType));
    }
  }

  Future _initFeedTypes() async {
    _feedTypes = await _sharedDataService.loadFeedTypesFromDB();
    if (_feedTypes == null) {
      await _fetchFeedTypes();
    } else {
      fetchIfConnected(_fetchFeedTypes);
    }
  }

  Future _initFeedStores() async {
    _feedStores = await _sharedDataService.loadFeedStoresFromDB();
    if (_feedStores == null) {
      await _fetchFeedStores();
    } else {
      fetchIfConnected(_fetchFeedStores);
    }
  }

  Future _fetchTenantInfo() async {
    _tenantInfo = await _sharedDataService.fetchTenantInfo();
  }

  Future _fetchAllCauses(CauseType type) async {
    var causes = await _sharedDataService.fetchAllCauses(type);
    if (type == CauseType.Mortality) {
      _causesOfDealth = causes;
    } else {
      _cullingCauses = causes;
    }
  }

  Future _fetchAllSpecies() async {
    _species = await _sharedDataService.fetchAllSpecies();
  }

  Future _fetchAllSensors() async {
    _sensors = await _sharedDataService.fetchAllSensors();
  }

  Future _fetchAllSensorTypes() async {
    _sensorTypes = await _sharedDataService.fetchAllSensorTypes();
  }

  Future _fetchSampleTakers() async {
    _sampleTakers = await _sharedDataService.fetchSampleTakers();
  }

  Future _fetchLiceTypes() async {
    _liceTypes = await _sharedDataService.fetchLiceTypes();
  }

  Future _fetchSedationMethods() async {
    _sedationMethods = await _sharedDataService.fetchSedationMethods();
  }

  Future _fetchMissedReasons(String reasonType) async {
    var missedReason = await _sharedDataService.fetchMissedReasons(reasonType);
    if (reasonType == AppConfigKeys.missedFeedingReason) {
      _missedFeedingReason = missedReason;
    } else {
      _missedMortalityReason = missedReason;
    }
  }

  Future _fetchFeedTypes() async {
    _feedTypes = await _sharedDataService.fetchFeedTypes();
  }

  Future _fetchFeedStores() async {
    _feedStores = await _sharedDataService.fetchFeedStores();
  }

  List<BaseCause> _getCauses(CauseType type) {
    var languageCode = _appModel.currentLocale.languageCode;
    var causes;
    if (type == CauseType.Mortality) {
      causes = _causesOfDealth;
    } else {
      causes = _cullingCauses;
    }
    if (causes.containsKey(languageCode)) {
      List<BaseCause> result = causes[languageCode];

      var ids = result.map((f) => f.causeId).toList();

      var notExistedIds = causes["?"].where((x) => !ids.contains(x.causeId));

      if (notExistedIds.length > 0) {
        result.addAll(notExistedIds);
      }

      return result;
    } else {
      return causes["?"];
    }
  }

  List<LiceType> _getLiceTypes() {
    var languageCode = _appModel.currentLocale.languageCode;
    if (_liceTypes != null && _liceTypes.containsKey(languageCode)) {
      List<LiceType> result = _liceTypes[languageCode];

      var ids = result.map((f) => f.itemId).toList();

      var notExistedIds = _liceTypes["?"].where((x) => !ids.contains(x.itemId));

      if (notExistedIds.length > 0) {
        result.addAll(notExistedIds);
      }

      return result;
    }

    return List<LiceType>();
  }

  List<SensorType> _getSensorTypes() {
    var languageCode = _appModel.currentLocale.languageCode;
    if (_sensorTypes != null && _sensorTypes.containsKey(languageCode)) {
      List<SensorType> result = _sensorTypes[languageCode];

      var ids = result.map((f) => f.itemId).toList();

      var notExistedIds =
          _sensorTypes["?"].where((x) => !ids.contains(x.itemId));

      if (notExistedIds.length > 0) {
        result.addAll(notExistedIds);
      }

      return result;
    }

    return List<SensorType>();
  }

  List<Sensor> _getManualActiveSensors() {
    List<Sensor> result = <Sensor>[];
    if (sensors != null && sensors.isNotEmpty) {
      /// Condition for manual sensor is
      /// - disabled = false
      /// - isAuto = false
      /// Condition for sensor activing is
      /// - Must have history assigment list
      /// - At least 1 assignment in the history list that has endTime null
      result = sensors
          .where((sensor) =>
              !sensor.disabled &&
              !sensor.isAuto &&
              sensor.history != null &&
              sensor.history.any((assignment) => assignment.endTime == null))
          .toList();
    }
    return result;
  }

  List<OptionItem> _getMissedReason(String reasonType) {
    var languageCode = _appModel.currentLocale.languageCode;
    var missedReason = reasonType == AppConfigKeys.missedFeedingReason
        ? _missedFeedingReason
        : _missedMortalityReason;
    if (missedReason.containsKey(languageCode)) {
      List<OptionItem> result = missedReason[languageCode];

      var ids = result.map((f) => f.id).toList();

      var notExistedIds = missedReason["?"].where((x) => !ids.contains(x.id));

      if (notExistedIds.length > 0) {
        result.addAll(notExistedIds);
      }

      return result;
    } else {
      return missedReason["?"];
    }
  }

  String getDeathCauseName(int causeId) {
    var cause = _causesOfDealth[_appModel.currentLocale.languageCode]
        .firstWhere((causesOfDeath) => causesOfDeath.causeId == causeId,
            orElse: () => null);
    if (cause == null) return '';
    return cause.name;
  }

  String getCullingCauseName(int causeId) {
    var cause = _cullingCauses[_appModel.currentLocale.languageCode].firstWhere(
        (cullingCauses) => cullingCauses.causeId == causeId,
        orElse: () => null);
    if (cause == null) return '';
    return cause.name;
  }
}

import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/models/registration.dart';

class CleanerFishFeedingRegistrationViewModel extends RegistrationViewModel {
  CleanerFishFeedingRegistrationViewModel() : super(false, RegistrationType.Feeding);
}
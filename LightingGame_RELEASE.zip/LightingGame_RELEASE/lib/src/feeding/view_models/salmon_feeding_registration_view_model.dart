import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/models/registration.dart';

class SalmonFeedingRegistrationViewModel extends RegistrationViewModel {
  SalmonFeedingRegistrationViewModel() : super(true, RegistrationType.Feeding);
}
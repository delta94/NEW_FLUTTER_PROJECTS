import 'package:Commons/dropdown.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/util/utils.dart';
import 'package:control_app/src/widgets/confirm_message.dart';
import 'package:control_app/src/widgets/no_registration_message.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

const DROPDOWN_BOTTOM_PADDING = 170;

class MissedFeedConfirmation extends StatefulWidget {
  const MissedFeedConfirmation({
    Key key,
    @required this.model,
  }) : super(key: key);

  final RegistrationViewModel model;

  @override
  _MissedFeedConfirmationState createState() => _MissedFeedConfirmationState();
}

class _MissedFeedConfirmationState extends State<MissedFeedConfirmation> {
  OptionItem selectedReason;
  GlobalKey dropdownKey = GlobalKey();
  double dropdownHeight = 0;
  int numberDropdownItems = 0;

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback(_getDropdownPositionY);
    super.initState();
  }

  void _getDropdownPositionY(_) {
    if (dropdownKey.currentContext != null) {
      final RenderBox registrationListKeyBox =
          dropdownKey.currentContext.findRenderObject();
      Offset position = registrationListKeyBox.localToGlobal(Offset.zero);
      double registrationListPositionY = position.dy;
      setState(() {
        dropdownHeight = MediaQuery.of(context).size.height -
            registrationListPositionY -
            DROPDOWN_BOTTOM_PADDING;
        numberDropdownItems = (dropdownHeight / DROPDOWN_ITEM_HEIGHT).floor();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final S appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    SharedDataModel sharedDataModel =
        Provider.of<SharedDataModel>(this.context, listen: false);
    OrganizationModel organizationModel =
        Provider.of<OrganizationModel>(this.context, listen: false);

    RegistrationUserRight registrationUserRight =
        organizationModel.registrationUserRightMap[RegistrationType.Feeding];

    List<OptionItem> missedFeedingReasons = sharedDataModel.missedFeedingReason;
    var newSelectedReasonId = widget.model.checkConfirmedMissedReason();

    if (selectedReason == null || newSelectedReasonId != selectedReason.id) {
      selectedReason = missedFeedingReasons.firstWhere(
        (missedFeedingReason) => missedFeedingReason.id == newSelectedReasonId,
        orElse: () => null,
      );
      // this will make dropdown reinit.
      dropdownKey = GlobalKey();
    }

    void onMissedFeedingReasonChanged(OptionItem newOptionItem) {
      widget.model.confirmMissedReason(newOptionItem.id);
    }

    return SingleChildScrollView(
      child: Stack(children: <Widget>[
        Column(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Container(
              height: 200,
            ),
            NoRegistrationMessage(registrationStatus: widget.model.status),
          ],
        ),
        ConfirmMessage(
          confirmWidget: Column(
            children: <Widget>[
              SizedBox(
                height: 10,
              ),
              Container(
                padding: EdgeInsets.fromLTRB(20, 0, 20, 20),
                child: AkvaDropDown(
                  key: dropdownKey,
                  enable:
                      !widget.model.busy && registrationUserRight.allowWrite,
                  items: sharedDataModel.missedFeedingReason,
                  onSelectedItem: registrationUserRight.allowWrite
                      ? onMissedFeedingReasonChanged
                      : null,
                  label: appText.cause,
                  leftIcon: AkvaIcons.search,
                  hint: appText.search,
                  numberOfDisplayedItems: numberDropdownItems,
                  selectedItems: [selectedReason],
                  isDarkTheme: appModel.isDarkTheme,
                ),
              ),
            ],
          ),
          confirmText: selectedReason == null
              ? appText.i_missed_feeding_unit_today(
                  widget.model.organizationModel.currentOrganizationEntity.name)
              : appText.i_confirm_that_i_missed_feeding_unit_today(widget
                  .model.organizationModel.currentOrganizationEntity.name),
          isConfirmed: selectedReason != null,
          onTap: registrationUserRight.allowDelete
              ? () => setState(() {
                    selectedReason = null;
                    widget.model.revertMissedReason();
                  })
              : null,
        ),
      ]),
    );
  }
}

import 'dart:async';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/registration_factory.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/organization/organizationListener.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/services/timezone_service.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:control_app/src/base/base_view_model.dart';

class LiceSampleViewModel extends BaseViewModel
    implements OrganizationEventListener {
  LiceSampleViewModel() {
    this._organizationModel = OrganizationModel();
    this._organizationModel.addEventListener(this);
    if (this._organizationModel.currentUnit != null) {
      this.fetchLiceSamples();
    }
  }
  final _dbRepos = DBRegistrationRepository(RegistrationType.Lice);
  final List<Registration> _liceSamples = List<Registration>();
  AppModel _appModel;
  OrganizationModel _organizationModel;
  SharedDataModel _sharedDataModel;
  Registration _currentLiceSample;
  RegistrationStatus status = RegistrationStatus.NO_REGISTRATION;
  Registration get currentLiceSample => _currentLiceSample;
  List<Registration> get liceSamples => _liceSamples;

  /// Backup the last quarantineDetails for the scenario:
  /// Default quarantine the fish is YES, and on All tab,
  /// user is allowed to edit values. He selects quarantine the fish to NO.
  /// At that time, we should back up the current quarantine detail object before
  /// erease it to null so that if he decide to select YES again then the backup
  /// data should be rolled back.
  QuarantineDetails backupQuarantineDetails;
  quarantineTheFish(LiceSample liceSample, bool quarantine) {
    if (liceSample.quarantineTheFish != quarantine) {
      liceSample.quarantineTheFish = quarantine;
      notifyListeners();
    }
  }

  bool _isEditingRegistrationMode = false;
  bool get isEditingRegistrationMode => _isEditingRegistrationMode;
  set isEditingRegistrationMode(bool val) {
    if (_isEditingRegistrationMode != val) {
      _isEditingRegistrationMode = val;
      notifyListeners();
    }
  }

  int sampleIdForDeletion;

  /// -1 is all
  int currentSampleNumber = 1;
  bool get hasSample =>
      _currentLiceSample != null &&
      (_currentLiceSample.item as LiceSample)
          .samples
          .any((sample) => sample.measureId >= 1);

  void setConsequence(Consequence consequenceType, bool val) {
    if (_currentLiceSample == null) return;
    var lice = (_currentLiceSample.item as LiceSample);
    if (val) {
      /// Setting bit
      lice.quarantineDetails.consequences ^= 1 << consequenceType.index;
    } else {
      /// Clear bit
      lice.quarantineDetails.consequences &= ~(1 << consequenceType.index);
    }
  }

  void updateDependencies(
      AppModel appModel,
      OrganizationModel organizationModel,
      SharedDataModel sharedDataModel) async {
    if (_appModel != appModel) {
      _appModel = appModel;
    }

    if (_organizationModel != organizationModel) {
      _organizationModel = organizationModel;
      _organizationModel.addEventListener(this);
    }

    if (_sharedDataModel != sharedDataModel) {
      _sharedDataModel = sharedDataModel;
    }
  }

  _checkStatus() {
    bool haveFish = _organizationModel.speciesOfCurrentUnit
        .any((specie) => specie.speciesId == 1);
    bool haveRegistration =
        _liceSamples.any((lice) => lice.changeStatus != ChangeStatus.Deleted);
    if (haveFish) {
      if (haveRegistration) {
        status = RegistrationStatus.HAVE_REGISTRATION;
      } else {
        status = RegistrationStatus.NO_REGISTRATION;
      }
    } else {
      status = RegistrationStatus.NO_FISH;
    }
  }

  Future fetchLiceSamples() async {
    _liceSamples.clear();
    _liceSamples
        .addAll(await _dbRepos.fetchByUnit(_organizationModel.currentUnit));
    _liceSamples.sort((a, b) => a.time.compareTo(b.time));
    await getLastRegistration();
    _checkStatus();
    //notifyListeners();
  }

  Future<void> getLastRegistration() async {
    /// Since registration information is most weeks the same information
    /// over and over again, so after the last lice samplping has been made
    /// then it should be reused for the next week
    Registration lastRegistration =
        await _dbRepos.getLastRegistration(_organizationModel.currentSite);
    if (lastRegistration != null) {
      /// Copy the last registration info but need change the registration time
      /// to present.
      _currentLiceSample = lastRegistration;
      _currentLiceSample.time = TimeZoneService.convertToTimezone(
          DateTime.now(), _organizationModel.currentSite.timeZoneId);
      _currentLiceSample.changeStatus = ChangeStatus.New;
      (_currentLiceSample.item as LiceSample).samples.forEach((sample) {
        sample.parameters = _defaultParameters();
      });
    }
  }

  void addNewLiceSample() {
    if (_currentLiceSample == null) {
      _currentLiceSample = Registration(
        siteId: _organizationModel.currentSite.id,
        unitId: _organizationModel.currentUnit.id,
        speciesId: 1,
        time: TimeZoneService.convertToTimezone(
            DateTime.now(), _organizationModel.currentSite.timeZoneId),
        changeStatus: ChangeStatus.New,
        item: RegistrationFactory.create(RegistrationType.Lice),
      );

      /// Add sedation tank sample to sample list by default
      (_currentLiceSample.item as LiceSample)
          .samples
          .add(Sample(parameters: _defaultParameters()));
    } else {
      _currentLiceSample.id = null;
      _currentLiceSample.siteId = _organizationModel.currentSite.id;
      _currentLiceSample.unitId = _organizationModel.currentUnit.id;
      (_currentLiceSample.item as LiceSample).reportGenerated = false;
      _currentLiceSample.time = TimeZoneService.convertToTimezone(
          DateTime.now(), _organizationModel.currentSite.timeZoneId);
      _currentLiceSample.changeStatus = ChangeStatus.New;
      (_currentLiceSample.item as LiceSample).samples.forEach((sample) {
        sample.parameters = _defaultParameters();
      });
    }
  }

  void addNewSample() {
    var liceSample = _currentLiceSample.item as LiceSample;
    Map<String, int> parameters = _defaultParameters();
    int maxId = 0;
    liceSample.samples.forEach((sample) {
      if (sample.measureId > maxId) {
        maxId = sample.measureId;
      }
    });
    var sample = Sample(measureId: maxId + 1, parameters: parameters);
    currentSampleNumber = sample.measureId;
    liceSample.samples.insert(liceSample.samples.length - 1, sample);
    notifyListeners();
  }

  void deleteSample() {
    if (sampleIdForDeletion != null) {
      var liceSample = _currentLiceSample.item as LiceSample;
      liceSample.samples
          .removeWhere((sample) => sample.measureId == sampleIdForDeletion);
      notifyListeners();
    }
  }

  int totalSampleCount(LiceSample liceSample, int measureId) {
    int total = 0;
    if (liceSample != null) {
      final sample = liceSample.samples.firstWhere(
          (sample) => sample.measureId == measureId,
          orElse: () => null);

      if (sample != null) {
        sample.parameters.forEach((key, value) {
          total += value;
        });
      }
    }

    return total;
  }

  _defaultParameters() {
    var liceTypes = _sharedDataModel.liceTypes;
    Map<String, int> parameters = Map.fromIterable(liceTypes,
        key: (e) => e.itemId.toString(), value: (e) => 0);
    return parameters;
  }

  void updateSedationMethod(int medicamentId) {
    /// When user change sedation method, it should be filled out
    /// withdrawal from [SedationMethod] into [LiceSample]
    if (_currentLiceSample == null) return;
    var lice = (_currentLiceSample.item as LiceSample);
    lice.medicamentId = medicamentId;

    var sedation = _sharedDataModel.sedationMethods.firstWhere(
        (sedation) => sedation.itemId == medicamentId,
        orElse: () => null);
    if (sedation != null) {
      lice.withdrawal = sedation.withdrawal != null
          ? Withdrawal.clone(sedation.withdrawal)
          : Withdrawal();
    }
  }

  updateSample(Sample sample, String liceTypeId, int val) {
    if (sample.parameters.containsKey(liceTypeId)) {
      if (sample.parameters[liceTypeId] != val) {
        sample.updateParameter(liceTypeId, val);
        notifyListeners();
      }
    }
  }

  getTotalLice(Sample sample) {
    int total = 0;
    sample.parameters.forEach((key, value) {
      total += value;
    });
    return total;
  }

  void updateOverrideWithdrawal() {
    if (_currentLiceSample == null) return;
    var sample = (_currentLiceSample.item as LiceSample);
    var sedation = _sharedDataModel.sedationMethods.firstWhere(
        (sedation) => sedation.itemId == sample.medicamentId,
        orElse: () => null);
    if (sedation != null) {
      if (sedation.withdrawal == sample.withdrawal) {
        sample.overrideWithdrawal = false;
      } else {
        sample.overrideWithdrawal = true;
      }
    } else {
      sample.overrideWithdrawal = true;
    }
  }

  signAndSubmit() async {
    try {
      /// Check in case duration is null then
      /// it should be '00:00:00' before synchronize
      /// to cloud.
      setBusy(true);
      final liceSample = currentLiceSample.item as LiceSample;
      if (liceSample.bathDuration == null) {
        liceSample.bathDuration = "00:00:00";
      }
      await _dbRepos.store(currentLiceSample);
      _appModel.synchronizeManager.syncByType(RegistrationType.Lice);
      await fetchLiceSamples();
      //_checkStatus();
    } catch (e) {} finally {
      setBusy(false);
    }
  }

  discardChanges() {
    (_currentLiceSample.item as LiceSample).rollback();
    isEditingRegistrationMode = false;
    notifyListeners();
  }

  setCurrentSampleNumber(int number) {
    currentSampleNumber = number;
    notifyListeners();
  }

  @override
  void organizationEntityChanged(OrganizationEntity newEntity) {
    if (newEntity is Unit) {
      this.fetchLiceSamples();
    }
  }
}

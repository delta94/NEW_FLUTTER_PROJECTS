import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:control_app/src/widgets/number_input.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class LiceInput extends StatelessWidget {
  const LiceInput({
    Key key,
    @required this.inputController,
    this.label,
    this.unitName,
    this.numberInputType,
    this.inputWidth,
    this.unitWidth,
    this.enable = true,
  }) : super(key: key);

  final TextEditingController inputController;
  final String label;
  final String unitName;
  final NumberInputType numberInputType;
  final double inputWidth;
  final double unitWidth;
  final bool enable;
  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context, listen: false);

    return Column(
      children: <Widget>[
        label != null
            ? Row(
                children: <Widget>[
                  Text(
                    label,
                    style: TextStyle(
                      fontSize: FontSize.small,
                      fontWeight: FontWeight.normal,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ],
              )
            : Container(),
        Container(
          margin: EdgeInsets.only(top: 5),
          child: Row(
            children: <Widget>[
              NumberInput(
                inputHeight: 38,
                numberInputType: numberInputType,
                controller: inputController,
                enabled: enable,
                activeColor: akvaMainAction,
                inputWidth: inputWidth - (unitWidth ?? 0),
              ),
              Visibility(
                visible: unitName != null,
                child: Container(
                  height: enable ? 38 : 39,
                  width: unitWidth,
                  alignment: Alignment.center,
                  padding: EdgeInsets.symmetric(
                    vertical: 6,
                  ),
                  decoration: new BoxDecoration(
                    color:
                        appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorB,
                    border: Border(
                      top: BorderSide(
                        color: UiUtils.getModeColor(appModel, enable),
                      ),
                      right: BorderSide(
                        color: UiUtils.getModeColor(appModel, enable),
                      ),
                      bottom: BorderSide(
                        color: UiUtils.getModeColor(appModel, enable),
                      ),
                    ),
                  ),
                  child: Text(
                    unitName ?? '',
                    style: TextStyle(
                      fontSize: FontSize.small,
                      fontWeight: FontWeight.normal,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ),
              )
            ],
          ),
        )
      ],
    );
  }
}

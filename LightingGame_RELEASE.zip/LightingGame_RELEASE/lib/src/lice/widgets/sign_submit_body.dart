import 'package:Commons/colors.dart';
import 'package:Commons/dropdown.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/widgets/number_input.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class SignSubmitBody extends StatefulWidget {
  final Function(bool) validateToSave;

  const SignSubmitBody({Key key, this.validateToSave}) : super(key: key);

  @override
  _SignSubmitBodyState createState() => _SignSubmitBodyState();
}

class _SignSubmitBodyState extends State<SignSubmitBody> {
  bool showDialog = false;
  String currentSiteName = '';
  String currentUnitName = '';
  OptionItem currentSampleTaker;
  List<OptionItem> sampleTakerOptions;

  @override
  void initState() {
    final appModel = Provider.of<AppModel>(context, listen: false);
    OrganizationModel organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);
    final sharedDataModel =
        Provider.of<SharedDataModel>(context, listen: false);
    final liceSampleViewModel =
        Provider.of<LiceSampleViewModel>(context, listen: false);
    final liceSample = liceSampleViewModel.currentLiceSample.item as LiceSample;

    currentSiteName = organizationModel.currentSite.name;
    currentUnitName = organizationModel.currentUnit.name;
    sampleTakerOptions = sharedDataModel.sampleTakers
        .map((contact) => OptionItem(id: contact.id, label: contact.name))
        .toList();

    var defaultSampleTaker = sharedDataModel.sampleTakers.firstWhere(
        (contact) => contact.userId == appModel.currentUserInfo.id,
        orElse: () => null);

    if (liceSample.sampleTakerContactId != null) {
      currentSampleTaker = sampleTakerOptions.firstWhere(
          (contact) => contact.id == liceSample.sampleTakerContactId,
          orElse: () => null);
    } else {
      if (defaultSampleTaker != null) {
        currentSampleTaker = sampleTakerOptions.firstWhere(
            (contact) => contact.id == defaultSampleTaker.id,
            orElse: () => null);
      }

      if (currentSampleTaker != null) {
        liceSample.sampleTakerContactId = currentSampleTaker.id;
      }
    }

    /// In case we are editing in previous screen (All samples screen)
    /// the it should be commit any changes
    Future.delayed(Duration.zero, () {
      liceSampleViewModel.isEditingRegistrationMode = false;
      liceSample.commit();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) => _checkTakerName());
    super.initState();
  }

  _checkTakerName() {
    if (currentSampleTaker == null)
      widget.validateToSave(false);
    else
      widget.validateToSave(true);
  }

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    LiceSampleViewModel liceSampleViewModel =
        Provider.of<LiceSampleViewModel>(context);
    final liceSample = liceSampleViewModel.currentLiceSample.item as LiceSample;
    _buildSpace() {
      return Column(children: <Widget>[
        SizedBox(height: 30),
        Divider(
          color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
          thickness: 1,
          height: 0,
        ),
        SizedBox(height: 15),
      ]);
    }

    _buildInputTitle(String title) {
      return Column(children: <Widget>[
        Row(
          children: <Widget>[
            Text(
              title,
              style: TextStyle(
                  color: appModel.isDarkTheme ? akvaDarkTextA : akvaDarkColorD,
                  fontSize: FontSize.small,
                  fontWeight: FontWeight.normal),
            ),
          ],
        ),
        SizedBox(height: 5),
      ]);
    }

    return Padding(
      padding: const EdgeInsets.only(left: 20.0, top: 16.0, right: 20),
      child: Container(
        height: MediaQuery.of(context).size.height - 261,
        padding: EdgeInsets.only(top: 0),
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              _buildInputTitle(appText.site),
              NumberInput(
                textAlign: TextAlign.left,
                controller: new TextEditingController(text: currentSiteName),
                enabled: false,
                inputWidth: MediaQuery.of(context).size.width,
              ),
              _buildSpace(),
              _buildInputTitle(appText.unit),
              NumberInput(
                textAlign: TextAlign.left,
                controller: new TextEditingController(text: currentUnitName),
                enabled: false,
                inputWidth: MediaQuery.of(context).size.width,
              ),
              _buildSpace(),
              AkvaDropDown(
                label: appText.sample_taker,
                items: sampleTakerOptions,
                numberOfDisplayedItems: 5,
                onSelectedItem: (item) {
                  setState(() {
                    currentSampleTaker = item;
                    liceSample.sampleTakerContactId = item.id.toString();
                    _checkTakerName();
                  });
                },
                hint: appText.sample_taker,
                selectedItems:
                    currentSampleTaker != null ? [currentSampleTaker] : [],
                isDarkTheme: appModel.isDarkTheme,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

import 'dart:async';

import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/models/contact.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:control_app/src/util/utils.dart';
import 'package:control_app/src/widgets/highlight_text.dart';
import 'package:control_app/src/widgets/registration_title.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import 'all_info.dart';

class LiceRegistrationContent extends StatefulWidget {
  LiceRegistrationContent();

  @override
  _LiceRegistrationContentState createState() =>
      _LiceRegistrationContentState();
}

class _LiceRegistrationContentState extends State<LiceRegistrationContent> {
  double allInfoBodyHeight = 0;
  ScrollController scrollController = ScrollController();

  @override
  void initState() {
    Future.delayed(Duration.zero, () {
      WidgetsBinding.instance.addPostFrameCallback(setRegistrationListHeight);
    });

    super.initState();
  }

  void setRegistrationListHeight(_) {
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);
    setState(() {
      allInfoBodyHeight = MediaQuery.of(context).size.height -
          300 -
          kBottomNavigationBarHeight -
          UiUtils.getSyncConnectionBarHeight(appModel);
    });
  }

  @override
  Widget build(BuildContext context) {
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);
    final sharedDataModel =
        Provider.of<SharedDataModel>(context, listen: false);
    final liceSampleViewModel =
        Provider.of<LiceSampleViewModel>(context, listen: false);

    _buildLiceSampleList() {
      Contact taker;

      List<Widget> allInfoList = [];
      liceSampleViewModel.liceSamples.forEach((registration) {
        List<Contact> sampleTakers = sharedDataModel.sampleTakers;
        LiceSample liceSample = registration.item as LiceSample;
        if (liceSample.sampleTakerContactId != null) {
          taker = sampleTakers.firstWhere(
              (contact) => contact.id == liceSample.sampleTakerContactId,
              orElse: () => null);
        } else {
          taker = sampleTakers.firstWhere(
              (contact) => contact.userId == appModel.currentUserInfo.id,
              orElse: () => null);
        }

        allInfoList.add(
          LiceRegistrationItem(
              dateTime: registration.time,
              registration: registration,
              takerName: taker != null ? taker.name : ''),
        );
      });

      return allInfoList;
    }

    return Column(
      children: <Widget>[
        SizedBox(height: 8),
        Padding(
          padding: EdgeInsets.symmetric(vertical: 5, horizontal: 19),
          child: RegistrationTitle(
            isViewMode: true,
            discardChanges: () => liceSampleViewModel.discardChanges(),
            isEditingCountMode: liceSampleViewModel.isEditingRegistrationMode,
            setEditingModeTrue: () =>
                liceSampleViewModel.isEditingRegistrationMode = true,
          ),
        ),
        SizedBox(height: 10),
        Container(
          color: appModel.isDarkTheme ? akvaDarkColorC : akvaLightColorA,
          height: allInfoBodyHeight,
          child: Scrollbar(
            key: ObjectKey('scroll'),
            isAlwaysShown: true,
            controller: scrollController,
            child: MediaQuery.removePadding(
              removeTop: true,
              context: context,
              child: SingleChildScrollView(
                key: ObjectKey('scroll'),
                controller: scrollController,
                child: Column(children: _buildLiceSampleList()),
              ),
            ),
          ),
        ),
      ],
    );
  }
}

class LiceRegistrationItem extends StatefulWidget {
  const LiceRegistrationItem({
    Key key,
    @required this.dateTime,
    @required this.registration,
    this.takerName,
  }) : super(key: key);

  final Registration registration;
  final DateTime dateTime;
  final String takerName;

  @override
  _LiceRegistrationItemState createState() => _LiceRegistrationItemState();
}

class _LiceRegistrationItemState extends State<LiceRegistrationItem> {
  bool isExpanded = true;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        RegistrationItemInfoTitle(
            isExpanded: isExpanded,
            dateTime: widget.dateTime,
            takerName: widget.takerName,
            onToggle: () => setState(() => isExpanded = !isExpanded)),
        Visibility(
          visible: isExpanded,
          child: AllInfoContent(
            isViewMode: true,
            liceSample: widget.registration.item as LiceSample,
          ),
        ),
      ],
    );
  }
}

class RegistrationItemInfoTitle extends StatelessWidget {
  final DateTime dateTime;
  final VoidCallback onToggle;
  final bool isExpanded;
  final String takerName;
  RegistrationItemInfoTitle(
      {@required this.dateTime,
      @required this.onToggle,
      this.isExpanded,
      @required this.takerName});

  @override
  Widget build(BuildContext context) {
    S appText = S.of(context);
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);
    return Column(
      children: <Widget>[
        Divider(
          color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
          height: 1,
          thickness: 1.3,
        ),
        Container(
          color: appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorB,
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Expanded(
                child: InkWell(
                  onTap: () => onToggle(),
                  child: Padding(
                    padding: EdgeInsets.fromLTRB(18, 17, 5, 17),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Expanded(
                          flex: 5,
                          child: Text(
                            getRegistrationTime(
                              appText.at,
                              dateTime,
                            ),
                            style: TextStyle(
                              fontSize: FontSize.small,
                              color: appModel.isDarkTheme
                                  ? akvaDarkTextA
                                  : akvaDarkColorD,
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 5,
                          child: HighlightText(
                            text: takerName,
                            mainAxisAlignment: MainAxisAlignment.end,
                          ),
                        ),
                        Expanded(
                          flex: 1,
                          child: Container(
                            margin: EdgeInsets.only(right: 3),
                            width: 20,
                            child: Material(
                              color: Colors.transparent,
                              child: Icon(
                                isExpanded
                                    ? AkvaIcons.keyboard_arrow_up
                                    : AkvaIcons.keyboard_arrow_down,
                                size: 12,
                                color: appModel.isDarkTheme
                                    ? akvaMainNeutral
                                    : akvaDarkColorD,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
        Divider(
          color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
          height: 1,
          thickness: 1.3,
        ),
      ],
    );
  }
}

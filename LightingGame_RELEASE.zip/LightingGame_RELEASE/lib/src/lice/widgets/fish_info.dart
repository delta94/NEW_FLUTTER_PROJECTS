import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/widgets/checkbox_list.dart';
import 'package:control_app/src/widgets/number_input.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

class FishInfo extends StatefulWidget {
  const FishInfo({
    Key key,
    this.isFreeHeight: false,
    this.isEditingMode: false,
    this.isSedationTank: false,
    @required this.fishSampleId,
    @required this.liceSample,
    this.bottomPadding,
  }) : super(key: key);

  final bool isFreeHeight;
  final bool isEditingMode;
  final bool isSedationTank;
  final double bottomPadding;
  final LiceSample liceSample;
  final int fishSampleId;
  @override
  _FishInfoState createState() => _FishInfoState();
}

class _FishInfoState extends State<FishInfo> {
  double fishInfoBodyHeight = 0;
  ScrollController scrollController = ScrollController();
  Map<int, TextEditingController> liceTypeControlerMap = {};

  @override
  void initState() {
    final liceSampleViewModel =
        Provider.of<LiceSampleViewModel>(context, listen: false);
    var sample = widget.liceSample.samples
        .firstWhere((sample) => sample.measureId == widget.fishSampleId);

    sample.parameters.forEach((key, val) {
      TextEditingController inputController =
          new TextEditingController(text: val > 0 ? val.toString() : "");
      inputController.addListener(() {
        var number = int.tryParse(inputController.text) ?? 0;
        liceSampleViewModel.updateSample(sample, key, number);
      });

      liceTypeControlerMap[int.tryParse(key)] = inputController;
    });

    if (!widget.isFreeHeight)
      WidgetsBinding.instance.addPostFrameCallback(_getBodyHeight);
    super.initState();
  }

  void _getBodyHeight(_) {
    setState(() {
      fishInfoBodyHeight = MediaQuery.of(context).size.height -
          242 -
          kBottomNavigationBarHeight -
          widget.bottomPadding;
    });
  }

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    final sharedDataModel =
        Provider.of<SharedDataModel>(context, listen: false);
    var sample = widget.liceSample.samples
        .firstWhere((sample) => sample.measureId == widget.fishSampleId);

    _buildLiceTypeWidgets() {
      List<Widget> liceTypeWidgets = [];
      liceTypeControlerMap.forEach((key, inputController) {
        var liceType = sharedDataModel.liceTypes
            .firstWhere((lice) => lice.itemId == key, orElse: () => null);

        if (!sample.hasChanged)
          inputController.text = sample.parameters[key.toString()] > 0
              ? sample.parameters[key.toString()].toString()
              : "";

        liceTypeWidgets.add(
          Column(
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Expanded(
                    flex: 7,
                    child: Text(
                      liceType.name,
                      style: TextStyle(
                        fontSize: FontSize.small,
                        fontStyle: FontStyle.normal,
                        color: appModel.isDarkTheme
                            ? akvaDarkTextA
                            : akvaDarkColorD,
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 3,
                    child: Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: NumberInput(
                        numberInputType: NumberInputType.INT,
                        controller: inputController,
                        enabled: widget.isEditingMode,
                        activeColor: akvaMainAction,
                        inputWidth: 116,
                      ),
                    ),
                  )
                ],
              ),
              SizedBox(height: 25),
              Divider(
                color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
                thickness: 1,
                height: 0,
              ),
              SizedBox(height: 18),
            ],
          ),
        );
      });

      return liceTypeWidgets;
    }

    _buildBodyContent() {
      return Column(
        children: <Widget>[
          SizedBox(height: 30),
          ..._buildLiceTypeWidgets(),
          Visibility(
            visible: !widget.isSedationTank,
            child: CheckboxList(
              paddingRight: 7,
              enable: widget.isEditingMode,
              checkboxTitles: [appText.returned_to_the_unit],
              checkedIndices: sample.returnedToUnit ? [0] : [],
              onChangeCheckedBoxIndices: () => setState(() {
                sample.returnedToUnit = !sample.returnedToUnit;
              }),
            ),
          ),
          SizedBox(height: 25)
        ],
      );
    }

    return Container(
      padding: EdgeInsets.only(top: 0, left: 19),
      height: widget.isFreeHeight ? null : fishInfoBodyHeight,
      child: widget.isFreeHeight
          ? _buildBodyContent()
          : Scrollbar(
              key: PageStorageKey('scroll'),
              isAlwaysShown: true,
              controller: scrollController,
              child: MediaQuery.removePadding(
                removeTop: true,
                context: context,
                child: SingleChildScrollView(
                  key: PageStorageKey('scroll'),
                  controller: scrollController,
                  child: _buildBodyContent(),
                ),
              ),
            ),
    );
  }
}

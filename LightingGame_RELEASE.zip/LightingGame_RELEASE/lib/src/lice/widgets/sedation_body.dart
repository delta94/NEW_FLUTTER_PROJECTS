import 'package:Commons/colors.dart';
import 'package:Commons/dropdown.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/src/widgets/date_picker/date_picker_widget.dart';
import 'package:control_app/src/widgets/duration_picker/control_app_picker.dart';
import 'package:flutter/cupertino.dart';
import 'package:intl/intl.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/lice/widgets/lice_input.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:control_app/src/widgets/radio_group.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';
import 'package:control_app/src/widgets/number_input.dart';

class SedationBody extends StatefulWidget {
  final Function(bool) validateToSave;
  final bool isFreeHeight;
  final bool isEditingMode;
  final LiceSample liceSample;
  final double bottomPadding;

  const SedationBody(
      {Key key,
      this.validateToSave,
      this.isFreeHeight: false,
      this.isEditingMode: false,
      @required this.liceSample,
      this.bottomPadding: 0})
      : assert(liceSample != null),
        super(key: key);

  @override
  _SedationBodyState createState() => _SedationBodyState();
}

class _SedationBodyState extends State<SedationBody> {
  double sedationBodyHeight = 0;
  ScrollController scrollController = ScrollController();

  int currentRadioIndex = 0;
  bool showDialog = false;

  final TextEditingController waterController = new TextEditingController();
  final TextEditingController sedationController = new TextEditingController();
  final TextEditingController concentrationController =
      new TextEditingController();
  final TextEditingController batchController = new TextEditingController();
  DateTime currentDate = DateTime.now();

  List<OptionItem> sedationMethods = [];
  bool isAllowedToSave = true;
  DateTime registrationDateTime;
  LiceSample currentLiceSample;
  OptionItem selectedItem;
  String duration = '00:00:00';

  @override
  void initState() {
    currentDate =
        DateTime(currentDate.year, currentDate.month, currentDate.day);

    waterController
        .addListener(() => _updateWaterInSedation(waterController.text));
    sedationController
        .addListener(() => _updateSedationUsed(sedationController.text));
    batchController.addListener(() => _updateBatchNumber(batchController.text));

    WidgetsBinding.instance.addPostFrameCallback(_getBodyHeight);
    super.initState();
  }

  _initData() {
    final liceSampleModel =
        Provider.of<LiceSampleViewModel>(context, listen: false);
    currentLiceSample = widget.liceSample ??
        liceSampleModel.currentLiceSample.item as LiceSample;
    sedationMethods = _getSedationMethods(context);
    if (currentLiceSample.medicamentId != null) {
      selectedItem = sedationMethods.firstWhere(
          (item) => item.id == currentLiceSample.medicamentId,
          orElse: () => null);
    }
    if (currentLiceSample.volumeLitre > 0) {
      waterController.text = currentLiceSample.volumeLitre.toString();
      _updateConcentration();
    }
    if (currentLiceSample.amountMilliLitre > 0) {
      sedationController.text = currentLiceSample.amountMilliLitre.toString();
      _updateConcentration();
    }

    if (currentLiceSample.bathDuration != null) {
      duration = currentLiceSample.bathDuration;
    }

    if (currentLiceSample.batchNo != null) {
      batchController.text = currentLiceSample.batchNo;
    }

    if (currentLiceSample.expiryDate != null) {
      currentDate = currentLiceSample.expiryDate;
    } else {
      currentLiceSample.expiryDate = currentDate;
    }
    currentRadioIndex = currentLiceSample.quarantineTheFish ? 0 : 1;
  }

  _updateWaterInSedation(String val) {
    double numVal = double.tryParse(val) ?? 0;
    currentLiceSample.volumeLitre = numVal;
    _updateConcentration();
  }

  _updateSedationUsed(String val) {
    double numVal = double.tryParse(val) ?? 0;
    currentLiceSample.amountMilliLitre = numVal;
    _updateConcentration();
  }

  _updateConcentration() {
    concentrationController.text = currentLiceSample.concentration.toString();
  }

  _updateDuration(String val) {
    currentLiceSample.bathDuration = val;
  }

  _updateBatchNumber(String val) {
    currentLiceSample.batchNo = val;
  }

  void _getBodyHeight(_) {
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    setState(() {
      sedationBodyHeight = MediaQuery.of(context).size.height -
          183 -
          UiUtils.getSyncConnectionBarHeight(appModel) -
          kBottomNavigationBarHeight -
          widget.bottomPadding;
    });
  }

  _getCurremtDate() {
    DateFormat dateFormat = DateFormat('dd.MM.yyyy');
    return dateFormat.format(currentDate);
  }

  List<OptionItem> _getSedationMethods(BuildContext context) {
    final sharedDataModel =
        Provider.of<SharedDataModel>(context, listen: false);
    return sharedDataModel.sedationMethods
        .map((e) => OptionItem(id: e.itemId, label: e.name))
        .toList();
  }

  _onChangeQuarantineOption(
      int newRadioIndex, LiceSampleViewModel liceSampleViewModel) {
    setState(() {
      currentRadioIndex = newRadioIndex;

      if (currentRadioIndex == 0) {
        if (liceSampleViewModel.backupQuarantineDetails != null) {
          widget.liceSample.quarantineDetails =
              liceSampleViewModel.backupQuarantineDetails;
        } else {
          widget.liceSample.quarantineDetails =
              QuarantineDetails(affectedUnitIds: <String>[]);
        }
      } else {
        if (widget.liceSample.quarantineDetails != null) {
          var source = widget.liceSample.quarantineDetails;
          liceSampleViewModel.backupQuarantineDetails = QuarantineDetails(
              consequences: source.consequences,
              affectedOtherUnits: source.affectedOtherUnits,
              manualClearance: source.manualClearance,
              affectedUnitIds: source.affectedUnitIds);
        }
        widget.liceSample.quarantineDetails = null;
      }
      liceSampleViewModel.quarantineTheFish(
          widget.liceSample, currentRadioIndex == 0);
    });
  }

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context, listen: false);

    LiceSampleViewModel liceSampleViewModel =
        Provider.of<LiceSampleViewModel>(context);

    List<String> _getNumberList(int max) {
      List<int> numberList = new List<int>.generate(max, (i) => i + 1);
      numberList.insert(0, 0);
      List<String> numberStringList = [];
      numberList.forEach((number) {
        numberStringList.add((number < 10 ? "0" : "") + number.toString());
      });

      return numberStringList;
    }

    List<int> _getCurrentDuration() {
      return duration.split(':').map((e) => int.parse(e)).toList();
    }

    showPickerArray(BuildContext context) {
      ConrolAppPicker(
          adapter: PickerDataAdapter<String>(
            pickerdata: [
              _getNumberList(99),
              _getNumberList(59),
              _getNumberList(59)
            ],
          ),
          selecteds: _getCurrentDuration(),
          onConfirm: (ConrolAppPicker picker) {
            setState(() {
              print(picker.getSelectedValues());
              List<String> hms = picker.getSelectedValues();
              duration = '${hms[0]}:${hms[1]}:${hms[2]}';
              _updateDuration(duration);
            });
          }).showDurationDialog(context);
    }

    _buildSedationContent() {
      return Stack(
        children: [
          Column(
            children: <Widget>[
              Container(height: 70),
              SedationInput(
                enable: widget.isEditingMode,
                inputController: waterController,
                label: appText.water_in_sedation_unit_l,
                unitName: 'l',
                numberInputType: NumberInputType.DECIMAL,
                inputWidth: 116,
                unitWidth: 34,
              ),
              SedationInput(
                enable: widget.isEditingMode,
                inputController: sedationController,
                label: appText.sedation_used_ml,
                unitName: 'ml',
                numberInputType: NumberInputType.DECIMAL,
                inputWidth: 116,
                unitWidth: 34,
              ),
              SedationInput(
                inputController: concentrationController,
                label: appText.concentration_ml_l,
                unitName: 'ml/l',
                numberInputType: NumberInputType.DECIMAL,
                inputWidth: 116,
                unitWidth: 44,
                enable: false,
              ),
              SizedBox(height: 25),
              Divider(
                color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
                thickness: 1,
                height: 0,
              ),
              SizedBox(height: 18),
              Row(
                children: <Widget>[
                  Text(
                    appText.duration,
                    style: TextStyle(
                      fontSize: FontSize.small,
                      fontWeight: FontWeight.normal,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ],
              ),
              SizedBox(height: 5),
              Row(children: <Widget>[
                InkWell(
                  child: Container(
                    padding: EdgeInsets.only(
                      top: 5,
                      bottom: 5,
                    ),
                    decoration: new BoxDecoration(
                      border: Border.all(
                          color: UiUtils.getModeColor(
                              appModel, widget.isEditingMode)),
                      color: appModel.isDarkTheme
                          ? akvaDarkColorA
                          : akvaLightColorB,
                    ),
                    height: 38,
                    width: 116,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: <Widget>[
                        Text(
                          duration,
                          style: TextStyle(
                            fontSize: FontSize.small,
                            fontWeight: FontWeight.normal,
                            color: akvaDarkTextB,
                          ),
                        ),
                      ],
                    ),
                  ),
                  onTap: widget.isEditingMode
                      ? () => showPickerArray(context)
                      : null,
                ),
              ]),
              SedationInput(
                enable: widget.isEditingMode,
                inputController: batchController,
                label: appText.batch_number,
                numberInputType: NumberInputType.TEXT,
                inputWidth: 116,
              ),
              SizedBox(height: 25),
              Divider(
                color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
                thickness: 1,
                height: 0,
              ),
              SizedBox(height: 18),
              Column(children: <Widget>[
                Row(
                  children: <Widget>[
                    Text(
                      appText.expiration_date,
                      style: TextStyle(
                        fontSize: FontSize.small,
                        fontWeight: FontWeight.normal,
                      ),
                      textAlign: TextAlign.left,
                    ),
                  ],
                ),
                SizedBox(height: 5),
                Row(children: <Widget>[
                  InkWell(
                    child: Container(
                      padding: EdgeInsets.only(
                        left: 17,
                        top: 5,
                        bottom: 5,
                      ),
                      decoration: new BoxDecoration(
                        border: Border.all(
                            color: UiUtils.getModeColor(
                                appModel, widget.isEditingMode)),
                        color: appModel.isDarkTheme
                            ? akvaDarkColorA
                            : akvaLightColorB,
                      ),
                      height: 38,
                      width: 146,
                      child: Row(
                        children: <Widget>[
                          Icon(
                            AkvaIcons.date_picker,
                            size: FontSize.medium,
                            color: akvaMainNeutral,
                          ),
                          SizedBox(width: 12),
                          Text(
                            _getCurremtDate(),
                            style: TextStyle(
                              fontSize: FontSize.small,
                              fontWeight: FontWeight.normal,
                              color: akvaDarkTextB,
                            ),
                            textAlign: TextAlign.left,
                          ),
                        ],
                      ),
                    ),
                    onTap: widget.isEditingMode
                        ? () async {
                            DateTime newDateTime =
                                await showControlAppDatePicker(
                              context: context,
                              initialDate: currentDate,
                              firstDate: DateTime(DateTime.now().year - 50),
                              lastDate: DateTime(DateTime.now().year + 50),
                            );

                            if (newDateTime != null) {
                              setState(() {
                                currentDate = newDateTime;
                                currentLiceSample.expiryDate = currentDate;
                              });
                            }
                          }
                        : null,
                  ),
                ]),
                SizedBox(height: 25),
                Divider(
                  color:
                      appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
                  thickness: 1,
                  height: 0,
                ),
                SizedBox(height: 18),
                Visibility(
                  visible: widget.isEditingMode,
                  child: Column(
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Text(
                            appText.quaratined_the_fish,
                            style: TextStyle(
                              fontSize: FontSize.small,
                              fontWeight: FontWeight.normal,
                            ),
                            textAlign: TextAlign.left,
                          ),
                        ],
                      ),
                      SizedBox(height: 10),
                      RadioGroup(
                        enable: widget.isEditingMode,
                        direction: Axis.horizontal,
                        currentRadioIndex: currentRadioIndex,
                        radioTitles: [appText.yes, appText.no],
                        onChangeRadioIndex: (newRadioIndex) =>
                            _onChangeQuarantineOption(
                                newRadioIndex, liceSampleViewModel),
                      ),
                      SizedBox(height: 50),
                    ],
                  ),
                ),
              ]),
            ],
          ),
          Padding(
            padding: const EdgeInsets.only(right: 20),
            child: AkvaDropDown(
              items: sedationMethods,
              enable: widget.isEditingMode,
              onSelectedItem: (item) {
                liceSampleViewModel.updateSedationMethod(item.id);
                setState(() {
                  selectedItem = item;
                });
              },
              label: appText.sedation,
              hint: appText.select_sedation_method,
              selectedItems: selectedItem != null ? [selectedItem] : [],
              isDarkTheme: appModel.isDarkTheme,
            ),
          ),
        ],
      );
    }

    _initData();
    return Padding(
      padding: const EdgeInsets.only(left: 20.0, top: 16.0),
      child: Container(
        padding: EdgeInsets.only(top: 0),
        height: widget.isFreeHeight ? null : sedationBodyHeight,
        child: widget.isFreeHeight
            ? _buildSedationContent()
            : Scrollbar(
                key: PageStorageKey('scroll'),
                controller: scrollController,
                isAlwaysShown: true,
                child: MediaQuery.removePadding(
                  removeTop: true,
                  context: context,
                  child: SingleChildScrollView(
                    key: PageStorageKey('scroll'),
                    controller: scrollController,
                    child: _buildSedationContent(),
                  ),
                ),
              ),
      ),
    );
  }
}

class SedationInput extends StatelessWidget {
  const SedationInput({
    Key key,
    @required this.inputController,
    this.label,
    this.unitName,
    this.numberInputType,
    this.inputWidth,
    this.unitWidth,
    this.enable = true,
  }) : super(key: key);

  final TextEditingController inputController;
  final String label;
  final String unitName;
  final NumberInputType numberInputType;
  final double inputWidth;
  final double unitWidth;
  final bool enable;

  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context, listen: false);

    return Column(
      children: <Widget>[
        SizedBox(height: 25),
        Divider(
          color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
          thickness: 1,
          height: 0,
        ),
        SizedBox(height: 18),
        LiceInput(
          inputController: inputController,
          label: label,
          numberInputType: numberInputType,
          unitName: unitName,
          inputWidth: inputWidth,
          unitWidth: unitWidth,
          enable: enable,
        ),
      ],
    );
  }
}

import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:control_app/src/widgets/confirmation_dialog/confirmation_modal.dart';
import 'package:control_app/src/widgets/delete_button.dart';
import 'package:control_app/src/widgets/total_amount_count.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class LiceRegistrationPart extends StatefulWidget {
  final Key key;
  final String title;
  final int measureId;
  final Widget infoWidget;
  final bool isEditingMode;
  final int fishSampleId;
  final LiceSample liceSample;
  LiceRegistrationPart({
    this.key,
    @required this.infoWidget,
    @required this.title,
    this.measureId,
    this.isEditingMode: true,
    this.fishSampleId,
    @required this.liceSample,
  }) : super(key: key);

  @override
  _LiceRegistrationPartState createState() => _LiceRegistrationPartState();
}

class _LiceRegistrationPartState extends State<LiceRegistrationPart> {
  bool isExpanded = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        RegistrationHeader(
          title: widget.title,
          measureId: widget.measureId,
          isEditingMode: widget.isEditingMode,
          onToggle: () => setState(() => isExpanded = !isExpanded),
          isExpanded: isExpanded,
          fishSampleId: widget.fishSampleId,
          liceSample: widget.liceSample,
        ),
        isExpanded ? widget.infoWidget : Container()
      ],
    );
  }
}

class RegistrationHeader extends StatelessWidget {
  final VoidCallback onToggle;
  final bool isExpanded;
  final String title;
  final int measureId;
  final bool isEditingMode;
  final int fishSampleId;
  final LiceSample liceSample;
  RegistrationHeader(
      {@required this.onToggle,
      this.isExpanded,
      @required this.title,
      this.measureId,
      this.isEditingMode: true,
      this.fishSampleId,
      @required this.liceSample});

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);
    final liceSampleViewModel = Provider.of<LiceSampleViewModel>(context);

    _onDeleteSample() {
      liceSampleViewModel.deleteSample();
    }

    return Column(
      children: <Widget>[
        Divider(
          color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
          height: 1,
          thickness: 1.3,
        ),
        InkWell(
          onTap: () => onToggle(),
          child: Container(
            padding: EdgeInsets.fromLTRB(10, 15, 11, 15),
            color: appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorB,
            child: Column(
              children: <Widget>[
                Row(
                  children: <Widget>[
                    Expanded(
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: <Widget>[
                          Row(
                            children: <Widget>[
                              DeleteButton(
                                isVisible: measureId != null &&
                                    measureId >= 0 &&
                                    isEditingMode,
                                callback: () {
                                  liceSampleViewModel.sampleIdForDeletion =
                                      fishSampleId;
                                  showConfirmationModal(
                                    context: context,
                                    title: appText.delete_registration,
                                    messages: [
                                      appText
                                          .are_you_sure_you_want_to_delete_registration,
                                    ],
                                    leftButtonTitle: appText.cancel,
                                    rightButtonTitle: appText.delete,
                                    onTapRightButton: _onDeleteSample,
                                  );
                                },
                              ),
                              Text(
                                title,
                                style: TextStyle(
                                  fontSize: FontSize.small,
                                  color: appModel.isDarkTheme
                                      ? akvaDarkTextA
                                      : akvaDarkColorD,
                                ),
                              ),
                              SizedBox(width: 20),
                              Visibility(
                                visible: fishSampleId != null,
                                child: TotalAmountCount(
                                  isRightSide: true,
                                  title: appText.total,
                                  totalAmountCount: liceSampleViewModel
                                      .totalSampleCount(
                                          liceSample, fishSampleId)
                                      .toDouble(),
                                ),
                              ),
                            ],
                          ),
                          Container(
                            margin: EdgeInsets.only(right: 3),
                            width: 20,
                            child: Material(
                              color: Colors.transparent,
                              child: Icon(
                                isExpanded
                                    ? AkvaIcons.keyboard_arrow_up
                                    : AkvaIcons.keyboard_arrow_down,
                                size: 12,
                                color: appModel.isDarkTheme
                                    ? akvaMainNeutral
                                    : akvaDarkColorD,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
        Divider(
          color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
          height: 1,
          thickness: 1.3,
        ),
      ],
    );
  }
}

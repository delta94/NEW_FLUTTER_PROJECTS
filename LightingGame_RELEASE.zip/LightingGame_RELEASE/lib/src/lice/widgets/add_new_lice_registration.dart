import 'package:Commons/buttons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/base_view_model.dart';
import 'package:control_app/src/lice/widgets/fish_sample_BODY.dart';
import 'package:control_app/src/lice/widgets/quarantine_body.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/lice/widgets/sedation_body.dart';
import 'Package:flutter/material.dart';
import 'package:Commons/colors.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/routers.dart';
import 'package:control_app/src/widgets/add_new_registration_ui/add_new_registration_button.dart';
import 'package:control_app/src/widgets/common_heaher.dart';
import 'package:control_app/src/widgets/confirmation_dialog/confirmation_modal.dart';
import 'package:control_app/src/widgets/offline_status.dart';
import 'package:control_app/src/widgets/synchronize_progress_status.dart';
import 'package:provider/provider.dart';

import 'sign_submit_body.dart';

enum AddNewLiceScreenType {
  SEDATION,
  QUARANTINE,
  ADD_FISH_SAMPLE,
  SAVE_FISH_SAMPLE,
  SIGN_SUBMIT,
  NEW_REGISTRATION
}

const double BOTTOM_PADDING = 19;

class AddNewLiceRegistration extends StatefulWidget {
  final AddNewLiceScreenType addNewLiceScreenType;
  AddNewLiceRegistration({this.addNewLiceScreenType});

  @override
  _AddNewLiceRegistrationState createState() => _AddNewLiceRegistrationState();
}

class _AddNewLiceRegistrationState extends State<AddNewLiceRegistration> {
  bool isAllowedToSave = true;
  int fishIndex = 0;
  String bottomTitleButton = '';
  SavingStatusEnum savingStatusEnum = SavingStatusEnum.NOT_SAVE;

  @override
  void initState() {
    if (widget.addNewLiceScreenType == AddNewLiceScreenType.SEDATION) {
      var liceSampleViewModel =
          Provider.of<LiceSampleViewModel>(context, listen: false);
      liceSampleViewModel.addNewLiceSample();
    }

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    OrganizationModel organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);
    LiceSampleViewModel liceSampleViewModel =
        Provider.of<LiceSampleViewModel>(context);
    LiceSample liceSample = liceSampleViewModel.currentLiceSample.item;

    AddNewLiceScreenType _addNewLiceScreenType = widget.addNewLiceScreenType;

    if (_addNewLiceScreenType == AddNewLiceScreenType.ADD_FISH_SAMPLE) {
      if (liceSampleViewModel.currentSampleNumber == -1)
        _addNewLiceScreenType = AddNewLiceScreenType.SAVE_FISH_SAMPLE;
    }

    bool isSecondaryButton =
        _addNewLiceScreenType != AddNewLiceScreenType.SIGN_SUBMIT;

    _setSecondaryButtonTitle() {
      switch (_addNewLiceScreenType) {
        case AddNewLiceScreenType.SEDATION:
          bottomTitleButton = appText.save_sedation_13;
          break;
        case AddNewLiceScreenType.QUARANTINE:
          bottomTitleButton = appText.save_quarantine_23;
          break;
        case AddNewLiceScreenType.ADD_FISH_SAMPLE:
          bottomTitleButton = appText.add_fish_sample;
          break;
        case AddNewLiceScreenType.SAVE_FISH_SAMPLE:
          bottomTitleButton = appText.save_sample_23;
          break;
        default:
          break;
      }
    }

    _setPrimaryButtonTitle() {
      if (_addNewLiceScreenType == AddNewLiceScreenType.SIGN_SUBMIT) {
        bottomTitleButton = appText.sign_submit;
      } else {
        bottomTitleButton = appText.new_registration;
      }
    }

    if (isSecondaryButton)
      _setSecondaryButtonTitle();
    else
      _setPrimaryButtonTitle();

    _onRightButton() {
      Navigator.of(context).popUntil(ModalRoute.withName(Routers.lice));
    }

    _onClose() {
      showConfirmationModal(
        context: context,
        title: appText.unsaved_changes,
        messages: [
          appText.you_have_unsaved_changes,
          appText.are_you_sure_you_want_to_continue
        ],
        leftButtonTitle: appText.no,
        rightButtonTitle: appText.yes,
        onTapRightButton: _onRightButton,
      );

      return Future<bool>.value(false);
    }

    _getNewLiceSampleBody() {
      switch (_addNewLiceScreenType) {
        case AddNewLiceScreenType.SEDATION:
          return SedationBody(
            bottomPadding: BOTTOM_PADDING,
            isEditingMode: true,
            validateToSave: (isValid) {
              Future.delayed(Duration.zero, () {
                setState(() {
                  isAllowedToSave = isValid;
                });
              });
            },
            liceSample: liceSample,
          );
        case AddNewLiceScreenType.QUARANTINE:
          return QuarantineBody(
            bottomPadding: BOTTOM_PADDING,
            isEditingMode: true,
            validateToSave: (isValid) => setState(() {
              isAllowedToSave = isValid;
            }),
            liceSample: liceSample,
          );
        case AddNewLiceScreenType.ADD_FISH_SAMPLE:
        case AddNewLiceScreenType.SAVE_FISH_SAMPLE:
          return FishSampleBody(
            bottomPadding: BOTTOM_PADDING,
            validateToSave: (isValid) => setState(() {
              isAllowedToSave = isValid;
            }),
          );
        case AddNewLiceScreenType.SIGN_SUBMIT:
          return SignSubmitBody(
            validateToSave: (isValid) => setState(() {
              isAllowedToSave = isValid;
            }),
          );
        default:
          return Container();
      }
    }

    _navigateToNewScreen(AddNewLiceScreenType addNewLiceScreenType) {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (context) => AddNewLiceRegistration(
              addNewLiceScreenType: addNewLiceScreenType),
        ),
      );
    }

    _navigateToAddFishSample() {
      /// Create new sample if there is no sample.
      if (!liceSampleViewModel.hasSample) {
        liceSampleViewModel.addNewSample();
      }
      _navigateToNewScreen(AddNewLiceScreenType.ADD_FISH_SAMPLE);
    }

    _onBottonButton() async {
      switch (_addNewLiceScreenType) {
        case AddNewLiceScreenType.SEDATION:
          if (liceSample.quarantineDetails == null) {
            _navigateToAddFishSample();
          } else {
            _navigateToNewScreen(AddNewLiceScreenType.QUARANTINE);
          }
          break;
        case AddNewLiceScreenType.QUARANTINE:
          _navigateToAddFishSample();
          break;
        case AddNewLiceScreenType.ADD_FISH_SAMPLE:
          setState(() {
            liceSampleViewModel.addNewSample();
          });
          break;
        case AddNewLiceScreenType.SAVE_FISH_SAMPLE:
          _navigateToNewScreen(AddNewLiceScreenType.SIGN_SUBMIT);
          break;
        case AddNewLiceScreenType.SIGN_SUBMIT:
          await liceSampleViewModel.signAndSubmit();
          setState(() {
            savingStatusEnum = SavingStatusEnum.SAVED;
          });

          Future.delayed(Duration(seconds: 1), () {
            Navigator.of(context).popUntil(ModalRoute.withName(Routers.lice));
          });

          break;
        default:
          break;
      }
    }

    return Stack(
      children: [
        Scaffold(
          backgroundColor:
              appModel.isDarkTheme ? akvaDarkColorC : akvaDarkColorE,
          body: SingleChildScrollView(
            child: SafeArea(
              child: Container(
                color: appModel.isDarkTheme ? akvaDarkColorC : akvaLightColorA,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    SynchronizeProgressStatus(),
                    OfflineStatus(),
                    CommonHeader(
                      showBackButton: _addNewLiceScreenType !=
                          AddNewLiceScreenType.SEDATION,
                      unitName:
                          organizationModel.currentOrganizationEntity.name,
                      headerTitle: appText.new_lice_sample,
                      onClose: () => _onClose(),
                      onBack: () => Navigator.of(context).pop(),
                    ),
                    Divider(
                      color: appModel.isDarkTheme
                          ? akvaDarkColorD
                          : akvaLightColorD,
                      thickness: 1,
                      height: 0,
                    ),
                    _getNewLiceSampleBody(),
                  ],
                ),
              ),
            ),
          ),
          bottomNavigationBar: Container(
            color: appModel.isDarkTheme ? akvaDarkColorC : akvaLightColorA,
            child: Padding(
              padding:
                  const EdgeInsets.only(left: 20.0, right: 20.0, bottom: 30.0),
              child: isSecondaryButton
                  ? AkvaSecondaryButton(
                      fontWeight: FontWeight.bold,
                      label: bottomTitleButton,
                      onPressed: isAllowedToSave ? _onBottonButton : null,
                    )
                  : AddNewRegistrationButton(
                      buttonTitle: bottomTitleButton,
                      isBusy: liceSampleViewModel.busy,
                      savingStatusEnum: savingStatusEnum,
                      isAllowedToSave: isAllowedToSave,
                      onPressSave: () => _onBottonButton(),
                    ),
              // AkvaPrimaryButton(
              //     fontWeight: FontWeight.bold,
              //     label: bottomTitleButton,
              //     onPressed: isAllowedToSave &&
              //             savingStatusEnum == SavingStatusEnum.NOT_SAVE
              //         ? _onBottonButton
              //         : null,
              //   ),
            ),
          ),
        ),
      ],
    );
  }
}

import 'package:Commons/buttons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/lice/widgets/all_info.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import 'fish_info.dart';

class FishSampleBody extends StatefulWidget {
  final double bottomPadding;
  final Function(bool) validateToSave;

  const FishSampleBody({Key key, this.validateToSave, this.bottomPadding})
      : super(key: key);

  @override
  _FishSampleBodyState createState() => _FishSampleBodyState();
}

class _FishSampleBodyState extends State<FishSampleBody> {
  bool showDialog = false;
  bool isAllowedToSave = true;

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    final liceSampleViewModel =
        Provider.of<LiceSampleViewModel>(context, listen: false);
    LiceSample liceSample = liceSampleViewModel.currentLiceSample.item;
    bool showAllInfo = liceSampleViewModel.currentSampleNumber == -1;

    List<Widget> _buildFishList() {
      List<Widget> fishList = [];
      liceSample.samples.forEach((sample) {
        if (sample.individCount == 1) {
          fishList.add(
            Wrap(
              children: [
                SizedBox(width: 16),
                Container(
                  margin: EdgeInsets.only(left: 0),
                  child: ButtonTheme(
                    minWidth: 45,
                    child: AkvaTabBarButton(
                      onPressed: () => liceSampleViewModel
                          .setCurrentSampleNumber(sample.measureId),
                      label: '${appText.fish} ${sample.measureId}',
                      selected: liceSampleViewModel.currentSampleNumber ==
                          sample.measureId,
                      isDarkTheme: appModel.isDarkTheme,
                    ),
                  ),
                ),
              ],
            ),
          );
        }
      });

      if (liceSample.samples.length > 2)
        fishList.add(
          Container(
            margin: EdgeInsets.only(left: 16, top: 6, bottom: 8, right: 16),
            child: ButtonTheme(
              minWidth: 45,
              child: AkvaTabBarButton(
                onPressed: () => liceSampleViewModel.setCurrentSampleNumber(-1),
                label: appText.all,
                selected: showAllInfo,
                isDarkTheme: appModel.isDarkTheme,
              ),
            ),
          ),
        );

      return fishList;
    }

    List<Widget> fishWidgetList = _buildFishList();
    return Column(
      children: <Widget>[
        Container(
          height: 50,
          margin: EdgeInsets.only(top: 10),
          child: new ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: fishWidgetList.length,
              itemBuilder: (BuildContext ctxt, int index) {
                return fishWidgetList[index];
              }),
        ),
        SizedBox(height: showAllInfo ? 0 : 15),
        showAllInfo
            ? AllInfo(
                liceSample: liceSample,
                bottomPadding: widget.bottomPadding,
                isViewMode: false)
            : FishInfo(
                key: ObjectKey(liceSampleViewModel.currentSampleNumber),
                bottomPadding: widget.bottomPadding,
                isEditingMode: true,
                fishSampleId: liceSampleViewModel.currentSampleNumber,
                liceSample: liceSample,
              ),
      ],
    );
  }
}

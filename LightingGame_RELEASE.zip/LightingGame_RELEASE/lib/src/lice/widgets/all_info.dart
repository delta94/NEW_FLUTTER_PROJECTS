import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/lice/widgets/fish_info.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:control_app/src/widgets/registration_title.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import 'lice_registration_part.dart';
import 'quarantine_body.dart';
import 'sedation_body.dart';

class AllInfo extends StatefulWidget {
  const AllInfo({
    Key key,
    this.isViewMode: false,
    @required this.liceSample,
    this.bottomPadding,
  }) : super(key: key);

  final bool isViewMode;
  final LiceSample liceSample;
  final double bottomPadding;

  @override
  _AllInfoState createState() => _AllInfoState();
}

class _AllInfoState extends State<AllInfo> {
  GlobalKey allInfoBodyHeightKey = GlobalKey();
  double allInfoBodyHeight = 0;
  ScrollController scrollController = ScrollController();
  bool isReturnedToUnit = false;

  @override
  void initState() {
    if (widget.liceSample != null) {
      final liceSampleViewModel =
          Provider.of<LiceSampleViewModel>(context, listen: false);
      final liceSample =
          liceSampleViewModel.currentLiceSample.item as LiceSample;
      liceSample.commit();
    }

    WidgetsBinding.instance.addPostFrameCallback(_getBodyPositionY);
    super.initState();
  }

  void _getBodyPositionY(_) {
    final RenderBox registrationListKeyBox =
        allInfoBodyHeightKey.currentContext.findRenderObject();
    Offset position = registrationListKeyBox.localToGlobal(Offset.zero);
    double infoListPositionY = position.dy;
    setState(() {
      allInfoBodyHeight = MediaQuery.of(context).size.height -
          infoListPositionY -
          kBottomNavigationBarHeight -
          widget.bottomPadding;
    });
  }

  @override
  Widget build(BuildContext context) {
    final liceSampleViewModel =
        Provider.of<LiceSampleViewModel>(context, listen: false);
    return Container(
      padding: EdgeInsets.only(top: 0),
      child: Column(
        children: <Widget>[
          SizedBox(height: 8),
          Padding(
            padding: EdgeInsets.symmetric(vertical: 5, horizontal: 19),
            child: RegistrationTitle(
              isViewMode: widget.isViewMode,
              discardChanges: () => liceSampleViewModel.discardChanges(),
              isEditingCountMode: liceSampleViewModel.isEditingRegistrationMode,
              setEditingModeTrue: () =>
                  liceSampleViewModel.isEditingRegistrationMode = true,
            ),
          ),
          SizedBox(height: 10),
          Container(
            key: allInfoBodyHeightKey,
            height: allInfoBodyHeight,
            child: MediaQuery.removePadding(
              removeTop: true,
              context: context,
              child: SingleChildScrollView(
                key: ObjectKey('key'),
                controller: scrollController,
                child: AllInfoContent(
                  isViewMode: widget.isViewMode,
                  liceSample: widget.liceSample,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class AllInfoContent extends StatelessWidget {
  const AllInfoContent({
    Key key,
    @required this.isViewMode,
    @required this.liceSample,
  }) : super(key: key);

  final bool isViewMode;
  final LiceSample liceSample;

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    LiceSampleViewModel liceSampleViewModel =
        Provider.of<LiceSampleViewModel>(context, listen: false);

    _isEditing() {
      return isViewMode ? false : liceSampleViewModel.isEditingRegistrationMode;
    }

    _buildFishRegistrationWidgetList() {
      List<Widget> fishRegistrationList = [];
      liceSample.samples.asMap().forEach((index, sample) {
        fishRegistrationList.add(LiceRegistrationPart(
          title: sample.measureId >= 0
              ? '${appText.fish} ${sample.measureId}'
              : '${appText.sedation_tank}',
          measureId: sample.measureId,
          isEditingMode: _isEditing(),
          fishSampleId: sample.measureId,
          infoWidget: FishInfo(
            isFreeHeight: true,
            isSedationTank: sample.measureId < 0,
            isEditingMode: _isEditing(),
            fishSampleId: sample.measureId,
            liceSample: liceSample,
          ),
          liceSample: liceSample,
        ));
      });

      return fishRegistrationList;
    }

    return Column(
      children: <Widget>[
        LiceRegistrationPart(
          title: appText.sedation,
          isEditingMode: _isEditing(),
          infoWidget: SedationBody(
            liceSample: liceSample,
            isFreeHeight: true,
            isEditingMode: _isEditing(),
            validateToSave: (isValid) {},
          ),
          liceSample: liceSample,
        ),
        liceSample.quarantineDetails != null
            ? LiceRegistrationPart(
                title: appText.quarantine,
                isEditingMode: _isEditing(),
                infoWidget: QuarantineBody(
                  liceSample: liceSample,
                  isFreeHeight: true,
                  isEditingMode: _isEditing(),
                  validateToSave: (isValid) {},
                ),
                liceSample: liceSample,
              )
            : Container(),
        ..._buildFishRegistrationWidgetList(),
      ],
    );
  }
}

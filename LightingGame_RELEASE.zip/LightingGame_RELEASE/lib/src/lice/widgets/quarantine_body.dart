import 'package:Commons/colors.dart';
import 'package:Commons/dropdown.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/main/main_screen_helper.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/util/ui_utils.dart';
import 'package:control_app/src/widgets/checkbox_list.dart';
import 'package:control_app/src/widgets/number_input.dart';
import 'package:control_app/src/widgets/radio_group.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import 'lice_input.dart';

class QuarantineBody extends StatefulWidget {
  final Function(bool) validateToSave;
  final bool isFreeHeight;
  final bool isEditingMode;
  final LiceSample liceSample;
  final double bottomPadding;

  const QuarantineBody({
    Key key,
    this.validateToSave,
    this.isFreeHeight: false,
    this.isEditingMode: false,
    @required this.liceSample,
    this.bottomPadding: 0,
  })  : assert(liceSample != null),
        super(key: key);

  @override
  _QuarantineBodyState createState() => _QuarantineBodyState();
}

class _QuarantineBodyState extends State<QuarantineBody> {
  double quarantineBodyHeight = 0;
  ScrollController scrollController = ScrollController();

  /// 0: and, 1: or
  int currentOperatorIndex = 0;

  /// 0: automatic clearance at the end of the biological
  /// clearance period
  /// 1: Requires formal clearance
  int currentClearanceIndex = 0;
  bool showDialog = false;

  final TextEditingController daysController = new TextEditingController();
  final TextEditingController degreeDaysController =
      new TextEditingController();
  DateTime currentDate = DateTime.now();
  bool isAllowedToSave = true;
  DateTime registrationDateTime;
  Registration currentRegistration;
  final List<OptionItem> selectedUnits = new List<OptionItem>();
  List<Unit> units;
  final List<int> checkedConsequences = new List<int>();
  @override
  void initState() {
    final liceSampleViewModel =
        Provider.of<LiceSampleViewModel>(context, listen: false);

    daysController.addListener(() {
      var days = int.tryParse(daysController.text);
      (liceSampleViewModel.currentLiceSample.item as LiceSample)
          .withdrawal
          .days = days;
      liceSampleViewModel.updateOverrideWithdrawal();
    });
    degreeDaysController.addListener(() {
      var degDays = int.tryParse(degreeDaysController.text);
      (liceSampleViewModel.currentLiceSample.item as LiceSample)
          .withdrawal
          .atus = degDays;
      liceSampleViewModel.updateOverrideWithdrawal();
    });

    WidgetsBinding.instance.addPostFrameCallback(_getBodyHeight);
    super.initState();
  }

  void _getBodyHeight(_) {
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    setState(() {
      quarantineBodyHeight = MediaQuery.of(context).size.height -
          183 -
          UiUtils.getSyncConnectionBarHeight(appModel) -
          kBottomNavigationBarHeight -
          widget.bottomPadding;
    });
  }

  bool getConsequence(LiceSample liceSample, Consequence consequenceType) =>
      liceSample != null &&
      liceSample.quarantineDetails != null &&
      (liceSample.quarantineDetails.consequences &
              (1 << consequenceType.index)) !=
          0;

  _initData() {
    daysController.text = widget.liceSample.withdrawal != null &&
            widget.liceSample.withdrawal.days != null
        ? widget.liceSample.withdrawal.days.toString()
        : "";
    degreeDaysController.text = widget.liceSample.withdrawal != null &&
            widget.liceSample.withdrawal.atus != null
        ? widget.liceSample.withdrawal.atus.toString()
        : "";
    currentOperatorIndex = widget.liceSample.withdrawal != null
        ? (widget.liceSample.withdrawal.and ? 0 : 1)
        : 0;
    currentClearanceIndex = widget.liceSample.quarantineDetails != null &&
            widget.liceSample.quarantineDetails.manualClearance == false
        ? 0
        : 1;
    checkedConsequences.clear();
    Consequence.values.forEach((type) {
      if (getConsequence(widget.liceSample, type)) {
        checkedConsequences.add(type.index);
      }
    });
    final organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);
    units = MainScreenHelper.getUnits(organizationModel);
    if (widget.liceSample.quarantineDetails != null) {
      selectedUnits.clear();
      if (widget.liceSample.quarantineDetails.affectedOtherUnits) {
        widget.liceSample.quarantineDetails.affectedUnitIds.forEach((unitId) {
          var unit =
              units.firstWhere((u) => u.id == unitId, orElse: () => null);
          if (unit != null) {
            selectedUnits.add(OptionItem(id: unit.id, label: unit.name));
          }
        });
      } else {
        widget.liceSample.quarantineDetails.affectedUnitIds = List<String>();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    final liceSampleViewModel = Provider.of<LiceSampleViewModel>(context);
    final liceSample = widget.liceSample;
    _initData();
    List<Widget> _buildSelectedUnitWidgets() {
      final List<Widget> shortLiceTypeWidgets = [];
      selectedUnits.forEach((unit) {
        shortLiceTypeWidgets.add(
          Wrap(
            children: <Widget>[
              Text(
                unit.label,
                style: TextStyle(
                  color: appModel.isDarkTheme ? akvaDarkTextB : akvaLightTextB,
                  fontSize: FontSize.small,
                  fontWeight: FontWeight.w500,
                ),
              ),
              SizedBox(width: 15),
            ],
          ),
        );
      });
      return shortLiceTypeWidgets;
    }

    List<Widget> selectedUnitWidgets = _buildSelectedUnitWidgets();

    Widget _getBodyWidget() {
      return MediaQuery.removePadding(
        removeTop: true,
        context: context,
        child: SingleChildScrollView(
          key: PageStorageKey('scroll'),
          controller: scrollController,
          child: Column(
            children: <Widget>[
              Row(
                children: <Widget>[
                  Text(
                    appText.duration,
                    style: TextStyle(
                      fontSize: FontSize.small,
                      fontWeight: FontWeight.normal,
                    ),
                    textAlign: TextAlign.left,
                  ),
                ],
              ),
              SizedBox(height: 5),
              Row(
                children: <Widget>[
                  LiceInput(
                    enable: widget.isEditingMode,
                    inputController: daysController,
                    numberInputType: NumberInputType.INT,
                    unitName: appText.days,
                    inputWidth: 128,
                    unitWidth: 50,
                  ),
                  SizedBox(width: 20),
                  RadioGroup(
                    enable: widget.isEditingMode,
                    direction: Axis.horizontal,
                    currentRadioIndex: currentOperatorIndex,
                    radioTitles: [appText.and, appText.or],
                    onChangeRadioIndex: (newRadioInxex) => setState(() {
                      currentOperatorIndex = newRadioInxex;
                      (liceSampleViewModel.currentLiceSample.item as LiceSample)
                          .withdrawal
                          .and = currentOperatorIndex == 0;
                      liceSampleViewModel.updateOverrideWithdrawal();
                    }),
                  ),
                ],
              ),
              SizedBox(height: 20),
              LiceInput(
                enable: widget.isEditingMode,
                inputController: degreeDaysController,
                numberInputType: NumberInputType.INT,
                unitName: appText.degree_days,
                inputWidth: 168,
                unitWidth: 110,
              ),
              SizedBox(height: 21),
              Divider(
                color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
                thickness: 1,
                height: 0,
              ),
              SizedBox(height: 20),
              CheckboxList(
                paddingRight: 7,
                enable: widget.isEditingMode,
                title: appText.quarantine_consequences,
                checkboxTitles: [
                  appText.cannot_be_harvested,
                  appText.cannot_be_sold_or_transferred_to_another_site,
                  appText.cannot_be_mixed_with_other_populations,
                  appText.cannot_be_transferred_to_another_unit,
                ],
                checkedIndices: checkedConsequences,
                onChangeCheckedBoxIndices: () {
                  Consequence.values.forEach((type) {
                    liceSampleViewModel.setConsequence(type, false);
                  });
                  checkedConsequences.forEach((index) {
                    liceSampleViewModel.setConsequence(
                        Consequence.values[index], true);
                  });
                },
              ),
              SizedBox(height: 21),
              Divider(
                color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
                thickness: 1,
                height: 0,
              ),
              SizedBox(height: 20),
              CheckboxList(
                paddingRight: 7,
                enable: widget.isEditingMode,
                title: appText.quarantine_other_units,
                checkboxTitles: [
                  appText.affects_other_units_on_the_site,
                ],
                checkedIndices: liceSample.quarantineDetails != null &&
                        liceSample.quarantineDetails.affectedOtherUnits
                    ? <int>[0]
                    : <int>[],
                onChangeCheckedBoxIndices: () {
                  setState(() {
                    var liceSample = liceSampleViewModel.currentLiceSample.item
                        as LiceSample;
                    liceSample.quarantineDetails.affectedOtherUnits =
                        !liceSample.quarantineDetails.affectedOtherUnits;
                    // if (!liceSample.quarantineDetails.affectedOtherUnits) {
                    //   if (liceSample
                    //       .quarantineDetails.affectedUnitIds.isNotEmpty) {
                    //     liceSample.quarantineDetails.affectedUnitIds.clear();
                    //   }
                    //   checkedQuarantineOtherUnits.clear();
                    //   selectedUnits.clear();
                    // }
                  });
                },
              ),
              Stack(
                children: <Widget>[
                  Column(
                    children: <Widget>[
                      Container(
                          height: liceSample.quarantineDetails != null &&
                                  liceSample
                                      .quarantineDetails.affectedOtherUnits &&
                                  widget.isEditingMode
                              ? 55
                              : 0),
                      Visibility(
                        visible: !widget.isEditingMode,
                        child: Container(
                          height: 20,
                          margin: EdgeInsets.only(top: 20),
                          child: new ListView.builder(
                              scrollDirection: Axis.horizontal,
                              itemCount: selectedUnitWidgets.length,
                              itemBuilder: (BuildContext ctxt, int index) {
                                return selectedUnitWidgets[index];
                              }),
                        ),
                      ),
                      SizedBox(height: 21),
                      Divider(
                        color: appModel.isDarkTheme
                            ? akvaDarkColorB
                            : akvaLightColorC,
                        thickness: 1,
                        height: 0,
                      ),
                      SizedBox(height: 20),
                      Row(
                        children: <Widget>[
                          Text(
                            appText.clearance,
                            style: TextStyle(
                              fontSize: FontSize.small,
                              fontWeight: FontWeight.normal,
                            ),
                            textAlign: TextAlign.left,
                          ),
                        ],
                      ),
                      SizedBox(height: 15),
                      RadioGroup(
                        enable: widget.isEditingMode,
                        direction: Axis.vertical,
                        currentRadioIndex: currentClearanceIndex,
                        radioTitles: [
                          appText
                              .automatic_clearance_at_the_end_of_the_biological_clearance_period,
                          appText.requires_formal_clearance
                        ],
                        onChangeRadioIndex: (newRadioInxex) => setState(() {
                          currentClearanceIndex = newRadioInxex;
                          widget.liceSample.quarantineDetails.manualClearance =
                              currentClearanceIndex == 1 ? true : false;
                        }),
                      ),
                      SizedBox(height: 50),
                    ],
                  ),
                  Visibility(
                    visible: liceSample.quarantineDetails != null &&
                        liceSample.quarantineDetails.affectedOtherUnits,
                    child: Padding(
                      padding: const EdgeInsets.only(
                        right: 27,
                        top: 10,
                        bottom: 20,
                      ),
                      child: Visibility(
                        visible: widget.isEditingMode,
                        child: AkvaDropDown(
                          enable: widget.isEditingMode,
                          items: units
                              .map((unit) =>
                                  OptionItem(id: unit.id, label: unit.name))
                              .toList(),
                          showSelectAllCheckbox: true,
                          ontoggleSelectAll: (items) => setState(() {
                            widget.liceSample.quarantineDetails
                                    .affectedUnitIds =
                                items
                                    .map((item) => item.id.toString())
                                    .toList();
                          }),
                          onSelectedItem: (item) {
                            setState(() {
                              bool existed = selectedUnits
                                  .any((unitItem) => unitItem.id == item.id);
                              List<String> list = List.from(widget.liceSample
                                  .quarantineDetails.affectedUnitIds);
                              if (existed) {
                                list.removeWhere((unitId) => unitId == item.id);
                              } else {
                                list.add(item.id);
                              }
                              widget.liceSample.quarantineDetails
                                  .affectedUnitIds = list;
                            });
                          },
                          hint: appText.units,
                          selectedItems: selectedUnits,
                          isDarkTheme: appModel.isDarkTheme,
                        ),
                      ),
                    ),
                  ),
                ],
              )
            ],
          ),
        ),
      );
    }

    return Padding(
      padding: const EdgeInsets.only(left: 20.0, top: 16.0),
      child: Container(
        padding: EdgeInsets.only(top: 0),
        height: widget.isFreeHeight ? null : quarantineBodyHeight,
        child: widget.isFreeHeight
            ? _getBodyWidget()
            : Scrollbar(
                key: PageStorageKey('scroll'),
                isAlwaysShown: true,
                controller: scrollController,
                child: _getBodyWidget(),
              ),
      ),
    );
  }
}

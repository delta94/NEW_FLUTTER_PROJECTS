import 'dart:async';
import 'package:control_app/src/cloud/organization_cloud_repository.dart';

import '../repositories/organization_repository.dart';
import '../models/site_model.dart';
import 'package:rxdart/rxdart.dart';

// TODO: Delete after blocs are converted to models
class OrganizationBloc {
  static final OrganizationBloc _instance = OrganizationBloc._internal();
  final _organizationRepository = OrganizationCloudRepository();

  final _organizationItems = BehaviorSubject<OrganizationRoot>();
  final _currentOrganizationEntity = BehaviorSubject<OrganizationEntity>();
  static var _organizationRoot;

  factory OrganizationBloc() {
    return _instance;
  }
  Future initialize() async {}

  OrganizationBloc._internal() {
    _fetchSites();
  }

  Observable<OrganizationRoot> get siteListStream => _organizationItems.stream;

  Observable<OrganizationEntity> get currentOrganizationEntityStream =>
      _currentOrganizationEntity.stream;
  OrganizationEntity get currentOrganizationEntity =>
      _currentOrganizationEntity.value;

  Observable<List<OrganizationEntity>> get navStackStream =>
      _currentOrganizationEntity.stream.transform(_navHistoryTransformer);

  _fetchSites() async {
    _organizationRoot = await _organizationRepository.fetchOrganization();
    _organizationItems.sink.add(_organizationRoot);
    _currentOrganizationEntity.sink.add(_organizationRoot);
  }

  setCurrentEntity(OrganizationEntity organizationEntity) {
    _currentOrganizationEntity.sink.add(organizationEntity);
  }

  setCurrentEntityFromId(String id) {
    final entity = findEntity(id, _organizationRoot);
    if (entity != null) {
      setCurrentEntity(entity);
    }
  }

  void resetNavigation() {
    setCurrentEntity(_organizationRoot);
  }

  bool isCurrentOrganizationSite() {
    if (currentOrganizationEntity is Site) {
      return true;
    } else if (currentOrganizationEntity is Unit) {
      return false;
    }
    return null;
  }

  void dispose() {
    _organizationItems.close();
    _currentOrganizationEntity.close();
  }

  final _navHistoryTransformer = StreamTransformer<OrganizationEntity,
      List<OrganizationEntity>>.fromHandlers(handleData: (orgEntity, sink) {
    final entity = findEntity(orgEntity.id, _organizationRoot);
    var reversedEntityPath = List<OrganizationEntity>();
    if (entity.id != _organizationRoot.id) {
      reversedEntityPath.add(entity);
    }
    var currentParent = entity.parent;
    while (currentParent?.parent != null) {
      reversedEntityPath.add(currentParent);
      currentParent = currentParent.parent;
    }
    sink.add(reversedEntityPath.reversed.toList());
  });

  // Search for *any* of the ids mapped to an entity
  static OrganizationEntity findEntity(
      String id, OrganizationEntity startEntity) {
    if (startEntity.id == id ||
        (startEntity.extIds != null && startEntity.extIds.contains(id))) {
      return startEntity;
    }
    if (startEntity.children.length < 1) {
      return null;
    }
    for (final child in startEntity.children) {
      final result = findEntity(id, child);
      if (result != null) {
        return result;
      }
    }
    return null;
  }
}

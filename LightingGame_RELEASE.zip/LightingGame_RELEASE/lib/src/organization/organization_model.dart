import 'dart:collection';
import 'dart:convert';

import 'package:control_app/src/base/base_view_model.dart';
import 'package:control_app/src/database/quick_access_sqlite_repository.dart';
import 'package:control_app/src/models/feeding/feed_type_available.dart';
import 'package:control_app/src/models/feeding/site_feed_types.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/species.dart';
import 'package:control_app/src/models/quick_access.dart';
import 'package:control_app/src/models/unit_status.dart';
import 'package:control_app/src/models/user_right.dart';
import 'package:control_app/src/organization/organizationListener.dart';
import 'package:control_app/src/repositories/cloud_registration_repository.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/services/timezone_service.dart';
import 'package:control_app/src/util/constants.dart';
import '../models/site_model.dart';
import '../app_model.dart';
import 'package:control_app/src/database/app_config_db_repository.dart';
import 'package:data_connection_checker/data_connection_checker.dart';

import '../cloud/organization_cloud_repository.dart';
import '../database/organization_db_repository.dart';
import '../models/organization_unit.dart';
import '../shared_data_model.dart';

enum AccessType { Favorite, FrequentlyVisit }

class OrganizationModel extends BaseViewModel {
  static final OrganizationModel _instance = OrganizationModel._internal();
  AppModel _appModel;
  SharedDataModel _sharedDataModel;
  static var _organizationTree;
  static var _organizationRoot;
  UserRight _userRight;
  Map<String, List<int>> _unitSpecieMap = Map<String, List<int>>();
  Map<String, UnitStatus> _unitStatusMap = Map<String, UnitStatus>();
  Map<String, List<FeedTypeAvailable>> _siteFeedTypesMap =
      Map<String, List<FeedTypeAvailable>>();

  List<Site> get siteList => _getSiteList();
  List<Species> get speciesOfCurrentUnit => _getSpeciesOfCurrentUnit();
  UnitStatus get unitStatus => _unitStatusMap[currentUnit.id];
  Unit get currentUnit => _getCurrentUnit();
  Site get currentSite => _getCurrentSite();
  Map<RegistrationType, RegistrationUserRight> registrationUserRightMap = {};

  factory OrganizationModel() {
    return _instance;
  }

  OrganizationModel._internal();

  HashSet<OrganizationEventListener> _eventListeners = HashSet();

  _getCurrentUnit() {
    if (currentOrganizationEntity != null &&
        currentOrganizationEntity is Unit) {
      return currentOrganizationEntity;
    }
    return null;
  }

  _getCurrentSite() {
    if (currentOrganizationEntity != null) {
      if (currentOrganizationEntity is Unit) {
        return currentOrganizationEntity.parent;
      } else if (currentOrganizationEntity is Site) {
        return currentOrganizationEntity;
      }
    }
    return null;
  }

  /// Get a list of [FeedTypeAvailable] of a current unit
  List<FeedTypeAvailable> get feedTypesOfCurrentUnit =>
      _getFeedTypesOfCurrentUnit();

  List<Site> _getSiteList() {
    List<Site> result = List<Site>();
    if (_organizationRoot != null && _organizationRoot.children != null) {
      List<Site> sites = _organizationRoot.children;
      for (Site site in sites) {
        if (!site.isHidden) {
          if (_sharedDataModel.tenantInfo != null &&
              _sharedDataModel.tenantInfo.timeZoneId != null &&
              site.timeZoneId == null) {
            site.timeZoneId = _sharedDataModel.tenantInfo.timeZoneId;
          }
          result.add(site);
        }
      }
    }

    return result;
  }

  /// Get list of Feed Type of current Unit
  ///
  /// Returns list of [FeedTypeAvailable] of a current unit
  List<FeedTypeAvailable> _getFeedTypesOfCurrentUnit() {
    List<FeedTypeAvailable> feedTypesAvailable = new List<FeedTypeAvailable>();
    var unit = currentOrganizationEntity;
    if (unit != null && _siteFeedTypesMap.containsKey(unit.parent.id)) {
      var feedTypeAvailables = _siteFeedTypesMap[unit.parent.id];
      feedTypeAvailables.sort((a, b) => a.feedTypeId.compareTo(b.feedTypeId));

      final feedTypeMap = _sharedDataModel.feedTypes;
      final feedStoreMap = _sharedDataModel.feedStores;
      final Map<int, List<FeedTypeAvailable>> feedTypeAvailableMap = {};

      feedTypeAvailables.forEach((x) {
        if (feedTypeMap.containsKey(x.feedTypeId) &&
            feedStoreMap.containsKey(x.feedStoreId)) {
          final feedTypeName = feedTypeMap[x.feedTypeId].name;
          if (feedTypeAvailableMap.containsKey(x.feedTypeId)) {
            x.name = feedTypeName + ' (${feedStoreMap[x.feedStoreId].name})';

            feedTypeAvailableMap[x.feedTypeId].forEach((y) {
              y.name = feedTypeName + ' (${feedStoreMap[y.feedStoreId].name})';
            });
          } else {
            x.name = feedTypeName;

            feedTypeAvailableMap[x.feedTypeId] = [];
          }

          feedTypeAvailableMap[x.feedTypeId].add(x);

          x.wrasse = feedTypeMap[x.feedTypeId].wrasse;

          if (x.endTime == null ||
              (x.endTime != null && x.endTime.isAfter(DateTime.now()))) {
            feedTypesAvailable.add(x);
          }
        }
      });
    }

    return feedTypesAvailable;
  }

  List<Species> _getSpeciesOfCurrentUnit() {
    var unit = currentOrganizationEntity;
    if (unit != null && _unitSpecieMap.containsKey(unit.id)) {
      List<int> speciesIds = _unitSpecieMap[unit.id];

      var languageCode = _appModel.currentLocale.languageCode;

      if (_sharedDataModel.species.containsKey(languageCode)) {
        List<Species> result =
            _sharedDataModel.species[languageCode].where((x) {
          return speciesIds.contains(x.speciesId);
        }).toList();

        var ids = result.map((f) => f.speciesId).toList();

        var notExistedIds = speciesIds.where((x) => !ids.contains(x));

        if (notExistedIds.length > 0) {
          var additionalSpecies = _sharedDataModel.species["?"].where((x) {
            return notExistedIds.contains(x.speciesId);
          }).toList();

          result.addAll(additionalSpecies);
        }

        return result;
      } else {
        return _sharedDataModel.species["?"].where((x) {
          return speciesIds.contains(x.speciesId);
        }).toList();
      }
    } else {
      return [];
    }
  }

  fetchIfConnected(Function function) {
    if (_appModel.connectionStatus == DataConnectionStatus.connected) {
      function();
    }
  }

  Future fetchSiteStatus() async {
    final sitelist = siteList;

    if (siteList != null && siteList.length > 0) {
      final repos = OrganizationCloudRepository();

      await repos.fetchUnitStatusBySite(sitelist).then((onValue) {
        _unitStatusMap.clear();
        _unitStatusMap.addAll(onValue);
      });

      List<UnitStatus> statusList = [];

      _unitStatusMap.forEach((key, value) {
        statusList.add(value);
      });

      try {
        await AppConfigDBRepository.saveAppConfig(
            AppConfigKeys.unitsStatus, unitStatusToMap(statusList));
      } catch (e) {
        print('Exception during encode status list: ' + e);
      }
    }
  }

  loadSiteStatus() async {
    final sitelist = siteList;

    if (sitelist != null && sitelist.length > 0) {
      var siteIds = sitelist.map((f) => f.id).toList();

      final repos = OrganizationDBRepository();

      await repos.fetchUnitStatus(siteIds).then((onValue) {
        _unitStatusMap.clear();
        _unitStatusMap.addAll(onValue);
      });
    }
  }

  Future fetchSiteSpecies() async {
    final sitelist = siteList;

    if (sitelist != null && sitelist.length > 0) {
      var siteIds = sitelist.map((f) => f.id).toList();

      final repos = OrganizationCloudRepository();

      await repos.fetchUnitSpecies(siteIds).then((onValue) {
        _unitSpecieMap.clear();
        _unitSpecieMap.addAll(onValue);
      });

      await AppConfigDBRepository.saveAppConfig(
          AppConfigKeys.unitsSpecies, jsonEncode(_unitSpecieMap));
    }
  }

  loadSiteSpecies() async {
    final sitelist = siteList;

    if (sitelist != null && sitelist.length > 0) {
      var siteIds = sitelist.map((f) => f.id).toList();

      final repos = OrganizationDBRepository();

      await repos.fetchUnitSpecies(siteIds).then((onValue) {
        _unitSpecieMap.clear();
        _unitSpecieMap.addAll(onValue);
      });
    }
  }

  Future fetchSiteFeedTypes() async {
    final sitelist = siteList;

    if (sitelist != null && sitelist.length > 0) {
      var siteIds = sitelist
          .map((f) => f.id)
          .where((siteId) => this._userRight.hasFeedingReadOnSite(siteId))
          .toList();

      final repos = OrganizationCloudRepository();

      await repos.fetchSitesFeedTypes(siteIds).then((onValue) {
        _siteFeedTypesMap.clear();
        _siteFeedTypesMap.addAll(onValue);
      });

      var list = new List<SiteFeedTypes>();

      _siteFeedTypesMap.forEach((key, value) {
        list.add(new SiteFeedTypes(siteId: key, feedTypes: value));
      });

      var json = jsonEncode(List<dynamic>.from(list.map((x) => x.toJson())));

      await AppConfigDBRepository.saveAppConfig(
          AppConfigKeys.siteFeedTypes, json);
    }
  }

  loadSiteFeedTypes() async {
    final sitelist = siteList;

    if (sitelist != null && sitelist.length > 0) {
      var siteIds = sitelist.map((f) => f.id).toList();

      final repos = OrganizationDBRepository();

      await repos.fetchSiteFeedTypes(siteIds).then((onValue) {
        _siteFeedTypesMap.clear();
        _siteFeedTypesMap.addAll(onValue);
      });
    }
  }

  getSpecieName(int speciesId) {
    Species speices = speciesOfCurrentUnit.firstWhere(
        (causesOfDeath) => causesOfDeath.speciesId == speciesId,
        orElse: () => null);

    if (speices == null) return '';
    return speices.name;
  }

  getSiteUserRightForAllModules() {
    String currentSiteId = currentSite.id;
    registrationUserRightMap = {};
    registrationUserRightMap[RegistrationType.Mortality] =
        new RegistrationUserRight(
      allowRead: _userRight.hasMortalityReadOnSite(currentSiteId),
      allowWrite: _userRight.hasMortalityWriteOnSite(currentSiteId),
      allowDelete: _userRight.hasMortalityDeleteOnSite(currentSiteId),
    );

    registrationUserRightMap[RegistrationType.Feeding] =
        new RegistrationUserRight(
      allowRead: _userRight.hasFeedingReadOnSite(currentSiteId),
      allowWrite: _userRight.hasFeedingWriteOnSite(currentSiteId),
      allowDelete: _userRight.hasFeedingDeleteOnSite(currentSiteId),
    );

    registrationUserRightMap[RegistrationType.Culling] =
        new RegistrationUserRight(
      allowRead: _userRight.hasCullingReadOnSite(currentSiteId),
      allowWrite: _userRight.hasCullingWriteOnSite(currentSiteId),
      allowDelete: _userRight.hasCullingDeleteOnSite(currentSiteId),
    );

    registrationUserRightMap[RegistrationType.Environment] =
        new RegistrationUserRight(
      allowRead: _userRight.hasSensorsReadOnSite(currentSiteId),
      allowWrite: _userRight.hasSensorsWriteOnSite(currentSiteId),
      allowDelete: _userRight.hasSensorsDeleteOnSite(currentSiteId),
    );

    registrationUserRightMap[RegistrationType.Lice] = new RegistrationUserRight(
      allowRead: _userRight.hasLiceSampleReadOnSite(currentSiteId),
      allowWrite: _userRight.hasLiceSampleWriteOnSite(currentSiteId),
      allowDelete: _userRight.hasLiceSampleDeleteOnSite(currentSiteId),
    );
  }

  Future _fetchUserRight() async {
    _userRight = await new OrganizationCloudRepository().fetchUserRight();
  }

  Future initializeData() async {
    // Organization Data
    Future organizationData = loadOrganization().then((dynamic) async {
      if (_organizationTree == null) {
        await fetchOrganization();
        await loadOrganization();
      } else {
        fetchIfConnected(fetchOrganization);
      }

      await loadUserRightFromDB().then((userRight) async {
        if (userRight == null) {
          await _fetchUserRight();
          await loadUserRightFromDB();
        } else {
          _userRight = userRight;
          fetchIfConnected(_fetchUserRight);
        }
      });

      await loadSites().then((dynamic) async {
        if (_organizationRoot == null) {
          await fetchSites();
          await loadSites();
        } else {
          fetchIfConnected(fetchSites);
        }
      });

      Future loadQuickAccessSites = QuickAccessSqliteRepository()
          .getByUsername(_appModel.currentUserInfo.email)
          .then((value) => loadAccessList(value));

      Future siteStatus = loadSiteStatus().then((dynamic) async {
        if (_unitStatusMap.isEmpty) {
          await fetchSiteStatus();
          await loadSiteStatus();
        } else {
          fetchIfConnected(fetchSiteStatus);
        }
      });

      Future siteSpecies = loadSiteSpecies().then((dynamic) async {
        if (_unitSpecieMap.isEmpty) {
          await fetchSiteSpecies();
          await loadSiteSpecies();
        } else {
          fetchIfConnected(fetchSiteSpecies);
        }
      });

      Future siteFeedTypes = loadSiteFeedTypes().then((dynamic) async {
        if (_siteFeedTypesMap.isEmpty) {
          await fetchSiteFeedTypes();
          await loadSiteFeedTypes();
        } else {
          fetchIfConnected(fetchSiteFeedTypes);
        }
      });

      if (_appModel.connectionStatus == DataConnectionStatus.connected) {
        await Future.wait(
          [
            fetchLastDate(),
            fetchLastLiceSample(),
            loadQuickAccessSites,
            siteStatus,
            siteSpecies,
            siteFeedTypes
          ],
        );
      } else {
        await Future.wait([siteStatus, siteSpecies]);
      }
    });

    try {
      await Future.wait([organizationData]);
    } catch (e) {
      print('Error=========================: $e');
    } finally {
      notifyListeners();
    }
  }

  Future fetchLastLiceSample() async {
    final sitelist = siteList;

    if (sitelist != null && sitelist.length > 0) {
      var futures = <Future>[];

      for (int i = 0; i < sitelist.length; i++) {
        if (_userRight.hasLiceSampleReadOnSite(sitelist[i].id)) {
          var fetchLastSampleFuture =
              CloudRegistrationRepository(RegistrationType.Lice)
                  .fetchLastSampleBySite(sitelist[i].id)
                  .then((liceSamples) {
            if (liceSamples.length > 0) {
              processDownloadedRegistrations(RegistrationType.Lice,
                  sitelist[i].id, liceSamples, liceSamples[0].time);
            }
            return;
          });

          futures.add(fetchLastSampleFuture);
        } 
      }

      await Future.wait(futures);
    }
  }

  Future fetchLastDate() async {
    DateTime now = DateTime.now();

    final sitelist = siteList;
    if (sitelist != null && sitelist.length > 0) {
      var futures = <Future>[];

      var sensorIds = _getSensorIds(false);

      for (int i = 0; i < sitelist.length; i++) {
        var nowInLocal =
            TimeZoneService.convertToTimezone(now, sitelist[i].timeZoneId);

        if (_userRight.hasMortalityReadOnSite(sitelist[i].id)) {
          var moratlityFuture =
              CloudRegistrationRepository(RegistrationType.Mortality)
                  .fetchBySite(siteId: sitelist[i].id, date: nowInLocal)
                  .then((mortalities) {
            if (mortalities.length > 0) {
              processDownloadedRegistrations(RegistrationType.Mortality,
                  sitelist[i].id, mortalities, nowInLocal);
            }
          });

          futures.add(moratlityFuture);
        }

        if (_userRight.hasFeedingReadOnSite(sitelist[i].id)) {
          var feedingFuture =
              CloudRegistrationRepository(RegistrationType.Feeding)
                  .fetchBySite(siteId: sitelist[i].id, date: nowInLocal)
                  .then((feedings) {
            if (feedings.length > 0) {
              processDownloadedRegistrations(RegistrationType.Feeding,
                  sitelist[i].id, feedings, nowInLocal);
            }
          });

          futures.add(feedingFuture);
        }

        if (_userRight.hasCullingReadOnSite(sitelist[i].id)) {
          var cullingFuture =
              CloudRegistrationRepository(RegistrationType.Culling)
                  .fetchBySite(siteId: sitelist[i].id, date: nowInLocal)
                  .then((cullings) {
            if (cullings.length > 0) {
              processDownloadedRegistrations(RegistrationType.Culling,
                  sitelist[i].id, cullings, nowInLocal);
            }
          });

          futures.add(cullingFuture);
        }

        if (_userRight.hasLiceSampleReadOnSite(sitelist[i].id)) {
          var liceSampleFuture =
              CloudRegistrationRepository(RegistrationType.Lice)
                  .fetchBySite(siteId: sitelist[i].id, date: nowInLocal)
                  .then((liceSamples) {
            if (liceSamples.length > 0) {
              processDownloadedRegistrations(RegistrationType.Lice,
                  sitelist[i].id, liceSamples, nowInLocal);
            }
          });

          futures.add(liceSampleFuture);
        }

        if (_userRight.hasSensorsReadOnSite(sitelist[i].id)) {
          var sensorReadingFuture =
              CloudRegistrationRepository(RegistrationType.Environment)
                  .fetchBySite(
                      siteId: sitelist[i].id,
                      date: nowInLocal,
                      sensorIds: sensorIds)
                  .then((sensorReadings) {
            if (sensorReadings.length > 0) {
              processDownloadedRegistrations(RegistrationType.Environment,
                  sitelist[i].id, sensorReadings, nowInLocal);
            }
          });

          futures.add(sensorReadingFuture);
        }
      }

      await Future.wait(futures);
    }
  }

  /// Get ids of sensors
  /// [isAuto] Filter sensors is auto or not or both
  /// If [isAuto] = [true], get only sensor id of auto sensors
  /// If [isAuto] = [false], get only sensor id of manual sensors
  /// If [isAuto] = [null], return null,
  List<String> _getSensorIds(bool isAuto) {
    if (isAuto != null &&
        _sharedDataModel != null &&
        _sharedDataModel.sensors != null) {
      return _sharedDataModel.sensors
          .where((element) => element.isAuto == isAuto)
          .map((e) => e.id)
          .toList();
    }

    return null; // If list of sensor id is null, we will fetch all reading for  all sensors
  }

  void processDownloadedRegistrations(RegistrationType type, String siteId,
      List<Registration> downloadeds, DateTime date) async {
    var dbRepos = new DBRegistrationRepository(type);

    List<Registration> existings =
        await dbRepos.fetchBySite(siteId: siteId, date: date);

    if (existings == null) {
      existings = new List<Registration>();
    } else {
      existings.removeWhere((r) => r.changeStatus == ChangeStatus.New);
    }

    Map<String, Registration> existingsMap =
        Map.fromIterable(existings, key: (e) => e.id, value: (e) => e);
    Map<String, Registration> downloadedsMap =
        Map.fromIterable(downloadeds, key: (e) => e.id, value: (e) => e);

    var inserts = <Registration>[];
    var updates = <Registration>[];
    var deletes = <Registration>[];

    downloadeds.forEach((downloaded) {
      if (existingsMap.containsKey(downloaded.id)) {
        if (existingsMap[downloaded.id].changeStatus ==
            ChangeStatus.Unchanged) {
          existingsMap[downloaded.id].item = downloaded.item;
          updates.add(existingsMap[downloaded.id]);
        }
      } else {
        var inProcessing = existings.firstWhere(
            (element) =>
                element.speciesId == downloaded.speciesId &&
                element.time == downloaded.time &&
                element.id == "-1",
            orElse: () => null);

        if (inProcessing != null) {
          inProcessing.id = downloaded.id;

          if (inProcessing.changeStatus == ChangeStatus.Unchanged) {
            inProcessing.item = downloaded.item;
          }

          updates.add(inProcessing);
        } else {
          inserts.add(downloaded);
        }
      }
    });

    existings.forEach((item) {
      if (!downloadedsMap.containsKey(item.id) &&
          item.id != null &&
          item.id != "-1") {
        deletes.add(item);
      }
    });

    var futures = <Future>[];

    inserts.forEach((f) => futures.add(dbRepos.store(f)));

    updates.forEach((f) => futures.add(dbRepos.update(f)));

    deletes.forEach((f) => futures.add(dbRepos.delete(f)));

    if (futures.length > 0) {
      await Future.wait(futures);
    }
  }

  List<OrganizationUnit> _getOrganizationUnits() {
    List<OrganizationUnit> result = List<OrganizationUnit>();
    if (_organizationRoot != null && _organizationRoot.children != null) {
      List<Site> sites = _organizationRoot.children;
      for (Site site in sites) {
        if (!site.isHidden && site.children != null) {
          result.add(OrganizationUnit(
              id: site.id,
              siteName: site.parent.name,
              departmentName: site.name));
        }
      }
    }

    return result;
  }

  List<Site> getSitesWithAppMode(AppMode mode) {
    if (mode == AppMode.Landbased) {
      return siteList
          .where((site) =>
              site.sitePlacement == 'Undefined' || site.sitePlacement == 'Land')
          .toList();
    } else if (mode == AppMode.Seabased) {
      return siteList
          .where((site) =>
              site.sitePlacement == 'Undefined' ||
              site.sitePlacement == 'Sea' ||
              site.sitePlacement == 'Lake')
          .toList();
    }
    return siteList;
  }

  OrganizationEntity _currentOrganizationEntity;
  OrganizationEntity get currentOrganizationEntity =>
      _currentOrganizationEntity;

  fetchOrganization() async {
    final cloudRepos = OrganizationCloudRepository();
    await cloudRepos.fetchOrganization();

    if (cloudRepos.orgTreeJson != null) {
      await AppConfigDBRepository.saveAppConfig(
          AppConfigKeys.orgTree, cloudRepos.orgTreeJson);
    }
  }

  fetchSites() async {
    final cloudRepos = OrganizationCloudRepository();
    await cloudRepos.fetchSites();

    if (cloudRepos.sitesJson != null) {
      await AppConfigDBRepository.saveAppConfig(
          AppConfigKeys.sites, cloudRepos.sitesJson);
    }
  }

  loadOrganization() async {
    _organizationTree = await OrganizationDBRepository().fetchOrganization();
  }

  Future<UserRight> loadUserRightFromDB() async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.userRight);
    if (data != null) {
      return userRightFromMap(data.jsonData);
    } else {
      return null;
    }
  }

  loadSites() async {
    _organizationRoot = await OrganizationDBRepository().fetchSites();

    if (_organizationTree != null && _organizationRoot != null) {
      List<Site> sites = _organizationRoot.children;
      for (Site site in sites) {
        var parent = _findSiteParent(site, _organizationTree);
        if (parent != null) {
          site.parent = parent;
        }
      }
    }

    if (_organizationRoot != null) {
      (_organizationRoot as OrganizationRoot).name =
          "Unknown"; //We do not know the site parent.
    }
  }

  OrganizationEntity _findSiteParent(Site site, OrganizationEntity node) {
    if (node.children.length == 0) {
      return null;
    }

    if (node.children.map((item) => item.id).contains(site.id)) {
      return node;
    }

    for (int i = 0; i < node.children.length; i++) {
      var found = _findSiteParent(site, node.children[i]);
      if (found != null) {
        return found;
      }
    }

    return null;
  }

  updateStates(AppModel appState, SharedDataModel sharedDataModel) {
    if (_appModel != appState) {
      _appModel = appState;
    }

    if (_sharedDataModel != sharedDataModel) {
      _sharedDataModel = sharedDataModel;
    }
  }

  setCurrentOrganizationEntityById(String id) {
    OrganizationEntity entity;

    if (id != null) {
      entity = findEntity(id, _organizationRoot);
    }

    if (_currentOrganizationEntity != entity) {
      _currentOrganizationEntity = entity;
      notifyEntityChanged(entity);
    }

    getSiteUserRightForAllModules();
    notifyListeners();
  }

  bool isCurrentOrganizationSite() {
    if (currentOrganizationEntity is Site) {
      return true;
    } else if (currentOrganizationEntity is Unit) {
      return false;
    }
    return null;
  }

  // Search for *any* of the ids mapped to an entity
  static OrganizationEntity findEntity(
      String id, OrganizationEntity startEntity) {
    if (startEntity.id == id ||
        (startEntity.extIds != null && startEntity.extIds.contains(id))) {
      return startEntity;
    }
    if (startEntity.children.length < 1) {
      return null;
    }
    for (final child in startEntity.children) {
      final result = findEntity(id, child);
      if (result != null) {
        return result;
      }
    }
    return null;
  }

  ///
  /// Favorite sites

  QuickAccessSqliteRepository quickAccessRepository =
      new QuickAccessSqliteRepository();
  List<OrganizationUnit> quickAccessList = new List<OrganizationUnit>();

  UnmodifiableListView<OrganizationUnit> getAccessList(AccessType accessType) {
    if (accessType == AccessType.FrequentlyVisit) {
      quickAccessList.sort((b, a) => a.visit.compareTo(b.visit));

      var frequentlyList = quickAccessList.toList();

      frequentlyList.removeWhere((x) => x.visit == 0);

      return UnmodifiableListView(frequentlyList);
    } else if (accessType == AccessType.Favorite) {
      var favoriteList = quickAccessList.toList();

      favoriteList.removeWhere((x) => !x.favorite);

      return UnmodifiableListView(favoriteList);
    } else {
      return UnmodifiableListView([]);
    }
  }

  Future loadAccessList(List<QuickAccess> list) async {
    if (list != null && list.length > 0) {
      quickAccessList.clear();

      Map<String, OrganizationUnit> siteMap = Map.fromIterable(
          _getOrganizationUnits(),
          key: (e) => e.id,
          value: (e) => e);

      for (int i = 0; i < list.length; i++) {
        if (siteMap.containsKey(list[i].unitId)) {
          var site = siteMap[list[i].unitId];

          var item = new OrganizationUnit(
              id: site.id,
              siteName: site.siteName,
              departmentName: site.departmentName);

          item.favorite = list[i].favorite;
          item.visit = list[i].frequency;

          quickAccessList.add(item);
        }
      }

      notifyListeners();
    }
  }

  void visit(String id) {
    // increase visit number with 1 for Site with id equal to id param
    var item =
        quickAccessList.firstWhere((e) => e.id == id, orElse: () => null);

    if (item != null) {
      item.visit++;
      // update to repository
      quickAccessRepository.update(new QuickAccess(
          unitId: item.id,
          username: _appModel.currentUserInfo.email,
          frequency: item.visit,
          favorite: item.favorite));
    } else {
      item = _getOrganizationUnits()
          .firstWhere((e) => e.id == id, orElse: () => null);

      var newItem = new OrganizationUnit(
          id: item.id,
          siteName: item.siteName,
          departmentName: item.departmentName);

      newItem.favorite = false;
      newItem.visit = 1;

      // Add to state
      quickAccessList.add(newItem);
      // Add to repository
      quickAccessRepository.insert(new QuickAccess(
          unitId: newItem.id,
          username: _appModel.currentUserInfo.email,
          frequency: newItem.visit,
          favorite: newItem.favorite));
    }
    setCurrentOrganizationEntityById(id);
    // short list of sites by frequently visited, take number of limited items configured in setting.
  }

  void toggleFavorite(String id) {
    var item =
        quickAccessList.firstWhere((e) => e.id == id, orElse: () => null);

    if (item != null) {
      item.favorite = !item.favorite;

      quickAccessRepository.update(new QuickAccess(
          unitId: item.id,
          username: _appModel.currentUserInfo.email,
          frequency: item.visit,
          favorite: item.favorite));
    } else {
      item = _getOrganizationUnits()
          .firstWhere((e) => e.id == id, orElse: () => null);

      var newItem = new OrganizationUnit(
          id: item.id,
          siteName: item.siteName,
          departmentName: item.departmentName);

      newItem.favorite = true;
      newItem.visit = 0;
      // add into state
      quickAccessList.add(newItem);
      // Add to repository
      quickAccessRepository.insert(new QuickAccess(
          unitId: newItem.id,
          username: _appModel.currentUserInfo.email,
          frequency: newItem.visit,
          favorite: newItem.favorite));
      // add site also into data store.
    }

    notifyListeners();
  }

  bool isFavoritedSite(String id) {
    return quickAccessList.any((e) => e.id == id && e.favorite);
  }

  void resetSiteData() {
    _organizationRoot = null;
    _organizationTree = null;
    notifyListeners();
  }

  bool shouldBeDisplayed(String unitId) {
    if (_appModel.hideEmptyUnit) {
      if (_unitSpecieMap.containsKey(unitId)) {
        if (_unitSpecieMap[unitId].length == 0)
          return false;
        else
          return true;
      } else {
        return false;
      }
    } else {
      return true;
    }
  }

  void notifyEntityChanged(OrganizationEntity newEntity) {
    _eventListeners
        .forEach((listener) => listener.organizationEntityChanged(newEntity));
  }

  void addEventListener(OrganizationEventListener listener) {
    if (!this._eventListeners.contains(listener)) {
      this._eventListeners.add(listener);
    }
  }
}

class RegistrationUserRight {
  bool allowRead;
  bool allowWrite;
  bool allowDelete;

  RegistrationUserRight({this.allowRead, this.allowWrite, this.allowDelete});
}

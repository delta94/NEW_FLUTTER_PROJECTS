import 'package:control_app/src/models/site_model.dart';

abstract class OrganizationEventListener {
  void organizationEntityChanged(OrganizationEntity newEntity){}
}
import 'package:Commons/dropdown.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/mortality/view_models/salmon_mortality_registration_view_model.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:control_app/src/widgets/confirm_message.dart';
import 'package:control_app/src/widgets/no_registration_message.dart';
import 'package:control_app/src/widgets/radio_group.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class NoMortalityConfirmation extends StatefulWidget {
  const NoMortalityConfirmation({
    Key key,
    @required this.model,
  }) : super(key: key);

  final RegistrationViewModel model;

  @override
  _NoMortalityConfirmationState createState() =>
      _NoMortalityConfirmationState();
}

class _NoMortalityConfirmationState extends State<NoMortalityConfirmation> {
  int currentRadioIndex = 0;
  OptionItem selectedNoCheckingCause;

  @override
  void initState() {
    SharedDataModel sharedDataModel =
        Provider.of<SharedDataModel>(this.context, listen: false);
    var allNoCheckingCauses = sharedDataModel.missedMortalityReason;
    int selectedNoCheckingId = widget.model.checkConfirmedMissedReason();
    selectedNoCheckingCause = allNoCheckingCauses.firstWhere(
        (cause) => cause.id == selectedNoCheckingId,
        orElse: () => null);

    if (selectedNoCheckingCause != null) currentRadioIndex = 1;
    super.initState();
  }

  onChangeRadioIndex(int newRadioIndex) async {
    if (currentRadioIndex != newRadioIndex) {
      if (newRadioIndex == 0 && selectedNoCheckingCause != null) {
        currentRadioIndex = newRadioIndex;
        selectedNoCheckingCause = null;
        await (widget.model as SalmonMortalityRegistrationViewModel)
            .setConfirmNothingReport();
      } else {
        setState(() {
          currentRadioIndex = newRadioIndex;
        });
      }
    }
  }

  onMissedMortalityReasonChanged(OptionItem newCause) async {
    await widget.model.confirmMissedReason(newCause.id);

    setState(() {
      selectedNoCheckingCause = newCause;
    });
  }

  confirmNothingReport() async {
    widget.model.setBusy(true);

    try {
      currentRadioIndex = 0;
      await (widget.model as SalmonMortalityRegistrationViewModel)
          .setConfirmNothingReport();
    } catch (e) {} finally {
      widget.model.setBusy(false);
    }
  }

  undoConfirmNothingReport() async {
    widget.model.setBusy(true);
    try {
      selectedNoCheckingCause = null;
      if (currentRadioIndex == 0) {
        await (widget.model as SalmonMortalityRegistrationViewModel)
            .revertConfirmedNoRegistration();
      } else {
        await widget.model.revertMissedReason();
      }
    } catch (e) {} finally {
      widget.model.setBusy(false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final S appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    SharedDataModel sharedDataModel =
        Provider.of<SharedDataModel>(this.context, listen: false);
    OrganizationModel organizationModel =
        Provider.of<OrganizationModel>(this.context, listen: false);

    RegistrationUserRight registrationUserRight =
        organizationModel.registrationUserRightMap[RegistrationType.Mortality];

    var allNoCheckingCauses = sharedDataModel.missedMortalityReason;
    var isConfirmed =
        widget.model.status == RegistrationStatus.CONFIRMED_NO_REGISTRATION ||
            widget.model.status == RegistrationStatus.MISSED_REGISTRATION;
    return isConfirmed
        ? Visibility(
            visible: widget.model.isForSalmon,
            child: SingleChildScrollView(
              child: ConfirmMessage(
                confirmWidget: Column(
                  children: <Widget>[
                    Padding(
                      padding: EdgeInsets.only(left: 30),
                      child: Column(
                        children: <Widget>[
                          SizedBox(height: 20),
                          RadioGroup(
                            enable: !widget.model.busy &&
                                registrationUserRight.allowWrite,
                            direction: Axis.vertical,
                            currentRadioIndex: currentRadioIndex,
                            radioTitles: [
                              appText.checked_found_no_mortality,
                              appText.couldnt_check_for_mortality
                            ],
                            onChangeRadioIndex: onChangeRadioIndex,
                          ),
                          SizedBox(
                            height: 20,
                          ),
                          Visibility(
                            visible: currentRadioIndex == 1,
                            maintainState: true,
                            child: Container(
                              padding: EdgeInsets.only(right: 23, bottom: 26),
                              child: AkvaDropDown(
                                enable: !widget.model.busy,
                                items: allNoCheckingCauses,
                                onSelectedItem: onMissedMortalityReasonChanged,
                                label: appText.cause,
                                leftIcon: AkvaIcons.search,
                                hint: appText.search,
                                numberOfDisplayedItems: 2,
                                selectedItems: [selectedNoCheckingCause],
                                isDarkTheme: appModel.isDarkTheme,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                confirmText: appText.nothing_to_report_in_mortality,
                isConfirmed: true,
                onTap: widget.model.busy || !registrationUserRight.allowDelete
                    ? null
                    : () => undoConfirmNothingReport(),
              ),
            ),
          )
        : Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Visibility(
                visible: widget.model.isForSalmon,
                child: ConfirmMessage(
                  confirmText: appText.nothing_to_report_in_mortality,
                  confirmWidget: Container(),
                  onTap: registrationUserRight.allowWrite
                      ? () => confirmNothingReport()
                      : null,
                ),
              ),
              NoRegistrationMessage(
                registrationStatus: widget.model.status,
              ),
              SizedBox(
                height: 10,
              ),
              SizedBox(
                height: 10,
              ),
            ],
          );
  }
}

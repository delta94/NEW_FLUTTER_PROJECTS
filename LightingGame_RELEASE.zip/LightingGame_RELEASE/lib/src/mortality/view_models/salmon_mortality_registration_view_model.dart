import 'mortality_registration_view_model.dart';

class SalmonMortalityRegistrationViewModel extends MortalityRegistrationViewModel {
  SalmonMortalityRegistrationViewModel():super(true);
}


import 'mortality_registration_view_model.dart';

class CleanerFishMortalityRegistrationViewModel extends MortalityRegistrationViewModel {
  CleanerFishMortalityRegistrationViewModel():super(false);
}


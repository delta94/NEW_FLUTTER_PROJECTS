import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/models/mortality/mortality_registration.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/util/constants.dart';

class MortalityRegistrationViewModel extends RegistrationViewModel {
  final bool isForSalmon;
  MortalityRegistrationViewModel(this.isForSalmon)
      : super(isForSalmon, RegistrationType.Mortality);

  setConfirmNothingReport() async {
    if (hasConfirmedNoMortality()) return;
    setBusy(true);

    try {
      /// Finding current registrations if there is any registration that
      /// was set missed reason. If it was then update that registration to
      /// be checked but not found mortality. Otherwise then create a new registration
      /// and set checked but not found.
      var registration = registrations.firstWhere(
          (registration) =>
              (registration.item as MortalityRegistration)
                      .missedMortalityReasonId !=
                  -1 &&
              registration.changeStatus != ChangeStatus.Deleted,
          orElse: () => null);
      if (registration != null) {
        (registration.item as MortalityRegistration).missedMortalityReasonId =
            -1;
        if (registration.changeStatus != ChangeStatus.New) {
          registration.changeStatus = ChangeStatus.Changed;
        }
      } else {
        registration = await addNewRegistration(1);
        registrations.add(registration);
      }

      await saveChanges(keepEmpty: true, notify: false);
      await fetchRegistrations();

      status = RegistrationStatus.CONFIRMED_NO_REGISTRATION;
    } catch (e) {} finally {
      setBusy(false);
    }
  }

  bool hasConfirmedNoMortality() {
    return registrations.any((registration) {
      var item = registration.item as MortalityRegistration;
      return item.mortalities.isEmpty &&
          registration.changeStatus != ChangeStatus.Deleted &&
          item.missedMortalityReasonId == -1;
    });
  }

  revertConfirmedNoRegistration({bool notify: true}) async {
    if (hasConfirmedNoMortality()) {
      registrations.forEach(
          (registration) => registration.changeStatus = ChangeStatus.Deleted);
      await saveChanges(keepEmpty: true, notify: false);
      await fetchRegistrations();
      status = RegistrationStatus.NO_REGISTRATION;
    }
  }
}

import 'dart:async';

import 'package:control_app/src/util/constants.dart';

import '../models/registration.dart';
import '../repositories/cloud_registration_repository.dart';
import '../repositories/db_registration_repository.dart';

import 'sync_result.dart';
import 'synchronize_helper.dart';

class RegistrationSynchronizeHelper extends SynchronizeHelper {
  CloudRegistrationRepository _cloudRepository;
  DBRegistrationRepository _dbRepository;
  StreamController<SyncResult> _syncResultStreamController;

  RegistrationSynchronizeHelper(RegistrationType type, StreamController<SyncResult> syncResultStreamController) : super(type: type) {
    _cloudRepository = new CloudRegistrationRepository(type);
    _dbRepository = new DBRegistrationRepository(type);
    _syncResultStreamController = syncResultStreamController;
  }

  @override
  Future sync() async {
    List<Registration> registrations = await _dbRepository.fetchBySite();

    if (registrations != null && registrations.length > 0) {
      print("SYNC: ========== $type Synchronization in progress");

      List<Registration> result =
          await _cloudRepository.saveChanges(registrations);

      if (result != null && result.length > 0) {
        // Send sync result to listener
        _syncResultStreamController.add(new SyncResult(type, result.length));

        var updateList = result
            .where((x) => x.changeStatus != ChangeStatus.Deleted)
            .toList();

        if (updateList.length > 0) {
          _dbRepository.updateMultiple(updateList);
        }

        var deletedList = result
            .where((x) => x.changeStatus == ChangeStatus.Deleted)
            .toList();

        if (deletedList.length > 0) {
          _dbRepository.deleteMultiple(deletedList);
        }
      }

      print("SYNC: ========== $type Synchronization DONE.");
    }

    return;
  }
}

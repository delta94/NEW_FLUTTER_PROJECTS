import 'package:control_app/src/models/registration.dart';

class SyncResult {
  RegistrationType type;
  int numberOfItems;
  SyncResult(this.type, this.numberOfItems);
}
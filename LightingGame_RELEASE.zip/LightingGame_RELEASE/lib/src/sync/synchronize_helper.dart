import '../models/registration.dart';

abstract class SynchronizeHelper {
  RegistrationType type;

  SynchronizeHelper({this.type});

  Future sync();
}

import 'dart:async';

import 'package:control_app/src/models/registration.dart';
import 'registration_synchronize_helper.dart';

import 'sync_result.dart';
import 'synchronize_helper.dart';
import 'package:data_connection_checker/data_connection_checker.dart';

class SynchronizeManager {
  final _helpers = new List<SynchronizeHelper>();
  final StreamController<RegistrationType> _syncStreamController = new StreamController.broadcast();
  Stream<RegistrationType> get syncStream => _syncStreamController.stream;

  final StreamController<SyncResult> _syncResultStreamController = new StreamController.broadcast();
  Stream<SyncResult> get syncResultStream => _syncResultStreamController.stream;

  DataConnectionStatus connectionStatus;

  SynchronizeManager() {
    _helpers.add(new RegistrationSynchronizeHelper(RegistrationType.Mortality, _syncResultStreamController));
    _helpers.add(new RegistrationSynchronizeHelper(RegistrationType.Feeding, _syncResultStreamController));
    _helpers.add(new RegistrationSynchronizeHelper(RegistrationType.Culling, _syncResultStreamController));
    _helpers.add(new RegistrationSynchronizeHelper(RegistrationType.Lice, _syncResultStreamController));
    _helpers.add(new RegistrationSynchronizeHelper(RegistrationType.Environment, _syncResultStreamController));
  }

  Future performSync() async {
    if (connectionStatus == DataConnectionStatus.connected) {
      _helpers.forEach((f) async{
        await f.sync();
        _syncStreamController.add(f.type);
      });
    }
  }

  Future syncByType(RegistrationType type) async {
    if (connectionStatus == DataConnectionStatus.connected) {
      print("SYNC: ========== Start to sync by type: $type");

      await new RegistrationSynchronizeHelper(type, _syncResultStreamController).sync();
      _syncStreamController.add(type);
    }
    else{
      print("SYNC: ========== Sync cannot Start due to Network connection is NOT available.");
    }
  }
}

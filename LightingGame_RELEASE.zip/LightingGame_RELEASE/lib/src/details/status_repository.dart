import 'dart:convert';
import '../services/api_service.dart';

class StatusModel {
  String id;
  String populationId;
  String fishGroupName;
  String fishGroupNumber;
  DateTime statusTime;
  String species;
  String yearClass;
  double closingCount;
  double closingBiomassKg;
  double avgWeightGram;
  double harvestCount;
  double harvestBiomassKg;
  double inputCount;
  double inputBiomassKg;
  double mortalityCount;
  double mortalityBiomassKg;
  double cullingCount;
  double cullingBiomassKg;
  double escapeCount;
  double escapeBiomassKg;
  bool isFasting;
  String reasonForNotFeeding;

  StatusModel.fromJson(Map<String, dynamic> parsedJson) {
    id = parsedJson['id'];
    populationId = parsedJson['populationId'];
    fishGroupName = parsedJson['fishGroupName'];
    fishGroupNumber = parsedJson['fishGroupNumber'];
    statusTime = DateTime.parse(parsedJson['statusTime']);
    species = parsedJson['species'];
    yearClass = parsedJson['yearClass'];
    closingCount = parsedJson['closingCount'] as double;
    closingBiomassKg = parsedJson['closingBiomassKg'];
    avgWeightGram = parsedJson['avgWeightGram'];
    harvestCount = parsedJson['harvestCount'];
    harvestBiomassKg = parsedJson['harvestBiomassKg'];
    inputCount = parsedJson['inputCount'];
    inputBiomassKg = parsedJson['inputBiomassKg'];
    mortalityCount = parsedJson['mortalityCount'];
    mortalityBiomassKg = parsedJson['mortalityBiomassKg'];
    cullingCount = parsedJson['cullingCount'];
    cullingBiomassKg = parsedJson['cullingBiomassKg'];
    escapeCount = parsedJson['escapeCount'];
    escapeBiomassKg = parsedJson['escapeBiomassKg'];
    isFasting = parsedJson['isFasting'];
    reasonForNotFeeding = parsedJson['reasonForNotFeeding'];
  }
}

class StatusRepository {
  final _apiService = ApiService();
  Future<StatusModel> getYesterdaysStatusForContainer(
      String containerId) async {
    try {
      return await _apiService.httpGet(
          '${ApiService.urlRoot}/population-status/latest?unitId=$containerId',
          (data) {
        final parsedJson = json.decode(data);
        if (parsedJson.length > 0) {
          return StatusModel.fromJson(parsedJson[0]);
        } else {
          return null;
        }
      });
    } on AuthenticationException catch (e) {
      print(e);
      return null;
    } on Exception catch (e) {
      print('handling failure $e');
      return null;
    }
  }
}

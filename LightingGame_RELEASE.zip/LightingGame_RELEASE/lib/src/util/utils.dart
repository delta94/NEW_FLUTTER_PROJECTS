import 'package:Commons/dropdown.dart';
import 'package:control_app/src/app_model.dart';
import 'package:intl/intl.dart';

Map<T, List<S>> groupBy<S, T>(Iterable<S> values, T key(S element)) {
  var map = <T, List<S>>{};
  for (var element in values) {
    var list = map.putIfAbsent(key(element), () => []);
    list.add(element);
  }
  return map;
}

getRegistrationTime(String multiLanguageString, DateTime dateTime) {
  String date = DateFormat('dd.MM.yyyy').format(dateTime);
  String time = DateFormat('HH:mm').format(dateTime);
  return '$date $multiLanguageString $time';
}

isSelectedOption(
    OptionItem searchingOption, List<OptionItem> selectedOptionItems) {
  return selectedOptionItems.any((option) => option.id == searchingOption.id);
}

getFirstLetter(String name) {
  if (name == null || name == '') return '';
  return name.substring(0, 1).toUpperCase();
}

getShortName(AppModel appModel) {
  String shortName = '';
  if (appModel.currentUserInfo != null) {
    String givenName = appModel.currentUserInfo.givenName;
    String familyName = appModel.currentUserInfo.familyName;
    String name = appModel.currentUserInfo.name;
    shortName = getFirstLetter(givenName) + getFirstLetter(familyName);
    if (shortName == '') shortName = getFirstLetter(name);
  }

  return shortName;
}

const DROPDOWN_ITEM_HEIGHT = 44.0;
const YESTERDAY_CAUSE_HEIGHT = 37.0;

import 'package:flutter/material.dart';

enum ChangeStatus { Unchanged, Changed, Deleted, New }

enum RegistrationStatus {
  NO_FISH,
  NO_REGISTRATION,
  CONFIRMED_NO_REGISTRATION,
  HAVE_REGISTRATION,
  MISSED_REGISTRATION,
}

class Constants {
  static const mainHeaderColor = Colors.black;
}

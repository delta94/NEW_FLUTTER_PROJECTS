import 'package:Commons/colors.dart';
import 'package:Commons/fonts.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:flare_flutter/flare_actor.dart';
import 'package:data_connection_checker/data_connection_checker.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';

import 'flare_loop_controller.dart';

class UiUtils {
  static Widget _spinArrow;

  static get spinArrow => _spinArrow;

  static LinearGradient getRegistraionLinearGradient(
      Color decorationColor, bool isDarkTheme) {
    return LinearGradient(stops: [
      0.017,
      0.017
    ], colors: [
      decorationColor,
      isDarkTheme ? akvaDarkColorC : akvaLightColorB
    ]);
  }

  static Widget loadingIndicator() {
    return Container(
      alignment: Alignment.center,
      color: Colors.transparent,
      child: CircularProgressIndicator(
        value: null,
        backgroundColor: Colors.redAccent,
      ),
    );
  }

  static Color getModeColor(AppModel appModel, bool isActive) {
    return isActive
        ? akvaMainAction
        : appModel.isDarkTheme ? akvaDarkColorE : akvaLightColorE;
  }

  static initFlareSpinWidget() {
    FlareLoopController _loopController = FlareLoopController('rotate', 2.0);
    _spinArrow = Container(
      padding: EdgeInsets.only(top: 2, bottom: 5),
      width: 47,
      height: 47,
      child: FlareActor(
        "assets/spin.flr",
        alignment: Alignment.center,
        controller: _loopController,
      ),
    );
  }

  static ObjectKey getKeyBaseOnSyncConnectionStatus(AppModel appModel) {
    if (appModel.connectionStatus == DataConnectionStatus.disconnected) {
      return ObjectKey(appModel.connectionStatus);
    } else {
      return ObjectKey(appModel.synResult.length);
    }
  }

  static getSyncConnectionBarHeight(AppModel appModel) {
    double syncConnectionBarHeight = 0;
    if (appModel.synResult.isNotEmpty) syncConnectionBarHeight += 32;
    if (appModel.connectionStatus == DataConnectionStatus.disconnected)
      syncConnectionBarHeight += 32;

    return syncConnectionBarHeight;
  }

  static showToast({String message, AppModel appModel}) {
    Fluttertoast.showToast(
      msg: message,
      toastLength: Toast.LENGTH_LONG,
      gravity: ToastGravity.CENTER,
      timeInSecForIosWeb: 10,
      backgroundColor: appModel.isDarkTheme ? akvaLightColorA : akvaDarkColorC,
      textColor: appModel.isDarkTheme ? akvaMainDark : akvaLightColorA,
      fontSize: FontSize.small,
    );
  }
}

import 'dart:convert';

import 'package:barcode_scan/barcode_scan.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import 'package:permission_handler/permission_handler.dart';
import '../routers.dart';

Future navigateByQR(BuildContext context) async {
  final organizationModel = Provider.of<OrganizationModel>(context, listen: false);
  PermissionStatus cameraPermission = await PermissionHandler().checkPermissionStatus(PermissionGroup.camera);
  if(cameraPermission == PermissionStatus.granted){
    try {
      String jsonBarcode = await BarcodeScanner.scan();
      var parsedJsonData = json.decode(jsonBarcode);
      String entityId = parsedJsonData['id'];
      organizationModel.setCurrentOrganizationEntityById(entityId);
      Navigator.pushNamed(context, Routers.main);
    } on FormatException {
      String res = 'You pressed the back button before scanning anything';
      print(res);
    } catch (e) {
      String res = 'Unknown Error $e';
      print(res);
    }
  }
  else{
    Map<PermissionGroup, PermissionStatus> permissions = await PermissionHandler().requestPermissions([PermissionGroup.camera]);
    if(permissions[PermissionGroup.camera] == PermissionStatus.granted){
      return navigateByQR(context);
    }
    else {
      return;
    }
  }
}



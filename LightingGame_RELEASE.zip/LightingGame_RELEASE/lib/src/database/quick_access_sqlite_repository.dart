
import 'package:control_app/src/models/quick_access.dart';
import 'package:control_app/src/repositories/quick_access_repository.dart';
import 'package:sqflite/sqflite.dart';

import '../models/quick_access.dart';
import '../repositories/quick_access_repository.dart';

import 'sqlite_database_helper.dart';



class QuickAccessSqliteRepository implements QuickAccessRepository {
  /// Insert Quick Access data model
  Future<int> insert(QuickAccess quickAccess) async {
    validate(quickAccess);

    Database db = await SqliteDatabaseHelper.instance.database;
    int id = await db.insert("QuickAccess", quickAccess.toMap());
    return id;
  }

  /// Update Quick Access data model
  Future<int> update(QuickAccess quickAccess) async {
    validate(quickAccess);

    Database db = await SqliteDatabaseHelper.instance.database;
    int id = await db.update(
      "QuickAccess",
      quickAccess.toMap(),
      where:
          '${QuickAccess.columnUnitId} = ? AND ${QuickAccess.columnUserName} = ?',
      whereArgs: [quickAccess.unitId, quickAccess.username],
    );
    return id;
  }

  /// Get all quick access data models for a user by user name
  Future<List<QuickAccess>> getByUsername(String username) async {
    List<QuickAccess> result = List<QuickAccess>();
    Database db = await SqliteDatabaseHelper.instance.database;
    List<Map> maps = await db.query("QuickAccess",
        columns: [
          QuickAccess.columnUserName,
          QuickAccess.columnUnitId,
          QuickAccess.columnFrequency,
          QuickAccess.columnFavorite
        ],
        where: '${QuickAccess.columnUserName} = ?',
        whereArgs: [username]);

    if (maps.length > 0) {
      for (var item in maps) {
        var qa = QuickAccess.fromMap(item);
        result.add(qa);
      }
    }

    return result;
  }

  void validate(QuickAccess quickAccess) {
    if (quickAccess == null) throw Exception("Object is null");

    if (quickAccess.username == null) throw Exception("Username is required");

    if (quickAccess.unitId == null) throw Exception("UnitId is required");
  }

  Future<void> delete() async {
    Database db = await SqliteDatabaseHelper.instance.database;

    try {
      db.delete("QuickAccess");
    } on Exception catch (e) {
      print(e.toString());
    }
  }

  Future<void> dropTable() async {
    Database db = await SqliteDatabaseHelper.instance.database;

    try {
      db.rawDelete("DROP TABLE IF EXISTS QuickAccess");
    } on Exception catch (e) {
      print(e.toString());
    }
  }
}



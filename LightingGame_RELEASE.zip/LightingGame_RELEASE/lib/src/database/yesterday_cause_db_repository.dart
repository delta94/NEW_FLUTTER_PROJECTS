import 'package:control_app/src/database/sqlite_database_helper.dart';
import 'package:control_app/src/database/yesterday_db_repository.dart';
import 'package:control_app/src/models/yesterday_cause.dart';
import 'package:sqflite/sqflite.dart';

class YesterdayCauseDBRepository extends YesterdayDBRepository<YesterdayCause>{

  
  YesterdayCauseDBRepository(tableName) : super(tableName: tableName);

  /// Insert Yesterday Cause data model
  Future<int> insert(List<YesterdayCause> causes) async {
    if (causes == null || causes.isEmpty) return -1;

    causes.forEach((element) {
      validate(element);
    });

    Database db = await SqliteDatabaseHelper.instance.database;

    var todayCauses = await getByUsernameAndUnitId(
        causes[0].username, causes[0].unitId,
        isForToday: true);

    causes.forEach((element) async {
      var index = todayCauses
          .lastIndexWhere((item) => item.causeId == element.causeId);

      if (index < 0) {
        int id = await db.insert(tableName, element.toMap());
        return id;
      }

      return -1;
    });

    return -1;
  }

  /// Get all of Yesterday cause data models for a user by user name and unitId
  Future<List<YesterdayCause>> getByUsernameAndUnitId(
      String username, String unitId,
      {bool isForToday = false}) async {
    removeOldEntries();

    Database db = await SqliteDatabaseHelper.instance.database;

    List<YesterdayCause> result = new List<YesterdayCause>();

    List<Map> maps = await db.query(tableName,
        columns: [
          YesterdayCause.columnUserName,
          YesterdayCause.columnCauseId,
          YesterdayCause.columnUnitId,
          YesterdayCause.columnDate
        ],
        where:
            "${YesterdayCause.columnUserName} = ? AND ${YesterdayCause.columnUnitId} = ? AND ${YesterdayCause.columnDate} = " +
                (isForToday == true
                    ? " Date('now')"
                    : " Date('now','localtime','-1 day')"),
        whereArgs: [username, unitId]);

    if (maps.length > 0) {
      for (var item in maps) {
        var mc = YesterdayCause.fromMap(item);
        result.add(mc);
      }
    }

    return result;
  }

  void validate(YesterdayCause mortalityCause) {
    if (mortalityCause == null) throw Exception("Object is null");

    if (mortalityCause.username == null)
      throw Exception("Username is required");

    if (mortalityCause.causeId == null)
      throw Exception("Cause IDs is required");

    if (mortalityCause.unitId == null) throw Exception("Unit ID is required");

    if (mortalityCause.date == null) throw Exception("Date is required");
  }

  // Removes all entires in the database that are older that 1 day, i.e. not todays or yesterdays entries
  Future<void> removeOldEntries() async {
    Database db = await SqliteDatabaseHelper.instance.database;

    try {
      await db.delete(
        tableName,
        where: "Date < DATE('now','localtime','-1 day')",
      );
    } on Exception catch (e) {
      print(e.toString());
    }
  }
}

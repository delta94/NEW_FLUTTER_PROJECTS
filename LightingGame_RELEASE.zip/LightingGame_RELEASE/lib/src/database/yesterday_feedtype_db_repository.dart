import 'package:control_app/src/database/sqlite_database_helper.dart';
import 'package:control_app/src/database/yesterday_db_repository.dart';
import 'package:control_app/src/models/yesterday_feedtype.dart';
import 'package:sqflite/sqflite.dart';

class YesterdayFeedTypeDBRepository extends YesterdayDBRepository<YesterdayFeedType> {
  YesterdayFeedTypeDBRepository(): super(tableName: "YesterdayFeedType");
  @override
  Future<int> insert(List<YesterdayFeedType> causes) async {
    if (causes == null || causes.isEmpty) return -1;

    causes.forEach((element) {
      validate(element);
    });

    Database db = await SqliteDatabaseHelper.instance.database;

    var todayCauses = await getByUsernameAndUnitId(causes[0].username, causes[0].unitId, isForToday: true);

    causes.forEach((element) async {
      var index = todayCauses.lastIndexWhere((item) => item.feedStoreId == element.feedStoreId && item.feedTypeId == element.feedTypeId);

      if (index < 0) {
        int id = await db.insert(tableName, element.toMap());
        return id;
      }

      return -1;
    });

    return -1;
  }

  @override
  Future<List<YesterdayFeedType>> getByUsernameAndUnitId(String username, String unitId, {bool isForToday = false}) async {
    removeOldEntries();

    Database db = await SqliteDatabaseHelper.instance.database;

    List<YesterdayFeedType> result = new List<YesterdayFeedType>();

    List<Map> maps = await db.query("YesterdayFeedType",
        columns: [
          YesterdayFeedType.columnUserName,
          YesterdayFeedType.columnFeedStoreId,
          YesterdayFeedType.columnFeedTypeId,
          YesterdayFeedType.columnUnitId,
          YesterdayFeedType.columnDate
        ],
        where:
            "${YesterdayFeedType.columnUserName} = ? AND ${YesterdayFeedType.columnUnitId} = ? AND ${YesterdayFeedType.columnDate} = " +
                (isForToday == true
                    ? " Date('now')"
                    : " Date('now','localtime','-1 day')"),
        whereArgs: [username, unitId]);

    if (maps.length > 0) {
      for (var item in maps) {
        var mc = YesterdayFeedType.fromMap(item);
        result.add(mc);
      }
    }

    return result;
  }

  @override
  void validate(YesterdayFeedType item) {
    if (item == null) throw Exception("Object is null");

    if (item.username == null)
      throw Exception("Username is required");

    if (item.feedStoreId == null)
      throw Exception("Feed store Id is required");

    if (item.feedTypeId == null)
      throw Exception("Feed type Id is required");

    if (item.unitId == null) throw Exception("Unit ID is required");

    if (item.date == null) throw Exception("Date is required");
  }

  @override
  Future<void> removeOldEntries() async {
    Database db = await SqliteDatabaseHelper.instance.database;

    try {
      await db.delete(
        'YesterdayFeedType',
        where: "Date < DATE('now','localtime','-1 day')",
      );
    } on Exception catch (e) {
      print(e.toString());
    }
  }
}

import 'dart:io';
import 'package:control_app/src/models/app_config.dart';
import 'package:control_app/src/models/yesterday_cause.dart';
import 'package:control_app/src/models/yesterday_feedtype.dart';
import 'package:path/path.dart';
import 'package:control_app/src/models/quick_access.dart';
import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';

class SqliteDatabaseHelper {
  /// This is the actual database filename that is saved in the docs directory.
  static final _databaseName = "ControlApp.db";

  /// Increment this version when you need to change the schema.
  static final _databaseVersion = 10;

  /// Make this a singleton class.
  SqliteDatabaseHelper._privateConstructor();
  static final SqliteDatabaseHelper instance =
      SqliteDatabaseHelper._privateConstructor();

  /// Only allow a single open connection to the database.
  static Database _database;

  Future<Database> get database async {
    if (_database != null) return _database;
    _database = await _initDatabase();
    return _database;
  }

  /// open the database
  _initDatabase() async {
    /// The path_provider plugin gets the right directory for Android or iOS.
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, _databaseName);

    /// Open the database. Can also add an onUpdate callback parameter.
    return await openDatabase(
      path,
      version: _databaseVersion,
      onCreate: _onCreate,
      onUpgrade: _onUpgrade,
    );
  }

  /// SQL string to create the database
  Future _onCreate(Database db, int version) async {
    print("_onCreate is called.");

    final createQuickAccessTable = db.execute('''
              CREATE TABLE QuickAccess (
                ${QuickAccess.columnUserName} TEXT NOT NULL,
                ${QuickAccess.columnUnitId} TEXT NOT NULL,
                ${QuickAccess.columnFrequency} INTEGER NULL,
                ${QuickAccess.columnFavorite} INTEGER NULL
              )
              ''');

    var futures = <Future>[];

    if (version == 2) {
      futures.add(_onUpgrade(db, 1, 2));
    } else if (version == 3) {
      futures.add(_onUpgrade(db, 1, 3));
    } else if (version == 4) {
      futures.add(_onUpgrade(db, 1, 4));
    } else if (version == 5) {
      futures.add(_onUpgrade(db, 1, 5));
    } else if (version == 6) {
      futures.add(_onUpgrade(db, 1, 6));
    } else if (version == 7) {
      futures.add(_onUpgrade(db, 1, 7));
    } else if (version == 8) {
      futures.add(_onUpgrade(db, 1, 8));
    } else if (version == 9) {
      futures.add(_onUpgrade(db, 1, 9));
    } else if (version == 10) {
      futures.add(_onUpgrade(db, 1, 10));
    }

    futures.add(createQuickAccessTable);

    await Future.wait(futures);
  }

  /// SQL string to upgrade the database
  Future _onUpgrade(Database db, int oldVersion, int newVersion) async {
    if (oldVersion == 1 && newVersion >= 2) {
      _upgradeFrom1To2(db);
    }
    if (oldVersion < 3 && newVersion >= 3) {
      _upgradeFrom2To3(db);
    }
    if (oldVersion < 4 && newVersion >= 4) {
      _upgradeFrom3To4(db);
    }
    if (oldVersion < 5 && newVersion >= 5) {
      _upgradeFrom4To5(db);
    }
    if (oldVersion < 6 && newVersion >= 6) {
      _upgradeFrom5To6(db);
    }
    if (oldVersion < 7 && newVersion >= 7) {
      _upgradeFrom6To7(db);
    }
    if (oldVersion < 8 && newVersion >= 8) {
      _upgradeFrom7To8(db);
    }
    if (oldVersion < 9 && newVersion >= 9) {
      _upgradeFrom8To9(db);
    }
    if (oldVersion < 10 && newVersion >= 10) {
      _upgradeFrom9To10(db);
    }
  }

  Future _upgradeFrom1To2(Database db) async {
    print("_onUpgrade is called. Upgrade from version 1 to version 2");

    final createAppConfigTable = db.execute('''
              CREATE TABLE AppConfig (
                ${AppConfig.colKey} TEXT NOT NULL,
                ${AppConfig.colJsonData} TEXT NOT NULL
              )
              ''');

    final createMortalityTable = db.execute('''
              CREATE TABLE Mortality (
                id TEXT,
                siteId TEXT,
                unitId TEXT,
                populationId TEXT,
                causeId INTEGER,
                speciesId INTEGER,
                mortalityCount INTEGER,
                registrationTime TEXT,
                utcOffset REAL,
                changeStatus INTEGER
              )
              ''');

    var futures = <Future>[];

    futures.add(createAppConfigTable);
    futures.add(createMortalityTable);

    await Future.wait(futures);
  }

  Future _upgradeFrom2To3(Database db) async {
    print("_onUpgrade is called. Upgrade from version 2 to version 3");

    await _createYesterdayCauseTable("MortalityCause", db);
  }

  Future _createYesterdayCauseTable(String tableName, Database db) async {
    await db.execute('''
              CREATE TABLE $tableName (
                ${YesterdayCause.columnUserName} TEXT NOT NULL,
                ${YesterdayCause.columnCauseId} INT NOT NULL,
                ${YesterdayCause.columnUnitId} TEXT NOT NULL,
                ${YesterdayCause.columnDate} TEXT NOT NULL
              )
              ''');
  }

  Future _upgradeFrom3To4(Database db) async {
    print("_onUpgrade is called. Upgrade from version 3 to version 4");

    await db.execute('''
              CREATE TABLE Mortality2 (
                id TEXT,
                siteId TEXT,
                unitId TEXT,
                speciesId INTEGER,
                time TEXT,
                rawJson TEXt,
                status INTEGER
              )
              ''');
  }

  Future _upgradeFrom4To5(Database db) async {
    print("_onUpgrade is called. Upgrade from version 4 to version 5");
    await db.execute('''
              CREATE TABLE Feeding (
                id TEXT,
                siteId TEXT,
                unitId TEXT,
                speciesId INTEGER,
                time TEXT,
                rawJson TEXt,
                status INTEGER
              )
              ''');
  }

  Future _upgradeFrom5To6(Database db) async {
    print("_onUpgrade is called. Upgrade from version 5 to version 6");
    await db.execute('''
              CREATE TABLE YesterdayFeedType (
                ${YesterdayFeedType.columnUserName} TEXT NOT NULL,
                ${YesterdayFeedType.columnUnitId} TEXT NOT NULL,
                ${YesterdayFeedType.columnFeedStoreId} TEXT NOT NULL,
                ${YesterdayFeedType.columnFeedTypeId} INT NOT NULL,
                ${YesterdayFeedType.columnDate} TEXT NOT NULL
              )
              ''');
  }

  Future _upgradeFrom6To7(Database db) async {
    print("_onUpgrade is called. Upgrade from version 6 to version 7");
    await db.execute('''
              CREATE TABLE Culling (
                id TEXT,
                siteId TEXT,
                unitId TEXT,
                speciesId INTEGER,
                time TEXT,
                rawJson TEXt,
                status INTEGER
              )
              ''');
  }

  Future _upgradeFrom7To8(Database db) async {
    await _createYesterdayCauseTable("CullingCause", db);
  }

  Future _upgradeFrom8To9(Database db) async {
    print("_onUpgrade is called. Upgrade from version 8 to version 9");
    await db.execute('''
              CREATE TABLE Lice (
                id TEXT,
                siteId TEXT,
                unitId TEXT,
                speciesId INTEGER,
                time TEXT,
                rawJson TEXt,
                status INTEGER
              )
              ''');
  }

  Future _upgradeFrom9To10(Database db) async {
    print("_onUpgrade is called. Upgrade from version 9 to version 10");
    await db.execute('''
              CREATE TABLE Environment (
                id TEXT,
                siteId TEXT,
                unitId TEXT,
                speciesId INTEGER,
                time TEXT,
                rawJson TEXt,
                status INTEGER
              )
              ''');
  }
}

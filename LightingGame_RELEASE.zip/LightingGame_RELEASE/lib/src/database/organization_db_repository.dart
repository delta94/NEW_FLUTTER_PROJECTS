import 'dart:convert';

import 'package:control_app/src/models/feeding/feed_type_available.dart';
import 'package:control_app/src/models/feeding/site_feed_types.dart';
import 'package:control_app/src/models/unit_status.dart';

import '../database/app_config_db_repository.dart';
import '../models/site_model.dart';
import '../repositories/organization_repository.dart';

class OrganizationDBRepository extends OrganizationRepository {
  @override
  Future<OrganizationRoot> fetchOrganization() async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.orgTree);
    if (data != null) {
      return parseOrgTreeJsonData(data.jsonData);
    } else {
      return null;
    }
  }

  @override
  Future<OrganizationRoot> fetchSites() async {
    final data = await AppConfigDBRepository.getAppConfig(AppConfigKeys.sites);
    if (data != null) {
      return parseSitesJsonData(data.jsonData);
    } else {
      return null;
    }
  }

  Future<Map<String, UnitStatus>> fetchUnitStatus(List<String> siteIds) async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.unitsStatus);

    if (data != null && data.jsonData != null) {
      List<UnitStatus> list = unitStatusFromMap(data.jsonData);

      if (list != null && list.length > 0) {
        Map<String, UnitStatus> result = Map<String, UnitStatus>();

        list.forEach((item) {
          result[item.unitId] = item;
        });

        return result;
      }

      return Map<String, UnitStatus>();
    } else {
      return Map<String, UnitStatus>();
    }
  }

  @override
  Future<Map<String, List<int>>> fetchUnitSpecies(List<String> siteIds) async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.unitsSpecies);

    if (data != null && data.jsonData != null) {
      var unitSpeciesData = jsonDecode(data.jsonData) as Map<String, dynamic>;

      if (unitSpeciesData == null) {
        return Map<String, List<int>>();
      } else {
        Map<String, List<int>> result = {};

        unitSpeciesData.forEach((k, v) {
          result[k] = new List<int>();

          var speciesIds = v as List<dynamic>;

          if (speciesIds != null) {
            speciesIds.forEach((f) => result[k].add(f));
          }
        });

        return result;
      }
    } else {
      return Map<String, List<int>>();
    }
  }

  Future<Map<String, List<FeedTypeAvailable>>> fetchSiteFeedTypes(
      List<String> siteIds) async {
    final data =
        await AppConfigDBRepository.getAppConfig(AppConfigKeys.siteFeedTypes);

    if (data != null && data.jsonData != null) {
      var result = siteFeedTypesFromJson(data.jsonData);

      Map<String, List<FeedTypeAvailable>> siteFeedTypesMap = Map.fromIterable(
          result,
          key: (e) => e.siteId,
          value: (e) => e.feedTypes);
      return siteFeedTypesMap;
    } else {
      return Map<String, List<FeedTypeAvailable>>();
    }
  }

  // Cache orgTreeJsonData
  Future saveOrgTreeJsonData(String jsonData) async {
    await AppConfigDBRepository.saveAppConfig(AppConfigKeys.orgTree, jsonData);
  }

  // Cache sitesJsonData
  Future saveSitesJsonData(String jsonData) async {
    await AppConfigDBRepository.saveAppConfig(AppConfigKeys.sites, jsonData);
  }
}

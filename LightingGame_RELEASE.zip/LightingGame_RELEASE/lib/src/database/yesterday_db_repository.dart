import 'package:control_app/src/database/yesterday_cause_db_repository.dart';
import 'package:control_app/src/database/yesterday_feedtype_db_repository.dart';
import 'package:control_app/src/models/registration.dart';

abstract class YesterdayDBRepository<T> {
  final String tableName;
  final List<T> items = new List<T>();
  YesterdayDBRepository({this.tableName});
  Future<int> insert(List<T> items);
  Future<List<T>> getByUsernameAndUnitId(
      String username, String unitId,
      {bool isForToday = false});
  void validate(T item);
  Future<void> removeOldEntries();
}

class YesterdayDBRepositoryFactory {
  static YesterdayDBRepository create(RegistrationType type) {
    switch (type) {
      case RegistrationType.Mortality:
        return YesterdayCauseDBRepository("MortalityCause");
      case RegistrationType.Culling:
        return YesterdayCauseDBRepository("CullingCause");
      case RegistrationType.Feeding:
        return YesterdayFeedTypeDBRepository();
      default:
        return null;
    }
  }
}
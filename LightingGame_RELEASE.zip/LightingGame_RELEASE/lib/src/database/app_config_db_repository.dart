import 'package:control_app/src/models/app_config.dart';
import 'package:sqflite/sqflite.dart';
import 'sqlite_database_helper.dart';

class AppConfigKeys {
  static String sites = "sites";
  static String orgTree = "orgTree";
  static String mortalityCauses = "mortalityCauses";
  static String missedFeedingReason = "missedFeedingReason";
  static String missedMortalityReason = "missedMortalityReason";
  static String species = "species";
  static String unitsSpecies = "unitsSpecies";
  static String unitsStatus = "unitsStatus";
  static String tenantInfo = "tenantInfo";
  static String feedTypes = "feedTypes";
  static String feedStores = "feedStores";
  static String siteFeedTypes = "siteFeedTypes";
  static String cullingCauses = "cullingCauses";
  static String medicament = "medicament";
  static String liceType = "liceType";
  static String sampleTaker = "sampleTakers";
  static String sensors = "sensors";
  static String sensorTypes = "sensorTypes";
  static String userRight = "userRight";
}

class AppConfigDBRepository {
  static Future<AppConfig> getAppConfig(String key) async {
    Database db = await SqliteDatabaseHelper.instance.database;
    List<Map> maps = await db.query("AppConfig",
        columns: [AppConfig.colKey, AppConfig.colJsonData],
        where: '${AppConfig.colKey} = ?',
        whereArgs: [key]);

    if (maps.length == 1) {
      var qa = AppConfig.fromMap(maps[0]);
      return qa;
    }

    return null;
  }

  static Future saveAppConfig(String key, String jsonData) async {
    Database db = await SqliteDatabaseHelper.instance.database;

    db.delete("AppConfig", where: '${AppConfig.colKey} = ? ', whereArgs: [key]);

    await db.insert(
        "AppConfig", new AppConfig(key: key, jsonData: jsonData).toMap());
  }
}

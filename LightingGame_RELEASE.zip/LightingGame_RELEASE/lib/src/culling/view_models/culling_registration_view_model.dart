import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/models/culling/culling_registration.dart';
import 'package:control_app/src/models/registration.dart';

class CullingRegistrationViewModel extends RegistrationViewModel {
  final bool isForSalmon;
  CullingRegistrationViewModel(this.isForSalmon)
      : super(isForSalmon, RegistrationType.Culling);

  bool get wasCulledAll => _checkCulledAll();
  int get stockNumber => getStockNumber();

  getStockNumber() {
    var total = getTotalAmountCount();
    int stockNo = organizationModel.unitStatus != null &&
            organizationModel.unitStatus.stockNo != null
        ? organizationModel.unitStatus.stockNo.round()
        : 0;
    int cullingCount = stockNo - total.round();
    if (cullingCount < 0) cullingCount = 0;
    return cullingCount;
  }

  _checkCulledAll() {
    // If total count is greater than stock number then it was culled all
    int stockNo = organizationModel.unitStatus != null &&
            organizationModel.unitStatus.stockNo != null
        ? organizationModel.unitStatus.stockNo.round()
        : 0;
    if (stockNo > 0) {
      var total = getTotalAmountCount();
      return total.round() >= stockNo;
    }

    return false;
  }

  bool get allowCulledAll => _allowCulledAll();

  bool _allowCulledAll() {
    return newRegistrations.any((registration) =>
        (registration.item as CullingRegistration).cullings.length == 1);
  }

  void culledEntireUnit(DateTime time, int speciesId) {
    if (allowCulledAll) {
      var registration = newRegistrations.firstWhere(
          (reg) => reg.speciesId == speciesId && reg.time == time,
          orElse: () => null);
      if (registration != null) {
        var cullingItem = (registration.item as CullingRegistration);
        int cullingCount = getStockNumber();
        cullingItem.cullings[0].cullingCount = cullingCount;
        cullingItem.resultingStock.individCount = 0;
        notifyListeners();
      } else {
        print("Not found registration");
      }
    }
  }

  void uncheckCulledEntireUnit(DateTime time, int speciesId) {
    if (allowCulledAll) {
      var registration = newRegistrations.firstWhere(
          (reg) => reg.speciesId == speciesId && reg.time == time,
          orElse: () => null);
      if (registration != null) {
        var cullingItem = (registration.item as CullingRegistration);
        cullingItem.resultingStock.individCount = null;
        cullingItem.cullings[0].cullingCount =
            cullingItem.cullings[0].cullingCount ?? 0;
        notifyListeners();
      } else {
        print("Not found registration");
      }
    }
  }
}

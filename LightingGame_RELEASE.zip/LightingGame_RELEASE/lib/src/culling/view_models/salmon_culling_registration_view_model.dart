import 'culling_registration_view_model.dart';

class SalmonCullingRegistrationViewModel extends CullingRegistrationViewModel {
  SalmonCullingRegistrationViewModel():super(true);
}


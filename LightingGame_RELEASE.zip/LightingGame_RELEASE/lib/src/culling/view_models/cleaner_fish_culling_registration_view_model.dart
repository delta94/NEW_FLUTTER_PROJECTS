import 'culling_registration_view_model.dart';

class CleanerFishCullingRegistrationViewModel extends CullingRegistrationViewModel {
  CleanerFishCullingRegistrationViewModel():super(false);
}


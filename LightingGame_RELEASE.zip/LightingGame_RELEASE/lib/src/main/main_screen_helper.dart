import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/organization/organization_model.dart';

class MainScreenHelper{
  static bool _isValidSite(OrganizationEntity organizationEntity) {
    if (organizationEntity != null &&
        organizationEntity is Site &&
        !organizationEntity.isHidden) {
      return true;
    }

    return false;
  }

  static Site getCurrentSite(OrganizationModel organizationModel){
    Site currentSite;
    OrganizationEntity currentOrganizationEntity = organizationModel.currentOrganizationEntity;
    if (currentOrganizationEntity != null) {
      if (_isValidSite(currentOrganizationEntity)) {
        currentSite = currentOrganizationEntity;
      } else if (currentOrganizationEntity is Unit && _isValidSite(currentOrganizationEntity.parent)) {
        currentSite = currentOrganizationEntity.parent;
      }
    }

    return currentSite;
  }

  static List<Unit> getUnits(OrganizationModel organizationModel){
    Site currentSite = getCurrentSite(organizationModel);
    if (currentSite != null && currentSite.children != null) {
      return (currentSite.children as List<Unit>)
            .where((unit) => !unit.isHidden && organizationModel.shouldBeDisplayed(unit.id))
            .toList();
    } else {
      return List<Unit>();
    }
  }
    
}
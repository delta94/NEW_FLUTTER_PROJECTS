import 'package:Commons/colors.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/culling/view_models/cleaner_fish_culling_registration_view_model.dart';
import 'package:control_app/src/culling/view_models/salmon_culling_registration_view_model.dart';
import 'package:control_app/src/environment/view_models/environment_view_model.dart';
import 'package:control_app/src/feeding/view_models/cleaner_fish_feeding_registration_view_model.dart';
import 'package:control_app/src/feeding/view_models/salmon_feeding_registration_view_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/mortality/view_models/cleaner_fish_mortality_registration_view_model.dart';
import 'package:control_app/src/mortality/view_models/salmon_mortality_registration_view_model.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:control_app/src/routers.dart';
import 'package:control_app/src/widgets/total_amount_count.dart';
import 'package:flutter/widgets.dart';
import 'package:provider/provider.dart';

import 'landbased_units.dart';
import 'locality_button.dart';
import 'locality_detail_button.dart';
import 'seabased_units.dart';

class MainScreenBody extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    OrganizationModel organizationModel =
        Provider.of<OrganizationModel>(context);
    OrganizationEntity currentOrganizationEntity =
        organizationModel.currentOrganizationEntity;

    _getCurrentRegistrations(RegistrationViewModel registrationViewModel) {
      return registrationViewModel.registrations
          .where((currentRegistration) =>
              currentRegistration.changeStatus != ChangeStatus.Deleted)
          .toList();
    }

    _getTotalLices() {
      final appText = S.of(context);
      LiceSampleViewModel liceSampleViewModel =
          Provider.of<LiceSampleViewModel>(context);

      if (liceSampleViewModel.liceSamples.isEmpty)
        return null;
      else {
        int totalFishes = 0;
        liceSampleViewModel.liceSamples.forEach((registration) {
          (registration.item as LiceSample).samples.forEach((sample) {
            sample.parameters.forEach((key, val) {
              totalFishes += val;
            });
          });
        });

        return TotalAmountCount(
          title: appText.salmon,
          totalAmountCount: totalFishes.toDouble(),
        );
      }
    }

    _getTotalSensors() {
      final appText = S.of(context);
      EnvironmentViewModel environmentViewModel =
          Provider.of<EnvironmentViewModel>(context);

      int totalSensors = environmentViewModel.registrations.length;

      return TotalAmountCount(
        title: appText.sensors,
        totalAmountCount: totalSensors.toDouble(),
      );
    }

    Widget _getContent(RegistrationType registrationType, {String unitSymbol}) {
      final appText = S.of(context);
      RegistrationViewModel salmonRegistrationViewModel;
      RegistrationViewModel cleanerFishRegistrationViewModel;
      switch (registrationType) {
        case RegistrationType.Mortality:
          salmonRegistrationViewModel =
              Provider.of<SalmonMortalityRegistrationViewModel>(context);
          cleanerFishRegistrationViewModel =
              Provider.of<CleanerFishMortalityRegistrationViewModel>(context);
          break;
        case RegistrationType.Feeding:
          salmonRegistrationViewModel =
              Provider.of<SalmonFeedingRegistrationViewModel>(context);
          cleanerFishRegistrationViewModel =
              Provider.of<CleanerFishFeedingRegistrationViewModel>(context);
          break;
        case RegistrationType.Culling:
          salmonRegistrationViewModel =
              Provider.of<SalmonCullingRegistrationViewModel>(context);
          cleanerFishRegistrationViewModel =
              Provider.of<CleanerFishCullingRegistrationViewModel>(context);
          break;
        case RegistrationType.Lice:
          return _getTotalLices();
        case RegistrationType.Environment:
          return _getTotalSensors();
        default:
      }

      List<Registration> salmonRegistrations =
          _getCurrentRegistrations(salmonRegistrationViewModel);

      List<Registration> cleanerFishRegistrations =
          _getCurrentRegistrations(cleanerFishRegistrationViewModel);

      if (salmonRegistrations.isEmpty && cleanerFishRegistrations.isEmpty) {
        return null;
      } else {
        bool isUnknownSalmonAmountCount = salmonRegistrations.isEmpty ||
            salmonRegistrationViewModel.status ==
                RegistrationStatus.MISSED_REGISTRATION;

        bool isUnknownCleanerFishAmountCount =
            cleanerFishRegistrations.isEmpty ||
                cleanerFishRegistrationViewModel.status ==
                    RegistrationStatus.MISSED_REGISTRATION;

        double salmonAmountCount = isUnknownSalmonAmountCount
            ? null
            : salmonRegistrationViewModel
                .getRegistrationsTotalCount(salmonRegistrations);
        double cleanerFishAmountCount = isUnknownCleanerFishAmountCount
            ? null
            : cleanerFishRegistrationViewModel
                .getRegistrationsTotalCount(cleanerFishRegistrations);

        unitSymbol ??= '';
        return Column(
          children: <Widget>[
            Visibility(
              visible: appModel.appMode == AppMode.Seabased,
              child: Column(
                children: [
                  TotalAmountCount(
                    title: appText.cleanerfish,
                    totalAmountCount: cleanerFishAmountCount,
                    unitSymbol: unitSymbol,
                  ),
                  SizedBox(height: 8),
                ],
              ),
            ),
            TotalAmountCount(
              title: appText.salmon,
              totalAmountCount: salmonAmountCount,
              unitSymbol: unitSymbol,
            ),
          ],
        );
      }
    }

    bool allowReadRegistration(RegistrationType registrationType) {
      return organizationModel
          .registrationUserRightMap[registrationType].allowRead;
    }

    navigate(String routeName) {
      Navigator.pushNamed(
        context,
        routeName,
      );
    }

    addModuleWidget({
      List<Widget> allModules,
      List<Widget> disabledModules,
      String title,
      Color leftBorderColor,
      RegistrationType registrationType,
      String routedName,
    }) {
      if (allowReadRegistration(registrationType)) {
        bool isFeeding = registrationType == RegistrationType.Feeding;
        allModules.add(
          LocalityButton(
            title: title,
            leftBorderColor: leftBorderColor,
            content: _getContent(registrationType,
                unitSymbol: isFeeding ? 'kg' : null),
            onPressed: () => navigate(routedName),
          ),
        );
      } else {
        disabledModules.add(
          LocalityButton(
            title: title,
            leftBorderColor: leftBorderColor,
            enabled: false,
          ),
        );
      }
    }

    buidModulesList() {
      List<Widget> allModules = [];
      List<Widget> disabledModules = [];

      // Detail
      allModules.add(
        LocalityDetailButton(
          onPressed: () {},
          buttonColor: appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorA,
        ),
      );

      // Mortality
      addModuleWidget(
        allModules: allModules,
        disabledModules: disabledModules,
        leftBorderColor: akvaMainSecondary,
        registrationType: RegistrationType.Mortality,
        routedName: Routers.mortality,
        title: appText.mortality,
      );

      // Feeding
      addModuleWidget(
        allModules: allModules,
        disabledModules: disabledModules,
        leftBorderColor: akvaAccentMain,
        registrationType: RegistrationType.Feeding,
        routedName: Routers.feeding,
        title: appText.feeding,
      );

      // Environment
      addModuleWidget(
        allModules: allModules,
        disabledModules: disabledModules,
        leftBorderColor: akvaMainActionDisabled,
        registrationType: RegistrationType.Environment,
        routedName: Routers.environment,
        title: appText.environment,
      );

      // Culling
      addModuleWidget(
        allModules: allModules,
        disabledModules: disabledModules,
        leftBorderColor: akvaMainTertiary,
        registrationType: RegistrationType.Culling,
        routedName: Routers.culling,
        title: appText.culling,
      );

      // Lice
      addModuleWidget(
        allModules: allModules,
        disabledModules: disabledModules,
        leftBorderColor: akvaLiceColor,
        registrationType: RegistrationType.Lice,
        routedName: Routers.lice,
        title: appText.lice,
      );

      allModules.addAll(disabledModules);
      return allModules;
    }

    List moduleWidgets = buidModulesList();

    return Expanded(
      child: Column(
        children: <Widget>[
          appModel.appMode == AppMode.Seabased
              ? SeabasedUnits()
              : LandbasedUnits(),
          Expanded(
            child: Container(
              color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorA,
              child: currentOrganizationEntity is Unit
                  ? GridView.builder(
                      itemCount: moduleWidgets.length,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 20, vertical: 20),
                      gridDelegate:
                          new SliverGridDelegateWithFixedCrossAxisCount(
                        mainAxisSpacing: 17,
                        crossAxisSpacing: 15,
                        crossAxisCount: 2,
                      ),
                      itemBuilder: (BuildContext context, int index) {
                        return moduleWidgets[index];
                      })
                  : Container(),
            ),
          ),
        ],
      ),
    );
  }
}

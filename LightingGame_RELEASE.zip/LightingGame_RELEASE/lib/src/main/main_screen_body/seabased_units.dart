import 'package:Commons/colors.dart';
import 'package:Commons/buttons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/main/main_screen_helper.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';

class SeabasedUnits extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    OrganizationModel organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);

    List<Unit> units = MainScreenHelper.getUnits(organizationModel);

    final s = S.of(context);
    final appModel = Provider.of<AppModel>(context);

    return Container(
      padding: EdgeInsets.only(top: 20, bottom: 20, right: 7, left: 7),
      color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorB,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Padding(
            padding: const EdgeInsets.only(left: 12),
            child: Text(
              s.unit,
              style: TextStyle(
                  fontSize: 20,
                  color: appModel.isDarkTheme ? akvaDarkTextA : akvaLightTextA),
            ),
          ),
          SizedBox(height: 15),
          Container(
            height: 34,
            child: new ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: units.length,
                itemBuilder: (BuildContext ctxt, int index) {
                  return Container(
                    margin: EdgeInsets.only(left: 12),
                    child: ButtonTheme(
                      minWidth: 45,
                      child: AkvaTabBarButton(
                        onPressed: () => (organizationModel
                            .setCurrentOrganizationEntityById(units[index].id)),
                        label: units[index].name,
                        selected:
                            (units[index] == organizationModel.currentUnit),
                        isDarkTheme: appModel.isDarkTheme,
                      ),
                    ),
                  );
                }),
          ),
        ],
      ),
    );
  }
}

import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/widgets/highlight_text.dart';
import 'package:flutter/material.dart';
import 'package:Commons/colors.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:provider/provider.dart';

class LocalityButton extends StatelessWidget {
  LocalityButton({
    @required this.title,
    @required this.leftBorderColor,
    this.onPressed,
    this.content,
    this.enabled: true,
    // this.isUpTrend,
  });

  final String title;
  final Color leftBorderColor;
  final VoidCallback onPressed;
  final Widget content;
  final bool enabled;
  // final bool isUpTrend;

  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context);
    final appText = S.of(context);

    getContent() {
      if (!enabled)
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5),
          child: HighlightText(
              text: appText.access_required,
              mainAxisAlignment: MainAxisAlignment.center),
        );

      if (content == null)
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            CircleAvatar(
              radius: 14,
              backgroundColor:
                  appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorE,
              child: Icon(
                AkvaIcons.pen,
                size: 18,
                color: appModel.isDarkTheme ? akvaDarkColorA : akvaMainNeutral,
              ),
            ),
            SizedBox(height: 5),
            Text(
              appText.no_registrations,
              style: TextStyle(
                fontSize: 17,
                fontWeight: FontWeight.w500,
                color: appModel.isDarkTheme ? akvaDarkColorB : akvaMainNeutral,
              ),
            ),
          ],
        );
      else
        return content;
    }

    return Container(
      height: 177,
      decoration: BoxDecoration(
        gradient: enabled
            ? new LinearGradient(
                stops: [0.025, 0.025],
                colors: [leftBorderColor, Colors.transparent])
            : null,
        borderRadius: new BorderRadius.circular(5),
        border: Border.all(
          color: appModel.isDarkTheme ? akvaMainDark : akvaLightColorA,
        ),
      ),
      padding: EdgeInsets.only(left: enabled ? 4 : 0),
      child: RaisedButton(
        disabledColor: appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorB,
        onPressed: onPressed,
        padding: EdgeInsets.zero,
        color: appModel.isDarkTheme ? akvaDarkColorC : akvaLightColorB,
        textColor: appModel.isDarkTheme ? akvaDarkTextA : akvaLightTextA,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.only(
            bottomRight: Radius.circular(5),
            topRight: Radius.circular(5),
          ),
        ),
        child: Container(
          padding:
              const EdgeInsets.only(top: 10, left: 10, bottom: 15, right: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: <Widget>[
                  Expanded(
                    child: Row(
                      children: <Widget>[
                        Visibility(
                          visible: !enabled,
                          child: Wrap(
                            children: [
                              CircleAvatar(
                                radius: 14,
                                backgroundColor: appModel.isDarkTheme
                                    ? akvaDarkColorB
                                    : akvaLightColorE,
                                child: Icon(
                                  AkvaIcons.lock,
                                  size: 17,
                                  color: akvaMainAction,
                                ),
                              ),
                              SizedBox(width: 10),
                            ],
                          ),
                        ),
                        Flexible(
                          fit: FlexFit.loose,
                          child: Text(
                            title,
                            softWrap: false,
                            overflow: TextOverflow.fade,
                            style: TextStyle(
                                fontSize: 20, fontWeight: FontWeight.w500),
                          ),
                        ),
                        // TODO: This trend icon will be implemented in next phase

                        // CircleAvatar(
                        //   radius: 12,
                        //   backgroundColor: appModel.isDarkTheme
                        //       ? akvaDarkColorB
                        //       : isUpTrend ? akvaMainSecondary : akvaMainAction,
                        //   child: Icon(
                        //       isUpTrend
                        //           ? AkvaIcons.up_trend
                        //           : AkvaIcons.down_trend,
                        //       size: 17,
                        //       color: appModel.isDarkTheme
                        //           ? isUpTrend
                        //               ? akvaMainSecondary
                        //               : akvaMainAction
                        //           : akvaLightColorB),
                        // ),
                      ],
                    ),
                  ),
                ],
              ),
              getContent()
            ],
          ),
        ),
      ),
    );
  }
}

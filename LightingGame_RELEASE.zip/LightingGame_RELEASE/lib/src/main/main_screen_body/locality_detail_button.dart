import 'package:Commons/fonts.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:flutter/material.dart';
import 'package:Commons/colors.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:provider/provider.dart';

import '../../app_model.dart';

class LocalityDetailButton extends StatelessWidget {
  LocalityDetailButton({
    @required this.onPressed,
    this.buttonColor,
  });

  final VoidCallback onPressed;
  final Color buttonColor;
  @override
  Widget build(BuildContext context) {
    double biomass = 0.00;
    int stock = 0;
    double avgWeight = 0.00;

    final appText = S.of(context);
    final AppModel appModel = Provider.of<AppModel>(context, listen: false);
    OrganizationModel organizationModel =
        Provider.of<OrganizationModel>(context);

    double getAvgWeight() {
      if (organizationModel.unitStatus.stockNo == 0 ||
          organizationModel.unitStatus.stockBm == 0) {
        return 0.0;
      }

      return organizationModel.unitStatus.stockBm /
          organizationModel.unitStatus.stockNo;
    }

    if (organizationModel.unitStatus != null) {
      biomass = organizationModel.unitStatus.stockBm / 1000000;
      stock = organizationModel.unitStatus.stockNo;
      avgWeight = getAvgWeight();
    }

    return Container(
      height: 177,
      child: RaisedButton(
        onPressed: onPressed,
        color: appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorB,
        padding: EdgeInsets.zero,
        textColor: appModel.isDarkTheme ? akvaDarkTextA : akvaDarkColorD,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(5),
        ),
        child: Container(
          padding:
              const EdgeInsets.only(top: 12, left: 12, bottom: 15, right: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Padding(
                    padding: EdgeInsetsDirectional.only(bottom: 10),
                    child: Text(
                      appText.details,
                      style: TextStyle(
                        fontSize: FontSize.medium,
                        fontWeight: FontWeight.normal,
                      ),
                    ),
                  ),
                ],
              ),
              SizedBox(height: 7),
              Text(appText.biomass,
                  style: TextStyle(
                    fontSize: FontSize.xsmall,
                    fontWeight: FontWeight.normal,
                  )),
              Padding(
                padding: EdgeInsets.fromLTRB(0, 0, 0, 5),
                child: Text(
                  biomass.toStringAsFixed(2),
                  style: TextStyle(
                    fontWeight: FontWeight.normal,
                    fontSize: FontSize.xsmall,
                  ),
                ),
              ),
              SizedBox(height: 4),
              Text(appText.stock,
                  style: TextStyle(
                    fontSize: FontSize.xsmall,
                    fontWeight: FontWeight.normal,
                  )),
              Padding(
                padding: EdgeInsets.fromLTRB(0, 0, 0, 5),
                child: Text(
                  stock.toString(),
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: FontSize.xsmall,
                  ),
                ),
              ),
              SizedBox(height: 4),
              Text(
                appText.avg_weight + " [g]",
                style: TextStyle(
                  fontSize: FontSize.xsmall,
                  fontWeight: FontWeight.normal,
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(0, 0, 0, 5),
                child: Text(
                  avgWeight.toStringAsFixed(2),
                  style: TextStyle(
                    fontWeight: FontWeight.w500,
                    fontSize: FontSize.xsmall,
                  ),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}

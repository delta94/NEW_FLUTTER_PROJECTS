import 'package:Commons/colors.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/culling/view_models/cleaner_fish_culling_registration_view_model.dart';
import 'package:control_app/src/culling/view_models/salmon_culling_registration_view_model.dart';
import 'package:control_app/src/environment/view_models/environment_view_model.dart';
import 'package:control_app/src/feeding/view_models/cleaner_fish_feeding_registration_view_model.dart';
import 'package:control_app/src/feeding/view_models/salmon_feeding_registration_view_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/mortality/view_models/cleaner_fish_mortality_registration_view_model.dart';
import 'package:control_app/src/mortality/view_models/salmon_mortality_registration_view_model.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';

import '../main_screen_helper.dart';

class LandbasedUnits extends StatefulWidget {
  @override
  _LandbasedUnitsState createState() => _LandbasedUnitsState();
}

class _LandbasedUnitsState extends State<LandbasedUnits> {
  List<Unit> _units;

  @override
  Widget build(BuildContext context) {
    OrganizationModel organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);

    final s = S.of(context);
    final appModel = Provider.of<AppModel>(context);

    _units = MainScreenHelper.getUnits(organizationModel);

    List<DropdownMenuItem<String>> dropdownItems = _units
        .map((unit) =>
            new DropdownMenuItem(child: Text(unit.name), value: unit.id))
        .toList();

    return Container(
      padding: EdgeInsets.all(20),
      color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorA,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(s.unit_name,
              style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.normal,
                  color:
                      appModel.isDarkTheme ? akvaDarkTextA : akvaMainNeutral)),
          SizedBox(height: 15),
          Container(
            decoration: BoxDecoration(
                border: Border.all(color: akvaMainNeutral),
                color: appModel.isDarkTheme ? akvaDarkColorA : akvaLightColorB),
            child: Row(children: <Widget>[
              SizedBox(width: 10),
              Icon(Icons.search, color: akvaMainNeutral),
              SizedBox(width: 10),
              Expanded(
                child: DropdownButtonHideUnderline(
                  child: DropdownButton<String>(
                      hint: Text(s.jump_to_unit,
                          style: TextStyle(
                              color: appModel.isDarkTheme
                                  ? akvaDarkTextB
                                  : akvaLightTextB)),
                      isDense: true,
                      value: organizationModel.currentUnit.id,
                      icon: Container(
                        padding: EdgeInsets.only(left: 5, right: 5, top: 2),
                        decoration: BoxDecoration(
                            border: Border(
                              left: BorderSide(
                                  color: appModel.isDarkTheme
                                      ? akvaMainNeutral
                                      : akvaLightColorE),
                            ),
                            color: appModel.isDarkTheme
                                ? akvaDarkColorA
                                : akvaLightColorB),
                        child: Icon(Icons.keyboard_arrow_down,
                            size: 36, color: akvaMainNeutral),
                      ),
                      iconSize: 40,
                      style: TextStyle(
                          color: appModel.isDarkTheme
                              ? akvaDarkTextB
                              : akvaDarkColorD,
                          fontSize: 18),
                      onChanged: (String unitId) => organizationModel
                          .setCurrentOrganizationEntityById(unitId),
                      items: dropdownItems),
                ),
              ),
            ]),
          ),
        ],
      ),
    );
  }
}

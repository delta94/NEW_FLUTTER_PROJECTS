import 'package:control_app/src/util/constants.dart';

class BaseModel {
  ChangeStatus changeStatus;
}

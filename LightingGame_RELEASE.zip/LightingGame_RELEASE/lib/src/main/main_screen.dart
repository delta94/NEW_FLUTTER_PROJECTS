import 'Package:flutter/material.dart';
import 'package:Commons/colors.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/widgets/offline_status.dart';
import 'package:control_app/src/widgets/synchronize_progress_status.dart';
import 'package:provider/provider.dart';
import 'main_screen_body/main_screen_body.dart';
import 'main_screen_header/main_screen_header.dart';

class MainScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<AppModel>(
        builder: (context, model, child) => buildScreen(context, model));
  }

  Widget buildScreen(BuildContext context, AppModel appModel) {
    return Scaffold(
      backgroundColor: appModel.isDarkTheme ? akvaDarkColorC : akvaDarkColorE,
      body: SafeArea(
        child: Column(
          children: <Widget>[
            SynchronizeProgressStatus(),
            OfflineStatus(),
            MainScreenHeader(),
            Divider(height: 0, thickness: 1, color: akvaMainNeutral),
            MainScreenBody(),
          ],
        ),
      ),
    );
  }
}


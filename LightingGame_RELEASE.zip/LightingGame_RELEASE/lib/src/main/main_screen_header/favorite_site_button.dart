import 'package:Commons/buttons.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';

class FavoriteSiteButton extends StatefulWidget {
  final bool isFavoritedSite;

  FavoriteSiteButton(this.isFavoritedSite);

  @override
  _FavoriteSiteButtonState createState() =>
      _FavoriteSiteButtonState(this.isFavoritedSite);
}

class _FavoriteSiteButtonState extends State<FavoriteSiteButton> {
  bool isFavoritedSite;

  _FavoriteSiteButtonState(this.isFavoritedSite);

  @override
  Widget build(BuildContext context) {
    return Consumer<AppModel>(
        builder: (context, model, child) => buildButton(context, model));
  }

  void onFavoritePress(BuildContext context) {
    var organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);
    OrganizationEntity currentOrganizationEntity =
        organizationModel.currentOrganizationEntity;
    if (currentOrganizationEntity != null) {
      Site currentSite;
      if (currentOrganizationEntity is Site) {
        currentSite = currentOrganizationEntity;
      } else if (currentOrganizationEntity is Unit) {
        currentSite = currentOrganizationEntity.parent;
      }

      toggleFavorite(currentSite);
    }
  }

  void toggleFavorite(Site currentSite) {
    final organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);
    organizationModel.toggleFavorite(currentSite.id);
    this.setState(() => isFavoritedSite = !isFavoritedSite);
  }

  Widget buildButton(BuildContext context, AppModel appModel) {
    final s = S.of(context);

    return Container(
        margin: EdgeInsets.only(right: 10),
        child: AkvaToggleLabel(
          label: s.favorite_site,
          icon: isFavoritedSite ? AkvaIcons.favorite : AkvaIcons.star_border,
          onPressed: () => onFavoritePress(context),
          toggled: isFavoritedSite,
        ));
  }
}

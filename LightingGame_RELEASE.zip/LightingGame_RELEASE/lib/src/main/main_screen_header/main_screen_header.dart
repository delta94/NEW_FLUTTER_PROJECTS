import 'package:Commons/buttons.dart';
import 'package:Commons/colors.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/main/main_screen_helper.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:provider/provider.dart';
import 'favorite_site_button.dart';

class MainScreenHeader extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<AppModel>(
        builder: (context, model, child) => buildHeader(context, model));
  }

  Widget buildHeader(BuildContext context, AppModel appModel) {
    OrganizationModel organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);
    Site currentSite = MainScreenHelper.getCurrentSite(organizationModel);
    String siteId = currentSite.id;
    String siteName = currentSite.name;
    bool isFavoritedSite;

    isFavoritedSite = organizationModel.isFavoritedSite(siteId);

    final s = S.of(context);

    return Padding(
      padding: EdgeInsets.only(left: 15, right: 15, top: 5),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              FlatButton(
                materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
                padding: EdgeInsets.all(0),
                onPressed: () => Navigator.pop(context),
                child: Wrap(
                  children: <Widget>[
                    Icon(AkvaIcons.back_circle,
                        size: 25,
                        color: appModel.isDarkTheme
                            ? akvaDarkTextA
                            : akvaLightColorB),
                    SizedBox(width: 10),
                    Container(
                        padding: EdgeInsets.only(top: 2, bottom: 2),
                        child: Text(s.back,
                            style: TextStyle(
                                fontSize: 18,
                                color: appModel.isDarkTheme
                                    ? akvaDarkTextA
                                    : akvaLightColorB)))
                  ],
                ),
              ),
              FavoriteSiteButton(isFavoritedSite)
            ],
          ),
          Padding(
            padding: EdgeInsets.only(top: 15, bottom: 20, left: 5, right: 5),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: <Widget>[
                            Container(
                                child: Text(
                              siteName != null ? siteName : '',
                              style: TextStyle(
                                  fontSize: 24,
                                  color: appModel.isDarkTheme
                                      ? akvaDarkTextA
                                      : akvaLightColorB),
                            )),
                            Visibility(
                              maintainSize: true,
                              maintainAnimation: true,
                              maintainState: true,
                              visible: appModel.appMode == AppMode.Landbased,
                              child: AkvaPrimaryButton.iconOnly(
                                  icon: AkvaIcons.barcode, onPressed: () => {}),
                            )
                          ],
                        ),
                        Container(
                          padding: EdgeInsets.zero,
                          child: Text(
                              'Department', // This text should be replace by real data
                              style: TextStyle(
                                  fontSize: 20,
                                  color: appModel.isDarkTheme
                                      ? akvaDarkTextA
                                      : akvaLightColorB)),
                        )
                      ]),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/culling/view_models/cleaner_fish_culling_registration_view_model.dart';
import 'package:control_app/src/culling/view_models/salmon_culling_registration_view_model.dart';
import 'package:control_app/src/environment/view_models/environment_view_model.dart';
import 'package:control_app/src/feeding/view_models/cleaner_fish_feeding_registration_view_model.dart';
import 'package:control_app/src/feeding/view_models/salmon_feeding_registration_view_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:provider/provider.dart';
import 'package:provider/single_child_widget.dart';

import 'mortality/view_models/cleaner_fish_mortality_registration_view_model.dart';
import 'mortality/view_models/salmon_mortality_registration_view_model.dart';

List<SingleChildWidget> providers = [
  ...commonServices,
  ...mortalityServices,
  ...feedingServices,
  ...cullingServices,
  ...liceServices,
  ...environmentServices
];

///
/// Commons services that will be used for the whole app
List<SingleChildWidget> commonServices = [
  ChangeNotifierProvider<AppModel>(
    create: (_) => AppModel(),
  ),
  ChangeNotifierProxyProvider<AppModel, SharedDataModel>(
    create: (_) => SharedDataModel(),
    update: (_, appModel, sharedDataModel) =>
        sharedDataModel..updateAppModel(appModel),
  ),
  ChangeNotifierProxyProvider2<AppModel, SharedDataModel, OrganizationModel>(
    create: (_) => OrganizationModel(),
    update: (_, appModel, sharedDataModel, organizationModel) =>
        organizationModel..updateStates(appModel, sharedDataModel),
  ),
];

///
/// Mortality services
List<SingleChildWidget> mortalityServices = [
  ChangeNotifierProxyProvider2<AppModel, OrganizationModel,
      SalmonMortalityRegistrationViewModel>(
    create: (_) => SalmonMortalityRegistrationViewModel(),
    update: (_, appModel, organizationModel, mortalityRegistrationViewModel) =>
        mortalityRegistrationViewModel
          ..updateModel(appModel, organizationModel),
  ),
  ChangeNotifierProxyProvider2<AppModel, OrganizationModel,
      CleanerFishMortalityRegistrationViewModel>(
    create: (_) => CleanerFishMortalityRegistrationViewModel(),
    update: (_, appModel, organizationModel, mortalityRegistrationViewModel) =>
        mortalityRegistrationViewModel
          ..updateModel(appModel, organizationModel),
  ),
];

///
/// Feeding services
List<SingleChildWidget> feedingServices = [
  ChangeNotifierProxyProvider2<AppModel, OrganizationModel,
      SalmonFeedingRegistrationViewModel>(
    create: (_) => SalmonFeedingRegistrationViewModel(),
    update: (_, appModel, organizationModel, feedingRegistrationViewModel) =>
        feedingRegistrationViewModel..updateModel(appModel, organizationModel),
  ),
  ChangeNotifierProxyProvider2<AppModel, OrganizationModel,
      CleanerFishFeedingRegistrationViewModel>(
    create: (_) => CleanerFishFeedingRegistrationViewModel(),
    update: (_, appModel, organizationModel, feedingRegistrationViewModel) =>
        feedingRegistrationViewModel..updateModel(appModel, organizationModel),
  ),
];

///
/// Culling services
List<SingleChildWidget> cullingServices = [
  ChangeNotifierProxyProvider2<AppModel, OrganizationModel,
      SalmonCullingRegistrationViewModel>(
    create: (_) => SalmonCullingRegistrationViewModel(),
    update: (_, appModel, organizationModel, cullingRegistrationViewModel) =>
        cullingRegistrationViewModel..updateModel(appModel, organizationModel),
  ),
  ChangeNotifierProxyProvider2<AppModel, OrganizationModel,
      CleanerFishCullingRegistrationViewModel>(
    create: (_) => CleanerFishCullingRegistrationViewModel(),
    update: (_, appModel, organizationModel, cullingRegistrationViewModel) =>
        cullingRegistrationViewModel..updateModel(appModel, organizationModel),
  ),
];

///
/// Lice services
List<SingleChildWidget> liceServices = [
  ChangeNotifierProxyProvider3<AppModel, OrganizationModel, SharedDataModel,
      LiceSampleViewModel>(
    create: (_) => LiceSampleViewModel(),
    update: (_, appModel, organizationModel, sharedDataModel,
            liceSampleViewModel) =>
        liceSampleViewModel
          ..updateDependencies(appModel, organizationModel, sharedDataModel),
  ),
];

///
/// Environment services
List<SingleChildWidget> environmentServices = [
  ChangeNotifierProxyProvider3<AppModel, OrganizationModel, SharedDataModel,
      EnvironmentViewModel>(
    create: (_) => EnvironmentViewModel(),
    update: (_, appModel, organizationModel, sharedDataModel,
            environmentViewModel) =>
        environmentViewModel
          ..updateDI(appModel, organizationModel, sharedDataModel),
  ),
];

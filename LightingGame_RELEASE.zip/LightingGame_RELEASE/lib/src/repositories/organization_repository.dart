import 'dart:convert';

import '../models/site_model.dart';
import 'package:flutter/material.dart';

abstract class OrganizationRepository {
  String sitesJson;
  String orgTreeJson;
  String speciesJson;
  String tenantInfoJson;
  Future<OrganizationRoot> fetchSites();
  Future<OrganizationRoot> fetchOrganization();
  Future<Map<String, List<int>>> fetchUnitSpecies(List<String> siteIds);
  @protected
  OrganizationRoot parseSitesJsonData(data) {
    if (data != null) {
      final parsedJson = json.decode(data);

      OrganizationRoot x = OrganizationRoot.fromJson(parsedJson);
      print(x.children);
      return x;
    } else {
      return new OrganizationRoot.fromJson(new List<dynamic>());
    }
  }

  @protected
  OrganizationRoot parseOrgTreeJsonData(data) {
    if (data != null) {
      final parsedJson = json.decode(data);

      OrganizationRoot root = OrganizationRoot();

      parsedJson.forEach((orgUnit){
        root.children.add(OrganizationRoot.fromOrgTreeJson(orgUnit));
      });

      return root;
    } else {
      return new OrganizationRoot.fromOrgTreeJson({});
    }
  }
}

import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/site_model.dart';

abstract class RegistrationBaseRepository {
  RegistrationType type;
  RegistrationBaseRepository({this.type});
  Future<List<Registration>> fetchByUnit(Unit unit, {DateTime time});
  Future<List<Registration>> fetchBySite({String siteId, DateTime date});
  Future<dynamic> store(Registration registration);
  Future<List<Registration>> storeMultiple(List<Registration> registrations);

  Future<dynamic> saveChanges(List<Registration> registrations);
  Future<bool> update(Registration updatedItem);
  Future<dynamic> updateMultiple(List<Registration> updatedItem, {bool includeId});
  Future<bool> delete(Registration registration);

  /// Delete multiple [Registration] from repository
  ///
  /// [registrations] List of [Registration] to delete
  /// 
  /// Return a list of [Registration] is deleted from repository.
  Future<List<Registration>> deleteMultiple(List<Registration> registrations);
}
import 'package:control_app/src/models/quick_access.dart';

abstract class QuickAccessRepository {
  /// Insert Quick Access data model
  Future<int> insert(QuickAccess quickAccess);

  /// Update Quick Access data model
  Future<int> update(QuickAccess quickAccess);

  /// Get all quick access data models for a user by user name
  Future<List<QuickAccess>> getByUsername(String username);
}

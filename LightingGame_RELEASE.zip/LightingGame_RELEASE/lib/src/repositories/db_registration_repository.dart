import 'dart:convert';
import 'package:control_app/src/database/sqlite_database_helper.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/registration_factory.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/services/timezone_service.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:sqflite/sqflite.dart';
import 'package:intl/intl.dart';
import 'registration_base_repository.dart';

const registrationColumns = [
  'rowid',
  'id',
  'siteId',
  'unitId',
  'speciesId',
  'time',
  'rawJson',
  'status'
];

List<String> getColumns(RegistrationType type) {
  switch (type) {
    case RegistrationType.Mortality:
    case RegistrationType.Feeding:
    case RegistrationType.Culling:
    case RegistrationType.Lice:
    case RegistrationType.Environment:
      return registrationColumns;
    default:
      return null;
  }
}

String getRegistrationTableName(RegistrationType type) {
  switch (type) {
    case RegistrationType.Mortality:
      return "Mortality2";
    case RegistrationType.Feeding:
      return "Feeding";
    case RegistrationType.Culling:
      return "Culling";
    case RegistrationType.Environment:
      return "Environment";
    case RegistrationType.Lice:
      return "Lice";
    default:
      return "Mortality";
  }
}

class DBRegistrationRepository extends RegistrationBaseRepository {
  DBRegistrationRepository(RegistrationType type) : super(type: type);

  @override
  Future<bool> delete(Registration registration) async {
    int rowsAffected = 0;

    if (registration.rowId != null) {
      Database db = await SqliteDatabaseHelper.instance.database;

      rowsAffected = await db.delete(
        getRegistrationTableName(type),
        where: 'rowid = ? ',
        whereArgs: [registration.rowId],
      );
    }

    return rowsAffected == 1;
  }

  /// Delete multiple [Registration] from repository
  ///
  /// [registrations] List of [Registration] to delete
  ///
  /// Return a list of [Registration] is deleted from repository.
  @override
  Future<List<Registration>> deleteMultiple(
      List<Registration> registrations) async {
    if (registrations == null || registrations.length == 0) {
      return [];
    }

    Database db = await SqliteDatabaseHelper.instance.database;

    var idList = registrations.map((r) => r.rowId).join(',');

    var rowsAffected = await db.delete(
      getRegistrationTableName(type),
      where: 'rowid IN (' + idList + ')',
    );

    return rowsAffected == idList.length ? registrations : [];
  }

  @override
  Future<List<Registration>> fetchByUnit(Unit unit, {DateTime time}) async {
    Database db = await SqliteDatabaseHelper.instance.database;
    Site site = unit.parent;
    DateTime timezoneTime = TimeZoneService.convertToTimezone(
        time != null ? time : DateTime.now(), site.timeZoneId);

    String dateSlug = DateFormat('yyyy-MM-dd').format(timezoneTime);

    /// For environment, since sensors can be applied for entire site.
    /// These kind of sensors do not have unitId filled in (null).
    List<Map> maps = await db.query(getRegistrationTableName(type),
        columns: getColumns(type),
        where: type == RegistrationType.Environment
            ? 'siteId = ? AND (unitId is null OR unitId = ?) AND strftime(\'%Y-%m-%d\', time) = ? AND status != ?'
            : 'siteId = ? AND unitId = ? AND strftime(\'%Y-%m-%d\', time) = ? AND status != ?',
        whereArgs: [
          unit.parent.id,
          unit.id,
          dateSlug,
          ChangeStatus.Deleted.index
        ]);
    if (maps != null && maps.length > 0) {
      return maps
          .map((map) => Registration.fromMap(
              map,
              (_) => RegistrationFactory.create(type,
                  jsonObj: json.decode(map["rawJson"]))))
          .toList();
    }

    return new List<Registration>();
  }

  /// Get the last registration stored in db for [unit]
  /// Return [null] if no registration existed for that [unit]
  Future<Registration> getLastRegistration(Site site) async {
    Database db = await SqliteDatabaseHelper.instance.database;
    List<Map> maps = await db.query(getRegistrationTableName(type),
        columns: getColumns(type),
        where: 'siteId = ? AND status != ?',
        whereArgs: [site.id, ChangeStatus.Deleted.index],
        limit: 1,
        orderBy: "time DESC");
    if (maps != null && maps.length > 0) {
      return Registration.fromMap(
          maps.first,
          (_) => RegistrationFactory.create(type,
              jsonObj: json.decode(maps.first["rawJson"])));
    }
    return null;
  }

  @override
  Future store(Registration registration) async {
    if (registration == null) return;
    Database db = await SqliteDatabaseHelper.instance.database;
    final rowId =
        await db.insert(getRegistrationTableName(type), registration.toMap());
    //Update row id to current registration for querying at later time
    registration.rowId = rowId;
  }

  /// Store multiple [Registration] to DB
  ///
  /// List of [Registration] to store
  /// Return list of [Registration] is stored.
  @override
  Future<List<Registration>> storeMultiple(
      List<Registration> registrations) async {
    if (registrations == null && registrations.length > 0) return null;

    var futures = <Future>[];
    registrations.forEach((f) => futures.add(store(f)));

    await Future.wait(futures);

    return registrations;
  }

  @override
  Future saveChanges(List<Registration> registrations) async {
    if (registrations == null) return;
    var futures = <Future>[];
    registrations.forEach((registration) {
      /// To ensure that any changes on [item] will be updated into
      /// local storage, we must call [commit] function
      registration.item.commit();
      if (registration.changeStatus != ChangeStatus.Unchanged) {
        if (registration.changeStatus == ChangeStatus.Deleted) {
          if (registration.id != null) {
            futures.add(update(registration));
          } else {
            futures.add(delete(registration));
          }
        } else {
          if (registration.rowId != null) {
            futures.add(update(registration));
          } else {
            futures.add(store(registration));
          }
        }
      }
    });
    await Future.wait(futures);
  }

  @override
  Future<bool> update(Registration updatedItem) async {
    int rowsAffected = 0;

    if (updatedItem.rowId != null) {
      Database db = await SqliteDatabaseHelper.instance.database;
      rowsAffected = await db.update(
        getRegistrationTableName(type),
        updatedItem.toMap(),
        where: 'rowid = ? ',
        whereArgs: [updatedItem.rowId],
      );
    }

    return rowsAffected == 1;
  }

  @override
  Future<List<Registration>> updateMultiple(List<Registration> registrations,
      {bool includeId}) async {
    List<Registration> result = new List<Registration>();

    if (registrations != null && registrations.length > 0) {
      var all = <Future>[];

      Database db = await SqliteDatabaseHelper.instance.database;

      registrations.forEach((registration) {
        var f = db.update(
          getRegistrationTableName(type),
          registration.toMap(
              includeStatus: true, useRawJson: true, includeId: includeId),
          where: 'rowid = ? ',
          whereArgs: [registration.rowId],
        ).then((onValue) => result.add(registration));

        all.add(f);
      });

      await Future.wait(all);
    }

    return result;
  }

  @override
  Future<List<Registration>> fetchBySite({String siteId, DateTime date}) async {
    Database db = await SqliteDatabaseHelper.instance.database;

    String whereClause = "";
    var whereArgs = <dynamic>[];

    if (siteId != null) {
      whereClause += "siteId = ? ";
      whereArgs.add(siteId);
    }

    final dateFormat = DateFormat('yyyy-MM-dd');

    if (date != null) {
      if (whereClause.length > 0) {
        whereClause += " AND ";
      }

      whereClause +=
          "strftime(\'%Y-%m-%d\', time) = '${dateFormat.format(date)}'";
    }

    List<Map> maps = await db.query(getRegistrationTableName(type),
        columns: getColumns(type),
        where: whereClause != "" ? whereClause : null,
        whereArgs: whereArgs.length > 0 ? whereArgs : null);

    if (maps != null && maps.length > 0) {
      return maps
          .map((map) => Registration<RegistrationBaseItem>.fromMap(
              map,
              (_) => RegistrationFactory.create(type,
                  jsonObj: json.decode(map["rawJson"]))))
          .toList();
    }

    return null;
  }
}

import 'dart:io';

import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/registration_factory.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/services/api_service.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:intl/intl.dart';
import 'registration_base_repository.dart';
import 'dart:convert';

class CloudRegistrationRepository extends RegistrationBaseRepository {
  final DateFormat dateFormat = DateFormat('yyyy-MM-ddTHH:mm:ss');
  final _apiService = ApiService();
  String module = '';

  CloudRegistrationRepository(RegistrationType type) : super(type: type) {
    switch (type) {
      case RegistrationType.Mortality:
        module = 'mortality';
        break;
      case RegistrationType.Feeding:
        module = 'feeding';
        break;
      case RegistrationType.Culling:
        module = 'culling';
        break;
      case RegistrationType.Lice:
        module = 'sample';
        break;
      case RegistrationType.Environment:
        module = 'sensor-readings';
        break;
    }
  }

  /// Delete a [Registration]
  ///
  /// Returns [true] if [Registration] is deleted or not found on server
  /// otherwise return [false]
  @override
  Future<bool> delete(Registration registration) async {
    bool isDeleted = false;

    await _apiService
        .httpDelete(
            '${ApiService.urlRoot}/control/$module/site/${registration.siteId}/${registration.id}')
        .then((reponse) {
      if (reponse.statusCode == HttpStatus.ok ||
          reponse.statusCode == HttpStatus.notFound ||
          reponse.statusCode == HttpStatus.noContent) {
        isDeleted = true;
      }
    }).catchError((onError) {
      print(onError);
    });

    return isDeleted;
  }

  @override
  Future<List<Registration>> fetchByUnit(Unit unit, {DateTime time}) async {
    return null;
  }

  /// Delete multiple [Registration] from repository
  ///
  /// [registrations] List of [Registration] to delete
  ///
  /// Return a list of [Registration] is deleted from repository.
  @override
  Future<List<Registration>> deleteMultiple(
      List<Registration> registrations) async {
    if (registrations == null || registrations.length == 0) {
      return [];
    }

    var futures = <Future>[];

    List<Registration> result = new List<Registration>();

    registrations.forEach((f) => futures.add(delete(f).then((isDeleted) {
          if (isDeleted) {
            result.add(f);
          }
        })));

    if (futures.length > 0) {
      await Future.wait(futures);
    }

    return result;
  }

  /// Store a [Registration] to cloud
  ///
  /// A [Registration] to store
  /// Return list of [Registration] is stored.
  @override
  Future store(Registration registration) async {
    if (registration != null) {
      var registrations = new List<Registration>();

      registrations.add(registration);

      var result = await storeMultiple(registrations);

      if (result.length == 1) {
        return registration;
      }
    }

    return null;
  }

  /// Store multiple [Registration] to cloud
  ///
  /// List of [Registration] to store
  /// Return list of [Registration] is stored.
  @override
  Future<List<Registration>> storeMultiple(
      List<Registration> registrations) async {
    List<Registration> result = new List<Registration>();

    if (registrations != null && registrations.length > 0) {
      String jsonPostBody = jsonEncode(registrations
              .map((i) => i.toMap(useRawJson: false, includeStatus: false))
              .toList())
          .toString();

      DBRegistrationRepository dbRepos = new DBRegistrationRepository(type);

      registrations.forEach((element) {
        element.id = '-1';
        element.changeStatus = ChangeStatus.Unchanged;
      });

      await dbRepos.updateMultiple(registrations).then((value) async {
        String uri = '${ApiService.urlRoot}/control/$module/list';
        if (type == RegistrationType.Lice) {
          uri += '/controlapp';
        }
        await _apiService.httpPost(uri, jsonPostBody).then((value) async {
          List<String> ids =
              (jsonDecode(value) as List<dynamic>).cast<String>();

          if (ids.length == registrations.length) {
            for (int i = 0; i < registrations.length; i++) {
              registrations[i].id = ids[i];
              registrations[i].changeStatus = ChangeStatus.Unchanged;

              result.add(registrations[i]);
            }

            if (type == RegistrationType.Lice) {
              await signAndSubmitLiceSamples(registrations);
            }
          }
        }).catchError((ex) {
          print(ex);

          // When post failed, we need to reset id and status it back to null and New
          // So next synchronize it will be posted again.
          registrations.forEach((element) {
            element.id = null;
            element.changeStatus = ChangeStatus.New;
          });

          dbRepos.updateMultiple(registrations, includeId: true);
        });
      });
    }

    return result;
  }

  Future signAndSubmitLiceSamples(List<Registration> registrations) async {
    var signSubmitFutures = <Future>[];

    for (int i = 0; i < registrations.length; i++) {
      var id = registrations[i].id;

      var signSubmitGet = _apiService.httpGet(
          '${ApiService.urlRoot}/control/sample/site/${registrations[i].siteId}/$id/signsubmit/controlapp',
          (data) {
        print('Signed and submitted Lice sample, id: $id');
        var sample = registrations[i].item as LiceSample;
        sample.reportGenerated = true;
      }).catchError((onError) {
        print('Failed to sign and submit Lice sample, id: $id');
      });

      signSubmitFutures.add(signSubmitGet);
    }

    await Future.wait(signSubmitFutures);
  }

  @override
  Future<List<Registration>> saveChanges(
      List<Registration> registrations) async {
    if (registrations == null || registrations.length == 0) return [];

    final updates = registrations.where((x) {
      return x.changeStatus == ChangeStatus.Changed;
    }).toList();

    final inserts = registrations.where((x) {
      return x.changeStatus == ChangeStatus.New && x.id == null;
    }).toList();

    final deletes = registrations.where((x) {
      return x.changeStatus == ChangeStatus.Deleted;
    }).toList();

    List<Registration> resultList = new List<Registration>();

    var futures = <Future>[];

    if (inserts.length > 0) {
      var postFuture = storeMultiple(inserts).then((inserteds) {
        resultList.addAll(inserteds);
      });
      futures.add(postFuture);
    }

    if (updates.length > 0) {
      futures.add(updateMultiple(updates).then((updateds) {
        resultList.addAll(updateds);
      }));
    }

    if (deletes.length > 0) {
      deletes.forEach((f) => futures.add(delete(f).then((isDeleted) {
            if (isDeleted) {
              resultList.add(f);
            }
          })));
    }

    await Future.wait(futures);

    return resultList;
  }

  @override
  Future<bool> update(Registration updatedItem) async {
    if (updatedItem == null || updatedItem.id == null) {
      throw new Exception("Invalid update item");
    }

    String body =
        jsonEncode(updatedItem.toMap(useRawJson: false, includeStatus: false));

    var response = await _apiService.httpPut(
        '${ApiService.urlRoot}/control/$module/${updatedItem.id}/controlapp',
        body);

    if (response != null && response.statusCode != HttpStatus.ok) {
      return false;
    }

    updatedItem.changeStatus = ChangeStatus.Unchanged;

    return true;
  }

  /// Update multiple [Registration].
  ///
  /// Return list of [Registration] are already changed status to [Unchanged] or [Deleted]
  @override
  Future<List<Registration>> updateMultiple(List<Registration> registrations,
      {bool includeId}) async {
    List<Registration> result = new List<Registration>();

    if (registrations != null && registrations.length > 0) {
      List<Future> futures = new List<Future>();

      registrations.forEach((e) {
        String jsonPutBody =
            jsonEncode(e.toMap(useRawJson: false, includeStatus: false));

        var f = _apiService
            .httpPut(
                '${ApiService.urlRoot}/control/$module/${e.id}', jsonPutBody)
            .then((response) {
          if (response.statusCode == HttpStatus.ok) {
            e.changeStatus = ChangeStatus.Unchanged;

            result.add(e);
          } else if (response.statusCode == HttpStatus.notFound) {
            e.changeStatus = ChangeStatus.Deleted;

            result.add(e);
          }
        }).catchError((onError) {
          print(onError);
        });
        futures.add(f);
      });

      await Future.wait(futures);
    }

    return result;
  }

  /// Fetch [Registration] from cloud by Site.
  ///
  /// [date] is date to get
  /// [sensorIds] list of sensor ids that need to get sensor reading for
  /// Return list of [Registration]
  @override
  Future<List<Registration>> fetchBySite(
      {String siteId, DateTime date, List<String> sensorIds}) async {
    DateTime from = new DateTime(date.year, date.month, date.day);
    DateTime to = new DateTime(date.year, date.month, date.day, 23, 59, 0);

    String notEnvironment =
        type == RegistrationType.Environment ? "" : "/controlapp";

    String sensorIdsParams = (sensorIds != null && sensorIds.length > 0)
        ? '&sensorIds=' + sensorIds.join(',')
        : "";

    String cursor;

    List<Registration> registrationList = new List<Registration>();

    do {
      var registrations = await _apiService.httpGet(
          '${ApiService.urlRoot}/control/$module/site/$siteId$notEnvironment?from=${dateFormat.format(from)}&to=${dateFormat.format(to)}$sensorIdsParams&pageSize=100',
          (body) {
        List<Registration> result = new List<Registration>();

        var pageResult = jsonDecode(body);

        cursor = pageResult['cursor'];

        List<dynamic> registrations = pageResult['data'];

        registrations.forEach((reg) {
          var registration = Registration.fromMap(
              reg, (reg) => RegistrationFactory.create(type, jsonObj: reg));

          result.add(registration);
        });

        return result;
      }, cursor: cursor).catchError((onError) {
        cursor = null;
        print(onError);
      });

      registrationList.addAll(registrations);
    } while (cursor != null && cursor != '');

    print('Number of $module(s) downloaded : ${registrationList.length}');

    return registrationList;
  }

  Future<List<Registration>> fetchLastSampleBySite(String siteId) async {
    return await _apiService.httpGet(
        '${ApiService.urlRoot}/control/sample/site/$siteId/last/controlapp',
        (body) {
      List<dynamic> registrations = jsonDecode(body);

      List<Registration> result = new List<Registration>();

      if (registrations.length > 0) {
        registrations.forEach((reg) {
          var registration = Registration.fromMap(
              reg, (reg) => RegistrationFactory.create(type, jsonObj: reg));

          result.add(registration);
        });
      }

      return result;
    });
  }
}

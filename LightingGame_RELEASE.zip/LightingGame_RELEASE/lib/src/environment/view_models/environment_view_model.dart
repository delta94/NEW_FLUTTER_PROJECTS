import 'dart:async';

import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/registration_view_model.dart';
import 'package:control_app/src/models/environment/sensor.dart';
import 'package:control_app/src/models/environment/sensor_reading.dart';
import 'package:control_app/src/models/environment/sensor_type.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/services/timezone_service.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/util/constants.dart';

class EnvironmentViewModel extends RegistrationViewModel {
  EnvironmentViewModel() : super(true, RegistrationType.Environment);
  SharedDataModel _sharedDataModel;

  /// Update dependencies injection
  updateDI(AppModel appModel, OrganizationModel organizationModel,
      SharedDataModel sharedDataModel) {
    if (_sharedDataModel != sharedDataModel) {
      _sharedDataModel = sharedDataModel;
    }
    super.updateModel(appModel, organizationModel);
  }

  List<Sensor> get activeManualSensorsForUnit => _activeSensorsForCurrentUnit();

  /// For environment, do not show "No Fish"
  /// if there are sensors available for the site
  /// or the current unit. In this case, this property
  /// is in order to identify should we display "No fish"
  /// or registration data
  bool get hasSensorData => activeManualSensorsForUnit.isNotEmpty;

  List<Sensor> _activeSensorsForCurrentUnit() {
    List<Sensor> result = <Sensor>[];
    if (_sharedDataModel.manualActiveSensors.isNotEmpty) {
      /// If sensorGroupId, departmentId, unitId are all null,
      /// then this sensor is applied to the whole site.
      /// Example: if unit A sees this value, then unit B
      /// sees this value also. If unit B edits these values,
      /// then unit A may see these changes as well.
      result = _sharedDataModel.manualActiveSensors
          .where((sensor) => sensor.history.any((assigment) =>
              assigment.siteId == organizationModel.currentSite.id &&
              (assigment.unitId == organizationModel.currentUnit.id ||
                  (assigment.unitId == null &&
                      assigment.departmentId == null &&
                      assigment.sensorGroupId == null))))
          .toList();
    }
    return result;
  }

  @override
  Future<Registration> addNewRegistration(int speciesId) {
    /// Environment does not support this function call
    throw UnimplementedError();
  }

  @override
  Future fetchRegistrations() async {
    await super.fetchRegistrations();

    /// Fill in helper properties such as sensor name,
    /// sensor type name, measurement unit name
    registrations.forEach((registration) {
      SensorReading sensorReading = registration.item as SensorReading;
      final sensorType = _sharedDataModel.sensorTypes.firstWhere(
          (sensorType) => sensorType.itemId == sensorReading.sensorTypeId,
          orElse: () => null);
      final sensor = _sharedDataModel.sensors.firstWhere(
          (sensor) => sensor.id == sensorReading.sensorId,
          orElse: () => null);
      if (sensor != null) {
        sensorReading.name = sensor.name;
        sensorReading.sensor = sensor;
      }
      if (sensorType != null) {
        sensorReading.sensorType = sensorType;
        sensorReading.sensorTypeName = sensorType.name;
        sensorReading.measurementUnit =
            MeasurementUnit.getMeasurementUnitName(sensorType.measUnit);
      }
    });
    notifyListeners();
  }

  _filterSensorsByValueMap(bool isValueMap, DateTime createTime) {
    List<Registration> sensorRegistration = <Registration>[];
    activeManualSensorsForUnit.forEach((sensor) {
      final sensorType = _sharedDataModel.sensorTypes.firstWhere(
          (sensorType) => sensorType.itemId == sensor.sensorTypeId,
          orElse: () => null);
      if ((isValueMap && sensorType.measUnit != MeasurementUnit.ValueMap) ||
          (!isValueMap && sensorType.measUnit == MeasurementUnit.ValueMap)) {
        return;
      }

      final sensorReading = SensorReading(
        sensorId: sensor.id,
        sensorTypeId: sensor.sensorTypeId,
        depth: sensor.depth,
        sensorGroupId: sensor.history[0].sensorGroupId,
        departmentId: sensor.history[0].departmentId,
        name: sensor.name,
        sensorTypeName: sensorType != null ? sensorType.name : '',
        sensorType: sensorType,
        measurementUnit:
            MeasurementUnit.getMeasurementUnitName(sensorType.measUnit),
      );
      sensorReading.sensor = sensor;
      var registration = Registration(
        siteId: organizationModel.currentSite.id,
        unitId: sensor.history.any((assignment) => assignment.unitId == null)
            ? null
            : organizationModel.currentUnit.id,
        time: createTime,
        item: sensorReading,
        changeStatus: ChangeStatus.New,
      );
      sensorRegistration.add(registration);
    });
    if (sensorRegistration.isNotEmpty) {
      sensorRegistration.sort((a, b) => (a.item as SensorReading)
          .sensorTypeName
          .compareTo((b.item as SensorReading).sensorTypeName));
    }
    return sensorRegistration;
  }

  void addNewSensorReading() {
    /// Get list of sensors which are manual sensor
    newRegistrations.clear();
    DateTime createTime = TimeZoneService.convertToTimezone(
        DateTime.now(), organizationModel.currentSite.timeZoneId);

    /// For sensors which have measurement unit = 29, they should
    /// be added at the end of registration. Other kinds will be
    /// sorted by sensor type name
    newRegistrations.addAll(_filterSensorsByValueMap(false, createTime));
    newRegistrations.addAll(_filterSensorsByValueMap(true, createTime));
  }

  @override
  Future storeRegistration() async {
    /// Drop sensors which are not filled yet
    newRegistrations.removeWhere(
        (registration) => (registration.item as SensorReading).reading == null);
    await super.storeRegistration();
  }

  Future _removeSensorReading(
    Registration sensorReading,
  ) async {
    sensorReading.changeStatus = ChangeStatus.Deleted;
    sensorReading.clearTracking();
    await saveChanges(notify: false);
    createViewRegistrations();
    checkRegistration();
    updateEditMode();
  }

  /// Remove a sensor reading [sensorReadingObj]
  /// Don't use [time] and [speciesId] params
  @override
  Future removeCount(
      [DateTime time, int speciesId, dynamic sensorReadingObj]) async {
    setBusy(true);

    try {
      if (sensorReadingObj is Registration) {
        await _removeSensorReading(sensorReadingObj);
      }
    } catch (e) {} finally {
      setBusy(false);
    }
  }

  updateSensorReading(Registration registration, double readingVal) {
    (registration.item as SensorReading).reading = readingVal;
    if (registration.item.hasChanged()) {
      if (registration.changeStatus != ChangeStatus.New) {
        registration.changeStatus = ChangeStatus.Changed;
      }
    } else {
      registration.undo();
    }
    updateEditMode();
  }
}

import 'package:Commons/dropdown.dart';
import 'package:Commons/fonts.dart';
import 'package:Commons/icons.dart';
import 'package:control_app/generated/l10n.dart';
import 'package:control_app/src/app_model.dart';
import 'Package:flutter/material.dart';
import 'package:Commons/colors.dart';
import 'package:control_app/src/base/base_view_model.dart';
import 'package:control_app/src/environment/view_models/environment_view_model.dart';
import 'package:control_app/src/models/environment/sensor_reading.dart';
import 'package:control_app/src/models/environment/sensor_type.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/routers.dart';
import 'package:control_app/src/widgets/add_new_registration_ui/add_new_registration_button.dart';
import 'package:control_app/src/widgets/common_heaher.dart';
import 'package:control_app/src/widgets/confirmation_dialog/confirmation_modal.dart';
import 'package:control_app/src/widgets/number_input.dart';
import 'package:control_app/src/widgets/offline_status.dart';
import 'package:control_app/src/widgets/synchronize_progress_status.dart';
import 'package:provider/provider.dart';

const double BOTTOM_PADDING = 22;

class AddNewEnvironmentRegistration extends StatefulWidget {
  AddNewEnvironmentRegistration();

  @override
  _AddNewEnvironmentRegistrationState createState() =>
      _AddNewEnvironmentRegistrationState();
}

class _AddNewEnvironmentRegistrationState
    extends State<AddNewEnvironmentRegistration> {
  bool isAllowedToSave = false;
  Map<String, TextEditingController> sensorReadingValueController =
      new Map<String, TextEditingController>();
  double bodyHeight = 0;
  ScrollController scrollController = ScrollController();
  SavingStatusEnum savingStatusEnum = SavingStatusEnum.NOT_SAVE;

  @override
  void initState() {
    final environmentViewModel =
        Provider.of<EnvironmentViewModel>(context, listen: false);
    environmentViewModel.addNewSensorReading();
    environmentViewModel.activeManualSensorsForUnit.forEach((sensor) {
      sensorReadingValueController[sensor.id] = TextEditingController();
      sensorReadingValueController[sensor.id].addListener(() {
        var number =
            double.tryParse(sensorReadingValueController[sensor.id].text);

        final registration = environmentViewModel.newRegistrations.firstWhere(
            (registration) =>
                (registration.item as SensorReading).sensorId == sensor.id,
            orElse: () => null);
        if (registration != null) {
          (registration.item as SensorReading).reading = number;
          validateData(environmentViewModel);
        }
      });
    });

    WidgetsBinding.instance.addPostFrameCallback(_getBodyHeight);
    super.initState();
  }

  @override
  void didUpdateWidget(AddNewEnvironmentRegistration oldWidget) {
    final environmentModel = Provider.of<EnvironmentViewModel>(context);
    if (environmentModel.busy) savingStatusEnum = SavingStatusEnum.SAVING;
    if (!environmentModel.busy && savingStatusEnum == SavingStatusEnum.SAVING) {
      setState(() {
        savingStatusEnum = SavingStatusEnum.SAVED;
      });

      Future.delayed(Duration(seconds: 1), () {
        Navigator.pop(context);
      });
    }

    super.didUpdateWidget(oldWidget);
  }

  void _getBodyHeight(_) {
    setState(() {
      bodyHeight =
          MediaQuery.of(context).size.height - 167 - kBottomNavigationBarHeight;
    });
  }

  validateData(EnvironmentViewModel environmentViewModel) {
    bool validData = environmentViewModel.newRegistrations.any(
        (registration) => (registration.item as SensorReading).reading != null);
    Future.delayed(
        Duration.zero, () => setState(() => isAllowedToSave = validData));
  }

  @override
  Widget build(BuildContext context) {
    final appText = S.of(context);
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    OrganizationModel organizationModel =
        Provider.of<OrganizationModel>(context, listen: false);
    final environmentModel = Provider.of<EnvironmentViewModel>(context);

    _onRightButton() {
      Navigator.of(context).popUntil(ModalRoute.withName(Routers.environment));
    }

    _onClose() {
      bool isAnySensorInfo = environmentModel.newRegistrations.any(
          (registration) =>
              (registration.item as SensorReading).reading != null);
      if (!isAnySensorInfo) {
        Navigator.pop(context);
      } else {
        showConfirmationModal(
          context: context,
          title: appText.unsaved_changes,
          messages: [
            appText.you_have_unsaved_changes,
            appText.are_you_sure_you_want_to_continue
          ],
          leftButtonTitle: appText.no,
          rightButtonTitle: appText.yes,
          onTapRightButton: _onRightButton,
        );
      }

      return Future<bool>.value(false);
    }

    _onBottonButton() async {
      await environmentModel.storeRegistration();
      setState(() {
        savingStatusEnum = SavingStatusEnum.SAVED;
      });

      Future.delayed(Duration(seconds: 1), () {
        Navigator.pop(context);
        environmentModel.clearRegistrations();
      });
    }

    _buildSensorList({bool isSiteSensor}) {
      List<Widget> sensorWidgets = <Widget>[];
      for (int index = 0;
          index < environmentModel.newRegistrations.length;
          index++) {
        Registration registration = environmentModel.newRegistrations[index];
        bool _isSiteSensor = registration.unitId == null;
        bool shouldCreateWidget = isSiteSensor == _isSiteSensor;
        if (!shouldCreateWidget) continue;
        var sensorReading = registration.item as SensorReading;
        sensorWidgets.add(SizedBox(height: 18));
        if (sensorReading.sensorType.measUnit != MeasurementUnit.ValueMap) {
          sensorWidgets.add(
            NumberSensorInput(
              allowNegativeNumber: sensorReading.measurementUnit == '°C',
              title:
                  "${sensorReading.sensorTypeName} [${sensorReading.measurementUnit}]",
              enabled: true,
              controller: sensorReadingValueController[sensorReading.sensorId],
            ),
          );
        } else {
          final sensorType = sensorReading.sensorType;
          if (sensorType != null) {
            List<OptionItem> valueMaps = sensorType.valueMap.entries
                .map((e) => OptionItem(id: e.key, label: e.value))
                .toList();
            OptionItem selectedItem;
            if (sensorReading.reading != null) {
              selectedItem = valueMaps.firstWhere(
                  (item) => item.id == sensorReading.reading.toInt(),
                  orElse: () => null);
            }

            sensorWidgets.add(Padding(
              padding: const EdgeInsets.only(right: 20),
              child: AkvaDropDown(
                label: sensorReading.sensorTypeName,
                selectedItems: selectedItem != null ? [selectedItem] : [],
                items: valueMaps,
                isDarkTheme: appModel.isDarkTheme,
                enable: true,
                key: ObjectKey(sensorType.name),
                hint: '${appText.select} ${sensorReading.sensorTypeName}',
                onSelectedItem: (item) {
                  sensorReading.reading = item.id.toDouble();
                  validateData(environmentModel);
                },
              ),
            ));
            sensorWidgets.add(SizedBox(height: 35));
          }
        }

        sensorWidgets.add(Divider(
          color: appModel.isDarkTheme ? akvaDarkColorB : akvaLightColorC,
          thickness: 1,
          height: 0,
        ));
      }

      return sensorWidgets;
    }

    List<Widget> siteSensorWidgets = _buildSensorList(isSiteSensor: true);
    List<Widget> unitSensorWidgets = _buildSensorList(isSiteSensor: false);
    return WillPopScope(
      onWillPop: () => _onClose(),
      child: Stack(
        children: [
          Scaffold(
            backgroundColor:
                appModel.isDarkTheme ? akvaDarkColorC : akvaDarkColorE,
            body: SingleChildScrollView(
              child: SafeArea(
                child: Container(
                  color:
                      appModel.isDarkTheme ? akvaDarkColorC : akvaLightColorA,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      SynchronizeProgressStatus(),
                      OfflineStatus(),
                      CommonHeader(
                        showBackButton: false,
                        unitName:
                            organizationModel.currentOrganizationEntity.name,
                        headerTitle: appText.new_environment,
                        onClose: () => _onClose(),
                        onBack: () => Navigator.of(context).pop(),
                      ),
                      Divider(
                        color: appModel.isDarkTheme
                            ? akvaDarkColorD
                            : akvaLightColorD,
                        thickness: 1,
                        height: 0,
                      ),
                      Container(
                        padding: EdgeInsets.only(top: 0),
                        height: bodyHeight,
                        child: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding:
                                    const EdgeInsets.only(left: 20, top: 11),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Visibility(
                                      visible: siteSensorWidgets.isNotEmpty,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          SensorTypeTitle(
                                            title: appText.site_sensors,
                                            description: appText
                                                .sensors_are_applicable_to_the_entire_site,
                                          ),
                                          ...siteSensorWidgets,
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Divider(
                                color: appModel.isDarkTheme
                                    ? akvaDarkColorB
                                    : akvaLightColorC,
                                thickness: 1,
                                height: 0,
                              ),
                              Padding(
                                padding:
                                    const EdgeInsets.only(left: 20, top: 11),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Visibility(
                                      visible: unitSensorWidgets.isNotEmpty,
                                      child: Column(
                                        crossAxisAlignment:
                                            CrossAxisAlignment.start,
                                        children: [
                                          SensorTypeTitle(
                                            title: appText.unit_sensors,
                                            description: appText
                                                .sensors_are_applicable_to_selected_unit,
                                          ),
                                          ...unitSensorWidgets
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 28),
                            ],
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ),
            bottomNavigationBar: Container(
              color: appModel.isDarkTheme ? akvaDarkColorC : akvaLightColorA,
              child: Padding(
                padding: const EdgeInsets.only(
                    left: 20.0, right: 20.0, bottom: 30.0),
                child: AddNewRegistrationButton(
                  buttonTitle: appText.save,
                  isBusy: environmentModel.busy,
                  savingStatusEnum: savingStatusEnum,
                  isAllowedToSave: isAllowedToSave,
                  onPressSave: () => _onBottonButton(),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class SensorTypeTitle extends StatelessWidget {
  const SensorTypeTitle({
    Key key,
    @required this.title,
    @required this.description,
  }) : super(key: key);

  final String title;
  final String description;

  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: FontSize.medium,
            fontStyle: FontStyle.normal,
            color: appModel.isDarkTheme ? akvaDarkTextA : akvaDarkColorD,
          ),
        ),
        SizedBox(height: 5),
        Row(
          children: [
            Icon(
              AkvaIcons.info,
              size: FontSize.large,
              color: appModel.isDarkTheme ? akvaDarkTextB : akvaLightTextB,
            ),
            SizedBox(width: 7),
            Text(
              description,
              style: TextStyle(
                fontSize: FontSize.small,
                fontStyle: FontStyle.normal,
                color: appModel.isDarkTheme ? akvaDarkTextB : akvaLightTextB,
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class NumberSensorInput extends StatelessWidget {
  const NumberSensorInput({
    Key key,
    @required this.title,
    this.controller,
    this.enabled,
    this.allowNegativeNumber: false,
  }) : super(key: key);

  final String title;
  final TextEditingController controller;
  final bool enabled;
  final bool allowNegativeNumber;

  @override
  Widget build(BuildContext context) {
    AppModel appModel = Provider.of<AppModel>(context, listen: false);
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          title,
          style: TextStyle(
            fontSize: FontSize.small,
            fontStyle: FontStyle.normal,
            color: appModel.isDarkTheme ? akvaDarkTextA : akvaDarkColorD,
          ),
        ),
        SizedBox(height: 5),
        NumberInput(
          allowNegativeNumber: allowNegativeNumber,
          controller: controller,
          enabled: enabled,
          activeColor: akvaMainAction,
          numberInputType: NumberInputType.DECIMAL,
          inputWidth: 116,
        ),
        SizedBox(height: 28),
      ],
    );
  }
}

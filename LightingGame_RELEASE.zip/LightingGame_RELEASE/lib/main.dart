import 'package:control_app/src/app_model.dart';
import 'package:flutter/material.dart';
import 'package:control_app/src/fishtalk_app.dart';
import 'package:appcenter/appcenter.dart';
import 'package:appcenter_analytics/appcenter_analytics.dart';
import 'package:appcenter_crashes/appcenter_crashes.dart';
import 'dart:io' show Platform;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await startAppcenterServices();
  AppCenterAnalytics.trackEvent("started");
  final appModel = AppModel();
  await appModel.initialize();
  runApp(FishtalkApp());
}

Future startAppcenterServices() async {
  String appcenterSecret = "";
  if (Platform.isAndroid) {
    appcenterSecret = "c24faabd-ce42-4a35-93f1-cf5c4f44854b";
  } else if (Platform.isIOS) {
    //insert appcenterSecret for ios here, when it's ready
  }
  await AppCenter.start(
      appcenterSecret, [AppCenterAnalytics.id, AppCenterCrashes.id]);
}

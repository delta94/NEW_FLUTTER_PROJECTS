// GENERATED CODE - DO NOT MODIFY BY HAND
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

// **************************************************************************
// Generator: Flutter Intl IDE plugin
// Made by Localizely
// **************************************************************************

// ignore_for_file: non_constant_identifier_names, lines_longer_than_80_chars

class S {
  S();
  
  static S current;
  
  static const AppLocalizationDelegate delegate =
    AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false) ? locale.languageCode : locale.toString();
    final localeName = Intl.canonicalizedLocale(name); 
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      S.current = S();
      
      return S.current;
    });
  } 

  static S of(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  /// `Seabased`
  String get seabased {
    return Intl.message(
      'Seabased',
      name: 'seabased',
      desc: '',
      args: [],
    );
  }

  /// `Landbased`
  String get landbased {
    return Intl.message(
      'Landbased',
      name: 'landbased',
      desc: '',
      args: [],
    );
  }

  /// `Search Location`
  String get search_location {
    return Intl.message(
      'Search Location',
      name: 'search_location',
      desc: '',
      args: [],
    );
  }

  /// `Scan barcode`
  String get scan_barcode {
    return Intl.message(
      'Scan barcode',
      name: 'scan_barcode',
      desc: '',
      args: [],
    );
  }

  /// `My {mode} sites`
  String my_X_sites(Object mode) {
    return Intl.message(
      'My $mode sites',
      name: 'my_X_sites',
      desc: '',
      args: [mode],
    );
  }

  /// `Favorite`
  String get favorite {
    return Intl.message(
      'Favorite',
      name: 'favorite',
      desc: '',
      args: [],
    );
  }

  /// `Frequently visited`
  String get frequently_visited {
    return Intl.message(
      'Frequently visited',
      name: 'frequently_visited',
      desc: '',
      args: [],
    );
  }

  /// `Dark mode`
  String get dark_mode {
    return Intl.message(
      'Dark mode',
      name: 'dark_mode',
      desc: '',
      args: [],
    );
  }

  /// `Light mode`
  String get light_mode {
    return Intl.message(
      'Light mode',
      name: 'light_mode',
      desc: '',
      args: [],
    );
  }

  /// `Log out`
  String get logout {
    return Intl.message(
      'Log out',
      name: 'logout',
      desc: '',
      args: [],
    );
  }

  /// `Back`
  String get back {
    return Intl.message(
      'Back',
      name: 'back',
      desc: '',
      args: [],
    );
  }

  /// `Units`
  String get units {
    return Intl.message(
      'Units',
      name: 'units',
      desc: '',
      args: [],
    );
  }

  /// `Yes`
  String get yes {
    return Intl.message(
      'Yes',
      name: 'yes',
      desc: '',
      args: [],
    );
  }

  /// `No`
  String get no {
    return Intl.message(
      'No',
      name: 'no',
      desc: '',
      args: [],
    );
  }

  /// `Ok`
  String get ok {
    return Intl.message(
      'Ok',
      name: 'ok',
      desc: '',
      args: [],
    );
  }

  /// `Cancel`
  String get cancel {
    return Intl.message(
      'Cancel',
      name: 'cancel',
      desc: '',
      args: [],
    );
  }

  /// `Favorite site`
  String get favorite_site {
    return Intl.message(
      'Favorite site',
      name: 'favorite_site',
      desc: '',
      args: [],
    );
  }

  /// `Unit`
  String get unit {
    return Intl.message(
      'Unit',
      name: 'unit',
      desc: '',
      args: [],
    );
  }

  /// `Unit name`
  String get unit_name {
    return Intl.message(
      'Unit name',
      name: 'unit_name',
      desc: '',
      args: [],
    );
  }

  /// `Jump to unit`
  String get jump_to_unit {
    return Intl.message(
      'Jump to unit',
      name: 'jump_to_unit',
      desc: '',
      args: [],
    );
  }

  /// `Biomass [ton]`
  String get biomass {
    return Intl.message(
      'Biomass [ton]',
      name: 'biomass',
      desc: '',
      args: [],
    );
  }

  /// `Stock`
  String get stock {
    return Intl.message(
      'Stock',
      name: 'stock',
      desc: '',
      args: [],
    );
  }

  /// `Details`
  String get details {
    return Intl.message(
      'Details',
      name: 'details',
      desc: '',
      args: [],
    );
  }

  /// `Mortality`
  String get mortality {
    return Intl.message(
      'Mortality',
      name: 'mortality',
      desc: '',
      args: [],
    );
  }

  /// `Feeding`
  String get feeding {
    return Intl.message(
      'Feeding',
      name: 'feeding',
      desc: '',
      args: [],
    );
  }

  /// `Environment`
  String get environment {
    return Intl.message(
      'Environment',
      name: 'environment',
      desc: '',
      args: [],
    );
  }

  /// `Culling`
  String get culling {
    return Intl.message(
      'Culling',
      name: 'culling',
      desc: '',
      args: [],
    );
  }

  /// `Lice`
  String get lice {
    return Intl.message(
      'Lice',
      name: 'lice',
      desc: '',
      args: [],
    );
  }

  /// `No registrations.`
  String get no_registrations {
    return Intl.message(
      'No registrations.',
      name: 'no_registrations',
      desc: '',
      args: [],
    );
  }

  /// `No registrations yet.`
  String get no_registrations_yet {
    return Intl.message(
      'No registrations yet.',
      name: 'no_registrations_yet',
      desc: '',
      args: [],
    );
  }

  /// `Avg. weight`
  String get avg_weight {
    return Intl.message(
      'Avg. weight',
      name: 'avg_weight',
      desc: '',
      args: [],
    );
  }

  /// `Mortality registration`
  String get mortality_registration {
    return Intl.message(
      'Mortality registration',
      name: 'mortality_registration',
      desc: '',
      args: [],
    );
  }

  /// `Salmon`
  String get salmon {
    return Intl.message(
      'Salmon',
      name: 'salmon',
      desc: '',
      args: [],
    );
  }

  /// `Cleaner fish`
  String get cleaner_fish {
    return Intl.message(
      'Cleaner fish',
      name: 'cleaner_fish',
      desc: '',
      args: [],
    );
  }

  /// `Nothing to report in mortality`
  String get nothing_to_report_in_mortality {
    return Intl.message(
      'Nothing to report in mortality',
      name: 'nothing_to_report_in_mortality',
      desc: '',
      args: [],
    );
  }

  /// `Checked & found no mortality`
  String get checked_found_no_mortality {
    return Intl.message(
      'Checked & found no mortality',
      name: 'checked_found_no_mortality',
      desc: '',
      args: [],
    );
  }

  /// `Couldn't check for mortality`
  String get couldnt_check_for_mortality {
    return Intl.message(
      'Couldn\'t check for mortality',
      name: 'couldnt_check_for_mortality',
      desc: '',
      args: [],
    );
  }

  /// `Click new registration to start registering.`
  String get click_new_registration_to_start_registering {
    return Intl.message(
      'Click new registration to start registering.',
      name: 'click_new_registration_to_start_registering',
      desc: '',
      args: [],
    );
  }

  /// `I confirm that {message}`
  String i_confirm_that_message(Object message) {
    return Intl.message(
      'I confirm that $message',
      name: 'i_confirm_that_message',
      desc: '',
      args: [message],
    );
  }

  /// `New mortality count`
  String get new_mortality_count {
    return Intl.message(
      'New mortality count',
      name: 'new_mortality_count',
      desc: '',
      args: [],
    );
  }

  /// `Cause`
  String get cause {
    return Intl.message(
      'Cause',
      name: 'cause',
      desc: '',
      args: [],
    );
  }

  /// `Search`
  String get search {
    return Intl.message(
      'Search',
      name: 'search',
      desc: '',
      args: [],
    );
  }

  /// `Number`
  String get number {
    return Intl.message(
      'Number',
      name: 'number',
      desc: '',
      args: [],
    );
  }

  /// `Add`
  String get add {
    return Intl.message(
      'Add',
      name: 'add',
      desc: '',
      args: [],
    );
  }

  /// `Edit`
  String get edit {
    return Intl.message(
      'Edit',
      name: 'edit',
      desc: '',
      args: [],
    );
  }

  /// `Registrations`
  String get registration {
    return Intl.message(
      'Registrations',
      name: 'registration',
      desc: '',
      args: [],
    );
  }

  /// `Save changes`
  String get save_changes {
    return Intl.message(
      'Save changes',
      name: 'save_changes',
      desc: '',
      args: [],
    );
  }

  /// `Delete registration`
  String get delete_registration {
    return Intl.message(
      'Delete registration',
      name: 'delete_registration',
      desc: '',
      args: [],
    );
  }

  /// `Added at {time}`
  String added_at(Object time) {
    return Intl.message(
      'Added at $time',
      name: 'added_at',
      desc: '',
      args: [time],
    );
  }

  /// `Cleaner fish type`
  String get cleaner_fish_type {
    return Intl.message(
      'Cleaner fish type',
      name: 'cleaner_fish_type',
      desc: '',
      args: [],
    );
  }

  /// `No fish`
  String get no_fish {
    return Intl.message(
      'No fish',
      name: 'no_fish',
      desc: '',
      args: [],
    );
  }

  /// `Cleanerfish`
  String get cleanerfish {
    return Intl.message(
      'Cleanerfish',
      name: 'cleanerfish',
      desc: '',
      args: [],
    );
  }

  /// `at`
  String get at {
    return Intl.message(
      'at',
      name: 'at',
      desc: '',
      args: [],
    );
  }

  /// `Total`
  String get total {
    return Intl.message(
      'Total',
      name: 'total',
      desc: '',
      args: [],
    );
  }

  /// `Save`
  String get save {
    return Intl.message(
      'Save',
      name: 'save',
      desc: '',
      args: [],
    );
  }

  /// `Feeding registration`
  String get feeding_registration {
    return Intl.message(
      'Feeding registration',
      name: 'feeding_registration',
      desc: '',
      args: [],
    );
  }

  /// `I missed feeding unit {unitName} today.`
  String i_missed_feeding_unit_today(Object unitName) {
    return Intl.message(
      'I missed feeding unit $unitName today.',
      name: 'i_missed_feeding_unit_today',
      desc: '',
      args: [unitName],
    );
  }

  /// `I confirm that I missed Feeding unit {unitName} today.`
  String i_confirm_that_i_missed_feeding_unit_today(Object unitName) {
    return Intl.message(
      'I confirm that I missed Feeding unit $unitName today.',
      name: 'i_confirm_that_i_missed_feeding_unit_today',
      desc: '',
      args: [unitName],
    );
  }

  /// `New feeding`
  String get new_feeding {
    return Intl.message(
      'New feeding',
      name: 'new_feeding',
      desc: '',
      args: [],
    );
  }

  /// `Feeding series`
  String get feeding_series {
    return Intl.message(
      'Feeding series',
      name: 'feeding_series',
      desc: '',
      args: [],
    );
  }

  /// `Select series`
  String get select_series {
    return Intl.message(
      'Select series',
      name: 'select_series',
      desc: '',
      args: [],
    );
  }

  /// `Feed amount [kg]`
  String get feed_amount_kg {
    return Intl.message(
      'Feed amount [kg]',
      name: 'feed_amount_kg',
      desc: '',
      args: [],
    );
  }

  /// `Amount [kg]`
  String get amount_kg {
    return Intl.message(
      'Amount [kg]',
      name: 'amount_kg',
      desc: '',
      args: [],
    );
  }

  /// `Culled the entire unit`
  String get culled_the_entire_unit {
    return Intl.message(
      'Culled the entire unit',
      name: 'culled_the_entire_unit',
      desc: '',
      args: [],
    );
  }

  /// `Culling registration`
  String get culling_registration {
    return Intl.message(
      'Culling registration',
      name: 'culling_registration',
      desc: '',
      args: [],
    );
  }

  /// `New culling`
  String get new_culling {
    return Intl.message(
      'New culling',
      name: 'new_culling',
      desc: '',
      args: [],
    );
  }

  /// `New Registration`
  String get new_registration {
    return Intl.message(
      'New Registration',
      name: 'new_registration',
      desc: '',
      args: [],
    );
  }

  /// `Unsaved changes`
  String get unsaved_changes {
    return Intl.message(
      'Unsaved changes',
      name: 'unsaved_changes',
      desc: '',
      args: [],
    );
  }

  /// `You have unsaved changes.`
  String get you_have_unsaved_changes {
    return Intl.message(
      'You have unsaved changes.',
      name: 'you_have_unsaved_changes',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure you want to continue?`
  String get are_you_sure_you_want_to_continue {
    return Intl.message(
      'Are you sure you want to continue?',
      name: 'are_you_sure_you_want_to_continue',
      desc: '',
      args: [],
    );
  }

  /// `Don't save`
  String get dont_save {
    return Intl.message(
      'Don\'t save',
      name: 'dont_save',
      desc: '',
      args: [],
    );
  }

  /// `Delete`
  String get delete {
    return Intl.message(
      'Delete',
      name: 'delete',
      desc: '',
      args: [],
    );
  }

  /// `Are you sure you want to delete registration?`
  String get are_you_sure_you_want_to_delete_registration {
    return Intl.message(
      'Are you sure you want to delete registration?',
      name: 'are_you_sure_you_want_to_delete_registration',
      desc: '',
      args: [],
    );
  }

  /// `January`
  String get january {
    return Intl.message(
      'January',
      name: 'january',
      desc: '',
      args: [],
    );
  }

  /// `February`
  String get february {
    return Intl.message(
      'February',
      name: 'february',
      desc: '',
      args: [],
    );
  }

  /// `March`
  String get march {
    return Intl.message(
      'March',
      name: 'march',
      desc: '',
      args: [],
    );
  }

  /// `April`
  String get april {
    return Intl.message(
      'April',
      name: 'april',
      desc: '',
      args: [],
    );
  }

  /// `May`
  String get may {
    return Intl.message(
      'May',
      name: 'may',
      desc: '',
      args: [],
    );
  }

  /// `June`
  String get june {
    return Intl.message(
      'June',
      name: 'june',
      desc: '',
      args: [],
    );
  }

  /// `July`
  String get july {
    return Intl.message(
      'July',
      name: 'july',
      desc: '',
      args: [],
    );
  }

  /// `August`
  String get august {
    return Intl.message(
      'August',
      name: 'august',
      desc: '',
      args: [],
    );
  }

  /// `September`
  String get september {
    return Intl.message(
      'September',
      name: 'september',
      desc: '',
      args: [],
    );
  }

  /// `October`
  String get october {
    return Intl.message(
      'October',
      name: 'october',
      desc: '',
      args: [],
    );
  }

  /// `November`
  String get november {
    return Intl.message(
      'November',
      name: 'november',
      desc: '',
      args: [],
    );
  }

  /// `December`
  String get december {
    return Intl.message(
      'December',
      name: 'december',
      desc: '',
      args: [],
    );
  }

  /// `Mon`
  String get mon {
    return Intl.message(
      'Mon',
      name: 'mon',
      desc: '',
      args: [],
    );
  }

  /// `Tue`
  String get tue {
    return Intl.message(
      'Tue',
      name: 'tue',
      desc: '',
      args: [],
    );
  }

  /// `Wed`
  String get wed {
    return Intl.message(
      'Wed',
      name: 'wed',
      desc: '',
      args: [],
    );
  }

  /// `Thu`
  String get thu {
    return Intl.message(
      'Thu',
      name: 'thu',
      desc: '',
      args: [],
    );
  }

  /// `Fri`
  String get fri {
    return Intl.message(
      'Fri',
      name: 'fri',
      desc: '',
      args: [],
    );
  }

  /// `Sat`
  String get sat {
    return Intl.message(
      'Sat',
      name: 'sat',
      desc: '',
      args: [],
    );
  }

  /// `Sun`
  String get sun {
    return Intl.message(
      'Sun',
      name: 'sun',
      desc: '',
      args: [],
    );
  }

  /// `Lice registration`
  String get lice_registration {
    return Intl.message(
      'Lice registration',
      name: 'lice_registration',
      desc: '',
      args: [],
    );
  }

  /// `Only applicable to salmon.`
  String get only_applicable_to_salmon {
    return Intl.message(
      'Only applicable to salmon.',
      name: 'only_applicable_to_salmon',
      desc: '',
      args: [],
    );
  }

  /// `New lice sample`
  String get new_lice_sample {
    return Intl.message(
      'New lice sample',
      name: 'new_lice_sample',
      desc: '',
      args: [],
    );
  }

  /// `Sedation`
  String get sedation {
    return Intl.message(
      'Sedation',
      name: 'sedation',
      desc: '',
      args: [],
    );
  }

  /// `Select sedation method`
  String get select_sedation_method {
    return Intl.message(
      'Select sedation method',
      name: 'select_sedation_method',
      desc: '',
      args: [],
    );
  }

  /// `Water in sedation unit [l]`
  String get water_in_sedation_unit_l {
    return Intl.message(
      'Water in sedation unit [l]',
      name: 'water_in_sedation_unit_l',
      desc: '',
      args: [],
    );
  }

  /// `Sedation used [ml]`
  String get sedation_used_ml {
    return Intl.message(
      'Sedation used [ml]',
      name: 'sedation_used_ml',
      desc: '',
      args: [],
    );
  }

  /// `Concentration [ml/l]`
  String get concentration_ml_l {
    return Intl.message(
      'Concentration [ml/l]',
      name: 'concentration_ml_l',
      desc: '',
      args: [],
    );
  }

  /// `Duration`
  String get duration {
    return Intl.message(
      'Duration',
      name: 'duration',
      desc: '',
      args: [],
    );
  }

  /// `Batch number`
  String get batch_number {
    return Intl.message(
      'Batch number',
      name: 'batch_number',
      desc: '',
      args: [],
    );
  }

  /// `Expiration date`
  String get expiration_date {
    return Intl.message(
      'Expiration date',
      name: 'expiration_date',
      desc: '',
      args: [],
    );
  }

  /// `Quarantined the fish?`
  String get quaratined_the_fish {
    return Intl.message(
      'Quarantined the fish?',
      name: 'quaratined_the_fish',
      desc: '',
      args: [],
    );
  }

  /// `Save sedation [1/3]`
  String get save_sedation_13 {
    return Intl.message(
      'Save sedation [1/3]',
      name: 'save_sedation_13',
      desc: '',
      args: [],
    );
  }

  /// `Save quarantine [2/3]`
  String get save_quarantine_23 {
    return Intl.message(
      'Save quarantine [2/3]',
      name: 'save_quarantine_23',
      desc: '',
      args: [],
    );
  }

  /// `days`
  String get days {
    return Intl.message(
      'days',
      name: 'days',
      desc: '',
      args: [],
    );
  }

  /// `Degree days`
  String get degree_days {
    return Intl.message(
      'Degree days',
      name: 'degree_days',
      desc: '',
      args: [],
    );
  }

  /// `And`
  String get and {
    return Intl.message(
      'And',
      name: 'and',
      desc: '',
      args: [],
    );
  }

  /// `Or`
  String get or {
    return Intl.message(
      'Or',
      name: 'or',
      desc: '',
      args: [],
    );
  }

  /// `Quarantine consequences`
  String get quarantine_consequences {
    return Intl.message(
      'Quarantine consequences',
      name: 'quarantine_consequences',
      desc: '',
      args: [],
    );
  }

  /// `Cannot be harvested`
  String get cannot_be_harvested {
    return Intl.message(
      'Cannot be harvested',
      name: 'cannot_be_harvested',
      desc: '',
      args: [],
    );
  }

  /// `Cannot be sold or transferred to another site`
  String get cannot_be_sold_or_transferred_to_another_site {
    return Intl.message(
      'Cannot be sold or transferred to another site',
      name: 'cannot_be_sold_or_transferred_to_another_site',
      desc: '',
      args: [],
    );
  }

  /// `Cannot be mixed with other populations`
  String get cannot_be_mixed_with_other_populations {
    return Intl.message(
      'Cannot be mixed with other populations',
      name: 'cannot_be_mixed_with_other_populations',
      desc: '',
      args: [],
    );
  }

  /// `Cannot be transferred to another unit`
  String get cannot_be_transferred_to_another_unit {
    return Intl.message(
      'Cannot be transferred to another unit',
      name: 'cannot_be_transferred_to_another_unit',
      desc: '',
      args: [],
    );
  }

  /// `Quarantine other units`
  String get quarantine_other_units {
    return Intl.message(
      'Quarantine other units',
      name: 'quarantine_other_units',
      desc: '',
      args: [],
    );
  }

  /// `Affects other units on the site`
  String get affects_other_units_on_the_site {
    return Intl.message(
      'Affects other units on the site',
      name: 'affects_other_units_on_the_site',
      desc: '',
      args: [],
    );
  }

  /// `Automatic clearance at the end of the biological clearance period`
  String get automatic_clearance_at_the_end_of_the_biological_clearance_period {
    return Intl.message(
      'Automatic clearance at the end of the biological clearance period',
      name: 'automatic_clearance_at_the_end_of_the_biological_clearance_period',
      desc: '',
      args: [],
    );
  }

  /// `Requires formal clearance`
  String get requires_formal_clearance {
    return Intl.message(
      'Requires formal clearance',
      name: 'requires_formal_clearance',
      desc: '',
      args: [],
    );
  }

  /// `You are currently in offline mode`
  String get you_are_currently_in_offline_mode {
    return Intl.message(
      'You are currently in offline mode',
      name: 'you_are_currently_in_offline_mode',
      desc: '',
      args: [],
    );
  }

  /// `{n} registrations were successfully uploaded`
  String n_registrations_were_successfully_uploaded(Object n) {
    return Intl.message(
      '$n registrations were successfully uploaded',
      name: 'n_registrations_were_successfully_uploaded',
      desc: '',
      args: [n],
    );
  }

  /// `Add fish sample`
  String get add_fish_sample {
    return Intl.message(
      'Add fish sample',
      name: 'add_fish_sample',
      desc: '',
      args: [],
    );
  }

  /// `Fish`
  String get fish {
    return Intl.message(
      'Fish',
      name: 'fish',
      desc: '',
      args: [],
    );
  }

  /// `All`
  String get all {
    return Intl.message(
      'All',
      name: 'all',
      desc: '',
      args: [],
    );
  }

  /// `Returned to the unit`
  String get returned_to_the_unit {
    return Intl.message(
      'Returned to the unit',
      name: 'returned_to_the_unit',
      desc: '',
      args: [],
    );
  }

  /// `Save samples [2/3]`
  String get save_sample_23 {
    return Intl.message(
      'Save samples [2/3]',
      name: 'save_sample_23',
      desc: '',
      args: [],
    );
  }

  /// `Quarantine`
  String get quarantine {
    return Intl.message(
      'Quarantine',
      name: 'quarantine',
      desc: '',
      args: [],
    );
  }

  /// `Sedation tank`
  String get sedation_tank {
    return Intl.message(
      'Sedation tank',
      name: 'sedation_tank',
      desc: '',
      args: [],
    );
  }

  /// `Sign & submit [3/3]`
  String get sign_submit {
    return Intl.message(
      'Sign & submit [3/3]',
      name: 'sign_submit',
      desc: '',
      args: [],
    );
  }

  /// `Sample taker`
  String get sample_taker {
    return Intl.message(
      'Sample taker',
      name: 'sample_taker',
      desc: '',
      args: [],
    );
  }

  /// `sent`
  String get sent {
    return Intl.message(
      'sent',
      name: 'sent',
      desc: '',
      args: [],
    );
  }

  /// `Site`
  String get site {
    return Intl.message(
      'Site',
      name: 'site',
      desc: '',
      args: [],
    );
  }

  /// `Environment registration`
  String get environment_registration {
    return Intl.message(
      'Environment registration',
      name: 'environment_registration',
      desc: '',
      args: [],
    );
  }

  /// `Hide empty units`
  String get hide_empty_units {
    return Intl.message(
      'Hide empty units',
      name: 'hide_empty_units',
      desc: '',
      args: [],
    );
  }

  /// `New environment`
  String get new_environment {
    return Intl.message(
      'New environment',
      name: 'new_environment',
      desc: '',
      args: [],
    );
  }

  /// `Clearance`
  String get clearance {
    return Intl.message(
      'Clearance',
      name: 'clearance',
      desc: '',
      args: [],
    );
  }

  /// `Select`
  String get select {
    return Intl.message(
      'Select',
      name: 'select',
      desc: '',
      args: [],
    );
  }

  /// `Site sensors`
  String get site_sensors {
    return Intl.message(
      'Site sensors',
      name: 'site_sensors',
      desc: '',
      args: [],
    );
  }

  /// `Sensors are applicable to the entire site`
  String get sensors_are_applicable_to_the_entire_site {
    return Intl.message(
      'Sensors are applicable to the entire site',
      name: 'sensors_are_applicable_to_the_entire_site',
      desc: '',
      args: [],
    );
  }

  /// `Unit sensors`
  String get unit_sensors {
    return Intl.message(
      'Unit sensors',
      name: 'unit_sensors',
      desc: '',
      args: [],
    );
  }

  /// `Sensors are applicable to selected unit`
  String get sensors_are_applicable_to_selected_unit {
    return Intl.message(
      'Sensors are applicable to selected unit',
      name: 'sensors_are_applicable_to_selected_unit',
      desc: '',
      args: [],
    );
  }

  /// `Sensors`
  String get sensors {
    return Intl.message(
      'Sensors',
      name: 'sensors',
      desc: '',
      args: [],
    );
  }

  /// `1 registration was successfully uploaded`
  String get one_registration_was_successfully_uploaded {
    return Intl.message(
      '1 registration was successfully uploaded',
      name: 'one_registration_was_successfully_uploaded',
      desc: '',
      args: [],
    );
  }

  /// `Frequently visited sites`
  String get frequently_visited_sites {
    return Intl.message(
      'Frequently visited sites',
      name: 'frequently_visited_sites',
      desc: '',
      args: [],
    );
  }

  /// `Favorites sites`
  String get favorites_sites {
    return Intl.message(
      'Favorites sites',
      name: 'favorites_sites',
      desc: '',
      args: [],
    );
  }

  /// `Can't save 0`
  String get cant_save_0 {
    return Intl.message(
      'Can\'t save 0',
      name: 'cant_save_0',
      desc: '',
      args: [],
    );
  }

  /// `No internet connection.`
  String get no_connection_msg {
    return Intl.message(
      'No internet connection.',
      name: 'no_connection_msg',
      desc: '',
      args: [],
    );
  }

  /// `Access required`
  String get access_required {
    return Intl.message(
      'Access required',
      name: 'access_required',
      desc: '',
      args: [],
    );
  }
}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'nb'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    if (locale != null) {
      for (var supportedLocale in supportedLocales) {
        if (supportedLocale.languageCode == locale.languageCode) {
          return true;
        }
      }
    }
    return false;
  }
}
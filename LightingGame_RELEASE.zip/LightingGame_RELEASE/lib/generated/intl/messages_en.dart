// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  static m0(time) => "Added at ${time}";

  static m1(unitName) => "I confirm that I missed Feeding unit ${unitName} today.";

  static m2(message) => "I confirm that ${message}";

  static m3(unitName) => "I missed feeding unit ${unitName} today.";

  static m4(mode) => "My ${mode} sites";

  static m5(n) => "${n} registrations were successfully uploaded";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static _notInlinedMessages(_) => <String, Function> {
    "access_required" : MessageLookupByLibrary.simpleMessage("Access required"),
    "add" : MessageLookupByLibrary.simpleMessage("Add"),
    "add_fish_sample" : MessageLookupByLibrary.simpleMessage("Add fish sample"),
    "added_at" : m0,
    "affects_other_units_on_the_site" : MessageLookupByLibrary.simpleMessage("Affects other units on the site"),
    "all" : MessageLookupByLibrary.simpleMessage("All"),
    "amount_kg" : MessageLookupByLibrary.simpleMessage("Amount [kg]"),
    "and" : MessageLookupByLibrary.simpleMessage("And"),
    "april" : MessageLookupByLibrary.simpleMessage("April"),
    "are_you_sure_you_want_to_continue" : MessageLookupByLibrary.simpleMessage("Are you sure you want to continue?"),
    "are_you_sure_you_want_to_delete_registration" : MessageLookupByLibrary.simpleMessage("Are you sure you want to delete registration?"),
    "at" : MessageLookupByLibrary.simpleMessage("at"),
    "august" : MessageLookupByLibrary.simpleMessage("August"),
    "automatic_clearance_at_the_end_of_the_biological_clearance_period" : MessageLookupByLibrary.simpleMessage("Automatic clearance at the end of the biological clearance period"),
    "avg_weight" : MessageLookupByLibrary.simpleMessage("Avg. weight"),
    "back" : MessageLookupByLibrary.simpleMessage("Back"),
    "batch_number" : MessageLookupByLibrary.simpleMessage("Batch number"),
    "biomass" : MessageLookupByLibrary.simpleMessage("Biomass [ton]"),
    "cancel" : MessageLookupByLibrary.simpleMessage("Cancel"),
    "cannot_be_harvested" : MessageLookupByLibrary.simpleMessage("Cannot be harvested"),
    "cannot_be_mixed_with_other_populations" : MessageLookupByLibrary.simpleMessage("Cannot be mixed with other populations"),
    "cannot_be_sold_or_transferred_to_another_site" : MessageLookupByLibrary.simpleMessage("Cannot be sold or transferred to another site"),
    "cannot_be_transferred_to_another_unit" : MessageLookupByLibrary.simpleMessage("Cannot be transferred to another unit"),
    "cant_save_0" : MessageLookupByLibrary.simpleMessage("Can\'t save 0"),
    "cause" : MessageLookupByLibrary.simpleMessage("Cause"),
    "checked_found_no_mortality" : MessageLookupByLibrary.simpleMessage("Checked & found no mortality"),
    "cleaner_fish" : MessageLookupByLibrary.simpleMessage("Cleaner fish"),
    "cleaner_fish_type" : MessageLookupByLibrary.simpleMessage("Cleaner fish type"),
    "cleanerfish" : MessageLookupByLibrary.simpleMessage("Cleanerfish"),
    "clearance" : MessageLookupByLibrary.simpleMessage("Clearance"),
    "click_new_registration_to_start_registering" : MessageLookupByLibrary.simpleMessage("Click new registration to start registering."),
    "concentration_ml_l" : MessageLookupByLibrary.simpleMessage("Concentration [ml/l]"),
    "couldnt_check_for_mortality" : MessageLookupByLibrary.simpleMessage("Couldn\'t check for mortality"),
    "culled_the_entire_unit" : MessageLookupByLibrary.simpleMessage("Culled the entire unit"),
    "culling" : MessageLookupByLibrary.simpleMessage("Culling"),
    "culling_registration" : MessageLookupByLibrary.simpleMessage("Culling registration"),
    "dark_mode" : MessageLookupByLibrary.simpleMessage("Dark mode"),
    "days" : MessageLookupByLibrary.simpleMessage("days"),
    "december" : MessageLookupByLibrary.simpleMessage("December"),
    "degree_days" : MessageLookupByLibrary.simpleMessage("Degree days"),
    "delete" : MessageLookupByLibrary.simpleMessage("Delete"),
    "delete_registration" : MessageLookupByLibrary.simpleMessage("Delete registration"),
    "details" : MessageLookupByLibrary.simpleMessage("Details"),
    "dont_save" : MessageLookupByLibrary.simpleMessage("Don\'t save"),
    "duration" : MessageLookupByLibrary.simpleMessage("Duration"),
    "edit" : MessageLookupByLibrary.simpleMessage("Edit"),
    "environment" : MessageLookupByLibrary.simpleMessage("Environment"),
    "environment_registration" : MessageLookupByLibrary.simpleMessage("Environment registration"),
    "expiration_date" : MessageLookupByLibrary.simpleMessage("Expiration date"),
    "favorite" : MessageLookupByLibrary.simpleMessage("Favorite"),
    "favorite_site" : MessageLookupByLibrary.simpleMessage("Favorite site"),
    "favorites_sites" : MessageLookupByLibrary.simpleMessage("Favorites sites"),
    "february" : MessageLookupByLibrary.simpleMessage("February"),
    "feed_amount_kg" : MessageLookupByLibrary.simpleMessage("Feed amount [kg]"),
    "feeding" : MessageLookupByLibrary.simpleMessage("Feeding"),
    "feeding_registration" : MessageLookupByLibrary.simpleMessage("Feeding registration"),
    "feeding_series" : MessageLookupByLibrary.simpleMessage("Feeding series"),
    "fish" : MessageLookupByLibrary.simpleMessage("Fish"),
    "frequently_visited" : MessageLookupByLibrary.simpleMessage("Frequently visited"),
    "frequently_visited_sites" : MessageLookupByLibrary.simpleMessage("Frequently visited sites"),
    "fri" : MessageLookupByLibrary.simpleMessage("Fri"),
    "hide_empty_units" : MessageLookupByLibrary.simpleMessage("Hide empty units"),
    "i_confirm_that_i_missed_feeding_unit_today" : m1,
    "i_confirm_that_message" : m2,
    "i_missed_feeding_unit_today" : m3,
    "january" : MessageLookupByLibrary.simpleMessage("January"),
    "july" : MessageLookupByLibrary.simpleMessage("July"),
    "jump_to_unit" : MessageLookupByLibrary.simpleMessage("Jump to unit"),
    "june" : MessageLookupByLibrary.simpleMessage("June"),
    "landbased" : MessageLookupByLibrary.simpleMessage("Landbased"),
    "lice" : MessageLookupByLibrary.simpleMessage("Lice"),
    "lice_registration" : MessageLookupByLibrary.simpleMessage("Lice registration"),
    "light_mode" : MessageLookupByLibrary.simpleMessage("Light mode"),
    "logout" : MessageLookupByLibrary.simpleMessage("Log out"),
    "march" : MessageLookupByLibrary.simpleMessage("March"),
    "may" : MessageLookupByLibrary.simpleMessage("May"),
    "mon" : MessageLookupByLibrary.simpleMessage("Mon"),
    "mortality" : MessageLookupByLibrary.simpleMessage("Mortality"),
    "mortality_registration" : MessageLookupByLibrary.simpleMessage("Mortality registration"),
    "my_X_sites" : m4,
    "n_registrations_were_successfully_uploaded" : m5,
    "new_culling" : MessageLookupByLibrary.simpleMessage("New culling"),
    "new_environment" : MessageLookupByLibrary.simpleMessage("New environment"),
    "new_feeding" : MessageLookupByLibrary.simpleMessage("New feeding"),
    "new_lice_sample" : MessageLookupByLibrary.simpleMessage("New lice sample"),
    "new_mortality_count" : MessageLookupByLibrary.simpleMessage("New mortality count"),
    "new_registration" : MessageLookupByLibrary.simpleMessage("New Registration"),
    "no" : MessageLookupByLibrary.simpleMessage("No"),
    "no_connection_msg" : MessageLookupByLibrary.simpleMessage("No internet connection."),
    "no_fish" : MessageLookupByLibrary.simpleMessage("No fish"),
    "no_registrations" : MessageLookupByLibrary.simpleMessage("No registrations."),
    "no_registrations_yet" : MessageLookupByLibrary.simpleMessage("No registrations yet."),
    "nothing_to_report_in_mortality" : MessageLookupByLibrary.simpleMessage("Nothing to report in mortality"),
    "november" : MessageLookupByLibrary.simpleMessage("November"),
    "number" : MessageLookupByLibrary.simpleMessage("Number"),
    "october" : MessageLookupByLibrary.simpleMessage("October"),
    "ok" : MessageLookupByLibrary.simpleMessage("Ok"),
    "one_registration_was_successfully_uploaded" : MessageLookupByLibrary.simpleMessage("1 registration was successfully uploaded"),
    "only_applicable_to_salmon" : MessageLookupByLibrary.simpleMessage("Only applicable to salmon."),
    "or" : MessageLookupByLibrary.simpleMessage("Or"),
    "quarantine" : MessageLookupByLibrary.simpleMessage("Quarantine"),
    "quarantine_consequences" : MessageLookupByLibrary.simpleMessage("Quarantine consequences"),
    "quarantine_other_units" : MessageLookupByLibrary.simpleMessage("Quarantine other units"),
    "quaratined_the_fish" : MessageLookupByLibrary.simpleMessage("Quarantined the fish?"),
    "registration" : MessageLookupByLibrary.simpleMessage("Registrations"),
    "requires_formal_clearance" : MessageLookupByLibrary.simpleMessage("Requires formal clearance"),
    "returned_to_the_unit" : MessageLookupByLibrary.simpleMessage("Returned to the unit"),
    "salmon" : MessageLookupByLibrary.simpleMessage("Salmon"),
    "sample_taker" : MessageLookupByLibrary.simpleMessage("Sample taker"),
    "sat" : MessageLookupByLibrary.simpleMessage("Sat"),
    "save" : MessageLookupByLibrary.simpleMessage("Save"),
    "save_changes" : MessageLookupByLibrary.simpleMessage("Save changes"),
    "save_quarantine_23" : MessageLookupByLibrary.simpleMessage("Save quarantine [2/3]"),
    "save_sample_23" : MessageLookupByLibrary.simpleMessage("Save samples [2/3]"),
    "save_sedation_13" : MessageLookupByLibrary.simpleMessage("Save sedation [1/3]"),
    "scan_barcode" : MessageLookupByLibrary.simpleMessage("Scan barcode"),
    "seabased" : MessageLookupByLibrary.simpleMessage("Seabased"),
    "search" : MessageLookupByLibrary.simpleMessage("Search"),
    "search_location" : MessageLookupByLibrary.simpleMessage("Search Location"),
    "sedation" : MessageLookupByLibrary.simpleMessage("Sedation"),
    "sedation_tank" : MessageLookupByLibrary.simpleMessage("Sedation tank"),
    "sedation_used_ml" : MessageLookupByLibrary.simpleMessage("Sedation used [ml]"),
    "select" : MessageLookupByLibrary.simpleMessage("Select"),
    "select_sedation_method" : MessageLookupByLibrary.simpleMessage("Select sedation method"),
    "select_series" : MessageLookupByLibrary.simpleMessage("Select series"),
    "sensors" : MessageLookupByLibrary.simpleMessage("Sensors"),
    "sensors_are_applicable_to_selected_unit" : MessageLookupByLibrary.simpleMessage("Sensors are applicable to selected unit"),
    "sensors_are_applicable_to_the_entire_site" : MessageLookupByLibrary.simpleMessage("Sensors are applicable to the entire site"),
    "sent" : MessageLookupByLibrary.simpleMessage("sent"),
    "september" : MessageLookupByLibrary.simpleMessage("September"),
    "sign_submit" : MessageLookupByLibrary.simpleMessage("Sign & submit [3/3]"),
    "site" : MessageLookupByLibrary.simpleMessage("Site"),
    "site_sensors" : MessageLookupByLibrary.simpleMessage("Site sensors"),
    "stock" : MessageLookupByLibrary.simpleMessage("Stock"),
    "sun" : MessageLookupByLibrary.simpleMessage("Sun"),
    "thu" : MessageLookupByLibrary.simpleMessage("Thu"),
    "total" : MessageLookupByLibrary.simpleMessage("Total"),
    "tue" : MessageLookupByLibrary.simpleMessage("Tue"),
    "unit" : MessageLookupByLibrary.simpleMessage("Unit"),
    "unit_name" : MessageLookupByLibrary.simpleMessage("Unit name"),
    "unit_sensors" : MessageLookupByLibrary.simpleMessage("Unit sensors"),
    "units" : MessageLookupByLibrary.simpleMessage("Units"),
    "unsaved_changes" : MessageLookupByLibrary.simpleMessage("Unsaved changes"),
    "water_in_sedation_unit_l" : MessageLookupByLibrary.simpleMessage("Water in sedation unit [l]"),
    "wed" : MessageLookupByLibrary.simpleMessage("Wed"),
    "yes" : MessageLookupByLibrary.simpleMessage("Yes"),
    "you_are_currently_in_offline_mode" : MessageLookupByLibrary.simpleMessage("You are currently in offline mode"),
    "you_have_unsaved_changes" : MessageLookupByLibrary.simpleMessage("You have unsaved changes.")
  };
}

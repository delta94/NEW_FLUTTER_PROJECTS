// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a nb locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'nb';

  static m0(time) => "Lagt til kl ${time}";

  static m1(unitName) => "Jeg bekrefter at jeg savnet fôringsenhet ${unitName} i dag.";

  static m2(message) => "Jeg bekrefter at ${message}";

  static m3(unitName) => "Jeg savnet fôringsenhet ${unitName} i dag.";

  static m4(mode) => "Mine ${mode} localiteter";

  static m5(n) => "${n} registreringer er sendt inn";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static _notInlinedMessages(_) => <String, Function> {
    "access_required" : MessageLookupByLibrary.simpleMessage("Tilgang kreves"),
    "add" : MessageLookupByLibrary.simpleMessage("Legg til"),
    "add_fish_sample" : MessageLookupByLibrary.simpleMessage("Legg til fiskeprøve"),
    "added_at" : m0,
    "affects_other_units_on_the_site" : MessageLookupByLibrary.simpleMessage("Påvirker andre enheter på nettstedet"),
    "all" : MessageLookupByLibrary.simpleMessage("Alle"),
    "amount_kg" : MessageLookupByLibrary.simpleMessage("Beløp [kg]"),
    "and" : MessageLookupByLibrary.simpleMessage("Og"),
    "april" : MessageLookupByLibrary.simpleMessage("April"),
    "are_you_sure_you_want_to_continue" : MessageLookupByLibrary.simpleMessage("Er du sikker på at du vil fortsette?"),
    "are_you_sure_you_want_to_delete_registration" : MessageLookupByLibrary.simpleMessage("Er du sikker på at du vil slette registreringen?"),
    "at" : MessageLookupByLibrary.simpleMessage("på"),
    "august" : MessageLookupByLibrary.simpleMessage("August"),
    "automatic_clearance_at_the_end_of_the_biological_clearance_period" : MessageLookupByLibrary.simpleMessage("Automatisk klarering ved slutten av den biologiske klareringsperioden"),
    "avg_weight" : MessageLookupByLibrary.simpleMessage("Gjennomsnittsvekt"),
    "back" : MessageLookupByLibrary.simpleMessage("Tilbake"),
    "batch_number" : MessageLookupByLibrary.simpleMessage("Batchnummer"),
    "biomass" : MessageLookupByLibrary.simpleMessage("Biomasse [tonn]"),
    "cancel" : MessageLookupByLibrary.simpleMessage("Avbryt"),
    "cannot_be_harvested" : MessageLookupByLibrary.simpleMessage("Kan ikke høstes"),
    "cannot_be_mixed_with_other_populations" : MessageLookupByLibrary.simpleMessage("Kan ikke blandes med andre populasjoner"),
    "cannot_be_sold_or_transferred_to_another_site" : MessageLookupByLibrary.simpleMessage("Kan ikke selges eller overføres til et annet nettsted"),
    "cant_save_0" : MessageLookupByLibrary.simpleMessage("Kan ikke lagre 0"),
    "cause" : MessageLookupByLibrary.simpleMessage("Årsak"),
    "checked_found_no_mortality" : MessageLookupByLibrary.simpleMessage("Sjekket og fant ingen dødelighet"),
    "cleaner_fish" : MessageLookupByLibrary.simpleMessage("Renere fisk"),
    "cleaner_fish_type" : MessageLookupByLibrary.simpleMessage("Renere fisketype"),
    "cleanerfish" : MessageLookupByLibrary.simpleMessage("Renerefisk"),
    "clearance" : MessageLookupByLibrary.simpleMessage("Klarering"),
    "click_new_registration_to_start_registering" : MessageLookupByLibrary.simpleMessage("Klikk ny registrering for å begynne å registreredeg."),
    "concentration_ml_l" : MessageLookupByLibrary.simpleMessage("Konsentrasjon [ml/l]"),
    "couldnt_check_for_mortality" : MessageLookupByLibrary.simpleMessage("Kunne ikke sjekke for dødelighet"),
    "culled_the_entire_unit" : MessageLookupByLibrary.simpleMessage("Rullet hele enhet"),
    "culling" : MessageLookupByLibrary.simpleMessage("Destruering"),
    "culling_registration" : MessageLookupByLibrary.simpleMessage("Destrueringregistrering"),
    "dark_mode" : MessageLookupByLibrary.simpleMessage("Nattmodus"),
    "days" : MessageLookupByLibrary.simpleMessage("dager"),
    "december" : MessageLookupByLibrary.simpleMessage("Desember"),
    "degree_days" : MessageLookupByLibrary.simpleMessage("Grad dager"),
    "delete" : MessageLookupByLibrary.simpleMessage("Slett"),
    "delete_registration" : MessageLookupByLibrary.simpleMessage("Slett registrering"),
    "details" : MessageLookupByLibrary.simpleMessage("Detaljer"),
    "dont_save" : MessageLookupByLibrary.simpleMessage("Ikke lagre"),
    "edit" : MessageLookupByLibrary.simpleMessage("Redigere"),
    "environment" : MessageLookupByLibrary.simpleMessage("Miljø"),
    "environment_registration" : MessageLookupByLibrary.simpleMessage("Miljøregistrering"),
    "expiration_date" : MessageLookupByLibrary.simpleMessage("Utløpsdato"),
    "favorite" : MessageLookupByLibrary.simpleMessage("Favoritt"),
    "favorite_site" : MessageLookupByLibrary.simpleMessage("Favoritt enhet"),
    "favorites_sites" : MessageLookupByLibrary.simpleMessage("Favorittnettsteder"),
    "february" : MessageLookupByLibrary.simpleMessage("Februar"),
    "feed_amount_kg" : MessageLookupByLibrary.simpleMessage("Fôr beløp [kg]"),
    "feeding" : MessageLookupByLibrary.simpleMessage("Fôring"),
    "feeding_registration" : MessageLookupByLibrary.simpleMessage("Fôringregistrering"),
    "feeding_series" : MessageLookupByLibrary.simpleMessage("Fôring serie"),
    "fish" : MessageLookupByLibrary.simpleMessage("Fisk"),
    "frequently_visited" : MessageLookupByLibrary.simpleMessage("Mest besøkte"),
    "frequently_visited_sites" : MessageLookupByLibrary.simpleMessage("Ofte besøkte nettsteder"),
    "fri" : MessageLookupByLibrary.simpleMessage("Fre"),
    "hide_empty_units" : MessageLookupByLibrary.simpleMessage("Skjul tomme enheter"),
    "i_confirm_that_i_missed_feeding_unit_today" : m1,
    "i_confirm_that_message" : m2,
    "i_missed_feeding_unit_today" : m3,
    "january" : MessageLookupByLibrary.simpleMessage("Januar"),
    "july" : MessageLookupByLibrary.simpleMessage("Juli"),
    "jump_to_unit" : MessageLookupByLibrary.simpleMessage("Gå til enhet"),
    "june" : MessageLookupByLibrary.simpleMessage("Juni"),
    "landbased" : MessageLookupByLibrary.simpleMessage("Landbasert"),
    "lice" : MessageLookupByLibrary.simpleMessage("Lus"),
    "lice_registration" : MessageLookupByLibrary.simpleMessage("LusDødelighetsregistrering"),
    "light_mode" : MessageLookupByLibrary.simpleMessage("Lysmodus"),
    "logout" : MessageLookupByLibrary.simpleMessage("Logg ut"),
    "march" : MessageLookupByLibrary.simpleMessage("Mars"),
    "may" : MessageLookupByLibrary.simpleMessage("Mai"),
    "mon" : MessageLookupByLibrary.simpleMessage("Man"),
    "mortality" : MessageLookupByLibrary.simpleMessage("Dødelighet"),
    "mortality_registration" : MessageLookupByLibrary.simpleMessage("Dødelighetsregistrering"),
    "my_X_sites" : m4,
    "n_registrations_were_successfully_uploaded" : m5,
    "new_culling" : MessageLookupByLibrary.simpleMessage("Ny destruering"),
    "new_environment" : MessageLookupByLibrary.simpleMessage("New miljø"),
    "new_feeding" : MessageLookupByLibrary.simpleMessage("Ny fôring"),
    "new_lice_sample" : MessageLookupByLibrary.simpleMessage("Ny luseprøve"),
    "new_mortality_count" : MessageLookupByLibrary.simpleMessage("Ny dødelighet teller"),
    "new_registration" : MessageLookupByLibrary.simpleMessage("Ny registrering"),
    "no" : MessageLookupByLibrary.simpleMessage("nei"),
    "no_connection_msg" : MessageLookupByLibrary.simpleMessage("Ingen internett-tilkobling."),
    "no_fish" : MessageLookupByLibrary.simpleMessage("Ingen fisk"),
    "no_registrations" : MessageLookupByLibrary.simpleMessage("Ingen registreringer."),
    "no_registrations_yet" : MessageLookupByLibrary.simpleMessage("Ingen registreringer ennå."),
    "nothing_to_report_in_mortality" : MessageLookupByLibrary.simpleMessage("Ingenting å rapportere om dødelighet"),
    "november" : MessageLookupByLibrary.simpleMessage("November"),
    "number" : MessageLookupByLibrary.simpleMessage("Antall"),
    "october" : MessageLookupByLibrary.simpleMessage("Oktober"),
    "ok" : MessageLookupByLibrary.simpleMessage("Ok"),
    "one_registration_was_successfully_uploaded" : MessageLookupByLibrary.simpleMessage("1 registrering er sendt inn"),
    "only_applicable_to_salmon" : MessageLookupByLibrary.simpleMessage("Gjelder kun for laks."),
    "or" : MessageLookupByLibrary.simpleMessage("Eller"),
    "quarantine" : MessageLookupByLibrary.simpleMessage("Karantene"),
    "quarantine_consequences" : MessageLookupByLibrary.simpleMessage("Karantene konsekvenser"),
    "quarantine_other_units" : MessageLookupByLibrary.simpleMessage("Karantene andre enheter"),
    "quaratined_the_fish" : MessageLookupByLibrary.simpleMessage("Fisken i karantene?"),
    "requires_formal_clearance" : MessageLookupByLibrary.simpleMessage("Krever formell godkjenning"),
    "returned_to_the_unit" : MessageLookupByLibrary.simpleMessage("Kom tilbake til enheten"),
    "salmon" : MessageLookupByLibrary.simpleMessage("Laks"),
    "sample_taker" : MessageLookupByLibrary.simpleMessage("Sample taker"),
    "sat" : MessageLookupByLibrary.simpleMessage("Lør"),
    "save" : MessageLookupByLibrary.simpleMessage("Lagre"),
    "save_changes" : MessageLookupByLibrary.simpleMessage("Lagre endringer"),
    "save_quarantine_23" : MessageLookupByLibrary.simpleMessage("Lagre karantene [2/3]"),
    "save_sample_23" : MessageLookupByLibrary.simpleMessage("Lagre prøver [2/3]"),
    "save_sedation_13" : MessageLookupByLibrary.simpleMessage("Lagre sedasjon [1/3]"),
    "scan_barcode" : MessageLookupByLibrary.simpleMessage("Skann QR-kode"),
    "seabased" : MessageLookupByLibrary.simpleMessage("Sjøbasert"),
    "search" : MessageLookupByLibrary.simpleMessage("Søk"),
    "search_location" : MessageLookupByLibrary.simpleMessage("Søk lokalitet"),
    "sedation" : MessageLookupByLibrary.simpleMessage("Sedation"),
    "sedation_tank" : MessageLookupByLibrary.simpleMessage("Sedasjonstank"),
    "sedation_used_ml" : MessageLookupByLibrary.simpleMessage("Sedasjon brukt [ml]"),
    "select" : MessageLookupByLibrary.simpleMessage("Velg"),
    "select_sedation_method" : MessageLookupByLibrary.simpleMessage("Velg sedasjonsmetode"),
    "select_series" : MessageLookupByLibrary.simpleMessage("Velg serie"),
    "sensors" : MessageLookupByLibrary.simpleMessage("Sensorer"),
    "sensors_are_applicable_to_selected_unit" : MessageLookupByLibrary.simpleMessage("Sensorer are applicable to selected Enheter"),
    "sensors_are_applicable_to_the_entire_site" : MessageLookupByLibrary.simpleMessage("Sensorer gjelder for hele enhet"),
    "sent" : MessageLookupByLibrary.simpleMessage("sendt"),
    "september" : MessageLookupByLibrary.simpleMessage("September"),
    "sign_submit" : MessageLookupByLibrary.simpleMessage("Signer og send inn [3/3]"),
    "site" : MessageLookupByLibrary.simpleMessage("Enhet"),
    "site_sensors" : MessageLookupByLibrary.simpleMessage("enhet sensorer"),
    "stock" : MessageLookupByLibrary.simpleMessage("Beholdning"),
    "sun" : MessageLookupByLibrary.simpleMessage("Son"),
    "thu" : MessageLookupByLibrary.simpleMessage("Tor"),
    "total" : MessageLookupByLibrary.simpleMessage("Total"),
    "tue" : MessageLookupByLibrary.simpleMessage("Tir"),
    "unit" : MessageLookupByLibrary.simpleMessage("Enhet"),
    "unit_name" : MessageLookupByLibrary.simpleMessage("Enhetsnavn"),
    "unit_sensors" : MessageLookupByLibrary.simpleMessage("Unit sensors"),
    "units" : MessageLookupByLibrary.simpleMessage("Enheter"),
    "unsaved_changes" : MessageLookupByLibrary.simpleMessage("Ikke lagrede endringer"),
    "water_in_sedation_unit_l" : MessageLookupByLibrary.simpleMessage("Vann i sedasjonsenhet [l]"),
    "wed" : MessageLookupByLibrary.simpleMessage("Ons"),
    "yes" : MessageLookupByLibrary.simpleMessage("ja"),
    "you_are_currently_in_offline_mode" : MessageLookupByLibrary.simpleMessage("Du er for øyeblikket uten internettdekning"),
    "you_have_unsaved_changes" : MessageLookupByLibrary.simpleMessage("Du har ikke lagrede endringer.")
  };
}

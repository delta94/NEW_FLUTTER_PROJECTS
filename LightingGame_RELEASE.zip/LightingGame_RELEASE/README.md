[TOC]:#

# Table of Contents
- [Table of Contents](#table-of-contents)
  - [Documentation](#documentation)
    - [Diagrams.io](#diagramsio)
  - [Internationalization](#internationalization)
    - [.arb format](#arb-format)
  - [Themes](#themes)
  - [Provider package](#provider-package)
  - [Local storage](#local-storage)
- [Navigation](#navigation)

## Documentation
### Diagrams.io
To see various views and diagrams, go to [diagrams.net (formerly draw.io)](https://www.diagrams.net/).
Select "Open existing" and choose OneDrive.
Navigate to Apps and Web > Documents > General > App Diagrams
Alternatively, use the links provided below.

**Quick links**
- [Architecture of the App](https://app.diagrams.net/#Wb!NuiT2QtZYUSK3BohQUkho7hwt4dVCXZBjzNYD3QuCpF3pp8oO311QbjHcFLCDHVd%2F01A64NGP5KHJELHLK3LJG2QG5W4KTBODS3)

## Internationalization

Internationalization in the app is solved using the Flutter intl package, with an Android studio and VSCode plugin: 

- [Android Studio](https://plugins.jetbrains.com/plugin/13666-flutter-intl)
- [VS Code](https://marketplace.visualstudio.com/items?itemName=localizely.flutter-intl)

Most files are generated, but to add translations, edit the `i10n/intl_en.arb` and `i10n/intl_no.arb` for english and norwegian texts respectively. 

These .arb files will most likely become quite large over time, so **please keep a neat and tidy format** so that we may reuse some strings. 

Note that it´s possible to use paramters in the strings, such that "Add new count" and "Add new cause" can both use `S.of(context).add_new(/* "count" or "cause" */)`. 

The IDE plugins linked above will use the .arb files to generate the class named S, which can be used anywhere in the UI tree as `S.of(context).<key in .arb file>`, for example `S.of(context).confirm`. Depending on language, this will display as "Cancel" or "Avbryt" in norwegian. 

### .arb format

- Write out the sentence in english, all lowercase
- Replace spaces with underscore (_)
- Mark paramters with X 
- Name the string with plural / male form if it changes based on numbers or gender. 

Examples: 

```json
// .arb
{
  "save": "Save", 
  "add_new_x": "Add new {item}",
  "submit_X_registration": "{howMany, plural, one{Submit 1 registration} other{Submit {howMany} registrations}}",
}
```

Usages: 

```dart
Text(S.of(context).save)  //En: Save, No: Lagre
Text(S.of(context).add_new_X("abc")) //En: Add new abc, No: Legg til ny abc. Use S.of... for abc as well. 
Text(S.of(context).submit_X_registration(1)) 
```

Note: For ease of use, it´s also possible to declare `final s = S.of(context)` in the build-method, and then use `s.add_new_X(s.count)`  to generate "Add new count" / "Legg til ny telling". 

## Themes



## Provider package
This package is used for state management in Flutter application

- #### Usage
1. Create a model (sometimes we call it view model) that extends ``ChangeNotifier`` 
```dart
class AppModel extends AppModel {
  // Declare Properties & functions here
  void add(Item item) {
    _items.add(item);
    // This call tells the widgets that are listening to this model to rebuild.
    notifyListeners();
  }
  ...
}
```
2. In ``lib/src/provider_setup.dart`` file, we need to register the model with ``ChangeNotifierProvider`` (if the model depends on another model then we should register it with ``ChangeNotifierProxyProvider``) so that when the model updated (by calling ``notifyListeners`` then it will rebuild widgets which comsumed this model.
```dart
import 'package:provider/provider.dart';
...
List<SingleChildWidget> commonServices = [
  ChangeNotifierProvider<AppModel>(
    create: (_) => AppModel(),
  ),
  ...
];
```
3. Now our model is provided to widgets in our app, we can start using it. This is done through the ```Comsumer``` widget
```dart
@override
Widget build(BuildContext context) {
  return Comsumer<AppModel>(
    builder: (context, model, child) {
      return Text("Total price: ${model.count}")
    }
  )
}
```
**Note:** Sometimes, we don't really want to rebuild the UI if the ``data`` is changed. In this case, we can use ``Provider.of`` with the ``listen`` parameter set to ``false``
```dart
var appModel = Provider.of<AppModel>(context, listen: false);
```
## Local storage
We use ``sqflite`` package (a SQLite plugin for Flutter) for storing,  manipulating and synchronizing data from server to local.

### SQLite database schema
1. The table ``AppConfig``
  - Usage: Store common and shared data infor such as tenant info, organization, sites, species, mortality causes, feed types, feed stores, missed feeding reasons, species by unit, ... <br/>
  - Structure:
    - key: TEXT NOT NULL (store name of common data. For example, key can be ``sites``, ``species``, ``mortalityCauses``, ...)
    - jsonData: TEXT NOT NULL (store raw json string of the data)
2. The table ``QuickAccess``
  - Usage: Store frequency visit sites or favorite sites of logged in user. This table will be queried and shown on Favorite sites UI or Frequency sites UI so that user can access the sites quickly.
  - Structure: 
    - username: TEXT NOT NULL (the username logged in)
    - siteId: TEXT NOT NULL (the site uuid string that user visted or marked favorite)
    - frequency: INTEGER (number of visited for a site id above)
    - favorite: INTEGER (1: true, 0: false)
3. The table ``MortalityCause``
  - Usage: Store historical mortality causes that user already registered so that when the user start a new registration in the next day then it will populate history causes for the user to choose quickly.
  - Structure:
    - username: TEXT NOT NULL (the user name logged in)
    - causeId: INTEGER (mortality cause id)
    - unitId: TEXT NOT NULL (unit uuid string)
    - date: TEXT NOT NULL (the time that user enters the cause)
4. The table ``Mortality``
  - Usage: Store mortality registration data
  - Structure: 
    - id: TEXT (registration id that is returned by server after API post when user added new registration)
    - siteId: TEXT (site id)
    - unitId: TEXT (unit id)
    - speciesId: INTEGER (species id. Salmon is always 1)
    - time: TEXT (registration time)
    - rawJson: TEXT (json data of a registration. It contains a list mortality counts, reason of not check and flag confirmed no mortality)
    - status: INTEGER (0: Unchanged, 1: Changed, 2: Deleted, 3: New)
5. The table ``Feeding``
  - Usage: Store feeding registration data
  - Structure: similar to ``Mortality``
### Manipulate local storage
#### &nbsp;&nbsp;&nbsp;&nbsp;Manipulate ``AppConfig``
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;In order to manipulate common data stored in ``AppConfig``, we need to import ``app_config_db_repository.dart`` first
  ```dart
  import 'package:control_app/src/database/app_config_db_repository.dart';
  ```
- Query common data: Call the static function ``AppConfigDBRepository.getAppConfig(String key)`` and return a future of ``AppConfig`` instance. The ``key`` is one of the predefined keys in ``AppConfigKeys``
- Save common data: Call the static function ``AppConfigDBRepository.saveAppConfig(String key, String jsonData)`` with ``key`` is one of the predefined keys in ``AppConfigKeys`` and ``jsonData`` is raw json string that presents the data.
#### &nbsp;&nbsp;&nbsp;&nbsp;Manipulate frequency or favorite sites (``QuickAccess``)
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;In order to manipulate ``QuickAccess`` data, we need to import ``quick_access_sqlite_repository.dart`` first
  ```dart
  import 'package:control_app/src/database/quick_access_sqlite_repository.dart';
  ```
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;And create a new instance of the repository
```dart
QuickAccessSqliteRepository quickAccessRepository
   = new QuickAccessSqliteRepository();
```
- Query frequency/favorite sites based on current logged in user
```dart
Future<List<QuickAccess>> getByUsername(String username) async
```
- Insert frequency/favorite sites: Create a ``QuickAccess`` object and then pass it into the function
```dart
Future<int> insert(QuickAccess quickAccess) async
```
- Update frequency/favorite sites: similar to insert, we change properties ``frequency`` or ``favorite`` in an existing ``QuickAccess`` object then call the function
```dart
Future<int> update(QuickAccess quickAccess) async
```
#### &nbsp;&nbsp;&nbsp;&nbsp;Manipulate registration (``Mortality``, ``Feeding``, ``Culling``, ...)
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;In order to manipulate registration data, we need to create an instance of ``DBRegistrationRepository`` with a specific type (``RegistrationType.Mortality``, ``RegistrationType.Feeding``, ..)
  ```dart
  import 'package:control_app/src/repositories/db_registration_repository.dart';
  ...
  DBRegistrationRepository _dbRepos = new DBRegistrationRepository(RegistrationType.Mortality);
  ...
  ```
- Insert a new registration: Create a ``Registration`` and call the function ``store`` to insert the new registration to database
```dart
var registration = Registration(
      speciesId: 1,
      siteId: <site id here>,
      unitId: <unit id here>,
      time: DateTime.now(),
      item: RegistrationFactory.create(RegistrationType.Mortality),
      changeStatus: ChangeStatus.New,
    );
_dbRepos.store(registration);
```
- Update existing registration: update ``item`` property and call the function ``update`` to update the registration
```dart
(registration.item as FeedingRegistration).feedings.add(new Feeding(feedTypeId: 1, feedStoreId: `uuid string`, feedAmountKg: 100.0));

_dbRepos.update(registration);
```
We can update a list of registrations by using ``updateMultiple`` function
```dart
List<Registration> registrations = _dbRepos.fetchByUnit('abc-xyz');
...
/// change value for registrations list
...
_dbRepos.updateMultiple(registrations);
```
- Delete a registration: simply call the function ``delete``
```dart
_dbRepos.delete(registration);
```
We can delete a list of registrations by using ``deleteMultiple``
```dart
List<Registration> registrations;
...
_dbRepos.deleteMultiple(registrations);
```
- Load registration list by a certain unit id for today
```dart
List<Registration> registrations = await _dbRepos.fetchByUnit("unitid string");
```
- Load registration list for the whole site
```dart
List<Registration> registrations = await _dbRepos.fetchBySite("siteid string", fromTime, toTime);
```
with ``fromTime``, ``toTime`` is ``DateTime`` type.
# Navigation 

- The provider hold's the states/models.
- Changing the language and theme will trigger a nav.push to the app_model
- If you set a location on the navigation_screen, you will do a nav.push to the org_model with the location.
- If you pick mortality, set a count, then this will trigger a nav.push to the mortality_model with the state on count for mortality.
- UI gets pushed with nav.pushnamed("/loc") for example, and all the path's are coming from Routers.dart.
- We use nav.pop() to navigate back.
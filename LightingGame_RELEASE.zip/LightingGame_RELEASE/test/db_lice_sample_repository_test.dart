// skip this file to avoid getting errors when running your unit tests
import 'package:control_app/src/models/lice/lice_sample.dart';
@Skip("sqflite cannot run on the machine.")
import 'package:control_app/src/models/mortality/mortality.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/registration_factory.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter_test/flutter_test.dart';

DBRegistrationRepository repos;
List<Registration> addedList;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  Registration generateRegistration() {
    var mortalites = List<Mortality>();
    mortalites.add(new Mortality(mortalityCount: 10, mortalityCauseId: 1));
    mortalites.add(new Mortality(mortalityCount: 20, mortalityCauseId: 18));
    mortalites.add(new Mortality(mortalityCount: 30, mortalityCauseId: 20));
    mortalites.add(new Mortality(mortalityCount: 40, mortalityCauseId: 22));
    var uuid = Uuid();
    var siteId = uuid.v4().toString();

    var unitId = uuid.v4().toString();
    var time = DateTime.now();
    RegistrationBaseItem liceSample =
        RegistrationFactory.create(RegistrationType.Lice);
    var lice = (liceSample as LiceSample);
    lice.medicamentId = 202;
    lice.overrideWithdrawal = true;
    lice.volumeLitre = 100;
    lice.amountMilliLitre = 20;
    lice.withdrawal.atus = 5;
    lice.withdrawal.days = 10;
    lice.expiryDate = DateTime(2020, 7, 9, 12);
    lice.samples.add(Sample(
      parameters: {"111": 1, "222": 2, "333": 3},
      measureId: 1,
    ));
    lice.samples.add(Sample(
      parameters: {"111": 2, "222": 5, "333": 5},
      measureId: 2,
    ));
    return new Registration(
        siteId: siteId,
        unitId: unitId,
        time: time,
        item: lice,
        changeStatus: ChangeStatus.New);
  }

  group("Testing lice sample ", () {
    var addedList = new List<Registration>();
    setUp(() async {
      repos = new DBRegistrationRepository(RegistrationType.Lice);
    });

    // Delete the database so every test run starts with a fresh database
    tearDownAll(() async {
      if (addedList.length > 0) {
        repos.deleteMultiple(addedList);
      }
    });

    test("Store new lice sample, should store succesfully", () async {
      var registration = generateRegistration();
      await repos.store(registration);
      print("registration rowId = ${registration.rowId}");
      addedList.add(registration);

      expect(registration.rowId, isNotNull);

      var registrationList =
          await repos.fetchBySite(siteId: registration.siteId);
      expect(registrationList.length, 1);

      var inserted = registrationList[0];

      expect(inserted.siteId, registration.siteId);
      expect(inserted.unitId, registration.unitId);
      expect(inserted.time.year, registration.time.year);
      expect(inserted.time.month, registration.time.month);
      expect(inserted.time.day, registration.time.day);
      expect(inserted.time.hour, registration.time.hour);
      expect(inserted.time.minute, registration.time.minute);
      expect(inserted.time.second, registration.time.second);

      var lice = inserted.item as LiceSample;
      expect(lice, isNotNull);
      var liceActual = registration.item as LiceSample;
      expect(lice.medicamentId, liceActual.medicamentId);
      expect(lice.overrideWithdrawal, liceActual.overrideWithdrawal);
      expect(lice.volumeLitre, liceActual.volumeLitre);
      expect(lice.amountMilliLitre, liceActual.amountMilliLitre);
      expect(lice.withdrawal.atus, liceActual.withdrawal.atus);
      expect(lice.withdrawal.days, liceActual.withdrawal.days);
      expect(lice.expiryDate, liceActual.expiryDate);
      expect(lice.samples.length, liceActual.samples.length);
    });

    test("Update lice sample, should update succesfully", () async {
      var registration = generateRegistration();
      await repos.store(registration);
      addedList.add(registration);

      expect(registration.rowId, isNotNull);
      (registration.item as LiceSample).samples.removeAt(0);
      await repos.update(registration);
      var registrationList =
          await repos.fetchBySite(siteId: registration.siteId);
      expect(registrationList.length, 1);

      var updated = registrationList[0];

      var lice = updated.item as LiceSample;
      expect(lice, isNotNull);
      var liceActual = registration.item as LiceSample;
      expect(lice.samples.length, liceActual.samples.length);
    });
  });
}

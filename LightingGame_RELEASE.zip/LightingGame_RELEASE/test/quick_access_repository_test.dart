// skip this file to avoid getting errors when running your unit tests
@Skip("sqflite cannot run on the machine.")
import 'package:uuid/uuid.dart';

import 'package:control_app/src/database/quick_access_sqlite_repository.dart';
import 'package:control_app/src/models/quick_access.dart';
import 'package:flutter_test/flutter_test.dart';

QuickAccessSqliteRepository repos;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  group("Sqlite: Insert Quick Access tests - ", () {
    setUp(() async {
      repos = new QuickAccessSqliteRepository();
    });

    // Delete the database so every test run starts with a fresh database
    tearDownAll(() async {
      await repos.delete();
    });

    test("Insert with username is null, should throw exception", () async {
      try {
        var unitId = Uuid().toString();
        var invalid = new QuickAccess(username: "tala@akvagroup.com", unitId: unitId, frequency: 100, favorite: true);
        invalid.username = null;

        await repos.insert(invalid);
        fail("exception not thrown");
      } on Exception catch (e) {
        expect(e.toString(), "Exception: Username is required");
      }
    });

    test("Update with unitId is null, should throw exception", () async {
      try {
        var unitId = Uuid().toString();
        var invalid = new QuickAccess(username: "tala@akvagroup.com", unitId: unitId, frequency: 100, favorite: true);
        invalid.unitId = null;

        await repos.insert(invalid);
        fail("exception not thrown");
      } on Exception catch (e) {
        expect(e.toString(), "Exception: UnitId is required");
      }
    });

    test("Insert a Quick Access successful", () async {
      var unitId = Uuid().toString();
      var quickAccess =
          new QuickAccess(username: "tala@akvagroup.com", unitId: unitId, frequency: 100, favorite: true);
      await repos.insert(quickAccess);
      var result = await repos.getByUsername("tala@akvagroup.com");

      QuickAccess inserted;

      for (var item in result) {
        //print("{username: ${item.username}, unitId: ${item.unitId}, frequency: ${item.frequency}, favorite: ${item.favorite}}");
        if (item.unitId == unitId) {
          inserted = item;
        }
      }

      expect(inserted, isNotNull);
    });

    test("Insert null, should throw exception", () async {
      try {
        await repos.insert(null);
        fail("exception not thrown");
      } on Exception catch (e) {
        expect(e.toString(), "Exception: Object is null");
      }
    });
  });

  group("Sqlite: UPDATE Quick Access tests - ", () {
    setUp(() async {
      repos = new QuickAccessSqliteRepository();
    });
    // Delete the database so every test run starts with a fresh database
    tearDownAll(() async {
      //await deleteDatabase( (await getDatabasesPath()) + "/" + testDBPath);
      await repos.delete();
    });

    test("Update a Quick Access successful", () async {
      var unitId = Uuid().toString();
      var quickAccess =
          new QuickAccess(username: "tala@akvagroup.com", unitId: unitId, frequency: 100, favorite: true);
      await repos.insert(quickAccess);
      var result = await repos.getByUsername("tala@akvagroup.com");

      QuickAccess inserted;

      for (var item in result) {
        //print("{username: ${item.username}, unitId: ${item.unitId}, frequency: ${item.frequency}, favorite: ${item.favorite}}");
        if (item.unitId == unitId) {
          inserted = item;
        }
      }

      expect(inserted, isNotNull);

      QuickAccess update = inserted;
      update.frequency = 1000;

      int affectedNum = await repos.update(update);
      var result1 = await repos.getByUsername("tala@akvagroup.com");

      QuickAccess updated;

      for (var item in result1) {
        if (item.unitId == unitId) {
          updated = item;
        }
      }

      expect(affectedNum, 1);
      expect(updated, isNotNull);
      expect(updated.frequency, update.frequency);
    });

    test("Update null, should throw exception", () async {
      try {
        await repos.update(null);
        fail("exception not thrown");
      } on Exception catch (e) {
        expect(e.toString(), "Exception: Object is null");
      }
    });

    test("Update non existed, should throw exception", () async {
      var unitId = Uuid().toString();
      var nonExisted =
          new QuickAccess(favorite: true, unitId: unitId, username: "tala1@akvagroup.com", frequency: 190);
      int affectedNum = await repos.update(nonExisted);
      expect(affectedNum, 0);

      nonExisted.frequency = null;
    });

    test("Update with username is null, should throw exception", () async {
      try {
        var unitId = Uuid().toString();
        var invalid = new QuickAccess(username: "tala@akvagroup.com", unitId: unitId, frequency: 100, favorite: true);
        invalid.username = null;

        await repos.update(invalid);
        fail("exception not thrown");
      } on Exception catch (e) {
        expect(e.toString(), "Exception: Username is required");
      }
    });

    test("Update with username is null, should throw exception", () async {
      try {
        var unitId = Uuid().toString();
        var invalid = new QuickAccess(username: "tala@akvagroup.com", unitId: unitId, frequency: 100, favorite: true);
        invalid.unitId = null;

        await repos.update(invalid);
        fail("exception not thrown");
      } on Exception catch (e) {
        expect(e.toString(), "Exception: UnitId is required");
      }
    });
  });
}

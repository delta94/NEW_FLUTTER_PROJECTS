// skip this file to avoid getting errors when running your unit tests
import 'package:control_app/src/models/culling/culling.dart';
import 'package:control_app/src/models/culling/culling_registration.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/services/timezone_service.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  DBRegistrationRepository repos;
  var siteId = Uuid().v4().toString();
  var unitId = Uuid().v4().toString();
  Registration generateRegistration() {
    var time = DateTime.now();
    return new Registration(
        siteId: siteId,
        unitId: unitId,
        time: time,
        item: CullingRegistration(
          cullings: [
            new Culling(cullingCount: 10, cullingCauseId: 1),
            new Culling(cullingCount: 20, cullingCauseId: 18)
          ],
          resultingStock: ResultingStock(),
        ),
        changeStatus: ChangeStatus.New);
  }

  group("Culling CRUD methods - ", () {
    Unit unit = Unit.fromJson({'id': unitId});
    unit.parent = Site.fromJson({
      'id': siteId,
      'timeZoneId': 'Europe/Oslo',
      'siteName': '',
      'isHidden': true,
      'sitePlacement': '',
      'coordinates': null,
      'units': []
    });

    setUp(() async {
      print("setUp run");
      repos = new DBRegistrationRepository(RegistrationType.Culling);
      await TimeZoneService().setup();
    });

    // Delete the database so every test run starts with a fresh database
    tearDown(() async {
      print("tearDown run");
      var registrations = await repos.fetchBySite(siteId: siteId);
      if (registrations != null) {
        await repos.deleteMultiple(registrations);
      }
    });

    test("Test Store & fetchByUnit", () async {
      var registration = generateRegistration();
      registration.time = TimeZoneService.convertToTimezone(
          registration.time, (unit.parent as Site).timeZoneId);
      var cullingData = (registration.item as CullingRegistration);
      expect(cullingData.resultingStock.individCount, isNull);
      expect(cullingData.cullings.isNotEmpty, true);
      await repos.store(registration);
      expect(registration.rowId, isNotNull);

      var registrations = await repos.fetchByUnit(unit);
      expect(registrations.length, 1);
      var inserted = registrations
          .firstWhere((element) => element.rowId == registration.rowId);

      expect(inserted.siteId, registration.siteId);
      expect(inserted.unitId, registration.unitId);
      expect(inserted.time.year, registration.time.year);
      expect(inserted.time.month, registration.time.month);
      expect(inserted.time.day, registration.time.day);
      expect(inserted.time.hour, registration.time.hour);
      expect(inserted.time.minute, registration.time.minute);
      expect(inserted.time.second, registration.time.second);

      cullingData = inserted.item as CullingRegistration;
      expect(cullingData.cullings.length, 2);
      expect(cullingData.resultingStock, isNotNull);
      expect(cullingData.resultingStock.individCount, isNull);
    });

    test("Test saveChanges & delete", () async {
      var registration = generateRegistration();
      registration.time = TimeZoneService.convertToTimezone(
          registration.time, (unit.parent as Site).timeZoneId);
      await repos.store(registration);
      var registrations = await repos.fetchByUnit(unit);
      expect(registrations.isNotEmpty, true);
      registration = registrations[0];
      expect(registration.changeStatus, ChangeStatus.New);
      var cullingRegistration = (registration.item as CullingRegistration);
      cullingRegistration.updateItem(1, 30);
      await repos.saveChanges(registrations);
      registrations = await repos.fetchByUnit(unit);
      expect(registrations.isNotEmpty, true);
      registration = registrations[0];
      expect(cullingRegistration.resultingStock.individCount, isNull);
      await repos.delete(registration);
      registrations = await repos.fetchByUnit(unit);
      expect(registrations.isEmpty, true);
    });
  });
}

// skip this file to avoid getting errors when running your unit tests
@Skip("sqflite cannot run on the machine.")
import 'package:control_app/src/models/mortality/mortality.dart';
import 'package:control_app/src/models/mortality/mortality_registration.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter_test/flutter_test.dart';

DBRegistrationRepository repos;
List<Registration> addedList;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  Registration generateRegistration({String siteId}) {
      var mortalites = List<Mortality>();
      mortalites.add(new Mortality(mortalityCount: 10, mortalityCauseId: 1));
      mortalites.add(new Mortality(mortalityCount: 20, mortalityCauseId: 18));
      mortalites.add(new Mortality(mortalityCount: 30, mortalityCauseId: 20));
      mortalites.add(new Mortality(mortalityCount: 40, mortalityCauseId: 22));
      var uuid = Uuid();
      var siteId1 = siteId == null ? uuid.v4().toString() : siteId;

      var unitId = uuid.v4().toString();
      var time = DateTime.now();
      return new Registration(
          siteId: siteId1,
          unitId: unitId,
          time: time,
          item: MortalityRegistration(
              hasCheckedForMortality: true,
              missedMortalityReasonId: -1,
              mortalities: mortalites),
          changeStatus: ChangeStatus.New);
    }
  group("DBRegistrationRepository.Store method - ", () {
    var addedList = new List<Registration>();
    setUp(() async {
      repos = new DBRegistrationRepository(RegistrationType.Mortality);
    });

    // Delete the database so every test run starts with a fresh database
    tearDownAll(() async {
      if (addedList.length > 0) {
        repos.deleteMultiple(addedList);
      }
    });

    test("Store new Mortality Registration, should store succesfully",
        () async {

      var registration = generateRegistration();
      await repos.store(registration);

      addedList.add(registration);

      expect(registration.rowId, isNotNull);

      var registrationList = await repos.fetchBySite(siteId: registration.siteId);

      var inserted = registrationList
          .firstWhere((element) => element.rowId == registration.rowId);

      expect(inserted.siteId, registration.siteId);
      expect(inserted.unitId, registration.unitId);
      expect(inserted.time.year, registration.time.year);
      expect(inserted.time.month, registration.time.month);
      expect(inserted.time.day, registration.time.day);
      expect(inserted.time.hour, registration.time.hour);
      expect(inserted.time.minute, registration.time.minute);
      expect(inserted.time.second, registration.time.second);

      var insertedMortalityRegistration =
          inserted.item as MortalityRegistration;
      expect(insertedMortalityRegistration, isNotNull);

      (registration.item as MortalityRegistration).mortalities.forEach((element) {
        expect(
            insertedMortalityRegistration.mortalities.contains(element), true);
      });
    });
  });

  group("DBRegistrationRepository.fetchBySite method - ", () {
    var addedList = new List<Registration>();

    setUp(() async {
      repos = new DBRegistrationRepository(RegistrationType.Mortality);
    });

    // Delete the database so every test run starts with a fresh database
    tearDownAll(() async {
      if (addedList.length > 0) {
        repos.deleteMultiple(addedList);
      }
    });

    test("fetch all site", () async {
      var reg1 = generateRegistration();
      var reg2 = generateRegistration();

      await repos.store(reg1);
      await repos.store(reg2);

      addedList.add(reg1);
      addedList.add(reg2);

      var regList = await repos.fetchBySite();

      var inserted1 = regList.firstWhere((x) => x.siteId == reg1.siteId);
      var inserted2 = regList.firstWhere((x) => x.siteId == reg2.siteId);

      expect(regList.length, greaterThanOrEqualTo(2));

      expect(inserted1, isNotNull);
      expect(inserted2, isNotNull);
    });

    test("fetch by siteId only", () async {
      var reg1 = generateRegistration();
      var reg2 = generateRegistration();
      var reg3 = generateRegistration();
      var reg4 = generateRegistration();

      var regs = List<Registration>();

      regs.add(reg1);
      regs.add(reg2);
      regs.add(reg3);
      regs.add(reg4);

      await repos.storeMultiple(regs);

      addedList.addAll(regs);

      var regList = await repos.fetchBySite(
          siteId: reg2.siteId);

      var inserted2 = regList.firstWhere((x) => x.siteId == reg2.siteId);
      
      expect(regList.length, 1);

      expect(inserted2, isNotNull);

    });

    test("with arguments siteId, date", () async {
      var today = DateTime.now();
      var reg1 = generateRegistration();

      var uuid = Uuid();
      var siteId = uuid.v4();
      var reg2 = generateRegistration(siteId: siteId);
      var reg3 = generateRegistration(siteId: siteId);

      var reg4 = generateRegistration();

      var datetime1 = today.add(Duration(days: 1));
      var datetime2 = today.add(Duration(days: 2));
      var datetime3 = today.add(Duration(days: 3));
      var datetime4 = today.add(Duration(days: 4));

      reg1.time = datetime1;
      reg2.time = datetime2;
      reg3.time = datetime3;
      reg4.time = datetime4;

      var regs = List<Registration>();

      regs.add(reg1);
      regs.add(reg2);
      regs.add(reg3);
      regs.add(reg4);

      await repos.storeMultiple(regs);

      addedList.addAll(regs);

      var regList = await repos.fetchBySite(
          siteId: reg4.siteId, date: reg4.time);

      var inserted4 = regList.firstWhere((x) => x.siteId == reg4.siteId);

      expect(regList.length, greaterThanOrEqualTo(1));

      expect(inserted4, isNotNull);
    });

    test("with arguments with date only", () async {
      var today = DateTime.now();
      var reg1 = generateRegistration();

      var reg2 = generateRegistration();
      var reg3 = generateRegistration();
      var reg4 = generateRegistration();

      var datetime1 = today.add(Duration(days: 1));
      var datetime2 = today.add(Duration(days: 2));
      var datetime3 = today.add(Duration(days: 3));
      var datetime4 = today.add(Duration(days: 4));

      reg1.time = datetime1;
      reg2.time = datetime2;
      reg3.time = datetime3;
      reg4.time = datetime4;

      var regs = List<Registration>();

      regs.add(reg1);
      regs.add(reg2);
      regs.add(reg3);
      regs.add(reg4);

      await repos.storeMultiple(regs);

      addedList.addAll(regs);

      var regList =
          await repos.fetchBySite(date: reg3.time);

      var inserted3 = regList.firstWhere((x) => x.siteId == reg3.siteId);

      expect(regList.length, greaterThanOrEqualTo(1));

      expect(inserted3, isNotNull);
    });
  });
}

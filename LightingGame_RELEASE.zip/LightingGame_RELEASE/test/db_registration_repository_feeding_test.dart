// skip this file to avoid getting errors when running your unit tests
import 'package:control_app/src/models/feeding/feeding.dart';
import 'package:control_app/src/models/feeding/feeding_registration.dart';
@Skip("sqflite cannot run on the machine.")
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/services/timezone_service.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter_test/flutter_test.dart';

DBRegistrationRepository repos;
List<Registration> addedList;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  Registration generateRegistration({String siteId}) {
    var feedings = List<Feeding>();
    var uuid = Uuid();
    var fakeUid = uuid.v4().toString();
    feedings.add(
        new Feeding(feedTypeId: 1, feedStoreId: fakeUid, feedAmountKg: 1000));
    feedings.add(
        new Feeding(feedTypeId: 2, feedStoreId: fakeUid, feedAmountKg: 100));

    var siteId1 = siteId != null ? siteId : uuid.v4().toString();

    var unitId = uuid.v4().toString();
    var time = DateTime.now();
    return new Registration(
        siteId: siteId1,
        unitId: unitId,
        time: time,
        item:
            FeedingRegistration(missedFeedingReasonId: -1, feedings: feedings),
        changeStatus: ChangeStatus.New);
  }

  group("Feeding Repository. Store method - ", () {
    var addedList = new List<Registration>();
    setUp(() async {
      repos = new DBRegistrationRepository(RegistrationType.Feeding);
    });

    // Delete the database so every test run starts with a fresh database
    tearDownAll(() async {
      if (addedList.length > 0) {
        repos.deleteMultiple(addedList);
      }
    });

    test("Store new Feeding Registration", () async {
      var registration = generateRegistration();
      await repos.store(registration);

      addedList.add(registration);

      expect(registration.rowId, isNotNull);

      var registrationList =
          await repos.fetchBySite(siteId: registration.siteId);

      var inserted = registrationList
          .firstWhere((element) => element.rowId == registration.rowId);

      expect(inserted.siteId, registration.siteId);
      expect(inserted.unitId, registration.unitId);
      expect(inserted.time.year, registration.time.year);
      expect(inserted.time.month, registration.time.month);
      expect(inserted.time.day, registration.time.day);
      expect(inserted.time.hour, registration.time.hour);
      expect(inserted.time.minute, registration.time.minute);
      expect(inserted.time.second, registration.time.second);

      var insertedFeedingRegistration = inserted.item as FeedingRegistration;
      expect(insertedFeedingRegistration, isNotNull);

      (registration.item as FeedingRegistration).feedings.forEach((element) {
        expect(insertedFeedingRegistration.feedings.contains(element), true);
      });
    });
  });

  group("Feeding Repository. fetchByUnit method - ", () {
    var addedList = new List<Registration>();
    setUp(() async {
      repos = new DBRegistrationRepository(RegistrationType.Feeding);
    });

    // Delete the database so every test run starts with a fresh database
    tearDownAll(() async {
      if (addedList.length > 0) {
        repos.deleteMultiple(addedList);
      }
    });

    test("Fetch feeding by Unit", () async {
      var reg1 = generateRegistration();
      await repos.store(reg1);
      var reg2 = generateRegistration();
      await repos.store(reg2);
      addedList.add(reg2);

      expect(reg1.rowId, isNotNull);
      expect(reg2.rowId, isNotNull);
      Unit unit = Unit.fromJson({'id': reg1.unitId});
      unit.parent =
          Site.fromJson({'id': reg1.siteId, 'timeZoneId': 'Europe/Oslo', 'siteName': '', 'isHidden': true, 'sitePlacement': '', 'coordinates': null, 'units': []});
      await TimeZoneService().setup();
      var regs = await repos.fetchByUnit(unit);
      expect(regs.isNotEmpty, true);
      var inserted = regs.firstWhere((element) => element.rowId == reg1.rowId);

      expect(inserted.item is FeedingRegistration, true);
      expect((inserted.item as FeedingRegistration).feedings.length, 2);
    });
  });

  group("Feeding Repository. update method - ", () {
    var addedList = new List<Registration>();

    setUp(() async {
      repos = new DBRegistrationRepository(RegistrationType.Feeding);
    });

    // Delete the database so every test run starts with a fresh database
    tearDownAll(() async {
      if (addedList.length > 0) {
        repos.deleteMultiple(addedList);
      }
    });

    test("update method", () async {
      var reg = generateRegistration();

      await repos.store(reg);
      expect(reg.rowId, isNotNull);
      addedList.add(reg);

      (reg.item as FeedingRegistration).feedings.removeLast();
      var result = await repos.update(reg);
      expect(result, true);
      Unit unit = Unit.fromJson({'id': reg.unitId});
      unit.parent =
          Site.fromJson({'id': reg.siteId, 'timeZoneId': 'Europe/Oslo', 'siteName': '', 'isHidden': true, 'sitePlacement': '', 'coordinates': null, 'units': []});
      await TimeZoneService().setup();
      var regs = await repos.fetchByUnit(unit);
      var inserted =
          regs.firstWhere((x) => x.rowId == reg.rowId, orElse: () => null);

      expect(inserted, isNotNull);
      //expect((inserted.item as FeedingRegistration).feedings.length, 1);
    });
  });

  group("Feeding Repository. fetchBySite method - ", () {
    var addedList = new List<Registration>();

    setUp(() async {
      repos = new DBRegistrationRepository(RegistrationType.Feeding);
    });

    // Delete the database so every test run starts with a fresh database
    tearDownAll(() async {
      if (addedList.length > 0) {
        repos.deleteMultiple(addedList);
      }
    });
    test("fetch by siteId only", () async {
      var reg1 = generateRegistration();
      var reg2 = generateRegistration();
      var reg3 = generateRegistration();
      var reg4 = generateRegistration();

      var regs = List<Registration>();

      regs.add(reg1);
      regs.add(reg2);
      regs.add(reg3);
      regs.add(reg4);

      await repos.storeMultiple(regs);

      addedList.addAll(regs);

      var regList = await repos.fetchBySite(siteId: reg2.siteId);

      var inserted2 = regList.firstWhere((x) => x.siteId == reg2.siteId,
          orElse: () => null);

      expect(regList.length, 1);

      expect(inserted2, isNotNull);
    });

    test("with arguments siteId, date", () async {
      var today = DateTime.now();
      var reg1 = generateRegistration();

      var uuid = Uuid();
      var siteId = uuid.v4().toString();
      var reg2 = generateRegistration(siteId: siteId);
      var reg3 = generateRegistration(siteId: siteId);
      expect(reg2.siteId, reg3.siteId);
      var reg4 = generateRegistration();

      var datetime1 = today.add(Duration(days: 1));
      var datetime2 = today.add(Duration(days: 2));
      var datetime3 = today.add(Duration(days: 3));
      var datetime4 = today.add(Duration(days: 4));

      reg1.time = datetime1;
      reg2.time = datetime2;
      reg3.time = datetime3;
      reg4.time = datetime4;

      var regs = List<Registration>();

      regs.add(reg1);
      regs.add(reg2);
      regs.add(reg3);
      regs.add(reg4);

      await repos.storeMultiple(regs);

      addedList.addAll(regs);

      var regList = await repos.fetchBySite(siteId: reg2.siteId, date: reg2.time);

      expect(regList.length, greaterThanOrEqualTo(1));

      var inserted2 = regList.firstWhere((x) => x.siteId == siteId);

      expect(inserted2, isNotNull);
    });

    test("with arguments are date", () async {
      var today = DateTime.now();
      var reg1 = generateRegistration();

      var reg2 = generateRegistration();
      var reg3 = generateRegistration();
      var reg4 = generateRegistration();

      var datetime1 = today.add(Duration(days: 1));
      var datetime2 = today.add(Duration(days: 2));
      var datetime3 = today.add(Duration(days: 3));
      var datetime4 = today.add(Duration(days: 4));

      reg1.time = datetime1;
      reg2.time = datetime2;
      reg3.time = datetime3;
      reg4.time = datetime4;

      var regs = List<Registration>();

      regs.add(reg1);
      regs.add(reg2);
      regs.add(reg3);
      regs.add(reg4);

      await repos.storeMultiple(regs);

      addedList.addAll(regs);

      var regList =
          await repos.fetchBySite(date: datetime2);

      var inserted2 = regList.firstWhere((x) => x.siteId == reg2.siteId);
      
      expect(regList.length, greaterThanOrEqualTo(1));

      expect(inserted2, isNotNull);
    });
  });
}

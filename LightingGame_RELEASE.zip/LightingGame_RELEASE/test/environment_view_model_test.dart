import 'dart:math';

import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/environment/view_models/environment_view_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/models/environment/sensor.dart';
import 'package:control_app/src/models/environment/sensor_reading.dart';
import 'package:control_app/src/models/environment/sensor_type.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:control_app/src/models/lice/lice_type.dart';
import 'package:control_app/src/models/lice/sedation_method.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/models/species.dart';
import 'package:control_app/src/organization/organization_model.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/services/timezone_service.dart';
import 'package:control_app/src/shared_data_model.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import 'mocks/mock_app_model.dart';
import 'mocks/mock_organization_model.dart';
import 'mocks/mock_shared_data_model.dart';

var unitId = Uuid().v4().toString();
var siteId = Uuid().v4().toString();

void main() async {
  TestWidgetsFlutterBinding.ensureInitialized();
  final AppModel appModel = MockAppModel();
  final DBRegistrationRepository repos =
      DBRegistrationRepository(RegistrationType.Environment);
  final _childKey = GlobalKey();

  final organizationModel = MockOrganizationModel();
  final sharedDataModel = MockSharedDataModel();
  Unit unit = Unit.fromJson({'id': unitId, 'name': '12-L'});
  Site site = Site.fromJson({
    'id': siteId,
    'siteName': 'Molkhomen',
    'timeZoneId': 'Europe/Oslo',
    'units': [
      {'id': unitId, 'name': '12-L'}
    ]
  });
  unit.parent = site;

  /// This is to mock the result of currentUnit getter function
  when(organizationModel.currentUnit).thenReturn(unit);

  /// This is to mock the result of currentSite getter function
  when(organizationModel.currentSite).thenReturn(site);
  List<Species> species = [
    Species(speciesId: 1, name: 'Salmon', wrasse: true),
  ];

  when(organizationModel.speciesOfCurrentUnit).thenReturn(species);
  when(sharedDataModel.sensorTypes).thenReturn([
    SensorType(itemId: 1, name: "Oxygen", measUnit: 8),
    SensorType(itemId: 2, name: "Salinity", measUnit: 2),
    SensorType(itemId: 3, name: "Temp", measUnit: 1),
    SensorType(
        itemId: 4,
        name: "Wind direction",
        measUnit: 29,
        valueMap: {1: "East", 2: "West", 3: "South", 4: "North"}),
  ]);
  when(sharedDataModel.sensors).thenReturn([
    Sensor(
        id: Uuid().v4().toString(),
        name: "Sensor 1",
        sensorTypeId: 1,
        disabled: false,
        isAuto: true,
        history: [
          SensorAssignment(
            startTime: DateTime(2020, 7, 28),
            siteId: siteId,
          )
        ]),
    Sensor(
        id: Uuid().v4().toString(),
        name: "Sensor 2",
        sensorTypeId: 2,
        disabled: false,
        isAuto: false,
        history: [
          SensorAssignment(
            startTime: DateTime(2020, 7, 28),
            siteId: siteId,
          )
        ]),
    Sensor(
        id: Uuid().v4().toString(),
        name: "Sensor 3",
        sensorTypeId: 3,
        disabled: false,
        isAuto: false,
        history: [
          SensorAssignment(
            startTime: DateTime(2020, 7, 28),
            siteId: siteId,
            sensorGroupId: Uuid().v4().toString(),
            departmentId: Uuid().v4().toString(),
            unitId: Uuid().v4().toString(),
          )
        ]),
    Sensor(
        id: Uuid().v4().toString(),
        name: "Sensor 4",
        sensorTypeId: 4,
        disabled: false,
        isAuto: false,
        history: [
          SensorAssignment(
            startTime: DateTime(2020, 7, 28),
            siteId: siteId,
            sensorGroupId: Uuid().v4().toString(),
            departmentId: Uuid().v4().toString(),
            unitId: unitId,
          )
        ]),
  ]);

  when(sharedDataModel.manualActiveSensors).thenReturn([
    Sensor(
        id: Uuid().v4().toString(),
        name: "Sensor 2",
        sensorTypeId: 2,
        disabled: false,
        isAuto: false,
        history: [
          SensorAssignment(
            startTime: DateTime(2020, 7, 28),
            siteId: siteId,
          )
        ]),
    Sensor(
        id: Uuid().v4().toString(),
        name: "Sensor 3",
        sensorTypeId: 3,
        disabled: false,
        isAuto: false,
        history: [
          SensorAssignment(
            startTime: DateTime(2020, 7, 28),
            siteId: siteId,
            sensorGroupId: Uuid().v4().toString(),
            departmentId: Uuid().v4().toString(),
            unitId: Uuid().v4().toString(),
          )
        ]),
    Sensor(
        id: Uuid().v4().toString(),
        name: "Sensor 4",
        sensorTypeId: 4,
        disabled: false,
        isAuto: false,
        history: [
          SensorAssignment(
            startTime: DateTime(2020, 7, 28),
            siteId: siteId,
            sensorGroupId: Uuid().v4().toString(),
            departmentId: Uuid().v4().toString(),
            unitId: unitId,
          )
        ]),
  ]);

  Widget makeTestableWidget() {
    return ChangeNotifierProvider<EnvironmentViewModel>(
        create: (_) => EnvironmentViewModel(),
        child: MaterialApp(key: _childKey, home: Container()));
  }

  group('Test Environment View Model', () {
    setUp(() async {
      await appModel.initialize();
    });

    tearDown(() async {
      final registrations = await repos.fetchByUnit(unit);
      if (registrations.isNotEmpty) {
        await repos.deleteMultiple(registrations);
      }
    });
    testWidgets('addNewSensorReading function', (WidgetTester tester) async {
      await tester.pumpWidget(makeTestableWidget());
      final environmentModel = Provider.of<EnvironmentViewModel>(
          _childKey.currentContext,
          listen: false);
      environmentModel.updateDI(appModel, organizationModel, sharedDataModel);
      await TimeZoneService().setup();
      expect(environmentModel, isNot(null));
      environmentModel.addNewSensorReading();
      expect(environmentModel.newRegistrations.length, 2);
    });

    testWidgets('storeRegistration function', (WidgetTester tester) async {
      await tester.pumpWidget(makeTestableWidget());
      final environmentModel = Provider.of<EnvironmentViewModel>(
          _childKey.currentContext,
          listen: false);
      environmentModel.updateDI(appModel, organizationModel, sharedDataModel);
      await TimeZoneService().setup();
      environmentModel.addNewSensorReading();
      environmentModel.newRegistrations.forEach((registration) {
        expect(registration.unitId, unitId);
        expect(registration.siteId, siteId);
        final sensorReading = registration.item as SensorReading;
        sensorReading.reading = Random().nextDouble();
      });
      await environmentModel.storeRegistration();
      await new Future.delayed(const Duration(seconds: 1));
      expect(environmentModel.status, RegistrationStatus.HAVE_REGISTRATION);
      expect(environmentModel.registrations.length, 2);
      environmentModel.registrations.forEach((registration) {
        expect((registration.item as SensorReading).reading, isNot(null));
        expect(registration.changeStatus, ChangeStatus.Unchanged);
        expect(
            (registration.item as SensorReading).measurementUnit, isNot(null));
      });
    });

    testWidgets('Delete a sensor reading', (WidgetTester tester) async {
      await tester.pumpWidget(makeTestableWidget());
      final environmentModel = Provider.of<EnvironmentViewModel>(
          _childKey.currentContext,
          listen: false);
      environmentModel.updateDI(appModel, organizationModel, sharedDataModel);
      await TimeZoneService().setup();
      environmentModel.addNewSensorReading();
      environmentModel.newRegistrations.forEach((registration) {
        expect(registration.unitId, unitId);
        expect(registration.siteId, siteId);
        final sensorReading = registration.item as SensorReading;
        sensorReading.reading = Random().nextDouble();
      });
      await environmentModel.storeRegistration();
      await new Future.delayed(const Duration(seconds: 1));
      await environmentModel.removeCount(environmentModel.registrations[0].time,
          null, environmentModel.registrations[0]);
      await new Future.delayed(const Duration(seconds: 1));
      expect(environmentModel.status, RegistrationStatus.HAVE_REGISTRATION);
      expect(environmentModel.registrations.length, 1);
    });

    testWidgets('Delete a list of sensor reading', (WidgetTester tester) async {
      await tester.pumpWidget(makeTestableWidget());
      final environmentModel = Provider.of<EnvironmentViewModel>(
          _childKey.currentContext,
          listen: false);
      environmentModel.updateDI(appModel, organizationModel, sharedDataModel);
      await TimeZoneService().setup();
      environmentModel.addNewSensorReading();
      environmentModel.newRegistrations.forEach((registration) {
        expect(registration.unitId, unitId);
        expect(registration.siteId, siteId);
        final sensorReading = registration.item as SensorReading;
        sensorReading.reading = Random().nextDouble();
      });
      await environmentModel.storeRegistration();
      await new Future.delayed(const Duration(seconds: 1));
      await environmentModel
          .removeRegistration(environmentModel.registrations[0].time);
      await new Future.delayed(const Duration(seconds: 1));
      expect(environmentModel.status, RegistrationStatus.NO_REGISTRATION);
      expect(environmentModel.registrations.length, 0);
    });
  });
}

import 'package:control_app/src/shared_data_model.dart';

/// Using mockito package to mock or stub the result of other functions
import 'package:mockito/mockito.dart';

/// Using Mock class of mockito package to mock up SharedDataModel
/// For reference about how to write unit test using mockito, you can
/// check the tutorial https://morioh.com/p/0a4df7df0798
class MockSharedDataModel extends Mock implements SharedDataModel {}
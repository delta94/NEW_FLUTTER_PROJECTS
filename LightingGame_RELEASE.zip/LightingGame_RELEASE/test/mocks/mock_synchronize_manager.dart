import 'dart:async';

import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:data_connection_checker/data_connection_checker.dart';
import 'package:mockito/mockito.dart';
import 'package:control_app/src/sync/synchronize_manager.dart';
import 'package:control_app/src/sync/registration_synchronize_helper.dart';
import 'package:uuid/uuid.dart';

class MockSynchronizeManager extends Mock implements SynchronizeManager {
  final StreamController<RegistrationType> _syncStreamController = new StreamController.broadcast();
  @override
  DataConnectionStatus connectionStatus;
  @override
  Stream<RegistrationType> get syncStream => _syncStreamController.stream;
  @override
  Future syncByType(RegistrationType type) async {
    if (connectionStatus == DataConnectionStatus.connected) {
      print("SYNC: ========== Start to sync by type: $type");
      await new MockRegistrationSynchronizeHelper(type).sync();
      _syncStreamController.add(type);
    } else {
      print(
          "SYNC: ========== Sync cannot Start due to Network connection is NOT available.");
    }
  }
}

class MockRegistrationSynchronizeHelper extends Mock implements RegistrationSynchronizeHelper {
  DBRegistrationRepository _dbRepository;
  RegistrationType type;
  MockRegistrationSynchronizeHelper(RegistrationType type) : this.type = type{
    _dbRepository = new DBRegistrationRepository(type);
  }

  @override
  Future sync() async {
    List<Registration> registrations = await _dbRepository.fetchBySite();

    if (registrations != null && registrations.length > 0) {
      print("SYNC: ========== $type Synchronization in progress");


    final inserts = registrations.where((x) {
      return x.changeStatus == ChangeStatus.New;
    }).toList();
    if (inserts.isNotEmpty) {
      inserts.forEach((registration){
        registration.changeStatus = ChangeStatus.Unchanged;
        registration.id = Uuid().v4().toString();
      } );
    }
    final updates = registrations.where((x) {
      return x.changeStatus == ChangeStatus.Changed;
    }).toList();

    if (updates.isNotEmpty) {
      updates.forEach((registration){
        registration.changeStatus = ChangeStatus.Unchanged;
      } );
    }
    final deletes = registrations.where((x) {
      return x.changeStatus == ChangeStatus.Deleted;
    }).toList();

    if (deletes.length > 0) {
      _dbRepository.deleteMultiple(deletes);
    }

    var updateList = registrations
      .where((x) => x.changeStatus != ChangeStatus.Deleted)
      .toList();

    if (updateList.length > 0) {
      _dbRepository.updateMultiple(updateList);
    }


      print("SYNC: ========== $type Synchronization DONE.");
    }

    return;
  }
}
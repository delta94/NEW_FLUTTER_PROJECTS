import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/sync/synchronize_manager.dart';
import 'package:data_connection_checker/data_connection_checker.dart';

/// Using mockito package to mock or stub the result of other functions
import 'package:mockito/mockito.dart';

import 'mock_synchronize_manager.dart';

/// Mockup app model
class MockAppModel extends Mock implements AppModel {
  @override
  DataConnectionStatus connectionStatus;
  @override
  SynchronizeManager synchronizeManager;
  @override
  Future initialize() async {
    setBusy(true);
    synchronizeManager = new MockSynchronizeManager();
    print(synchronizeManager);
    connectionStatus = await DataConnectionChecker().connectionStatus;
    print("connectionStatus = $connectionStatus");
    synchronizeManager.connectionStatus = connectionStatus;
    setBusy(false);
  }
}

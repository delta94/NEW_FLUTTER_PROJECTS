import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/lice/view_model/lice_sample_view_model.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
import 'package:control_app/src/models/lice/lice_type.dart';
import 'package:control_app/src/models/lice/sedation_method.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/models/species.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/services/timezone_service.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import 'mocks/mock_app_model.dart';
import 'mocks/mock_organization_model.dart';
import 'mocks/mock_shared_data_model.dart';

var unitId = Uuid().v4().toString();
var siteId = Uuid().v4().toString();

void main() async {
  TestWidgetsFlutterBinding.ensureInitialized();
  final AppModel appModel = MockAppModel();
  final DBRegistrationRepository repos =
      DBRegistrationRepository(RegistrationType.Lice);
  final _childKey = GlobalKey();

  MockOrganizationModel organizationModel = MockOrganizationModel();
  MockSharedDataModel sharedDataModel = MockSharedDataModel();
  Unit unit = Unit.fromJson({'id': unitId, 'name': '12-L'});
  Site site = Site.fromJson({
    'id': siteId,
    'siteName': 'Molkhomen',
    'timeZoneId': 'Europe/Oslo',
    'units': [
      {'id': unitId, 'name': '12-L'}
    ]
  });
  unit.parent = site;

  /// This is to mock the result of currentUnit getter function
  when(organizationModel.currentUnit).thenReturn(unit);

  /// This is to mock the result of currentSite getter function
  when(organizationModel.currentSite).thenReturn(site);
  List<Species> species = [
    Species(speciesId: 1, name: 'Salmon', wrasse: true),
    Species(speciesId: 18, name: 'Cleaner Fish 1', wrasse: false)
  ];

  when(organizationModel.speciesOfCurrentUnit).thenReturn(species);
  when(sharedDataModel.liceTypes).thenReturn([
    LiceType(itemId: 1, name: "Adult female lepo"),
    LiceType(itemId: 2, name: "Juveniles undefined"),
    LiceType(itemId: 3, name: "Mobile lepo lice"),
    LiceType(itemId: 4, name: "Lepo lice"),
    LiceType(itemId: 5, name: "Calligus all stages"),
  ]);
  when(sharedDataModel.sedationMethods).thenReturn([
    SedationMethod(
        itemId: 202, name: "ABC", withdrawal: Withdrawal(atus: 1, days: 1)),
    SedationMethod(
        itemId: 203,
        name: "XYZ",
        withdrawal: Withdrawal(atus: 2, days: 2, and: false)),
  ]);

  Widget makeTestableWidget() {
    return ChangeNotifierProvider<LiceSampleViewModel>(
      create: (_) => LiceSampleViewModel(),
      child: MaterialApp(key: _childKey, home: Container()),
    );
  }

  group('Test LiceSampleViewModel', () {
    setUp(() async {
      await appModel.initialize();
    });

    tearDown(() async {
      final registrations = await repos.fetchByUnit(unit);
      if (registrations.isNotEmpty) {
        await repos.deleteMultiple(registrations);
      }
    });
    testWidgets('addNewRegistration function', (WidgetTester tester) async {
      await tester.pumpWidget(makeTestableWidget());
      var liceSampleViewModel = Provider.of<LiceSampleViewModel>(
          _childKey.currentContext,
          listen: false);
      expect(liceSampleViewModel, isNot(null));

      liceSampleViewModel.updateDependencies(
          appModel, organizationModel, sharedDataModel);
      await TimeZoneService().setup();
      liceSampleViewModel.addNewLiceSample();
      expect(liceSampleViewModel.currentLiceSample, isNot(null));

      liceSampleViewModel.updateSedationMethod(202);
      var liceSample = liceSampleViewModel.currentLiceSample.item as LiceSample;
      expect(liceSample.medicamentId, 202);
      expect(liceSample.overrideWithdrawal, false);
      expect(liceSample.withdrawal,
          equals(sharedDataModel.sedationMethods[0].withdrawal));
      liceSampleViewModel.updateOverrideWithdrawal();
      liceSample = liceSampleViewModel.currentLiceSample.item as LiceSample;
      expect(liceSample.overrideWithdrawal, true);

      expect(liceSample.samples.length, 1);
      liceSampleViewModel.addNewSample();
      liceSampleViewModel.addNewSample();
      expect(liceSample.samples[0].measureId, 1);
      expect(liceSample.samples[1].measureId, 2);
      expect(liceSample.samples[2].measureId, -1);
    });
  });
}

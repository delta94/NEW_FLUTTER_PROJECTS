// skip this file to avoid getting errors when running your unit tests
import 'package:control_app/src/models/environment/sensor_reading.dart';
import 'package:control_app/src/models/lice/lice_sample.dart';
@Skip("sqflite cannot run on the machine.")
import 'package:control_app/src/models/mortality/mortality.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/registration_factory.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter_test/flutter_test.dart';

DBRegistrationRepository repos;
List<Registration> addedList;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  List<Registration> registrations = <Registration>[];
  void generateRegistrations() {
    var uuid = Uuid();
    var siteId = uuid.v4().toString();

    var unitId = uuid.v4().toString();

    var time = DateTime.now();
    for (int i = 1; i <= 10; i++) {
      registrations.add(Registration(
          siteId: siteId,
          unitId: unitId,
          time: time,
          changeStatus: ChangeStatus.New,
          item: SensorReading(
              sensorId: "sensor$i",
              sensorTypeId: i,
              reading: i.toDouble(),
              depth: i.toDouble())));
    }
  }

  generateRegistrations();
  group("Testing environment operations ", () {
    setUp(() async {
      repos = new DBRegistrationRepository(RegistrationType.Environment);
    });

    // Delete the database so every test run starts with a fresh database
    tearDownAll(() async {
      repos.deleteMultiple(registrations);
    });

    test("Store new environment, should store succesfully", () async {
      await repos.saveChanges(registrations);
      registrations.forEach((registration) {
        expect(registration.rowId, isNotNull);
      });

      var registrationList =
          await repos.fetchBySite(siteId: registrations[0].siteId);
      expect(registrationList.length, 10);
      for (int i = 0; i < registrationList.length; i++) {
        expect(registrationList[i].siteId, registrations[i].siteId);
        expect(registrationList[i].unitId, registrations[i].unitId);
        expect(registrationList[i].time.year, registrations[i].time.year);
        expect(registrationList[i].time.month, registrations[i].time.month);
        expect(registrationList[i].time.day, registrations[i].time.day);
        expect(registrationList[i].time.hour, registrations[i].time.hour);
        expect(registrationList[i].time.minute, registrations[i].time.minute);
        expect(registrationList[i].time.second, registrations[i].time.second);

        var sensorReading = registrationList[i].item as SensorReading;
        expect(sensorReading, isNotNull);
        var sensorReadingActual = registrations[i].item as SensorReading;
        expect(sensorReading.sensorId, sensorReadingActual.sensorId);
        expect(sensorReading.sensorTypeId, sensorReadingActual.sensorTypeId);
        expect(sensorReading.depth, sensorReadingActual.depth);
        expect(sensorReading.reading, sensorReadingActual.reading);
      }
    });
  });
}

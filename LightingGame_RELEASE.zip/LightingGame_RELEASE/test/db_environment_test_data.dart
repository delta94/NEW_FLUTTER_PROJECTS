import 'package:control_app/src/models/environment/sensor_reading.dart';
import 'package:control_app/src/models/environment/sensor_type.dart';
@Skip("sqflite cannot run on the machine.")
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/services/shared_data_service.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:flutter_test/flutter_test.dart';

DBRegistrationRepository repos;
List<Registration> addedList;

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  List<Registration> registrations = <Registration>[];
  void generateRegistrations() async {
    var shareService = SharedDataService();
    var sensors = await shareService.loadAllSensorsFromDB();
    var sensorTypes = await shareService.loadAllSensorTypesFromDB();
    
    var enSensorType = sensorTypes.values.elementAt(0);
   
    var time = DateTime.now();
    for (int i = 0; i < sensors.length; i++) {
      if (sensors[i].history != null && sensors[i].history.length > 0) {
        for (int j = 0; j < sensors[i].history.length; j++) {
          if (sensors[i].history[j].endTime == null) {
            var ssType = enSensorType.firstWhere(
                (element) => element.itemId == sensors[i].sensorTypeId,
                orElse: () => null);

            registrations.add(Registration(
                siteId: sensors[i].history[j].siteId,
                unitId: sensors[i].history[j].unitId,
                time: time,
                changeStatus: ChangeStatus.New,
                item: SensorReading(
                    sensorId: sensors[i].id,
                    sensorTypeId: sensors[i].sensorTypeId,
                    reading: ssType.measUnit == MeasurementUnit.ValueMap
                        ? ssType.valueMap.keys.elementAt(0).toDouble()
                        : (i + j + 2).toDouble(),
                    depth: (i + 1).toDouble())));
          }
        }
      }
    }

    var repos = new DBRegistrationRepository(RegistrationType.Environment);
    await repos.saveChanges(registrations);

    print("Create data successfully");
  }

  generateRegistrations();

  group("Create environment data", () {});
}

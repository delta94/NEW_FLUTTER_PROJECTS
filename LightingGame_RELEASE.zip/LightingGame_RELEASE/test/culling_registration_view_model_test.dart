import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/base_view_model.dart';
import 'package:control_app/src/culling/view_models/cleaner_fish_culling_registration_view_model.dart';
import 'package:control_app/src/culling/view_models/culling_registration_view_model.dart';
import 'package:control_app/src/culling/view_models/salmon_culling_registration_view_model.dart';
import 'package:control_app/src/models/culling/culling.dart';
import 'package:control_app/src/models/culling/culling_registration.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/models/species.dart';
import 'package:control_app/src/models/unit_status.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/services/timezone_service.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import 'mocks/mock_app_model.dart';
import 'mocks/mock_organization_model.dart';

var unitId = Uuid().v4().toString();
var siteId = Uuid().v4().toString();

void main() async {
  TestWidgetsFlutterBinding.ensureInitialized();
  final AppModel appModel = MockAppModel();
  final DBRegistrationRepository repos =
      DBRegistrationRepository(RegistrationType.Culling);
  final _childKey = GlobalKey();

  Registration generateRegistration() {
    var cullings = List<Culling>();
    cullings.add(new Culling(cullingCount: 10, cullingCauseId: 1));
    cullings.add(new Culling(cullingCount: 20, cullingCauseId: 18));
    var time = DateTime.now();
    return new Registration(
        siteId: siteId,
        unitId: unitId,
        speciesId: 1,
        time: time,
        item: CullingRegistration(
          cullings: cullings,
          resultingStock: ResultingStock(),
        ),
        changeStatus: ChangeStatus.New);
  }

  var registration = generateRegistration();

  MockOrganizationModel organizationModel = MockOrganizationModel();
  Unit unit = Unit.fromJson({'id': unitId, 'name': '12-L'});
  Site site = Site.fromJson({
    'id': siteId,
    'siteName': 'Molkhomen',
    'timeZoneId': 'Europe/Oslo',
    'units': [
      {'id': unitId, 'name': '12-L'}
    ]
  });
  unit.parent = site;

  /// This is to mock the result of currentUnit getter function
  when(organizationModel.currentUnit).thenReturn(unit);

  /// This is to mock the result of currentSite getter function
  when(organizationModel.currentSite).thenReturn(site);
  List<Species> species = [
    Species(speciesId: 1, name: 'Salmon', wrasse: true),
    Species(speciesId: 18, name: 'Cleaner Fish 1', wrasse: false)
  ];

  when(organizationModel.speciesOfCurrentUnit).thenReturn(species);
  when(organizationModel.unitStatus).thenReturn(UnitStatus(stockNo: 1000));
  Widget makeTestableWidget(CullingRegistrationViewModel model) {
    if (model is SalmonCullingRegistrationViewModel) {
      return ChangeNotifierProvider<SalmonCullingRegistrationViewModel>(
        create: (_) => SalmonCullingRegistrationViewModel(),
        child: MaterialApp(key: _childKey, home: Container()),
      );
    } else {
      return ChangeNotifierProvider<CleanerFishCullingRegistrationViewModel>(
        create: (_) => CleanerFishCullingRegistrationViewModel(),
        child: MaterialApp(key: _childKey, home: Container()),
      );
    }
  }

  group('Cullingtest initRegistration and addNewRegistration', () {
    setUp(() async {
      print("Setup test initRegistrationInfo");
      await repos.store(registration);
      await appModel.initialize();
    });

    tearDown(() async {
      print("Tear down initRegistrationInfo");
      final registrations = await repos.fetchByUnit(unit);
      if (registrations.isNotEmpty) {
        await repos.deleteMultiple(registrations);
      }
    });
    testWidgets('addNewRegistration function', (WidgetTester tester) async {
      await tester
          .pumpWidget(makeTestableWidget(SalmonCullingRegistrationViewModel()));
      var registrationViewModel =
          Provider.of<SalmonCullingRegistrationViewModel>(
              _childKey.currentContext,
              listen: false);
      expect(registrationViewModel, isNot(null));

      registrationViewModel.updateModel(appModel, organizationModel);
      await TimeZoneService().setup();
      await registrationViewModel.addNewRegistration(1);
      expect(registrationViewModel.registrations.isNotEmpty, true);
      expect(registrationViewModel.registrations.length, 1);
      expect(registrationViewModel.registrations.first.siteId, siteId);
    });

    testWidgets('initRegistrationInfo with existing registration in db',
        (WidgetTester tester) async {
      await tester
          .pumpWidget(makeTestableWidget(SalmonCullingRegistrationViewModel()));
      var registrationViewModel =
          Provider.of<SalmonCullingRegistrationViewModel>(
              _childKey.currentContext,
              listen: false);
      expect(registrationViewModel, isNot(null));
      registrationViewModel.updateModel(appModel, organizationModel);
      expect(registrationViewModel.organizationModel.currentUnit.id, unitId);
      await registrationViewModel.initRegistrationInfo();
      expect(registrationViewModel.registrations.isNotEmpty, true);
      expect(registrationViewModel.registrations.length, 1);
      expect(registrationViewModel.registrations.first.siteId,
          registration.siteId);
      expect(registrationViewModel.isEditingCountMode, false);
      expect(registrationViewModel.editMode, EditModeEnum.ADD);
      expect(
          registrationViewModel.status, RegistrationStatus.HAVE_REGISTRATION);
    });
  });

  testWidgets('initRegistrationInfo for Salmon with empty registration',
      (WidgetTester tester) async {
    await tester
        .pumpWidget(makeTestableWidget(SalmonCullingRegistrationViewModel()));
    var registrationViewModel = Provider.of<SalmonCullingRegistrationViewModel>(
        _childKey.currentContext,
        listen: false);
    registrationViewModel.updateModel(appModel, organizationModel);
    await registrationViewModel.initRegistrationInfo();
    expect(registrationViewModel.registrations.isEmpty, true);
    expect(registrationViewModel.isEditingCountMode, false);
    expect(registrationViewModel.editMode, EditModeEnum.ADD);
    expect(registrationViewModel.status, RegistrationStatus.NO_REGISTRATION);
  });
  testWidgets('initRegistrationInfo for Cleaner Fish',
      (WidgetTester tester) async {
    await tester.pumpWidget(
        makeTestableWidget(CleanerFishCullingRegistrationViewModel()));
    var registrationViewModel =
        Provider.of<CleanerFishCullingRegistrationViewModel>(
            _childKey.currentContext,
            listen: false);
    registrationViewModel.updateModel(appModel, organizationModel);
    await registrationViewModel.initRegistrationInfo();
    expect(registrationViewModel.registrations.isEmpty, true);
    expect(registrationViewModel.isEditingCountMode, false);
    expect(registrationViewModel.editMode, EditModeEnum.ADD);
    expect(registrationViewModel.status, RegistrationStatus.NO_REGISTRATION);
  });
  group('Test culling operations', () {
    setUp(() async {
      final registrations = await repos.fetchByUnit(unit);
      if (registrations.isNotEmpty) {
        await repos.deleteMultiple(registrations);
      }
      await appModel.initialize();
    });
    tearDown(() async {
      final registrations = await repos.fetchByUnit(unit);
      if (registrations.isNotEmpty) {
        await repos.deleteMultiple(registrations);
      }
    });
    testWidgets('storeRegistration for Salmon', (WidgetTester tester) async {
      await tester
          .pumpWidget(makeTestableWidget(SalmonCullingRegistrationViewModel()));
      var registrationViewModel =
          Provider.of<SalmonCullingRegistrationViewModel>(
              _childKey.currentContext,
              listen: false);
      registrationViewModel.updateModel(appModel, organizationModel);
      await TimeZoneService().setup();
      await registrationViewModel.addNewRegistration(1);
      expect(registrationViewModel.registrations.isNotEmpty, true);
      var _registration = registrationViewModel.registrations[0];
      (_registration.item as CullingRegistration).cullings = [
        ...(registration.item as CullingRegistration).cullings
      ];
      expect((_registration.item as CullingRegistration).cullings.isNotEmpty,
          true);
      await registrationViewModel.storeRegistration();
      await new Future.delayed(const Duration(seconds: 1));
      expect(registrationViewModel.registrations.isNotEmpty, true);
      _registration = registrationViewModel.registrations[0];
      expect(_registration.changeStatus, ChangeStatus.Unchanged);
      expect(registrationViewModel.getTotalAmountCount(), 30);
    });

    testWidgets('test removeCount and discardChanges',
        (WidgetTester tester) async {
      await tester
          .pumpWidget(makeTestableWidget(SalmonCullingRegistrationViewModel()));
      var registrationViewModel =
          Provider.of<SalmonCullingRegistrationViewModel>(
              _childKey.currentContext,
              listen: false);
      registrationViewModel.updateModel(appModel, organizationModel);
      await TimeZoneService().setup();
      await registrationViewModel.addNewRegistration(1);
      expect(registrationViewModel.registrations.isNotEmpty, true);
      var _registration = registrationViewModel.registrations[0];
      (_registration.item as CullingRegistration).cullings = [
        ...(registration.item as CullingRegistration).cullings
      ];

      await registrationViewModel.storeRegistration();
      await new Future.delayed(const Duration(seconds: 1));
      _registration = registrationViewModel.registrations[0];
      await registrationViewModel.removeCount(_registration.time, 1, 18);
      _registration = registrationViewModel.registrations[0];
      expect(_registration.changeStatus, ChangeStatus.Changed);
      expect(registrationViewModel.getTotalAmountCount(), 10);
      registrationViewModel.discardChanges();
      expect(registrationViewModel.getTotalAmountCount(), 30);
      expect(_registration.changeStatus, ChangeStatus.Unchanged);
      expect(registrationViewModel.isEditingCountMode, false);
    });

    testWidgets('test culled all and uncheck culled all',
        (WidgetTester tester) async {
      await tester
          .pumpWidget(makeTestableWidget(SalmonCullingRegistrationViewModel()));
      var registrationViewModel =
          Provider.of<SalmonCullingRegistrationViewModel>(
              _childKey.currentContext,
              listen: false);
      registrationViewModel.updateModel(appModel, organizationModel);
      await registrationViewModel.addNewRegistration(1);
      expect(registrationViewModel.allowCulledAll, false);
      var _registration = registrationViewModel.registrations[0];
      (_registration.item as CullingRegistration).cullings = [
        ...(registration.item as CullingRegistration).cullings
      ];
      expect(registrationViewModel.allowCulledAll, false);
      _registration.item.removeItem(18);
      expect(registrationViewModel.allowCulledAll, true);
      registrationViewModel.culledEntireUnit(_registration.time, 1);
      _registration = registrationViewModel.registrations[0];
      expect(
          (_registration.item as CullingRegistration).cullings[0].cullingCount,
          1000);
      expect(
          (_registration.item as CullingRegistration)
              .resultingStock
              .individCount,
          0);
      registrationViewModel.uncheckCulledEntireUnit(_registration.time, 1);
      _registration = registrationViewModel.registrations[0];
      expect(
          (_registration.item as CullingRegistration)
              .resultingStock
              .individCount,
          isNull);
    });
  });
}

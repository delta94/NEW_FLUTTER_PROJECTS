import 'package:control_app/src/app_model.dart';
import 'package:control_app/src/base/base_view_model.dart';
import 'package:control_app/src/database/sqlite_database_helper.dart';
import 'package:control_app/src/models/mortality/mortality.dart';
import 'package:control_app/src/models/mortality/mortality_registration.dart';
import 'package:control_app/src/models/registration.dart';
import 'package:control_app/src/models/site_model.dart';
import 'package:control_app/src/models/species.dart';
import 'package:control_app/src/mortality/view_models/cleaner_fish_mortality_registration_view_model.dart';
import 'package:control_app/src/mortality/view_models/mortality_registration_view_model.dart';
import 'package:control_app/src/mortality/view_models/salmon_mortality_registration_view_model.dart';
import 'package:control_app/src/repositories/db_registration_repository.dart';
import 'package:control_app/src/services/timezone_service.dart';
import 'package:control_app/src/util/constants.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:mockito/mockito.dart';
import 'package:provider/provider.dart';
import 'package:uuid/uuid.dart';

import 'mocks/mock_app_model.dart';
import 'mocks/mock_organization_model.dart';

var unitId = Uuid().v4().toString();
var siteId = Uuid().v4().toString();

void main() async {
  TestWidgetsFlutterBinding.ensureInitialized();
  final AppModel appModel = MockAppModel();
  final DBRegistrationRepository repos =
      DBRegistrationRepository(RegistrationType.Mortality);
  final _childKey = GlobalKey();
  await TimeZoneService().setup();
  MockOrganizationModel organizationModel = MockOrganizationModel();
  Unit unit = Unit.fromJson({'id': unitId, 'name': '12-L'});
  Site site = Site.fromJson({
    'id': siteId,
    'siteName': 'Molkhomen',
    'timeZoneId': 'Europe/Oslo',
    'units': [
      {'id': unitId, 'name': '12-L'}
    ]
  });
  unit.parent = site;
  Registration generateRegistration() {
    var mortalites = List<Mortality>();
    mortalites.add(new Mortality(mortalityCount: 10, mortalityCauseId: 1));
    mortalites.add(new Mortality(mortalityCount: 20, mortalityCauseId: 18));
    mortalites.add(new Mortality(mortalityCount: 30, mortalityCauseId: 20));
    mortalites.add(new Mortality(mortalityCount: 40, mortalityCauseId: 22));
    //var siteId1 = uuid.v4().toString();

    var time =
        TimeZoneService.convertToTimezone(DateTime.now(), site.timeZoneId);
    return new Registration(
        siteId: siteId,
        unitId: unitId,
        speciesId: 1,
        time: time,
        item: MortalityRegistration(
            hasCheckedForMortality: true,
            missedMortalityReasonId: -1,
            mortalities: mortalites),
        changeStatus: ChangeStatus.New);
  }

  var registration = generateRegistration();

  /// This is to mock the result of currentUnit getter function
  when(organizationModel.currentUnit).thenReturn(unit);

  /// This is to mock the result of currentSite getter function
  when(organizationModel.currentSite).thenReturn(site);
  List<Species> species = [Species(speciesId: 1, name: 'Salmon', wrasse: true)];

  when(organizationModel.speciesOfCurrentUnit).thenReturn(species);

  Widget makeTestableWidget(MortalityRegistrationViewModel model) {
    if (model is SalmonMortalityRegistrationViewModel) {
      return ChangeNotifierProvider<SalmonMortalityRegistrationViewModel>(
        create: (_) => SalmonMortalityRegistrationViewModel(),
        child: MaterialApp(key: _childKey, home: Container()),
      );
    } else {
      return ChangeNotifierProvider<CleanerFishMortalityRegistrationViewModel>(
        create: (_) => CleanerFishMortalityRegistrationViewModel(),
        child: MaterialApp(key: _childKey, home: Container()),
      );
    }
  }

  group('Mortality view model test initRegistration and addNewRegistration',
      () {
    setUp(() async {
      print("Setup test initRegistrationInfo");
      await repos.store(registration);
      await appModel.initialize();
    });

    tearDown(() async {
      print("Tear down initRegistrationInfo");
      await repos.delete(registration);
    });
    testWidgets('addNewRegistration function', (WidgetTester tester) async {
      await tester.pumpWidget(
          makeTestableWidget(SalmonMortalityRegistrationViewModel()));
      var registrationViewModel =
          Provider.of<SalmonMortalityRegistrationViewModel>(
              _childKey.currentContext,
              listen: false);
      expect(registrationViewModel, isNot(null));

      registrationViewModel.updateModel(appModel, organizationModel);

      await registrationViewModel.addNewRegistration(1);
      expect(registrationViewModel.newRegistrations.isNotEmpty, true);
      expect(registrationViewModel.newRegistrations.length, 1);
      expect(registrationViewModel.newRegistrations.first.siteId, siteId);
    });

    testWidgets('initRegistrationInfo with existing registration in db',
        (WidgetTester tester) async {
      await tester.pumpWidget(
          makeTestableWidget(SalmonMortalityRegistrationViewModel()));
      var registrationViewModel =
          Provider.of<SalmonMortalityRegistrationViewModel>(
              _childKey.currentContext,
              listen: false);
      expect(registrationViewModel, isNot(null));
      registrationViewModel.updateModel(appModel, organizationModel);
      expect(registrationViewModel.organizationModel.currentUnit.id, unitId);
      await registrationViewModel.initRegistrationInfo();
      expect(registrationViewModel.registrations.isNotEmpty, true);
      expect(registrationViewModel.registrations.length, 1);
      expect(registrationViewModel.registrations.first.siteId,
          registration.siteId);
      expect(registrationViewModel.isEditingCountMode, false);
      expect(registrationViewModel.editMode, EditModeEnum.ADD);
      expect(
          registrationViewModel.status, RegistrationStatus.HAVE_REGISTRATION);
    });
  });

  testWidgets('initRegistrationInfo for Salmon with empty registration',
      (WidgetTester tester) async {
    await tester
        .pumpWidget(makeTestableWidget(SalmonMortalityRegistrationViewModel()));
    var registrationViewModel =
        Provider.of<SalmonMortalityRegistrationViewModel>(
            _childKey.currentContext,
            listen: false);
    registrationViewModel.updateModel(appModel, organizationModel);
    await registrationViewModel.initRegistrationInfo();
    expect(registrationViewModel.registrations.isEmpty, true);
    expect(registrationViewModel.isEditingCountMode, false);
    expect(registrationViewModel.editMode, EditModeEnum.ADD);
    expect(registrationViewModel.status, RegistrationStatus.NO_REGISTRATION);
  });
  testWidgets('initRegistrationInfo for Cleaner Fish with empty species',
      (WidgetTester tester) async {
    await tester.pumpWidget(
        makeTestableWidget(CleanerFishMortalityRegistrationViewModel()));
    var registrationViewModel =
        Provider.of<CleanerFishMortalityRegistrationViewModel>(
            _childKey.currentContext,
            listen: false);
    registrationViewModel.updateModel(appModel, organizationModel);
    await registrationViewModel.initRegistrationInfo();
    expect(registrationViewModel.registrations.isEmpty, true);
    expect(registrationViewModel.isEditingCountMode, false);
    expect(registrationViewModel.editMode, EditModeEnum.ADD);
    expect(registrationViewModel.status, RegistrationStatus.NO_FISH);
  });
  group('Test mortality operations', () {
    setUp(() async {
      await appModel.initialize();
      await SqliteDatabaseHelper.instance.database;
    });
    tearDown(() async {
      final registrations = await repos.fetchByUnit(unit);
      if (registrations.isNotEmpty) {
        await repos.deleteMultiple(registrations);
      }
    });
    testWidgets('storeRegistration for Salmon', (WidgetTester tester) async {
      await tester.pumpWidget(
          makeTestableWidget(SalmonMortalityRegistrationViewModel()));
      var registrationViewModel =
          Provider.of<SalmonMortalityRegistrationViewModel>(
              _childKey.currentContext,
              listen: false);
      registrationViewModel.updateModel(appModel, organizationModel);
      await registrationViewModel.addNewRegistration(1);
      expect(registrationViewModel.newRegistrations.isNotEmpty, true);
      var _registration = registrationViewModel.newRegistrations[0];
      (_registration.item as MortalityRegistration).mortalities = [
        ...(registration.item as MortalityRegistration).mortalities
      ];
      expect(
          (_registration.item as MortalityRegistration).mortalities.isNotEmpty,
          true);
      await registrationViewModel.storeRegistration();
      await new Future.delayed(const Duration(seconds: 1));
      expect(registrationViewModel.registrations.isNotEmpty, true);
      _registration = registrationViewModel.registrations[0];
      expect(_registration.changeStatus, ChangeStatus.Unchanged);
      expect(registrationViewModel.getTotalAmountCount(), 100);
    });

    testWidgets('test removeCount and discardChanges',
        (WidgetTester tester) async {
      await tester.pumpWidget(
          makeTestableWidget(SalmonMortalityRegistrationViewModel()));
      var registrationViewModel =
          Provider.of<SalmonMortalityRegistrationViewModel>(
              _childKey.currentContext,
              listen: false);
      registrationViewModel.updateModel(appModel, organizationModel);
      await TimeZoneService().setup();
      await registrationViewModel.addNewRegistration(1);
      expect(registrationViewModel.newRegistrations.isNotEmpty, true);
      var _registration = registrationViewModel.newRegistrations[0];
      (_registration.item as MortalityRegistration).mortalities = [
        ...(registration.item as MortalityRegistration).mortalities
      ];

      await registrationViewModel.storeRegistration();
      await new Future.delayed(const Duration(seconds: 1));
      _registration = registrationViewModel.registrations[0];
      registrationViewModel.isEditingCountMode = true;
      await registrationViewModel.removeCount(
          _registration.time, 1, _registration.item.countObjAt(3));
      await new Future.delayed(const Duration(seconds: 1));
      _registration = registrationViewModel.registrations[0];
      expect(_registration.changeStatus, ChangeStatus.Changed);
      expect(registrationViewModel.getTotalAmountCount(), 60);
      registrationViewModel.discardChanges();
      expect(registrationViewModel.getTotalAmountCount(), 60);
      expect(registrationViewModel.isEditingCountMode, false);
    });

    testWidgets('test confirm and unconfirm', (WidgetTester tester) async {
      await tester.pumpWidget(
          makeTestableWidget(SalmonMortalityRegistrationViewModel()));
      var registrationViewModel =
          Provider.of<SalmonMortalityRegistrationViewModel>(
              _childKey.currentContext,
              listen: false);
      registrationViewModel.updateModel(appModel, organizationModel);
      await registrationViewModel.setConfirmNothingReport();
      expect(registrationViewModel.registrations.isNotEmpty, true);
      var _registration = registrationViewModel.registrations[0];
      expect((_registration.item as MortalityRegistration).mortalities.isEmpty,
          true);
      expect(registrationViewModel.status,
          RegistrationStatus.CONFIRMED_NO_REGISTRATION);
      expect(registrationViewModel.hasConfirmedNoMortality(), true);
      await registrationViewModel.revertConfirmedNoRegistration();
      await new Future.delayed(const Duration(seconds: 1));
      expect(registrationViewModel.registrations.isEmpty, true);
      expect(registrationViewModel.status, RegistrationStatus.NO_REGISTRATION);
    });

    testWidgets('test missed reason and revert', (WidgetTester tester) async {
      await tester.pumpWidget(
          makeTestableWidget(SalmonMortalityRegistrationViewModel()));
      var registrationViewModel =
          Provider.of<SalmonMortalityRegistrationViewModel>(
              _childKey.currentContext,
              listen: false);
      registrationViewModel.updateModel(appModel, organizationModel);
      await registrationViewModel.confirmMissedReason(10);
      await new Future.delayed(const Duration(seconds: 2));
      expect(registrationViewModel.registrations.isNotEmpty, true);
      var _registration = registrationViewModel.registrations[0];
      expect((_registration.item as MortalityRegistration).mortalities.isEmpty,
          true);
      expect(
          (_registration.item as MortalityRegistration).missedMortalityReasonId,
          10);
      expect(
          registrationViewModel.status, RegistrationStatus.MISSED_REGISTRATION);
      expect(registrationViewModel.checkConfirmedMissedReason(), 10);
      await registrationViewModel.revertMissedReason();
      await new Future.delayed(const Duration(seconds: 1));
      expect(registrationViewModel.registrations.isEmpty, true);
      expect(registrationViewModel.status, RegistrationStatus.NO_REGISTRATION);
    });
  });

  group('Test sorting', () {
    setUp(() async {
      var registration1 = generateRegistration();
      var registration2 = generateRegistration();
      registration2.time = registration2.time.add(new Duration(hours: 1));
      await repos.store(registration2);
      await repos.store(registration1);
      print(registration1.rowId);
      print(registration2.rowId);

      await appModel.initialize();
    });
    tearDown(() async {
      final registrations = await repos.fetchByUnit(unit);
      if (registrations.isNotEmpty) {
        print("Teardown delete registrations");
        await repos.deleteMultiple(registrations);
      }
    });

    testWidgets('sort', (WidgetTester tester) async {
      await tester.pumpWidget(
          makeTestableWidget(SalmonMortalityRegistrationViewModel()));
      var registrationViewModel =
          Provider.of<SalmonMortalityRegistrationViewModel>(
              _childKey.currentContext,
              listen: false);
      registrationViewModel.updateModel(appModel, organizationModel);
      await registrationViewModel.initRegistrationInfo();
      expect(registrationViewModel.registrations.isNotEmpty, true);
      expect(registrationViewModel.registrations.length, 2);
      var registration1 = registrationViewModel.registrations[0];
      var registration2 = registrationViewModel.registrations[1];
      expect(registration1.time.compareTo(registration2.time), lessThan(0));
    });
  });
}

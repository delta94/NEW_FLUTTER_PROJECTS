const String APP_ID = "ca-app-pub-6420987903580707~2140183927";
const String BANNER_ID = "ca-app-pub-6420987903580707/5763734161";
const String INTERSTITIAL_ID = "ca-app-pub-6420987903580707/3261693902";

const String TITLE = 'Always - Bon Jovi';
const String VIDEO_URL = '1983799995085892';
const String LYRIC = "\nDo you ever feel like a plastic bag\n" +
    "Drifting thought the wind\n" +
    "Wanting to start again\n" +
    "Do you ever feel, feel so paper thin\n" +
    "Like a house of cards\n" +
    "One blow from caving in\n" +
    "Do you ever feel already buried deep\n" +
    "Six feet under scream\n" +
    "But no one seems to hear a thing\n" +
    "Do you know that there's still a chance for you\n" +
    "'Cause there's a spark in you\n" +
    "You just gotta ignite the light\n" +
    "And let it shine\n" +
    "\n" +
    "Just own the night\n" +
    "Like the Fourth of July\n" +
    "'Cause baby you're a firework\n" +
    "Come on show 'em what your worth\n" +
    "Make 'em go \"Oh, oh, oh!\"\n" +
    "As you shoot across the sky-y-y\n" +
    "Baby you're a firework\n" +
    "Come on let your colors burst\n" +
    "Make 'em go \"Oh, oh, oh!\"\n" +
    "You're gonna leave 'em fallin' down down down\n" +
    "You don't have to feel like a waste of space\n" +
    "You're original, cannot be replaced\n" +
    "If you only knew what the future holds\n" +
    "After a hurricane comes a rainbow\n" +
    "Maybe a reason why all the doors are closed\n" +
    "So you can open one that leads you to the perfect road\n" +
    "Like a lightning bolt, your heart will glow\n" +
    "And when it's time, you'll know\n" +
    "You just gotta ignite the light\n" +
    "And let it shine\n" +
    "\n" +
    "Just own the night\n" +
    "Like the Fourth of July\n" +
    "'Cause baby you're a firework\n" +
    "Come on show 'em what your worth\n" +
    "Make 'em go \"Oh, oh, oh!\"\n" +
    "As you shoot across the sky-y-y\n" +
    "Baby you\'re a firework\n" +
    "Come on let your colors burst\n" +
    "Make \'em go \"Oh, oh, oh!\"\n" +
    "You're gonna leave \'em fallin' down down down\n" +
    "Boom, boom, boom\n" +
    "Even brighter than the moon, moon, moon\n" +
    "It\'s always been inside of you, you, you\n" +
    "And now it's time to let it through\n" +
    "'Cause baby you're a firework\n" +
    "Come on show 'em what your worth\n" +
    "Make \'em go \"Oh, oh, oh!\"\n" +
    "As you shoot across the sky-y-y\n" +
    "Baby you\'re a firework\n" +
    "Come on let your colors burst\n" +
    "Make \'em go \"Oh, oh, oh!\"\n" +
    "You\'re gonna leave \'em fallin' down down down\n" +
    "Boom, boom, boom\n" +
    "Even brighter than the moon, moon, moon\n" +
    "Boom, boom, boom\n" +
    "Even brighter than the moon, moon, moon\n" +
    "\n";
